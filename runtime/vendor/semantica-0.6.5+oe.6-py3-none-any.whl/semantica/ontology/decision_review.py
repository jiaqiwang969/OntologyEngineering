"""Evaluate a project ABox against one exact semantic package decision gate.

This is a composite of :class:`SemanticRuntime` primitives, not a second RDF
backend.  The package owns the domain semantics in its named SPARQL and SHACL
assets.  A clear report means only that this bounded semantic projection has
no recorded finding; it is never physical, regulatory, or product acceptance.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Mapping, Optional, Tuple, Union
from urllib.parse import urlsplit

from .lifecycle import canonical_json, is_sha256, sha256_text, utc_now
from .runtime import RDFTermDTO, SemanticInputError, SemanticRuntime


GATE_CONTRACT = "semantica.ontology.decision-review/v1"


@dataclass(frozen=True)
class DecisionReviewDTO:
    """Content-bound semantic review of one source-scoped project projection."""

    status: str
    package_id: str
    package_version: str
    package_digest: str
    query_asset_id: str
    query_asset_sha256: str
    shape_asset_id: str
    shape_asset_sha256: str
    evidence_id: str
    evidence_uri: str
    evidence_sha256: str
    evidence_format: str
    evidence_captured_at: str
    input_dataset_sha256: str
    evaluated_dataset_sha256: str
    scope_id: str
    focus_iri: str
    focus_type_iri: str
    focus_present: bool
    focus_type_present: bool
    focus_instance_count: int
    input_quad_count: int
    shape_conforms: bool
    findings_json: Tuple[str, ...]
    violations_json: Tuple[str, ...]
    created_at: str
    registry_package_sha256: Optional[str] = None
    contract: str = GATE_CONTRACT

    def __post_init__(self) -> None:
        if self.status not in {"clear", "blocked"}:
            raise ValueError("decision review status must be clear or blocked")
        for label, value in (
            ("package_digest", self.package_digest),
            ("query_asset_sha256", self.query_asset_sha256),
            ("shape_asset_sha256", self.shape_asset_sha256),
            ("evidence_sha256", self.evidence_sha256),
            ("input_dataset_sha256", self.input_dataset_sha256),
            ("evaluated_dataset_sha256", self.evaluated_dataset_sha256),
        ):
            if not is_sha256(value):
                raise ValueError("{} must be a lowercase SHA-256 digest".format(label))
        if self.registry_package_sha256 is not None and not is_sha256(
            self.registry_package_sha256
        ):
            raise ValueError("registry_package_sha256 must be a SHA-256 digest")
        if (
            self.input_quad_count < 0
            or self.focus_instance_count < 0
            or self.contract != GATE_CONTRACT
        ):
            raise ValueError("invalid decision review count or contract")
        if self.status == "clear" and (
            not self.focus_present
            or not self.focus_type_present
            or self.focus_instance_count != 1
            or self.input_quad_count == 0
            or not self.shape_conforms
            or self.findings_json
            or self.violations_json
        ):
            raise ValueError("clear review cannot have a missing focus or findings")

    def _content(self) -> dict[str, Any]:
        return {
            "contract": self.contract,
            "status": self.status,
            "package": {
                "id": self.package_id,
                "version": self.package_version,
                "digest": self.package_digest,
                "origin": (
                    "promoted_registry"
                    if self.registry_package_sha256 is not None
                    else "authoring_manifest"
                ),
                "registry_package_sha256": self.registry_package_sha256,
                "query_asset_id": self.query_asset_id,
                "query_asset_sha256": self.query_asset_sha256,
                "shape_asset_id": self.shape_asset_id,
                "shape_asset_sha256": self.shape_asset_sha256,
            },
            "evidence": {
                "id": self.evidence_id,
                "uri": self.evidence_uri,
                "sha256": self.evidence_sha256,
                "format": self.evidence_format,
                "captured_at": self.evidence_captured_at,
                "input_dataset_sha256": self.input_dataset_sha256,
                "evaluated_dataset_sha256": self.evaluated_dataset_sha256,
                "input_quad_count": self.input_quad_count,
            },
            "scope_id": self.scope_id,
            "focus_iri": self.focus_iri,
            "focus_type_iri": self.focus_type_iri,
            "focus_present": self.focus_present,
            "focus_type_present": self.focus_type_present,
            "focus_instance_count": self.focus_instance_count,
            "shape_conforms": self.shape_conforms,
            "findings": [json.loads(item) for item in self.findings_json],
            "violations": [json.loads(item) for item in self.violations_json],
            "created_at": self.created_at,
            "meaning": "semantic-record-consistency-only; no physical acceptance",
        }

    @property
    def report_sha256(self) -> str:
        return sha256_text(canonical_json(self._content()))

    def as_dict(self) -> dict[str, Any]:
        return {**self._content(), "report_sha256": self.report_sha256}


class DecisionReviewRunner:
    """Run named package checks against a fresh, hash-verified project ABox."""

    def evaluate_manifest(
        self,
        manifest: Union[Mapping[str, Any], str, Path],
        *,
        evidence: bytes,
        evidence_sha256: str,
        evidence_format: str,
        evidence_id: str,
        evidence_uri: str,
        evidence_captured_at: str,
        scope_id: str,
        focus_iri: str,
        focus_type_iri: str,
        query_asset_id: str,
        shape_asset_id: str,
        expected_package_digest: str,
        base_path: Optional[Union[str, Path]] = None,
        created_at: Optional[str] = None,
    ) -> DecisionReviewDTO:
        """Review an exact manifest; intended for authoring and controlled tests.

        Production callers should resolve an immutable promoted package through
        :meth:`evaluate_registry`.  Input bytes, package digest and named assets
        are checked before a clear status can be returned.
        """

        return self._evaluate(
            manifest,
            evidence=evidence,
            evidence_sha256=evidence_sha256,
            evidence_format=evidence_format,
            evidence_id=evidence_id,
            evidence_uri=evidence_uri,
            evidence_captured_at=evidence_captured_at,
            scope_id=scope_id,
            focus_iri=focus_iri,
            focus_type_iri=focus_type_iri,
            query_asset_id=query_asset_id,
            shape_asset_id=shape_asset_id,
            expected_package_digest=expected_package_digest,
            base_path=base_path,
            created_at=created_at,
        )

    def evaluate_registry(
        self,
        registry: Any,
        package_id: str,
        *,
        expected_package_sha256: str,
        version: Optional[str] = None,
        evidence: bytes,
        evidence_sha256: str,
        evidence_format: str,
        evidence_id: str,
        evidence_uri: str,
        evidence_captured_at: str,
        scope_id: str,
        focus_iri: str,
        focus_type_iri: str,
        query_asset_id: str,
        shape_asset_id: str,
        created_at: Optional[str] = None,
    ) -> DecisionReviewDTO:
        """Review only an exact, promoted Semantica industry package."""

        from .refinery import IndustryOntologyRegistry

        if not isinstance(registry, IndustryOntologyRegistry):
            raise TypeError("registry must be an IndustryOntologyRegistry")
        if not is_sha256(expected_package_sha256):
            raise SemanticInputError("expected_package_sha256 must be a SHA-256 digest")
        descriptor = registry.resolve_package(package_id, version=version)
        if descriptor.package_sha256 != expected_package_sha256:
            raise SemanticInputError(
                "promoted package identity differs from the binding"
            )
        manifest = registry.execution_manifest(
            descriptor.package_id, version=descriptor.version
        )
        review = self._evaluate(
            manifest,
            evidence=evidence,
            evidence_sha256=evidence_sha256,
            evidence_format=evidence_format,
            evidence_id=evidence_id,
            evidence_uri=evidence_uri,
            evidence_captured_at=evidence_captured_at,
            scope_id=scope_id,
            focus_iri=focus_iri,
            focus_type_iri=focus_type_iri,
            query_asset_id=query_asset_id,
            shape_asset_id=shape_asset_id,
            expected_package_digest=None,
            registry_package_sha256=descriptor.package_sha256,
            created_at=created_at,
        )
        if (
            review.package_id != descriptor.package_id
            or review.package_version != descriptor.version
        ):
            raise SemanticInputError(
                "executed package differs from promoted descriptor"
            )
        return review

    def _evaluate(
        self,
        manifest: Union[Mapping[str, Any], str, Path],
        *,
        evidence: bytes,
        evidence_sha256: str,
        evidence_format: str,
        evidence_id: str,
        evidence_uri: str,
        evidence_captured_at: str,
        scope_id: str,
        focus_iri: str,
        focus_type_iri: str,
        query_asset_id: str,
        shape_asset_id: str,
        expected_package_digest: Optional[str],
        base_path: Optional[Union[str, Path]] = None,
        registry_package_sha256: Optional[str] = None,
        created_at: Optional[str] = None,
    ) -> DecisionReviewDTO:
        if not isinstance(evidence, bytes):
            raise SemanticInputError("evidence must be exact RDF bytes")
        if not is_sha256(evidence_sha256):
            raise SemanticInputError(
                "evidence_sha256 must be a lowercase SHA-256 digest"
            )
        if hashlib.sha256(evidence).hexdigest() != evidence_sha256:
            raise SemanticInputError("project evidence SHA-256 mismatch")
        if expected_package_digest is not None and not is_sha256(
            expected_package_digest
        ):
            raise SemanticInputError("expected_package_digest must be a SHA-256 digest")
        for label, value in (
            ("evidence_format", evidence_format),
            ("evidence_id", evidence_id),
            ("evidence_uri", evidence_uri),
            ("evidence_captured_at", evidence_captured_at),
            ("scope_id", scope_id),
            ("query_asset_id", query_asset_id),
            ("shape_asset_id", shape_asset_id),
        ):
            if not isinstance(value, str) or not value.strip():
                raise SemanticInputError("{} must be non-empty".format(label))
        for label, iri in (("focus_iri", focus_iri), ("focus_type_iri", focus_type_iri)):
            if (
                not isinstance(iri, str)
                or not urlsplit(iri).scheme
                or any(char.isspace() for char in iri)
            ):
                raise SemanticInputError("{} must be an absolute IRI".format(label))
        try:
            parsed_time = datetime.fromisoformat(
                evidence_captured_at.replace("Z", "+00:00")
            )
        except ValueError as exc:
            raise SemanticInputError(
                "evidence_captured_at must be an ISO timestamp"
            ) from exc
        if parsed_time.tzinfo is None or parsed_time.utcoffset() is None:
            raise SemanticInputError("evidence_captured_at must include a timezone")

        runtime = SemanticRuntime(
            profile="ontology-runtime", backend="rdflib", cache_queries=False
        )
        runtime.load(evidence, format=evidence_format)
        input_snapshot = runtime.snapshot()
        focus_present = runtime.ask(
            "ASK WHERE { ?focus ?predicate ?object }",
            bindings={"focus": RDFTermDTO.iri(focus_iri)},
        ).boolean
        focus_type_present = runtime.ask(
            "ASK WHERE { ?focus a ?focus_type }",
            bindings={
                "focus": RDFTermDTO.iri(focus_iri),
                "focus_type": RDFTermDTO.iri(focus_type_iri),
            },
        ).boolean
        focus_instances = runtime.select(
            "SELECT DISTINCT ?instance WHERE { ?instance a ?focus_type }",
            bindings={"focus_type": RDFTermDTO.iri(focus_type_iri)},
            use_cache=False,
        ).rows
        focus_instance_count = len(focus_instances)
        loaded = runtime.load_package(manifest, base_path=base_path)
        if (
            expected_package_digest is not None
            and loaded.identity.digest != expected_package_digest
        ):
            raise SemanticInputError(
                "semantic package digest differs from the bound package"
            )
        if any(
            asset.loaded_into_dataset and asset.role != "ontology"
            for asset in loaded.assets
        ):
            raise SemanticInputError(
                "project review package cannot load instance or case data into the dataset"
            )
        query_asset = runtime.package_asset(
            loaded.identity.package_id, loaded.identity.version, query_asset_id
        )
        shape_asset = runtime.package_asset(
            loaded.identity.package_id, loaded.identity.version, shape_asset_id
        )
        if query_asset.role != "sparql" or query_asset.loaded_into_dataset:
            raise SemanticInputError(
                "decision query asset must be an unloaded SPARQL asset"
            )
        if (
            shape_asset.role not in {"shacl", "shapes"}
            or shape_asset.loaded_into_dataset
        ):
            raise SemanticInputError(
                "decision shape asset must be an unloaded SHACL asset"
            )

        query = runtime.select(query_asset.text(), use_cache=False)
        if "finding" not in query.variables:
            raise SemanticInputError("decision query must select a finding variable")
        validation = runtime.validate(
            shape_asset.content,
            shapes_format=shape_asset.format or "turtle",
            advanced=True,
        )
        evaluated_snapshot = runtime.snapshot()

        findings = []
        if input_snapshot.quad_count == 0:
            findings.append(
                canonical_json({"finding": "input:empty-abox", "source": "runtime"})
            )
        if not focus_present:
            findings.append(
                canonical_json({"finding": "input:focus-absent", "source": "runtime"})
            )
        if not focus_type_present:
            findings.append(
                canonical_json(
                    {"finding": "input:focus-type-mismatch", "source": "runtime"}
                )
            )
        if focus_instance_count != 1:
            findings.append(
                canonical_json(
                    {"finding": "input:focus-not-singleton", "source": "runtime"}
                )
            )
        for row in query.rows:
            if "finding" not in row or not row["finding"].value.strip():
                raise SemanticInputError("decision query returned an unbound finding")
            findings.append(
                canonical_json(
                    {
                        "finding": row["finding"].value,
                        "source": "package-query",
                        "bindings": {
                            name: term.as_dict() for name, term in row.items()
                        },
                    }
                )
            )
        violations = tuple(
            sorted(
                canonical_json(
                    {
                        "focus": item.focus,
                        "path": item.path,
                        "source_constraint": item.source_constraint,
                        "severity": item.severity,
                        "message": item.message,
                    }
                )
                for item in validation.violations
            )
        )
        findings_tuple = tuple(sorted(findings))
        return DecisionReviewDTO(
            status="clear" if not findings_tuple and validation.conforms else "blocked",
            package_id=loaded.identity.package_id,
            package_version=loaded.identity.version,
            package_digest=loaded.identity.digest,
            query_asset_id=query_asset_id,
            query_asset_sha256=query_asset.sha256,
            shape_asset_id=shape_asset_id,
            shape_asset_sha256=shape_asset.sha256,
            evidence_id=evidence_id,
            evidence_uri=evidence_uri,
            evidence_sha256=evidence_sha256,
            evidence_format=evidence_format,
            evidence_captured_at=evidence_captured_at,
            input_dataset_sha256=input_snapshot.dataset_sha256,
            evaluated_dataset_sha256=evaluated_snapshot.dataset_sha256,
            scope_id=scope_id,
            focus_iri=focus_iri,
            focus_type_iri=focus_type_iri,
            focus_present=focus_present,
            focus_type_present=focus_type_present,
            focus_instance_count=focus_instance_count,
            input_quad_count=input_snapshot.quad_count,
            shape_conforms=validation.conforms,
            findings_json=findings_tuple,
            violations_json=violations,
            created_at=created_at or utc_now(),
            registry_package_sha256=registry_package_sha256,
        )


__all__ = ["GATE_CONTRACT", "DecisionReviewDTO", "DecisionReviewRunner"]
