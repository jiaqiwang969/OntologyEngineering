"""Host-local safety boundary for one Autodesk Fusion MCP writer.

The guard deliberately runs on the same macOS execution node as Fusion.  It
binds a proxy process to the Fusion process that owns the loopback MCP listener,
holds a cross-process writer lease for that PID while bootstrapping or forwarding
an upstream request, performs a shallow Peekaboo window census before forwarding,
serializes all upstream requests, and leaves a PID/libproc-start-token-bound
retirement marker after any upstream transport exception.

It never opens a document, changes Fusion UI state, or forwards a network port.
The normal writer always requires a clean startup.  A separate owner-only,
one-shot receipt can narrowly authorize one exact request against one exact
pre-existing modified-document window without weakening that default.
"""

from __future__ import annotations

import ctypes
import fcntl
import hashlib
import json
import math
import os
import plistlib
import pwd
import re
import stat
import struct
import subprocess
import sys
import tempfile
import time
import uuid
import zlib
from collections.abc import Awaitable, Callable, Collection
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol, Self, TypeVar

import anyio

from .health_attestation import (
    HEALTH_ARGUMENTS_SHA256,
    HEALTH_CHALLENGE_SCHEMA,
    HEALTH_RECEIPT_SCHEMA,
    HEALTH_TOOL,
    HEALTH_USED_SCHEMA,
    HealthAttestationError,
    canonical_bytes as health_canonical_bytes,
    is_sha256,
    read_owner_only_json,
    sha256_hex,
)

DEFAULT_UPSTREAM = "http://127.0.0.1:27182/mcp"
FUSION_EXECUTABLE_SUFFIX = "/Autodesk Fusion.app/Contents/MacOS/Autodesk Fusion"
_KNOWN_WHITE_AUXILIARY_TITLE = "正在加载其他模块 - Autodesk Fusion"
_KNOWN_WHITE_AUXILIARY_SIZE = (860.0, 536.0)
_KNOWN_WHITE_AUXILIARY_CAPTURE_SIZES = frozenset(
    {(860, 536), (1720, 1072)}
)
_AUXILIARY_STABILITY_DELAY_SECONDS = 0.5
_MAX_SCREENSHOT_BYTES = 16 * 1024 * 1024
_MAX_SCREENSHOT_PIXELS = 8_000_000
_MIN_SCREENSHOT_DIMENSION = 64
_NEAR_WHITE_CHANNEL_FLOOR = 248
_NEAR_WHITE_FRACTION_FLOOR = 1.0
_WHITE_MEAN_FLOOR = 250.0
_WHITE_STANDARD_DEVIATION_CEILING = 8.0
_OPAQUE_FRACTION_FLOOR = 1.0
_TRANSPARENT_ALPHA_CEILING = 7
_TRANSPARENT_FRACTION_FLOOR = 1.0
_PRIMARY_FUSION_WINDOW_TITLE_PATTERN = re.compile(
    r"^.+\s+-\s+Autodesk Fusion(?:\s+\([^()\r\n]+\))?$",
    re.IGNORECASE,
)
_UNTITLED_DOCUMENT_BASE_NAMES = frozenset(
    {
        "untitled",
        "无标题",
        "未命名",
        "sans titre",
        "sin título",
        "sin titulo",
        "senza titolo",
        "unbenannt",
        "sem título",
        "sem titulo",
        "名称未設定",
        "タイトルなし",
        "제목 없음",
    }
)
_UNTITLED_ALLOWED_REQUEST_ROLES = frozenset(
    {
        "transport-bootstrap",
        "read-only",
        "preservation-inspect",
        "preservation-destination-preflight",
        "preservation-save-as",
        "preservation-readback",
    }
)
_PEEKABOO_CODESIGN_IDENTIFIER = "boo.peekaboo.peekaboo"
_PEEKABOO_CODESIGN_TEAM = "Y5PE65HELJ"
_PEEKABOO_LOCAL_ONDEMAND_BUILD = "3.2.1 (3.2.1)"
_PEEKABOO_LOCAL_ONDEMAND_OPERATIONS = frozenset(
    {"permissionsStatus", "listApplications", "listWindows", "captureWindow"}
)
_CODESIGN_EXECUTABLE = Path("/usr/bin/codesign")
DELIVERY_PROBE_ID_PREFIX = "fusion-mcp-cell-delivery:"
DARWIN_PROCESS_START_TOKEN_SCHEMA = "darwin-proc-bsdinfo-v1"
_DARWIN_BOOT_SESSION_SYSCTL = b"kern.bootsessionuuid"
_PROC_PIDTBSDINFO = 3
_PROC_PIDPATHINFO_MAXSIZE = 4096
_CTL_KERN = 1
_KERN_ARGMAX = 8
_KERN_PROCARGS2 = 49
_LSOF_EXECUTABLE = Path("/usr/sbin/lsof")
_PROCESS_START_TOKEN_PATTERN = re.compile(
    rf"^{DARWIN_PROCESS_START_TOKEN_SCHEMA}:"
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-"
    r"[0-9a-f]{4}-[0-9a-f]{12}:[1-9][0-9]*:[0-9]{6}$"
)
_BLOCKING_TITLE_PARTS = (
    "正在加载",
    "加载中",
    "正在准备",
    "正在保存",
    "另存为",
    "保存为",
    "安全警告",
    "安全验证",
    "恢复文档",
    "恢复文件",
    "文档恢复",
    "正在恢复",
    "服务器警告",
    "服务器验证警告",
    "loading...",
    "loading…",
    "saving...",
    "saving…",
    "recovery documents",
    "document recovery",
    "security warning",
    "security verification",
    "server warning",
)
_BLOCKING_TITLE_EXACT = frozenset(
    {
        "加载",
        "保存",
        "安全",
        "恢复",
        "loading",
        "save",
        "save as",
        "saving",
        "security",
        "recovery",
        "recovering",
    }
)
_BLOCKING_TITLE_PREFIXES = (
    "加载",
    "保存",
    "另存为",
    "安全",
    "恢复",
    "save ",
    "save-",
    "save:",
    "save as ",
    "saving ",
    "security ",
    "security:",
    "loading ",
    "loading:",
    "preparing ",
    "recovery ",
    "recovery:",
    "recovering ",
)
_DIRTY_RECOVERY_RECEIPT_SCHEMA = "fusion-mcp.dirty-recovery-authorization.v2"
_DIRTY_RECOVERY_USED_SCHEMA = "fusion-mcp.dirty-recovery-used.v2"
_MAX_DIRTY_RECOVERY_RECEIPT_BYTES = 16 * 1024
_SHA256_PATTERN = re.compile(r"[0-9a-f]{64}")
_EMPTY_ARGUMENTS_SHA256 = hashlib.sha256(b"{}").hexdigest()
_T = TypeVar("_T")


class FusionRuntimeGuardError(RuntimeError):
    """The execution node cannot safely forward a Fusion MCP request."""


class FusionRuntimeRetiredError(FusionRuntimeGuardError):
    """The bound Fusion PID was retired after an upstream runtime failure."""


class CommandRunner(Protocol):
    def __call__(
        self, command: list[str], *, timeout: float
    ) -> subprocess.CompletedProcess[str]: ...


def _default_runner(
    command: list[str], *, timeout: float
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        text=True,
        capture_output=True,
        check=False,
        timeout=timeout,
    )


def _require_success(completed: subprocess.CompletedProcess[str], label: str) -> str:
    if completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip()
        raise FusionRuntimeGuardError(f"{label} failed: {detail or 'no output'}")
    return completed.stdout.strip()


def _parse_json_output(
    completed: subprocess.CompletedProcess[str], label: str
) -> dict[str, Any]:
    raw = _require_success(completed, label)
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise FusionRuntimeGuardError(f"{label} returned invalid JSON") from exc
    if not isinstance(payload, dict) or payload.get("success") is not True:
        raise FusionRuntimeGuardError(f"{label} reported failure")
    return payload


def _write_all(descriptor: int, payload: bytes) -> None:
    view = memoryview(payload)
    while view:
        written = os.write(descriptor, view)
        if written <= 0:
            raise OSError("marker write made no progress")
        view = view[written:]


def _remaining_timeout(
    deadline: float | None,
    maximum_seconds: float,
    label: str,
) -> float:
    """Return one subprocess/async budget clipped to a shared deadline."""
    if deadline is None:
        return maximum_seconds
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TimeoutError(f"{label} exceeded its shared deadline")
    return min(maximum_seconds, remaining)


def _require_deadline(deadline: float | None, label: str) -> None:
    if deadline is not None and deadline - time.monotonic() <= 0:
        raise TimeoutError(f"{label} exceeded its shared deadline")


def _window_id(row: object) -> int | None:
    if not isinstance(row, dict):
        return None
    value = row.get("windowID")
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        return None
    return value


def _window_bounds(row: object) -> tuple[float, float, float, float] | None:
    if not isinstance(row, dict):
        return None
    raw = row.get("bounds")
    values: tuple[object, object, object, object] | None = None
    if (
        isinstance(raw, list)
        and len(raw) == 2
        and all(isinstance(pair, list) and len(pair) == 2 for pair in raw)
    ):
        values = (raw[0][0], raw[0][1], raw[1][0], raw[1][1])
    elif isinstance(raw, dict):
        values = (
            raw.get("x"),
            raw.get("y"),
            raw.get("width"),
            raw.get("height"),
        )
    if values is None:
        return None
    if any(
        isinstance(value, bool) or not isinstance(value, int | float)
        for value in values
    ):
        return None
    normalized = tuple(float(value) for value in values)
    if not all(math.isfinite(value) for value in normalized):
        return None
    if normalized[2] <= 0 or normalized[3] <= 0:
        return None
    return normalized


def _paeth_predictor(left: int, above: int, upper_left: int) -> int:
    estimate = left + above - upper_left
    left_distance = abs(estimate - left)
    above_distance = abs(estimate - above)
    upper_left_distance = abs(estimate - upper_left)
    if left_distance <= above_distance and left_distance <= upper_left_distance:
        return left
    if above_distance <= upper_left_distance:
        return above
    return upper_left


def _png_blank_auxiliary_evidence(
    payload: bytes,
) -> dict[str, int | float | str]:
    """Prove one bounded auxiliary capture is opaque white or transparent."""
    if not payload.startswith(b"\x89PNG\r\n\x1a\n"):
        raise FusionRuntimeGuardError("Peekaboo auxiliary screenshot is not a PNG")
    if len(payload) > _MAX_SCREENSHOT_BYTES:
        raise FusionRuntimeGuardError("Peekaboo auxiliary screenshot is too large")

    offset = 8
    header: bytes | None = None
    compressed = bytearray()
    saw_end = False
    while offset < len(payload):
        if len(payload) - offset < 12:
            raise FusionRuntimeGuardError(
                "Peekaboo auxiliary screenshot PNG is truncated"
            )
        length = struct.unpack(">I", payload[offset : offset + 4])[0]
        chunk_type = payload[offset + 4 : offset + 8]
        chunk_end = offset + 12 + length
        if length > _MAX_SCREENSHOT_BYTES or chunk_end > len(payload):
            raise FusionRuntimeGuardError(
                "Peekaboo auxiliary screenshot PNG is invalid"
            )
        chunk = payload[offset + 8 : offset + 8 + length]
        expected_crc = struct.unpack(">I", payload[offset + 8 + length : chunk_end])[0]
        observed_crc = zlib.crc32(chunk_type + chunk) & 0xFFFFFFFF
        if observed_crc != expected_crc:
            raise FusionRuntimeGuardError(
                "Peekaboo auxiliary screenshot PNG has an invalid checksum"
            )
        if chunk_type == b"IHDR":
            if header is not None or length != 13:
                raise FusionRuntimeGuardError(
                    "Peekaboo auxiliary screenshot PNG header is invalid"
                )
            header = chunk
        elif chunk_type == b"IDAT":
            compressed.extend(chunk)
            if len(compressed) > _MAX_SCREENSHOT_BYTES:
                raise FusionRuntimeGuardError(
                    "Peekaboo auxiliary screenshot PNG data is too large"
                )
        elif chunk_type == b"IEND":
            if length != 0:
                raise FusionRuntimeGuardError(
                    "Peekaboo auxiliary screenshot PNG terminator is invalid"
                )
            saw_end = True
            offset = chunk_end
            break
        offset = chunk_end
    if header is None or not compressed or not saw_end or offset != len(payload):
        raise FusionRuntimeGuardError("Peekaboo auxiliary screenshot PNG is incomplete")

    width, height, depth, color_type, compression, filter_method, interlace = (
        struct.unpack(">IIBBBBB", header)
    )
    channels_by_color_type = {0: 1, 2: 3, 4: 2, 6: 4}
    channels = channels_by_color_type.get(color_type)
    pixel_count = width * height
    if (
        channels is None
        or depth != 8
        or compression != 0
        or filter_method != 0
        or interlace != 0
        or width < _MIN_SCREENSHOT_DIMENSION
        or height < _MIN_SCREENSHOT_DIMENSION
        or pixel_count > _MAX_SCREENSHOT_PIXELS
    ):
        raise FusionRuntimeGuardError(
            "Peekaboo auxiliary screenshot PNG format is unsupported or undersized"
        )
    if (width, height) not in _KNOWN_WHITE_AUXILIARY_CAPTURE_SIZES:
        raise FusionRuntimeGuardError(
            "Peekaboo auxiliary screenshot dimensions do not match the known window"
        )

    stride = width * channels
    expected_raw_size = height * (stride + 1)
    decompressor = zlib.decompressobj()
    try:
        raw = decompressor.decompress(bytes(compressed), expected_raw_size + 1)
    except zlib.error as exc:
        raise FusionRuntimeGuardError(
            "Peekaboo auxiliary screenshot PNG data is invalid"
        ) from exc
    if (
        len(raw) != expected_raw_size
        or not decompressor.eof
        or decompressor.unconsumed_tail
        or decompressor.unused_data
    ):
        raise FusionRuntimeGuardError(
            "Peekaboo auxiliary screenshot PNG dimensions do not match its data"
        )

    previous = bytearray(stride)
    raw_offset = 0
    channel_sums = [0, 0, 0]
    channel_square_sums = [0, 0, 0]
    near_white_count = 0
    opaque_count = 0
    transparent_count = 0
    for _ in range(height):
        filter_type = raw[raw_offset]
        row = bytearray(raw[raw_offset + 1 : raw_offset + stride + 1])
        raw_offset += stride + 1
        if filter_type not in {0, 1, 2, 3, 4}:
            raise FusionRuntimeGuardError(
                "Peekaboo auxiliary screenshot PNG uses an invalid row filter"
            )
        for index, value in enumerate(row):
            left = row[index - channels] if index >= channels else 0
            above = previous[index]
            upper_left = previous[index - channels] if index >= channels else 0
            if filter_type == 1:
                predictor = left
            elif filter_type == 2:
                predictor = above
            elif filter_type == 3:
                predictor = (left + above) // 2
            elif filter_type == 4:
                predictor = _paeth_predictor(left, above, upper_left)
            else:
                predictor = 0
            row[index] = (value + predictor) & 0xFF

        for index in range(0, stride, channels):
            if color_type in {0, 4}:
                red = green = blue = row[index]
                alpha = row[index + 1] if color_type == 4 else 255
            else:
                red, green, blue = row[index : index + 3]
                alpha = row[index + 3] if color_type == 6 else 255
            for channel_index, channel in enumerate((red, green, blue)):
                channel_sums[channel_index] += channel
                channel_square_sums[channel_index] += channel * channel
            if min(red, green, blue) >= _NEAR_WHITE_CHANNEL_FLOOR:
                near_white_count += 1
            if alpha >= _NEAR_WHITE_CHANNEL_FLOOR:
                opaque_count += 1
            if alpha <= _TRANSPARENT_ALPHA_CEILING:
                transparent_count += 1
        previous = row

    channel_means = [total / pixel_count for total in channel_sums]
    channel_standard_deviations = [
        math.sqrt(max(0.0, square_total / pixel_count - mean * mean))
        for square_total, mean in zip(channel_square_sums, channel_means, strict=True)
    ]
    near_white_fraction = near_white_count / pixel_count
    opaque_fraction = opaque_count / pixel_count
    transparent_fraction = transparent_count / pixel_count
    is_opaque_near_white = not (
        min(channel_means) < _WHITE_MEAN_FLOOR
        or max(channel_standard_deviations) > _WHITE_STANDARD_DEVIATION_CEILING
        or near_white_fraction < _NEAR_WHITE_FRACTION_FLOOR
        or opaque_fraction < _OPAQUE_FRACTION_FLOOR
    )
    is_fully_transparent = (
        transparent_fraction >= _TRANSPARENT_FRACTION_FLOOR
    )
    if not is_opaque_near_white and not is_fully_transparent:
        raise FusionRuntimeGuardError(
            "Peekaboo auxiliary screenshot is neither nearly uniform white "
            "nor fully transparent"
        )
    return {
        "sha256": hashlib.sha256(payload).hexdigest(),
        "width": width,
        "height": height,
        "surface_kind": (
            "opaque-near-white"
            if is_opaque_near_white
            else "fully-transparent"
        ),
        "minimum_rgb_mean": round(min(channel_means), 6),
        "maximum_rgb_standard_deviation": round(max(channel_standard_deviations), 6),
        "near_white_fraction": round(near_white_fraction, 9),
        "opaque_fraction": round(opaque_fraction, 9),
        "transparent_fraction": round(transparent_fraction, 9),
    }


class _ProcBsdInfo(ctypes.Structure):
    """Darwin ``struct proc_bsdinfo`` from ``<libproc.h>``.

    The ABI has used 32-bit uid/gid fields and 64-bit start timeval members on
    every macOS architecture supported by Fusion.  Keeping the complete
    structure is important: using a hand-computed byte offset for the timeval
    would silently become an identity weakness if the ABI layout differed.
    """

    _fields_ = [
        ("pbi_flags", ctypes.c_uint32),
        ("pbi_status", ctypes.c_uint32),
        ("pbi_xstatus", ctypes.c_uint32),
        ("pbi_pid", ctypes.c_uint32),
        ("pbi_ppid", ctypes.c_uint32),
        ("pbi_uid", ctypes.c_uint32),
        ("pbi_gid", ctypes.c_uint32),
        ("pbi_ruid", ctypes.c_uint32),
        ("pbi_rgid", ctypes.c_uint32),
        ("pbi_svuid", ctypes.c_uint32),
        ("pbi_svgid", ctypes.c_uint32),
        ("rfu_1", ctypes.c_uint32),
        ("pbi_comm", ctypes.c_char * 16),
        ("pbi_name", ctypes.c_char * 32),
        ("pbi_nfiles", ctypes.c_uint32),
        ("pbi_pgid", ctypes.c_uint32),
        ("pbi_pjobc", ctypes.c_uint32),
        ("e_tdev", ctypes.c_uint32),
        ("e_tpgid", ctypes.c_uint32),
        ("pbi_nice", ctypes.c_int32),
        ("pbi_start_tvsec", ctypes.c_uint64),
        ("pbi_start_tvusec", ctypes.c_uint64),
    ]


ProcPidInfoReader = Callable[[int, _ProcBsdInfo], int]
BootSessionReader = Callable[[], str]
ProcessStartTokenReader = Callable[[int], str]


def is_darwin_process_start_token(value: object) -> bool:
    """Return whether ``value`` is one canonical high-resolution token."""

    return (
        isinstance(value, str)
        and _PROCESS_START_TOKEN_PATTERN.fullmatch(value) is not None
    )


def _libproc_pidbsdinfo(pid: int, info: _ProcBsdInfo) -> int:
    """Fill one exact ``proc_bsdinfo`` using the native macOS libproc ABI."""

    if sys.platform != "darwin":
        raise FusionRuntimeGuardError(
            "high-resolution Fusion process identity requires macOS libproc"
        )
    try:
        libproc = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
        proc_pidinfo = libproc.proc_pidinfo
        proc_pidinfo.argtypes = [
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_uint64,
            ctypes.c_void_p,
            ctypes.c_int,
        ]
        proc_pidinfo.restype = ctypes.c_int
        ctypes.set_errno(0)
        return int(
            proc_pidinfo(
                pid,
                _PROC_PIDTBSDINFO,
                0,
                ctypes.byref(info),
                ctypes.sizeof(info),
            )
        )
    except (AttributeError, OSError, TypeError, ValueError) as exc:
        raise FusionRuntimeGuardError(
            "macOS libproc process-start probe is unavailable"
        ) from exc


def _macos_boot_session_uuid() -> str:
    """Read the kernel boot-session UUID without spawning a second process."""

    if sys.platform != "darwin":
        raise FusionRuntimeGuardError(
            "high-resolution Fusion process identity requires a macOS boot session"
        )
    try:
        libc = ctypes.CDLL(None, use_errno=True)
        sysctlbyname = libc.sysctlbyname
        sysctlbyname.argtypes = [
            ctypes.c_char_p,
            ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_size_t),
            ctypes.c_void_p,
            ctypes.c_size_t,
        ]
        sysctlbyname.restype = ctypes.c_int
        length = ctypes.c_size_t()
        ctypes.set_errno(0)
        if (
            sysctlbyname(
                _DARWIN_BOOT_SESSION_SYSCTL,
                None,
                ctypes.byref(length),
                None,
                0,
            )
            != 0
            or not 1 < length.value <= 128
        ):
            raise FusionRuntimeGuardError("macOS boot-session identity is unavailable")
        buffer = ctypes.create_string_buffer(length.value)
        if (
            sysctlbyname(
                _DARWIN_BOOT_SESSION_SYSCTL,
                buffer,
                ctypes.byref(length),
                None,
                0,
            )
            != 0
        ):
            raise FusionRuntimeGuardError("macOS boot-session identity is unavailable")
        raw = bytes(buffer[: length.value]).rstrip(b"\0").decode("ascii")
        return str(uuid.UUID(raw)).lower()
    except FusionRuntimeGuardError:
        raise
    except (AttributeError, OSError, UnicodeError, ValueError) as exc:
        raise FusionRuntimeGuardError(
            "macOS boot-session identity is unavailable"
        ) from exc


def _macos_process_executable_path(pid: int) -> str:
    """Read the kernel-reported executable path for one live macOS PID."""

    if sys.platform != "darwin":
        raise FusionRuntimeGuardError(
            "Peekaboo daemon identity requires macOS libproc"
        )
    try:
        libproc = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
        proc_pidpath = libproc.proc_pidpath
        proc_pidpath.argtypes = [
            ctypes.c_int,
            ctypes.c_void_p,
            ctypes.c_uint32,
        ]
        proc_pidpath.restype = ctypes.c_int
        buffer = ctypes.create_string_buffer(_PROC_PIDPATHINFO_MAXSIZE)
        ctypes.set_errno(0)
        byte_count = int(proc_pidpath(pid, buffer, len(buffer)))
        if byte_count <= 0 or byte_count >= len(buffer):
            raise FusionRuntimeGuardError(
                "Peekaboo daemon executable path is unavailable"
            )
        return bytes(buffer[:byte_count]).rstrip(b"\0").decode("utf-8")
    except FusionRuntimeGuardError:
        raise
    except (AttributeError, OSError, UnicodeError, TypeError, ValueError) as exc:
        raise FusionRuntimeGuardError(
            "Peekaboo daemon executable path is unavailable"
        ) from exc


def _macos_process_arguments(pid: int) -> tuple[str, ...]:
    """Read one live process argv from ``KERN_PROCARGS2`` without shell parsing."""

    if sys.platform != "darwin":
        raise FusionRuntimeGuardError(
            "Peekaboo daemon arguments require the macOS kernel interface"
        )
    try:
        libc = ctypes.CDLL(None, use_errno=True)
        sysctl = libc.sysctl
        sysctl.argtypes = [
            ctypes.POINTER(ctypes.c_int),
            ctypes.c_uint,
            ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_size_t),
            ctypes.c_void_p,
            ctypes.c_size_t,
        ]
        sysctl.restype = ctypes.c_int
        argmax_mib = (ctypes.c_int * 2)(_CTL_KERN, _KERN_ARGMAX)
        argmax = ctypes.c_int()
        argmax_size = ctypes.c_size_t(ctypes.sizeof(argmax))
        ctypes.set_errno(0)
        if (
            sysctl(
                argmax_mib,
                2,
                ctypes.byref(argmax),
                ctypes.byref(argmax_size),
                None,
                0,
            )
            != 0
            or not 4096 <= argmax.value <= 2 * 1024 * 1024
        ):
            raise FusionRuntimeGuardError(
                "Peekaboo daemon argument capacity is unavailable"
            )
        arguments_mib = (ctypes.c_int * 3)(_CTL_KERN, _KERN_PROCARGS2, pid)
        buffer = ctypes.create_string_buffer(argmax.value)
        payload_size = ctypes.c_size_t(argmax.value)
        ctypes.set_errno(0)
        if (
            sysctl(
                arguments_mib,
                3,
                buffer,
                ctypes.byref(payload_size),
                None,
                0,
            )
            != 0
            or not 4 < payload_size.value <= argmax.value
        ):
            raise FusionRuntimeGuardError(
                "Peekaboo daemon arguments are unavailable"
            )
        payload = bytes(buffer[: payload_size.value])
        argument_count = struct.unpack_from("i", payload)[0]
        if not 1 <= argument_count <= 64:
            raise FusionRuntimeGuardError(
                "Peekaboo daemon argument count is invalid"
            )
        position = 4
        executable_end = payload.find(b"\0", position)
        if executable_end <= position:
            raise FusionRuntimeGuardError(
                "Peekaboo daemon executable argument is invalid"
            )
        position = executable_end
        while position < len(payload) and payload[position] == 0:
            position += 1
        arguments: list[str] = []
        while position < len(payload) and len(arguments) < argument_count:
            argument_end = payload.find(b"\0", position)
            if argument_end < position:
                break
            arguments.append(payload[position:argument_end].decode("utf-8"))
            position = argument_end + 1
        if len(arguments) != argument_count or any("\0" in item for item in arguments):
            raise FusionRuntimeGuardError(
                "Peekaboo daemon arguments are incomplete"
            )
        return tuple(arguments)
    except FusionRuntimeGuardError:
        raise
    except (AttributeError, OSError, UnicodeError, ValueError, struct.error) as exc:
        raise FusionRuntimeGuardError(
            "Peekaboo daemon arguments are unavailable"
        ) from exc


def _macos_unix_socket_listener_identity(
    socket_path: str,
    *,
    expected_pid: int | None = None,
    deadline: float | None = None,
) -> tuple[int, int]:
    """Map one Unix socket path to its kernel-visible listener PID and UID.

    The first proof intentionally searches the system-wide Unix-socket table.
    Once that proof has pinned a PID, callers can constrain later bracket checks
    to that exact process.  The constrained query preserves the path/PID/UID
    proof while avoiding repeated full-table scans during one window census.
    """

    if expected_pid is not None and (
        not isinstance(expected_pid, int)
        or isinstance(expected_pid, bool)
        or expected_pid <= 0
    ):
        raise FusionRuntimeGuardError(
            "Peekaboo pinned socket-listener PID is invalid"
        )

    try:
        metadata = _LSOF_EXECUTABLE.stat()
    except OSError as exc:
        raise FusionRuntimeGuardError(
            "macOS socket-listener inspector is unavailable"
        ) from exc
    if (
        not stat.S_ISREG(metadata.st_mode)
        or metadata.st_uid != 0
        or stat.S_IMODE(metadata.st_mode) & 0o022
        or not os.access(_LSOF_EXECUTABLE, os.X_OK)
    ):
        raise FusionRuntimeGuardError(
            "macOS socket-listener inspector identity is unsafe"
        )
    try:
        command = [
            str(_LSOF_EXECUTABLE),
            "-n",
            "-U",
            "-a",
        ]
        if expected_pid is not None:
            command.extend(["-p", str(expected_pid)])
        command.extend(["-F0pcufn", "--", socket_path])
        completed = _default_runner(
            command,
            timeout=_remaining_timeout(
                deadline, 10.0, "Peekaboo socket-listener inspection"
            ),
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise FusionRuntimeGuardError(
            "Peekaboo socket-listener inspection failed"
        ) from exc
    raw = _require_success(completed, "Peekaboo socket-listener inspection")
    current_pid: int | None = None
    current_uid: int | None = None
    current_command: str | None = None
    matches: list[tuple[int, int]] = []
    for line in raw.splitlines():
        for field in (item for item in line.split("\0") if item):
            tag, value = field[0], field[1:]
            if tag == "p":
                try:
                    current_pid = int(value)
                except ValueError:
                    current_pid = None
                current_uid = None
                current_command = None
            elif tag == "u":
                try:
                    current_uid = int(value)
                except ValueError:
                    current_uid = None
            elif tag == "c":
                current_command = value
            elif tag == "n" and value == socket_path:
                if (
                    current_pid is None
                    or current_pid <= 0
                    or current_uid is None
                    or current_uid < 0
                    or current_command != "peekaboo"
                ):
                    raise FusionRuntimeGuardError(
                        "Peekaboo socket listener record is incomplete"
                    )
                matches.append((current_pid, current_uid))
    if len(matches) != 1:
        raise FusionRuntimeGuardError(
            "Peekaboo socket does not have one unique trusted listener"
        )
    _require_deadline(deadline, "Peekaboo socket-listener inspection")
    return matches[0]


@dataclass(frozen=True)
class MacOSProcessStartTokenProbe:
    """Create a reboot-scoped, microsecond Fusion process-start token.

    The two readers are injectable so the ABI parsing and all failure paths are
    testable on non-macOS CI.  Production deliberately has no fallback to
    second-resolution ``ps lstart``: losing libproc precision fails closed.
    """

    proc_pidinfo: ProcPidInfoReader = _libproc_pidbsdinfo
    boot_session_reader: BootSessionReader = _macos_boot_session_uuid

    def __call__(self, pid: int) -> str:
        if isinstance(pid, bool) or not isinstance(pid, int) or pid <= 0:
            raise FusionRuntimeGuardError(
                "Fusion process-start probe requires a positive PID"
            )
        info = _ProcBsdInfo()
        try:
            byte_count = self.proc_pidinfo(pid, info)
        except FusionRuntimeGuardError:
            raise
        except Exception as exc:
            raise FusionRuntimeGuardError(
                "macOS libproc process-start probe failed"
            ) from exc
        if byte_count != ctypes.sizeof(info):
            raise FusionRuntimeGuardError(
                "macOS libproc returned an incomplete process identity"
            )
        seconds = int(info.pbi_start_tvsec)
        microseconds = int(info.pbi_start_tvusec)
        if (
            int(info.pbi_pid) != pid
            or seconds <= 0
            or not 0 <= microseconds < 1_000_000
        ):
            raise FusionRuntimeGuardError(
                "macOS libproc returned an invalid process identity"
            )
        try:
            boot_session = str(uuid.UUID(self.boot_session_reader())).lower()
        except FusionRuntimeGuardError:
            raise
        except Exception as exc:
            raise FusionRuntimeGuardError(
                "macOS boot-session identity is unavailable"
            ) from exc
        return (
            f"{DARWIN_PROCESS_START_TOKEN_SCHEMA}:{boot_session}:"
            f"{seconds}:{microseconds:06d}"
        )


@dataclass(frozen=True)
class FusionProcessIdentity:
    pid: int
    start_time: str
    start_token: str
    command: str
    listener: str
    hostname: str
    release: str = "UNKNOWN"

    def __post_init__(self) -> None:
        if not is_darwin_process_start_token(self.start_token):
            raise ValueError(
                "Fusion process start token must be one canonical macOS libproc token"
            )

    @property
    def stable_key(self) -> str:
        return f"{self.pid}:{self.start_token}"


@dataclass(frozen=True)
class FusionRequestEvidence:
    """Bounded, non-secret request identity retained across a crash boundary."""

    request_id: int | str | None
    tool: str
    arguments_sha256: str
    preservation_role: str = "unclassified"

    @classmethod
    def from_request(
        cls,
        *,
        request_id: int | str | None,
        tool: str,
        arguments: dict[str, object] | None,
        preservation_role: str = "unclassified",
    ) -> Self:
        encoded = json.dumps(
            arguments,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        if (
            preservation_role == "unclassified"
            and request_id is None
            and tool in {"initialize", "tools/list"}
            and arguments == {}
        ):
            # Legacy/non-lazy dirty-recovery bootstrap requests are transport
            # setup, not a selected Fusion operation.  They remain bounded by
            # the exact empty-argument bootstrap order in
            # _consume_dirty_recovery_request and therefore cannot be used to
            # bypass the untitled-document gate.
            preservation_role = "transport-bootstrap"
        return cls(
            request_id=request_id,
            tool=tool[:200],
            arguments_sha256=hashlib.sha256(encoded).hexdigest(),
            preservation_role=preservation_role[:100],
        )


@dataclass(frozen=True)
class DirtyRecoveryAuthorization:
    """One exact, expiring request allowed against one modified Fusion window.

    This is deliberately a single-stage transport authorization, not native
    document identity.  The initial request must be a separately reviewed
    inspect call whose captured response establishes ``document.creationId``.
    Any later mutation needs a new receipt for exact arguments whose Fusion
    script independently guards that creation ID; a window title never grants
    follow-up mutation authority.
    """

    receipt_sha256: str
    modified_document_title: str
    tool: str
    arguments_sha256: str
    expires_at_unix: float
    expires_at_monotonic: float


@dataclass(frozen=True)
class HealthIdentityAuthorization:
    """One exact controller challenge bound to this cell and Fusion start."""

    challenge_sha256: str
    nonce_sha256: str
    incident_id: str
    incident_manifest_sha256: str
    node_id: str
    hostname: str
    command_sha256: str
    receipt_path: Path
    used_path: Path
    expires_at_unix: float
    expires_at_monotonic: float


@dataclass
class MacOSFusionProcessProbe:
    upstream_url: str = DEFAULT_UPSTREAM
    expected_hostname: str | None = None
    runner: CommandRunner = _default_runner
    start_token_reader: ProcessStartTokenReader = MacOSProcessStartTokenProbe()
    lsof_path: str = "/usr/sbin/lsof"
    ps_path: str = "/bin/ps"
    hostname_path: str = "/bin/hostname"

    def _upstream_port(self) -> int:
        if self.upstream_url != DEFAULT_UPSTREAM:
            raise FusionRuntimeGuardError(
                f"Fusion MCP upstream must be exactly {DEFAULT_UPSTREAM}"
            )
        return 27182

    def _process_start_token(self, pid: int) -> str:
        try:
            token = self.start_token_reader(pid)
        except FusionRuntimeGuardError:
            raise
        except Exception as exc:
            raise FusionRuntimeGuardError(
                "high-resolution Fusion process-start probe failed"
            ) from exc
        if not is_darwin_process_start_token(token):
            raise FusionRuntimeGuardError(
                "high-resolution Fusion process-start probe returned an invalid token"
            )
        return token

    def _hostname(self, *, deadline: float | None = None) -> str:
        hostname = _require_success(
            self.runner(
                [self.hostname_path],
                timeout=_remaining_timeout(deadline, 5.0, "hostname probe"),
            ),
            "hostname probe",
        )
        _require_deadline(deadline, "hostname probe")
        if self.expected_hostname and hostname != self.expected_hostname:
            raise FusionRuntimeGuardError(
                "execution-node hostname does not match the configured identity"
            )
        return hostname

    @staticmethod
    def _parse_lsof(raw: str) -> dict[int, dict[str, list[str] | str]]:
        rows: dict[int, dict[str, list[str] | str]] = {}
        current_pid: int | None = None
        for line in raw.splitlines():
            if not line:
                continue
            tag, value = line[0], line[1:]
            if tag == "p":
                try:
                    current_pid = int(value)
                except ValueError as exc:
                    raise FusionRuntimeGuardError(
                        "lsof returned a non-numeric PID"
                    ) from exc
                rows.setdefault(current_pid, {"names": []})
            elif current_pid is not None and tag == "c":
                rows[current_pid]["command"] = value
            elif current_pid is not None and tag == "n":
                names = rows[current_pid].setdefault("names", [])
                assert isinstance(names, list)
                names.append(value)
        return rows

    def discover(self, *, deadline: float | None = None) -> FusionProcessIdentity:
        port = self._upstream_port()
        hostname = self._hostname(deadline=deadline)
        raw = _require_success(
            self.runner(
                [
                    self.lsof_path,
                    "-nP",
                    "-a",
                    f"-iTCP:{port}",
                    "-sTCP:LISTEN",
                    "-Fpcn",
                ],
                timeout=_remaining_timeout(deadline, 10.0, "Fusion listener probe"),
            ),
            "Fusion listener probe",
        )
        _require_deadline(deadline, "Fusion listener probe")
        rows = self._parse_lsof(raw)
        matching: list[tuple[int, str]] = []
        expected_listener = f"127.0.0.1:{port}"
        for pid, row in rows.items():
            names = row.get("names", [])
            assert isinstance(names, list)
            for name in names:
                normalized = re.sub(r"^TCP\s+", "", name).split(" ", 1)[0]
                if normalized != expected_listener:
                    raise FusionRuntimeGuardError(
                        "Fusion MCP port has a non-loopback listener"
                    )
                if normalized == expected_listener:
                    matching.append((pid, normalized))
        if len(matching) != 1:
            raise FusionRuntimeGuardError(
                "expected exactly one Fusion-owned loopback MCP listener"
            )
        pid, listener = matching[0]
        _require_deadline(deadline, "Fusion process-start probe")
        start_token_before = self._process_start_token(pid)
        _require_deadline(deadline, "Fusion process-start probe")
        ps_output = _require_success(
            self.runner(
                [self.ps_path, "-p", str(pid), "-o", "lstart=", "-o", "command="],
                timeout=_remaining_timeout(deadline, 5.0, "Fusion process probe"),
            ),
            "Fusion process probe",
        )
        _require_deadline(deadline, "Fusion process probe")
        lines = [line for line in ps_output.splitlines() if line.strip()]
        if len(lines) != 1:
            raise FusionRuntimeGuardError("Fusion process identity is ambiguous")
        line = lines[0].strip()
        match = re.match(
            r"^(\S{3}\s+\S{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}\s+\d{4})\s+(.+)$",
            line,
        )
        if match is None:
            raise FusionRuntimeGuardError("Fusion process start time is unreadable")
        start_time, command = match.groups()
        executable = command.split(" -", 1)[0]
        if not executable.endswith(FUSION_EXECUTABLE_SUFFIX):
            raise FusionRuntimeGuardError(
                "loopback MCP listener is not owned by Autodesk Fusion"
            )
        release = "UNKNOWN"
        info_plist = (
            Path(executable.removesuffix("/Contents/MacOS/Autodesk Fusion"))
            / "Contents"
            / "Info.plist"
        )
        try:
            with info_plist.open("rb") as stream:
                info = plistlib.load(stream)
            candidate = info.get("CFBundleShortVersionString") or info.get(
                "CFBundleVersion"
            )
            if isinstance(candidate, str) and candidate.strip():
                release = candidate.strip()[:200]
        except (OSError, plistlib.InvalidFileException, AttributeError):
            # The PID/start-token/listener binding remains authoritative even when
            # a deployment omits or temporarily hides its Info.plist.
            pass
        _require_deadline(deadline, "Fusion process-start probe")
        start_token_after = self._process_start_token(pid)
        _require_deadline(deadline, "Fusion process-start probe")
        if start_token_after != start_token_before:
            raise FusionRuntimeGuardError(
                "Fusion process identity changed while it was being inspected"
            )
        return FusionProcessIdentity(
            pid=pid,
            start_time=start_time,
            start_token=start_token_after,
            command=command,
            listener=listener,
            hostname=hostname,
            release=release,
        )


@dataclass
class PeekabooWindowProbe:
    executable: str
    mode: str = "local"
    runner: CommandRunner = _default_runner

    def __post_init__(self) -> None:
        if self.mode not in {"local", "bridge", "local-ondemand"}:
            raise ValueError(
                "Peekaboo mode must be local, bridge, or local-ondemand"
            )

    def has_uninjected_runner_shape(self) -> bool:
        """Return whether this probe uses the non-injected subprocess path.

        This is necessary but deliberately insufficient for recovery trust;
        ``signed_executable_identity`` must also authenticate the resolved
        executable before and after the window proof.
        """

        return (
            type(self) is PeekabooWindowProbe
            and self.runner is _default_runner
            and set(vars(self)) == {"executable", "mode", "runner"}
        )

    def signed_executable_identity(
        self, *, deadline: float | None = None
    ) -> tuple[object, ...]:
        """Authenticate and identify the official Peekaboo executable."""

        if not PeekabooWindowProbe.has_uninjected_runner_shape(self):
            raise FusionRuntimeGuardError(
                "Peekaboo recovery probe does not use the production runner"
            )
        configured = Path(self.executable)
        if not configured.is_absolute():
            raise FusionRuntimeGuardError(
                "Peekaboo recovery executable path is not absolute"
            )
        try:
            resolved = configured.resolve(strict=True)
            before = resolved.stat()
        except OSError as exc:
            raise FusionRuntimeGuardError(
                "Peekaboo recovery executable is unavailable"
            ) from exc
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_uid not in {0, os.geteuid()}
            or stat.S_IMODE(before.st_mode) & 0o022
            or not os.access(resolved, os.X_OK)
        ):
            raise FusionRuntimeGuardError(
                "Peekaboo recovery executable ownership or mode is unsafe"
            )
        if not _CODESIGN_EXECUTABLE.is_file():
            raise FusionRuntimeGuardError("macOS codesign verifier is unavailable")

        commands = (
            [
                str(_CODESIGN_EXECUTABLE),
                "--verify",
                "--strict",
                "--verbose=2",
                "--requirements",
                (
                    '=anchor apple generic and identifier "'
                    f"{_PEEKABOO_CODESIGN_IDENTIFIER}"
                    '" and certificate leaf[subject.OU] = "'
                    f"{_PEEKABOO_CODESIGN_TEAM}"
                    '"'
                ),
                str(resolved),
            ],
            [
                str(_CODESIGN_EXECUTABLE),
                "--display",
                "--verbose=4",
                str(resolved),
            ],
        )
        outputs: list[str] = []
        try:
            for index, command in enumerate(commands, start=1):
                completed = _default_runner(
                    command,
                    timeout=_remaining_timeout(
                        deadline,
                        30.0,
                        f"Peekaboo code-signature check {index}",
                    ),
                )
                if completed.returncode != 0:
                    raise FusionRuntimeGuardError(
                        "Peekaboo recovery executable signature is invalid"
                    )
                outputs.append(f"{completed.stdout}\n{completed.stderr}")
                _require_deadline(deadline, f"Peekaboo code-signature check {index}")
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise FusionRuntimeGuardError(
                "Peekaboo recovery executable signature cannot be verified"
            ) from exc

        details = outputs[1].splitlines()
        fields = {
            key: value
            for line in details
            if "=" in line
            for key, value in [line.split("=", 1)]
        }
        cdhash = fields.get("CDHash", "")
        if (
            fields.get("Identifier") != _PEEKABOO_CODESIGN_IDENTIFIER
            or fields.get("TeamIdentifier") != _PEEKABOO_CODESIGN_TEAM
            or re.fullmatch(r"[0-9a-f]{40,64}", cdhash) is None
        ):
            raise FusionRuntimeGuardError(
                "Peekaboo recovery executable signer identity is not trusted"
            )
        try:
            after = resolved.stat()
            resolved_after = configured.resolve(strict=True)
        except OSError as exc:
            raise FusionRuntimeGuardError(
                "Peekaboo recovery executable changed during verification"
            ) from exc

        def stat_identity(value: os.stat_result) -> tuple[int, ...]:
            return (
                value.st_dev,
                value.st_ino,
                value.st_mode,
                value.st_uid,
                value.st_gid,
                value.st_size,
                value.st_mtime_ns,
            )

        if resolved_after != resolved or stat_identity(after) != stat_identity(before):
            raise FusionRuntimeGuardError(
                "Peekaboo recovery executable changed during verification"
            )
        return (
            str(resolved),
            *stat_identity(after),
            fields["Identifier"],
            fields["TeamIdentifier"],
            cdhash,
        )

    def _command(
        self, arguments: list[str], *, bridge_socket: str | None = None
    ) -> list[str]:
        command = [self.executable, *arguments, "--json"]
        if self.mode == "local":
            command.append("--no-remote")
        elif bridge_socket is not None:
            command.extend(["--bridge-socket", bridge_socket])
        return command

    @staticmethod
    def _expected_local_ondemand_socket_path() -> Path:
        try:
            account = pwd.getpwuid(os.geteuid())
        except KeyError as exc:
            raise FusionRuntimeGuardError(
                "current local account identity is unavailable"
            ) from exc
        home = Path(account.pw_dir)
        if not home.is_absolute():
            raise FusionRuntimeGuardError(
                "current local account home is not absolute"
            )
        return home / "Library/Application Support/Peekaboo/bridge.sock"

    @staticmethod
    def _local_ondemand_socket_identity(socket_path: str) -> tuple[object, ...]:
        candidate = Path(socket_path)
        expected = PeekabooWindowProbe._expected_local_ondemand_socket_path()
        if not candidate.is_absolute() or candidate != expected:
            raise FusionRuntimeGuardError(
                "Peekaboo local on-demand socket path is not the canonical "
                "current-user path"
            )
        try:
            metadata = candidate.lstat()
            parent_metadata = candidate.parent.stat()
        except OSError as exc:
            raise FusionRuntimeGuardError(
                "Peekaboo local on-demand socket is unavailable"
            ) from exc
        if (
            not stat.S_ISSOCK(metadata.st_mode)
            or metadata.st_uid != os.geteuid()
            or stat.S_IMODE(metadata.st_mode) != 0o600
            or metadata.st_nlink != 1
        ):
            raise FusionRuntimeGuardError(
                "Peekaboo local on-demand socket identity or mode is unsafe"
            )
        if (
            not stat.S_ISDIR(parent_metadata.st_mode)
            or parent_metadata.st_uid != os.geteuid()
            or stat.S_IMODE(parent_metadata.st_mode) & 0o022
        ):
            raise FusionRuntimeGuardError(
                "Peekaboo local on-demand socket parent is unsafe"
            )
        return (
            str(candidate),
            metadata.st_dev,
            metadata.st_ino,
            metadata.st_mode,
            metadata.st_uid,
            metadata.st_gid,
            metadata.st_nlink,
        )

    @staticmethod
    def _observe_local_ondemand_peer_identity(
        socket_path: str,
        *,
        expected_pid: int | None = None,
        deadline: float | None = None,
    ) -> tuple[object, ...]:
        _require_deadline(deadline, "Peekaboo local on-demand peer identity")
        pid, effective_uid = _macos_unix_socket_listener_identity(
            socket_path,
            expected_pid=expected_pid,
            deadline=deadline,
        )
        if expected_pid is not None and pid != expected_pid:
            raise FusionRuntimeGuardError(
                "Peekaboo local on-demand peer changed from its pinned PID"
            )
        if effective_uid != os.geteuid():
            raise FusionRuntimeGuardError(
                "Peekaboo local on-demand peer does not use the current UID"
            )
        start_token_before = MacOSProcessStartTokenProbe()(pid)
        executable = Path(_macos_process_executable_path(pid)).resolve(strict=True)
        metadata = executable.stat()
        arguments = _macos_process_arguments(pid)
        start_token_after = MacOSProcessStartTokenProbe()(pid)
        _require_deadline(deadline, "Peekaboo local on-demand peer identity")
        if start_token_before != start_token_after:
            raise FusionRuntimeGuardError(
                "Peekaboo local on-demand peer changed during identity proof"
            )
        return (
            pid,
            effective_uid,
            start_token_after,
            str(executable),
            metadata.st_dev,
            metadata.st_ino,
            metadata.st_mode,
            metadata.st_uid,
            metadata.st_gid,
            metadata.st_size,
            metadata.st_mtime_ns,
            arguments,
        )

    @staticmethod
    def _validate_local_ondemand_peer_identity(
        peer_identity: tuple[object, ...],
        signed_executable_identity: tuple[object, ...],
        socket_path: str,
    ) -> None:
        if len(peer_identity) != 12 or len(signed_executable_identity) != 11:
            raise FusionRuntimeGuardError(
                "Peekaboo local on-demand peer proof is incomplete"
            )
        trusted_executable = Path(str(signed_executable_identity[0]))
        arguments = peer_identity[11]
        if (
            peer_identity[3] != str(trusted_executable)
            or tuple(peer_identity[4:11])
            != tuple(signed_executable_identity[1:8])
            or signed_executable_identity[8] != _PEEKABOO_CODESIGN_IDENTIFIER
            or signed_executable_identity[9] != _PEEKABOO_CODESIGN_TEAM
            or not isinstance(arguments, tuple)
            or len(arguments) != 7
            or Path(str(arguments[0])).resolve(strict=True) != trusted_executable
            or arguments[1:]
            != (
                "daemon",
                "run",
                "--mode",
                "manual",
                "--bridge-socket",
                socket_path,
            )
        ):
            raise FusionRuntimeGuardError(
                "Peekaboo local on-demand peer is not the pinned signed daemon"
            )

    def _json(
        self,
        arguments: list[str],
        label: str,
        *,
        bridge_socket: str | None = None,
        bridge_socket_identity: tuple[object, ...] | None = None,
        bridge_peer_identity: tuple[object, ...] | None = None,
        require_local_in_process_runtime: bool = False,
        deadline: float | None = None,
    ) -> dict[str, Any]:
        if require_local_in_process_runtime:
            capture_path = Path(arguments[10]) if len(arguments) == 13 else None
            if (
                len(arguments) != 13
                or arguments[0] != "image"
                or arguments[1] != "--pid"
                or not arguments[2].isdigit()
                or int(arguments[2]) <= 0
                or arguments[3:5] != ["--mode", "window"]
                or arguments[5] != "--window-id"
                or not arguments[6].isdigit()
                or int(arguments[6]) <= 0
                or arguments[7:9] != ["--capture-engine", "cg"]
                or arguments[9] != "--path"
                or capture_path is None
                or not capture_path.is_absolute()
                or capture_path.name != "window.png"
                or not capture_path.parent.name.startswith(
                    "fusion-mcp-auxiliary-"
                )
                or arguments[11:13] != ["--format", "png"]
            ):
                raise FusionRuntimeGuardError(
                    "Peekaboo local in-process exception is not the exact "
                    "auxiliary window CG capture contract"
                )
            if (
                self.mode != "local-ondemand"
                or bridge_socket is None
                or bridge_socket_identity is None
                or bridge_peer_identity is None
            ):
                raise FusionRuntimeGuardError(
                    "Peekaboo local in-process capture lacks pinned on-demand context"
                )
        if bridge_socket_identity is not None:
            if bridge_socket is None or self._local_ondemand_socket_identity(
                bridge_socket
            ) != bridge_socket_identity:
                raise FusionRuntimeGuardError(
                    "Peekaboo local on-demand socket changed before evidence capture"
                )
        if bridge_peer_identity is not None:
            pinned_pid = (
                bridge_peer_identity[0]
                if len(bridge_peer_identity) == 12
                and isinstance(bridge_peer_identity[0], int)
                and not isinstance(bridge_peer_identity[0], bool)
                and bridge_peer_identity[0] > 0
                else None
            )
            if pinned_pid is None:
                raise FusionRuntimeGuardError(
                    "Peekaboo local on-demand peer proof is incomplete"
                )
            if bridge_socket is None or self._observe_local_ondemand_peer_identity(
                bridge_socket,
                expected_pid=pinned_pid,
                deadline=deadline,
            ) != bridge_peer_identity:
                raise FusionRuntimeGuardError(
                    "Peekaboo local on-demand peer changed before evidence capture"
                )
        payload = _parse_json_output(
            self.runner(
                self._command(
                    arguments,
                    bridge_socket=(
                        None if require_local_in_process_runtime else bridge_socket
                    ),
                ),
                timeout=_remaining_timeout(deadline, 30.0, label),
            ),
            label,
        )
        if bridge_socket_identity is not None:
            if bridge_socket is None or self._local_ondemand_socket_identity(
                bridge_socket
            ) != bridge_socket_identity:
                raise FusionRuntimeGuardError(
                    "Peekaboo local on-demand socket changed during evidence capture"
                )
        if bridge_peer_identity is not None:
            pinned_pid = (
                bridge_peer_identity[0]
                if len(bridge_peer_identity) == 12
                and isinstance(bridge_peer_identity[0], int)
                and not isinstance(bridge_peer_identity[0], bool)
                and bridge_peer_identity[0] > 0
                else None
            )
            if pinned_pid is None:
                raise FusionRuntimeGuardError(
                    "Peekaboo local on-demand peer proof is incomplete"
                )
            if bridge_socket is None or self._observe_local_ondemand_peer_identity(
                bridge_socket,
                expected_pid=pinned_pid,
                deadline=deadline,
            ) != bridge_peer_identity:
                raise FusionRuntimeGuardError(
                    "Peekaboo local on-demand peer changed during evidence capture"
                )
        if require_local_in_process_runtime:
            debug_logs = payload.get("debug_logs")
            runtime_hosts = []
            if isinstance(debug_logs, list):
                marker = "DEBUG: Runtime host: "
                for row in debug_logs:
                    if isinstance(row, str) and marker in row:
                        runtime_hosts.append(row.rsplit(marker, 1)[1].strip())
            if runtime_hosts != ["local (in-process)"]:
                raise FusionRuntimeGuardError(
                    "Peekaboo exact auxiliary screenshot did not prove its "
                    "local in-process runtime host"
                )
        _require_deadline(deadline, label)
        return payload

    @staticmethod
    def _window_title(row: object) -> str:
        if not isinstance(row, dict):
            return ""
        value = row.get("title", row.get("window_title", ""))
        return str(value or "").strip()

    @staticmethod
    def _is_blocking_title(title: str) -> bool:
        lowered = title.casefold()
        return (
            lowered in _BLOCKING_TITLE_EXACT
            or any(part in lowered for part in _BLOCKING_TITLE_PARTS)
            or any(lowered.startswith(prefix) for prefix in _BLOCKING_TITLE_PREFIXES)
        )

    @staticmethod
    def _is_primary_fusion_window(row: object) -> bool:
        if not isinstance(row, dict) or row.get("isMinimized") is True:
            return False
        title = PeekabooWindowProbe._window_title(row)
        bounds = _window_bounds(row)
        return (
            title != _KNOWN_WHITE_AUXILIARY_TITLE
            and _PRIMARY_FUSION_WINDOW_TITLE_PATTERN.fullmatch(title) is not None
            and not PeekabooWindowProbe._is_blocking_title(title)
            and _window_id(row) is not None
            and bounds is not None
            and bounds[2] > _KNOWN_WHITE_AUXILIARY_SIZE[0]
            and bounds[3] > _KNOWN_WHITE_AUXILIARY_SIZE[1]
        )

    @staticmethod
    def _modified_document_titles(titles: list[str]) -> list[str]:
        return [
            title
            for title in titles
            if (
                (separator := title.casefold().find(" - autodesk fusion")) >= 0
                and "*" in title[:separator]
            )
        ]

    @staticmethod
    def _untitled_document_titles(titles: list[str]) -> list[str]:
        untitled: list[str] = []
        for title in titles:
            separator = title.casefold().find(" - autodesk fusion")
            if separator < 0:
                continue
            document_part = title[:separator].replace("*", "").strip()
            # Fusion can append an occurrence counter or signed-in user to the
            # document label.  Remove only trailing parenthesized suffixes and
            # then require one exact locale-default base name.
            while True:
                stripped = re.sub(r"\s*\([^()\r\n]+\)\s*$", "", document_part)
                if stripped == document_part:
                    break
                document_part = stripped.strip()
            if document_part.casefold() in _UNTITLED_DOCUMENT_BASE_NAMES:
                untitled.append(title)
        return untitled

    def _window_census(
        self,
        identity: FusionProcessIdentity,
        *,
        bridge_socket: str | None,
        bridge_socket_identity: tuple[object, ...] | None = None,
        bridge_peer_identity: tuple[object, ...] | None = None,
        deadline: float | None,
    ) -> tuple[list[object], dict[str, Any]]:
        windows = self._json(
            [
                "list",
                "windows",
                "--pid",
                str(identity.pid),
                "--include-details",
                "off_screen,bounds,ids",
            ],
            "Peekaboo Fusion window census",
            bridge_socket=bridge_socket,
            bridge_socket_identity=bridge_socket_identity,
            bridge_peer_identity=bridge_peer_identity,
            deadline=deadline,
        )
        window_data = windows.get("data", {})
        target = window_data.get("targetApplication", {})
        # Peekaboo 3.2.1's GUI Bridge does not echo targetApplication for this
        # operation.  When it does, require an exact match; otherwise the
        # independently verified app census is the PID/bundle authority.
        if target and (
            not isinstance(target, dict)
            or target.get("processIdentifier") != identity.pid
        ):
            raise FusionRuntimeGuardError(
                "Peekaboo target application does not match the MCP listener PID"
            )
        window_rows = window_data.get("windows", [])
        if not isinstance(window_rows, list) or not window_rows:
            raise FusionRuntimeGuardError("Fusion has no verified top-level windows")
        return window_rows, window_data

    @staticmethod
    def _stable_auxiliary_window(
        first_rows: list[object], second_rows: list[object]
    ) -> tuple[int, tuple[float, float, float, float]]:
        if any(
            sum(
                PeekabooWindowProbe._window_title(row) == _KNOWN_WHITE_AUXILIARY_TITLE
                for row in rows
            )
            != 1
            for rows in (first_rows, second_rows)
        ):
            raise FusionRuntimeGuardError(
                "Fusion module-loading auxiliary is not uniquely stable"
            )

        def candidates(
            rows: list[object],
        ) -> list[tuple[int, tuple[float, float, float, float]]]:
            result: list[tuple[int, tuple[float, float, float, float]]] = []
            for row in rows:
                if (
                    PeekabooWindowProbe._window_title(row)
                    != _KNOWN_WHITE_AUXILIARY_TITLE
                    or not isinstance(row, dict)
                    or row.get("isMainWindow") is not False
                ):
                    continue
                window_id = _window_id(row)
                bounds = _window_bounds(row)
                if window_id is not None and bounds is not None:
                    result.append((window_id, bounds))
            return result

        first = candidates(first_rows)
        second = candidates(second_rows)
        if len(first) != 1 or second != first:
            raise FusionRuntimeGuardError(
                "Fusion module-loading auxiliary is not uniquely stable"
            )
        if first[0][1][2:] != _KNOWN_WHITE_AUXILIARY_SIZE:
            raise FusionRuntimeGuardError(
                "Fusion module-loading auxiliary does not have its known size"
            )
        return first[0]

    @staticmethod
    def _stable_primary_fusion_window(
        first_rows: list[object], second_rows: list[object]
    ) -> tuple[int, str, tuple[float, float, float, float]]:
        def candidates(
            rows: list[object],
        ) -> list[tuple[int, str, tuple[float, float, float, float]]]:
            result: list[tuple[int, str, tuple[float, float, float, float]]] = []
            for row in rows:
                if not PeekabooWindowProbe._is_primary_fusion_window(row):
                    continue
                window_id = _window_id(row)
                bounds = _window_bounds(row)
                if window_id is not None and bounds is not None:
                    result.append(
                        (
                            window_id,
                            PeekabooWindowProbe._window_title(row),
                            bounds,
                        )
                    )
            return result

        first = candidates(first_rows)
        second = candidates(second_rows)
        if len(first) != 1 or second != first:
            raise FusionRuntimeGuardError(
                "Fusion module-loading auxiliary has no unique stable primary canvas"
            )
        return first[0]

    def _prove_white_auxiliary(
        self,
        identity: FusionProcessIdentity,
        *,
        first_rows: list[object],
        require_clean_start: bool,
        bridge_socket: str | None,
        bridge_socket_identity: tuple[object, ...] | None,
        bridge_peer_identity: tuple[object, ...] | None,
        deadline: float | None,
    ) -> dict[str, Any]:
        if (
            sum(
                self._window_title(row) == _KNOWN_WHITE_AUXILIARY_TITLE
                for row in first_rows
            )
            != 1
        ):
            raise FusionRuntimeGuardError(
                "Fusion module-loading auxiliary is not uniquely stable"
            )
        if sum(self._is_primary_fusion_window(row) for row in first_rows) != 1:
            raise FusionRuntimeGuardError(
                "Fusion module-loading auxiliary has no unique primary canvas"
            )
        sleep_budget = _remaining_timeout(
            deadline,
            _AUXILIARY_STABILITY_DELAY_SECONDS,
            "Peekaboo auxiliary stability interval",
        )
        if sleep_budget < _AUXILIARY_STABILITY_DELAY_SECONDS:
            raise TimeoutError(
                "Peekaboo auxiliary stability interval exceeded its shared deadline"
            )
        time.sleep(_AUXILIARY_STABILITY_DELAY_SECONDS)
        _require_deadline(deadline, "Peekaboo auxiliary stability interval")
        second_rows, _ = self._window_census(
            identity,
            bridge_socket=bridge_socket,
            bridge_socket_identity=bridge_socket_identity,
            bridge_peer_identity=bridge_peer_identity,
            deadline=deadline,
        )
        second_titles = [self._window_title(row) for row in second_rows]
        if any(
            title != _KNOWN_WHITE_AUXILIARY_TITLE and self._is_blocking_title(title)
            for title in second_titles
        ):
            raise FusionRuntimeGuardError(
                "Fusion acquired a loading, recovery, save, or security window"
            )
        if require_clean_start and self._modified_document_titles(second_titles):
            raise FusionRuntimeGuardError(
                "Fusion acquired a modified document during startup verification"
            )
        window_id, bounds = self._stable_auxiliary_window(first_rows, second_rows)
        primary_window_id, primary_title, primary_bounds = (
            self._stable_primary_fusion_window(first_rows, second_rows)
        )

        with tempfile.TemporaryDirectory(prefix="fusion-mcp-auxiliary-") as directory:
            directory_metadata = Path(directory).stat()
            if (
                directory_metadata.st_uid != os.geteuid()
                or not stat.S_ISDIR(directory_metadata.st_mode)
                or stat.S_IMODE(directory_metadata.st_mode) != 0o700
            ):
                raise FusionRuntimeGuardError(
                    "Peekaboo auxiliary screenshot directory is not owner-only"
                )
            screenshot_path = str(Path(directory) / "window.png")
            screenshot = self._json(
                [
                    "image",
                    "--pid",
                    str(identity.pid),
                    "--mode",
                    "window",
                    "--window-id",
                    str(window_id),
                    # Peekaboo's auto engine can select ScreenCaptureKit for this
                    # non-composited off-screen helper and wait forever for a
                    # frame.  The CG path captures the exact CGWindow directly.
                    "--capture-engine",
                    "cg",
                    "--path",
                    screenshot_path,
                    "--format",
                    "png",
                ],
                "Peekaboo exact auxiliary window screenshot",
                bridge_socket=bridge_socket,
                bridge_socket_identity=bridge_socket_identity,
                bridge_peer_identity=bridge_peer_identity,
                # Peekaboo 3.2.1's signed on-demand daemon can leak its Swift
                # continuation when CG captures this non-composited helper.
                # Keep the owner-only bridge and its peer pinned around the
                # call, but make only this exact-window CG operation run in
                # the authenticated CLI process.  _json fails closed unless
                # Peekaboo's own JSON debug evidence confirms that host.
                require_local_in_process_runtime=(self.mode == "local-ondemand"),
                deadline=deadline,
            )
            if screenshot.get("success") is not True:
                raise FusionRuntimeGuardError(
                    "Peekaboo exact auxiliary screenshot lacks success evidence"
                )
            screenshot_file = Path(screenshot_path)
            try:
                file_metadata = screenshot_file.lstat()
                if (
                    file_metadata.st_uid != os.geteuid()
                    or not stat.S_ISREG(file_metadata.st_mode)
                    or file_metadata.st_nlink != 1
                    or file_metadata.st_size <= 0
                    or file_metadata.st_size > _MAX_SCREENSHOT_BYTES
                ):
                    raise FusionRuntimeGuardError(
                        "Peekaboo auxiliary screenshot file is invalid"
                    )
                screenshot_file.chmod(0o600)
                if stat.S_IMODE(screenshot_file.stat().st_mode) != 0o600:
                    raise FusionRuntimeGuardError(
                        "Peekaboo auxiliary screenshot file is not owner-only"
                    )
                payload = screenshot_file.read_bytes()
            except OSError as exc:
                raise FusionRuntimeGuardError(
                    "Peekaboo auxiliary screenshot file is unavailable"
                ) from exc
            blank_evidence = _png_blank_auxiliary_evidence(payload)
        third_rows, _ = self._window_census(
            identity,
            bridge_socket=bridge_socket,
            bridge_socket_identity=bridge_socket_identity,
            bridge_peer_identity=bridge_peer_identity,
            deadline=deadline,
        )
        third_titles = [self._window_title(row) for row in third_rows]
        if any(
            title != _KNOWN_WHITE_AUXILIARY_TITLE
            and self._is_blocking_title(title)
            for title in third_titles
        ):
            raise FusionRuntimeGuardError(
                "Fusion acquired a loading, recovery, save, or security window "
                "during auxiliary capture"
            )
        if require_clean_start and self._modified_document_titles(third_titles):
            raise FusionRuntimeGuardError(
                "Fusion acquired a modified document during auxiliary capture"
            )
        post_capture_window_id, post_capture_bounds = (
            self._stable_auxiliary_window(second_rows, third_rows)
        )
        post_capture_primary = self._stable_primary_fusion_window(
            second_rows, third_rows
        )
        if (
            (post_capture_window_id, post_capture_bounds) != (window_id, bounds)
            or post_capture_primary
            != (primary_window_id, primary_title, primary_bounds)
        ):
            raise FusionRuntimeGuardError(
                "Fusion auxiliary or primary canvas changed during capture"
            )
        return {
            "classification": "known-nonblocking-uniform-blank-auxiliary",
            "title": _KNOWN_WHITE_AUXILIARY_TITLE,
            "window_id": window_id,
            "bounds": list(bounds),
            "stable_census_count": 3,
            "screenshot_command_success": screenshot.get("success") is True,
            "screenshot": blank_evidence,
            "primary_canvas": {
                "title": primary_title,
                "window_id": primary_window_id,
                "bounds": list(primary_bounds),
                "stable_census_count": 3,
            },
        }

    def verify(
        self,
        identity: FusionProcessIdentity,
        *,
        require_clean_start: bool,
        deadline: float | None = None,
    ) -> dict[str, Any]:
        signed_identity: tuple[object, ...] | None = None
        if PeekabooWindowProbe.has_uninjected_runner_shape(self):
            signed_identity = PeekabooWindowProbe.signed_executable_identity(
                self, deadline=deadline
            )
            self.executable = str(signed_identity[0])
        bridge: dict[str, Any] | None = None
        bridge_socket: str | None = None
        bridge_socket_identity: tuple[object, ...] | None = None
        bridge_peer_identity: tuple[object, ...] | None = None
        bridge_host_kind: str | None = None
        if self.mode in {"bridge", "local-ondemand"}:
            if self.mode == "local-ondemand":
                bridge_socket = str(self._expected_local_ondemand_socket_path())
                bridge_socket_identity = self._local_ondemand_socket_identity(
                    bridge_socket
                )
                if signed_identity is None:
                    raise FusionRuntimeGuardError(
                        "Peekaboo local on-demand mode requires the production "
                        "signed-executable probe"
                    )
                bridge_peer_identity = self._observe_local_ondemand_peer_identity(
                    bridge_socket, deadline=deadline
                )
                self._validate_local_ondemand_peer_identity(
                    bridge_peer_identity, signed_identity, bridge_socket
                )
            bridge = self._json(
                ["bridge", "status"],
                "Peekaboo bridge status",
                bridge_socket=bridge_socket,
                bridge_socket_identity=bridge_socket_identity,
                bridge_peer_identity=bridge_peer_identity,
                deadline=deadline,
            )
            bridge_data = bridge.get("data", {})
            selected = bridge_data.get("selected", {})
            handshake = (
                selected.get("handshake", {}) if isinstance(selected, dict) else {}
            )
            expected_host_kind = (
                "gui" if self.mode == "bridge" else "onDemand"
            )
            if (
                not isinstance(selected, dict)
                or selected.get("source") != "remote"
                or not isinstance(handshake, dict)
                or handshake.get("hostKind") != expected_host_kind
            ):
                raise FusionRuntimeGuardError(
                    "Peekaboo Bridge host kind does not match the configured mode"
                )
            bridge_host_kind = expected_host_kind
            socket_value = selected.get("socketPath")
            if not isinstance(socket_value, str) or not socket_value.startswith("/"):
                raise FusionRuntimeGuardError(
                    "Peekaboo Bridge socket identity is unavailable"
                )
            if self.mode == "bridge":
                bridge_socket = socket_value
            else:
                if socket_value != bridge_socket:
                    raise FusionRuntimeGuardError(
                        "Peekaboo local on-demand socket selection drifted"
                    )
                client = bridge_data.get("client", {})
                permissions_summary = handshake.get("permissions", {})
                supported = handshake.get("supportedOperations")
                enabled = handshake.get("enabledOperations")
                if (
                    not isinstance(client, dict)
                    or client.get("bundleIdentifier")
                    != _PEEKABOO_CODESIGN_IDENTIFIER
                    or client.get("teamIdentifier") != _PEEKABOO_CODESIGN_TEAM
                    or handshake.get("build") != _PEEKABOO_LOCAL_ONDEMAND_BUILD
                    or not isinstance(permissions_summary, dict)
                    or any(
                        permissions_summary.get(name) is not True
                        for name in ("screenRecording", "accessibility", "postEvent")
                    )
                    or not isinstance(supported, list)
                    or not all(isinstance(item, str) for item in supported)
                    or not _PEEKABOO_LOCAL_ONDEMAND_OPERATIONS.issubset(supported)
                    or not isinstance(enabled, list)
                    or not all(isinstance(item, str) for item in enabled)
                    or not _PEEKABOO_LOCAL_ONDEMAND_OPERATIONS.issubset(enabled)
                ):
                    raise FusionRuntimeGuardError(
                        "Peekaboo local on-demand handshake is incomplete"
                    )
        permissions = self._json(
            ["permissions"],
            "Peekaboo permissions",
            bridge_socket=bridge_socket,
            bridge_socket_identity=bridge_socket_identity,
            bridge_peer_identity=bridge_peer_identity,
            deadline=deadline,
        )
        permission_data = permissions.get("data", {})
        expected_source = "local" if self.mode == "local" else "bridge"
        if permission_data.get("source") != expected_source:
            raise FusionRuntimeGuardError(
                "Peekaboo permission source does not match the configured mode"
            )
        rows = permission_data.get("permissions", [])
        if not isinstance(rows, list):
            raise FusionRuntimeGuardError("Peekaboo permissions payload is invalid")
        by_name = {
            str(row.get("name")): row
            for row in rows
            if isinstance(row, dict) and row.get("name")
        }
        required_names = {"Screen Recording", "Accessibility", "Event Synthesizing"}
        missing = sorted(
            name
            for name in required_names
            if name not in by_name or by_name[name].get("isGranted") is not True
        )
        if missing:
            raise FusionRuntimeGuardError(
                "required Peekaboo permissions are unavailable: " + ", ".join(missing)
            )
        applications = self._json(
            ["list", "apps"],
            "Peekaboo application census",
            bridge_socket=bridge_socket,
            bridge_socket_identity=bridge_socket_identity,
            bridge_peer_identity=bridge_peer_identity,
            deadline=deadline,
        )
        application_rows = applications.get("data", {}).get("applications", [])
        if not isinstance(application_rows, list):
            raise FusionRuntimeGuardError("Peekaboo application census is invalid")
        matching_applications = [
            row
            for row in application_rows
            if isinstance(row, dict) and row.get("processIdentifier") == identity.pid
        ]
        executable = identity.command.split(" -", 1)[0]
        app_suffix = "/Contents/MacOS/Autodesk Fusion"
        expected_bundle_path = executable[: -len(app_suffix)]
        if (
            len(matching_applications) != 1
            or matching_applications[0].get("bundleIdentifier")
            != "com.autodesk.fusion360"
            or matching_applications[0].get("bundlePath") != expected_bundle_path
        ):
            raise FusionRuntimeGuardError(
                "Peekaboo application identity does not match the MCP listener PID"
            )
        window_rows, _ = self._window_census(
            identity,
            bridge_socket=bridge_socket,
            bridge_socket_identity=bridge_socket_identity,
            bridge_peer_identity=bridge_peer_identity,
            deadline=deadline,
        )
        titles = [self._window_title(row) for row in window_rows]
        other_blocking = [
            title
            for title in titles
            if title != _KNOWN_WHITE_AUXILIARY_TITLE and self._is_blocking_title(title)
        ]
        if other_blocking:
            raise FusionRuntimeGuardError(
                "Fusion has an unresolved loading, recovery, save, or security window"
            )
        known_auxiliary_evidence: dict[str, Any] | None = None
        if _KNOWN_WHITE_AUXILIARY_TITLE in titles:
            known_auxiliary_evidence = self._prove_white_auxiliary(
                identity,
                first_rows=window_rows,
                require_clean_start=require_clean_start,
                bridge_socket=bridge_socket,
                bridge_socket_identity=bridge_socket_identity,
                bridge_peer_identity=bridge_peer_identity,
                deadline=deadline,
            )
        blocking = [
            title
            for title in titles
            if self._is_blocking_title(title)
            and not (
                title == _KNOWN_WHITE_AUXILIARY_TITLE
                and known_auxiliary_evidence is not None
            )
        ]
        if blocking:
            raise FusionRuntimeGuardError(
                "Fusion has an unresolved loading, recovery, save, or security window"
            )
        modified = self._modified_document_titles(titles)
        untitled = self._untitled_document_titles(titles)
        if require_clean_start and modified:
            raise FusionRuntimeGuardError(
                "Fusion has a pre-existing modified document; writer lease refused"
            )
        modified_windows = []
        for row in window_rows:
            title = self._window_title(row)
            if title not in modified:
                continue
            bounds = _window_bounds(row)
            modified_windows.append(
                {
                    "title": title,
                    "window_id": _window_id(row),
                    "bounds": list(bounds) if bounds is not None else None,
                    "is_main_window": (
                        row.get("isMainWindow") if isinstance(row, dict) else None
                    ),
                    "is_minimized": (
                        row.get("isMinimized") if isinstance(row, dict) else None
                    ),
                    "window_index": (
                        row.get("index") if isinstance(row, dict) else None
                    ),
                }
            )
        if signed_identity is not None and signed_identity != (
            PeekabooWindowProbe.signed_executable_identity(self, deadline=deadline)
        ):
            raise FusionRuntimeGuardError(
                "Peekaboo recovery executable changed during Fusion window proof"
            )
        return {
            "pid": identity.pid,
            "hostname": identity.hostname,
            "observed_at_unix": time.time(),
            "census_scope": "shallow-top-level-windows",
            "permission_source": expected_source,
            "window_count": len(window_rows),
            "window_titles": titles,
            "blocking_titles": [],
            "known_nonblocking_auxiliary": known_auxiliary_evidence,
            "peekaboo_executable_authenticated": signed_identity is not None,
            "modified_document_count": len(modified),
            "modified_document_windows": modified_windows,
            "untitled_document_count": len(untitled),
            "untitled_document_titles": untitled,
            "bridge_verified": bridge is not None,
            "bridge_host_kind": bridge_host_kind,
            "local_ondemand_bridge_verified": bridge_peer_identity is not None,
            "bridge_peer_pid": (
                bridge_peer_identity[0] if bridge_peer_identity is not None else None
            ),
            "bridge_peer_start_token": (
                bridge_peer_identity[2] if bridge_peer_identity is not None else None
            ),
            "bridge_socket_device": (
                bridge_socket_identity[1]
                if bridge_socket_identity is not None
                else None
            ),
            "bridge_socket_inode": (
                bridge_socket_identity[2]
                if bridge_socket_identity is not None
                else None
            ),
        }


class FusionOwnerLease:
    def __init__(
        self,
        identity: FusionProcessIdentity,
        *,
        node_id: str,
        state_directory: Path,
    ) -> None:
        self.identity = identity
        self.node_id = node_id
        self.state_directory = state_directory
        self._descriptor: int | None = None
        self.lease_id = str(uuid.uuid4())

    @property
    def lock_path(self) -> Path:
        return self.state_directory / (
            f"fusion-mcp-owner-{os.geteuid()}-{self.identity.pid}.lock"
        )

    def acquire(self) -> None:
        self.state_directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        directory_metadata = self.state_directory.stat()
        if (
            directory_metadata.st_uid != os.geteuid()
            or not stat.S_ISDIR(directory_metadata.st_mode)
            or stat.S_IMODE(directory_metadata.st_mode) != 0o700
        ):
            raise FusionRuntimeGuardError(
                "Fusion owner state directory must be owner-only mode 0700"
            )
        flags = os.O_RDWR | os.O_CREAT
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        descriptor = os.open(self.lock_path, flags, 0o600)
        try:
            metadata = os.fstat(descriptor)
            if (
                metadata.st_uid != os.geteuid()
                or not stat.S_ISREG(metadata.st_mode)
                or metadata.st_nlink != 1
                or stat.S_IMODE(metadata.st_mode) != 0o600
            ):
                raise FusionRuntimeGuardError("Fusion owner lock inode is unsafe")
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                raise FusionRuntimeGuardError(
                    "another MCP owner already holds this Fusion PID"
                ) from exc
            payload = {
                "schema": "fusion-mcp.owner-lease.v2",
                "lease_id": self.lease_id,
                "node_id": self.node_id,
                "fusion_pid": self.identity.pid,
                "fusion_start_time": self.identity.start_time,
                "fusion_start_token": self.identity.start_token,
                "proxy_pid": os.getpid(),
                "acquired_at_unix": time.time(),
            }
            encoded = (json.dumps(payload, sort_keys=True) + "\n").encode("utf-8")
            os.ftruncate(descriptor, 0)
            _write_all(descriptor, encoded)
            os.fsync(descriptor)
            self._descriptor = descriptor
        except BaseException:
            os.close(descriptor)
            raise

    def release(self) -> None:
        if self._descriptor is None:
            return
        fcntl.flock(self._descriptor, fcntl.LOCK_UN)
        os.close(self._descriptor)
        self._descriptor = None


class FusionRuntimeGuard:
    def __init__(
        self,
        process_probe: MacOSFusionProcessProbe,
        window_probe: PeekabooWindowProbe,
        *,
        node_id: str,
        state_directory: Path,
        timeout_seconds: float = 120.0,
        startup_timeout_seconds: float | None = None,
        dirty_recovery_receipt: Path | None = None,
        health_attestation_challenge: Path | None = None,
        lazy_activation: bool = False,
        allowed_releases: Collection[str] | None = None,
    ) -> None:
        self.process_probe = process_probe
        self.window_probe = window_probe
        self.node_id = node_id
        self.state_directory = state_directory
        self._canonical_state_directory = state_directory.expanduser().resolve(
            strict=False
        )
        if (
            dirty_recovery_receipt is not None
            or health_attestation_challenge is not None
        ):
            self.state_directory = self._canonical_state_directory
        if not math.isfinite(timeout_seconds) or not 0 < timeout_seconds <= 300:
            raise ValueError("timeout_seconds must be finite and between 0 and 300")
        self.timeout_seconds = timeout_seconds
        if startup_timeout_seconds is None:
            startup_timeout_seconds = timeout_seconds
        if (
            not math.isfinite(startup_timeout_seconds)
            or not 0 < startup_timeout_seconds <= 300
        ):
            raise ValueError(
                "startup_timeout_seconds must be finite and between 0 and 300"
            )
        self.startup_timeout_seconds = startup_timeout_seconds
        self.dirty_recovery_receipt = (
            Path(os.path.abspath(dirty_recovery_receipt.expanduser()))
            if dirty_recovery_receipt is not None
            else None
        )
        self.health_attestation_challenge = (
            Path(os.path.abspath(health_attestation_challenge.expanduser()))
            if health_attestation_challenge is not None
            else None
        )
        if (
            self.dirty_recovery_receipt is not None
            and self.health_attestation_challenge is not None
        ):
            raise ValueError(
                "dirty recovery and health identity attestation are mutually exclusive"
            )
        if self.health_attestation_challenge is not None and not lazy_activation:
            raise ValueError("health identity attestation requires lazy activation")
        self.lazy_activation = lazy_activation
        self.allowed_releases = (
            frozenset(allowed_releases) if allowed_releases is not None else None
        )
        if self.allowed_releases is not None and (
            not self.allowed_releases
            or any(
                not isinstance(value, str) or not value
                for value in self.allowed_releases
            )
        ):
            raise ValueError("allowed_releases must contain non-empty release strings")
        self.identity: FusionProcessIdentity | None = None
        self.lease: FusionOwnerLease | None = None
        self.retired = False
        self.retirement_reason: str | None = None
        self._request_lock = anyio.Lock()
        self._completed_operation_pending_delivery = False
        self._pending_delivery_id: int | str | None = None
        self._pending_delivery_probe_id: str | None = None
        self._delivery_flushed = False
        self._request_evidence: FusionRequestEvidence | None = None
        self._window_evidence: dict[str, Any] | None = None
        self._startup_deadline: float | None = None
        self._dirty_recovery_authorization: DirtyRecoveryAuthorization | None = None
        self._dirty_recovery_used_path: Path | None = None
        self._dirty_recovery_consumed = False
        self._dirty_recovery_bootstrap_phase = "initialize"
        self._dirty_recovery_window_binding: dict[str, Any] | None = None
        self._health_identity_authorization: HealthIdentityAuthorization | None = None
        self._health_identity_consumed = False
        self._health_preopen_rechecked = False
        self._health_post_initialize_rechecked = False
        self._entered = False
        self._activated = False
        self._active_request_deadline: float | None = None

    @property
    def startup_deadline(self) -> float:
        if self._startup_deadline is None:
            raise FusionRuntimeGuardError("Fusion runtime startup has not begun")
        return self._startup_deadline

    @property
    def _identity_digest(self) -> str:
        if self.identity is None:
            raise FusionRuntimeGuardError("Fusion runtime guard is not bound")
        return hashlib.sha256(self.identity.stable_key.encode("utf-8")).hexdigest()[:16]

    @property
    def retirement_path(self) -> Path:
        if self.identity is None:
            raise FusionRuntimeGuardError("Fusion runtime guard is not bound")
        return self.state_directory / (
            f"fusion-mcp-retired-{os.geteuid()}-{self.identity.pid}-"
            f"{self._identity_digest}.json"
        )

    @property
    def inflight_path(self) -> Path:
        if self.identity is None:
            raise FusionRuntimeGuardError("Fusion runtime guard is not bound")
        return self.state_directory / (
            f"fusion-mcp-inflight-{os.geteuid()}-{self.identity.pid}-"
            f"{self._identity_digest}.json"
        )

    @property
    def quarantine_path(self) -> Path:
        if self.identity is None:
            raise FusionRuntimeGuardError("Fusion runtime guard is not bound")
        return self.state_directory / (
            f"fusion-mcp-quarantined-{os.geteuid()}-{self.identity.pid}-"
            f"{self._identity_digest}.json"
        )

    @property
    def dirty_recovery_used_path(self) -> Path:
        if self._dirty_recovery_used_path is None:
            raise FusionRuntimeGuardError(
                "no dirty-document recovery authorization is active"
            )
        return self._dirty_recovery_used_path

    @staticmethod
    def _load_owner_only_receipt(path: Path) -> dict[str, Any]:
        """Read one pinned owner-only JSON inode without following a symlink."""
        try:
            path_metadata = os.lstat(path)
        except OSError as exc:
            raise FusionRuntimeGuardError(
                "dirty recovery receipt is unavailable"
            ) from exc
        if stat.S_ISLNK(path_metadata.st_mode):
            raise FusionRuntimeGuardError(
                "dirty recovery receipt must not be a symlink"
            )
        flags = os.O_RDONLY
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        try:
            descriptor = os.open(path, flags)
        except OSError as exc:
            raise FusionRuntimeGuardError(
                "dirty recovery receipt cannot be opened safely"
            ) from exc
        try:
            before = os.fstat(descriptor)
            if (
                before.st_dev != path_metadata.st_dev
                or before.st_ino != path_metadata.st_ino
                or before.st_uid != os.geteuid()
                or not stat.S_ISREG(before.st_mode)
                or before.st_nlink != 1
                or stat.S_IMODE(before.st_mode) != 0o600
                or not 0 < before.st_size <= _MAX_DIRTY_RECOVERY_RECEIPT_BYTES
            ):
                raise FusionRuntimeGuardError(
                    "dirty recovery receipt must be one owner-only mode 0600 regular inode"
                )
            chunks: list[bytes] = []
            remaining = _MAX_DIRTY_RECOVERY_RECEIPT_BYTES + 1
            while remaining > 0:
                chunk = os.read(descriptor, min(4096, remaining))
                if not chunk:
                    break
                chunks.append(chunk)
                remaining -= len(chunk)
            encoded = b"".join(chunks)
            after = os.fstat(descriptor)
            if (
                len(encoded) != before.st_size
                or len(encoded) > _MAX_DIRTY_RECOVERY_RECEIPT_BYTES
                or after.st_dev != before.st_dev
                or after.st_ino != before.st_ino
                or after.st_size != before.st_size
                or after.st_mtime_ns != before.st_mtime_ns
            ):
                raise FusionRuntimeGuardError(
                    "dirty recovery receipt changed while it was being read"
                )
        finally:
            os.close(descriptor)

        def unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
            result: dict[str, Any] = {}
            for key, value in pairs:
                if key in result:
                    raise ValueError("duplicate JSON object key")
                result[key] = value
            return result

        try:
            payload = json.loads(encoded, object_pairs_hook=unique_object)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            raise FusionRuntimeGuardError(
                "dirty recovery receipt is not strict JSON"
            ) from exc
        if not isinstance(payload, dict):
            raise FusionRuntimeGuardError(
                "dirty recovery receipt must be a JSON object"
            )
        return payload

    def _load_dirty_recovery_authorization(self) -> DirtyRecoveryAuthorization:
        if self.identity is None or self.dirty_recovery_receipt is None:
            raise FusionRuntimeGuardError(
                "dirty recovery authorization cannot be bound before Fusion identity"
            )
        payload = self._load_owner_only_receipt(self.dirty_recovery_receipt)
        expected_keys = {
            "schema",
            "node_id",
            "fusion_pid",
            "fusion_start_time",
            "fusion_start_token",
            "state_directory",
            "modified_document_title",
            "allowed_request",
            "expires_at_unix",
        }
        if set(payload) != expected_keys:
            raise FusionRuntimeGuardError(
                "dirty recovery receipt fields do not match the exact contract"
            )
        allowed = payload.get("allowed_request")
        if not isinstance(allowed, dict) or set(allowed) != {
            "tool",
            "arguments_sha256",
        }:
            raise FusionRuntimeGuardError(
                "dirty recovery receipt has no unique exact allowed request"
            )
        title = payload.get("modified_document_title")
        tool = allowed.get("tool")
        arguments_sha256 = allowed.get("arguments_sha256")
        expires = payload.get("expires_at_unix")
        expires_at_unix: float | None = None
        if not isinstance(expires, bool) and isinstance(expires, int | float):
            try:
                candidate_expiry = float(expires)
            except (OverflowError, ValueError):
                pass
            else:
                if math.isfinite(candidate_expiry):
                    expires_at_unix = candidate_expiry
        if (
            payload.get("schema") != _DIRTY_RECOVERY_RECEIPT_SCHEMA
            or payload.get("node_id") != self.node_id
            or isinstance(payload.get("fusion_pid"), bool)
            or not isinstance(payload.get("fusion_pid"), int)
            or payload.get("fusion_pid") != self.identity.pid
            or payload.get("fusion_start_time") != self.identity.start_time
            or payload.get("fusion_start_token") != self.identity.start_token
            or payload.get("state_directory") != str(self._canonical_state_directory)
            or not isinstance(title, str)
            or not title
            or len(title) > 500
            or PeekabooWindowProbe._modified_document_titles([title]) != [title]
            or not isinstance(tool, str)
            or not tool
            or len(tool) > 200
            or not isinstance(arguments_sha256, str)
            or _SHA256_PATTERN.fullmatch(arguments_sha256) is None
            or expires_at_unix is None
            or expires_at_unix <= time.time()
        ):
            raise FusionRuntimeGuardError(
                "dirty recovery receipt identity, request, title, or expiry is invalid"
            )
        canonical = json.dumps(
            payload,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
        receipt_sha256 = hashlib.sha256(canonical).hexdigest()
        used_path = self.state_directory / (
            f"fusion-mcp-dirty-recovery-used-{receipt_sha256}.json"
        )
        if os.path.lexists(used_path):
            raise FusionRuntimeGuardError(
                "dirty recovery receipt was already used or its marker is unsafe"
            )
        self._dirty_recovery_used_path = used_path
        return DirtyRecoveryAuthorization(
            receipt_sha256=receipt_sha256,
            modified_document_title=title,
            tool=tool,
            arguments_sha256=arguments_sha256,
            expires_at_unix=expires_at_unix,
            expires_at_monotonic=time.monotonic()
            + max(0.0, expires_at_unix - time.time()),
        )

    def _load_health_identity_authorization(self) -> HealthIdentityAuthorization:
        """Bind one controller challenge to this exact cell and Fusion start."""
        if self.identity is None or self.health_attestation_challenge is None:
            raise FusionRuntimeGuardError(
                "health identity challenge cannot be bound before Fusion identity"
            )
        challenge_path = self.health_attestation_challenge
        if (
            challenge_path.parent.resolve(strict=False)
            != self._canonical_state_directory
        ):
            raise FusionRuntimeGuardError(
                "health identity challenge must be in the exact cell state directory"
            )
        try:
            payload, _ = read_owner_only_json(
                challenge_path,
                label="health identity challenge",
            )
        except HealthAttestationError as exc:
            raise FusionRuntimeGuardError(str(exc)) from exc
        expected_keys = {
            "schema",
            "nonce",
            "incident_id",
            "incident_manifest_sha256",
            "node_id",
            "state_directory",
            "fusion_identity",
            "allowed_request",
            "receipt_path",
            "expires_at_unix",
        }
        identity = payload.get("fusion_identity")
        allowed = payload.get("allowed_request")
        nonce = payload.get("nonce")
        incident_id = payload.get("incident_id")
        incident_digest = payload.get("incident_manifest_sha256")
        expires = payload.get("expires_at_unix")
        expires_at_unix: float | None = None
        if not isinstance(expires, bool) and isinstance(expires, int | float):
            try:
                candidate_expiry = float(expires)
            except (OverflowError, ValueError):
                pass
            else:
                if math.isfinite(candidate_expiry):
                    expires_at_unix = candidate_expiry
        command_sha256 = hashlib.sha256(
            self.identity.command.encode("utf-8")
        ).hexdigest()
        if (
            set(payload) != expected_keys
            or payload.get("schema") != HEALTH_CHALLENGE_SCHEMA
            or not is_sha256(nonce)
            or not isinstance(incident_id, str)
            or not incident_id
            or len(incident_id) > 300
            or not is_sha256(incident_digest)
            or payload.get("node_id") != self.node_id
            or payload.get("state_directory") != str(self._canonical_state_directory)
            or not isinstance(identity, dict)
            or set(identity)
            != {
                "pid",
                "start_time",
                "start_token",
                "release",
                "listener",
                "hostname",
                "command_sha256",
            }
            or identity.get("pid") != self.identity.pid
            or isinstance(identity.get("pid"), bool)
            or identity.get("start_time") != self.identity.start_time
            or identity.get("start_token") != self.identity.start_token
            or identity.get("release") != self.identity.release
            or identity.get("listener") != self.identity.listener
            or identity.get("hostname") != self.identity.hostname
            or identity.get("command_sha256") != command_sha256
            or not isinstance(allowed, dict)
            or set(allowed) != {"request_label", "tool", "arguments_sha256"}
            or allowed.get("request_label") != "health-document-read"
            or allowed.get("tool") != HEALTH_TOOL
            or allowed.get("arguments_sha256") != HEALTH_ARGUMENTS_SHA256
            or expires_at_unix is None
            or expires_at_unix <= time.time()
        ):
            raise FusionRuntimeGuardError(
                "health identity challenge does not match the exact cell, Fusion "
                "identity, or document-read request"
            )
        raw_receipt_path = payload.get("receipt_path")
        if not isinstance(raw_receipt_path, str) or not raw_receipt_path:
            raise FusionRuntimeGuardError(
                "health identity challenge has no receipt path"
            )
        receipt_path = Path(os.path.abspath(Path(raw_receipt_path).expanduser()))
        if (
            raw_receipt_path != str(receipt_path)
            or receipt_path.parent.resolve(strict=False)
            != self._canonical_state_directory
            or os.path.lexists(receipt_path)
        ):
            raise FusionRuntimeGuardError(
                "health identity receipt path is unsafe or already exists"
            )
        nonce_sha256 = sha256_hex(str(nonce).encode("ascii"))
        used_path = self.state_directory / (
            f"fusion-mcp-health-attestation-used-{nonce_sha256}.json"
        )
        if os.path.lexists(used_path):
            raise FusionRuntimeGuardError(
                "health identity challenge was already used or its marker is unsafe"
            )
        return HealthIdentityAuthorization(
            challenge_sha256=sha256_hex(health_canonical_bytes(payload)),
            nonce_sha256=nonce_sha256,
            incident_id=incident_id,
            incident_manifest_sha256=str(incident_digest),
            node_id=self.node_id,
            hostname=self.identity.hostname,
            command_sha256=command_sha256,
            receipt_path=receipt_path,
            used_path=used_path,
            expires_at_unix=expires_at_unix,
            expires_at_monotonic=time.monotonic()
            + max(0.0, expires_at_unix - time.time()),
        )

    def _consume_health_identity_request(
        self,
        *,
        delivery_id: int | str | None,
        request_evidence: FusionRequestEvidence,
    ) -> None:
        authorization = self._health_identity_authorization
        if authorization is None:
            return
        request_matches = (
            delivery_id is not None
            and request_evidence.request_id == delivery_id
            and request_evidence.tool == HEALTH_TOOL
            and request_evidence.arguments_sha256 == HEALTH_ARGUMENTS_SHA256
            and time.time() < authorization.expires_at_unix
            and time.monotonic() < authorization.expires_at_monotonic
        )
        payload = {
            "schema": HEALTH_USED_SCHEMA,
            "challenge_sha256": authorization.challenge_sha256,
            "nonce_sha256": authorization.nonce_sha256,
            "node_id": authorization.node_id,
            "fusion_pid": self.identity.pid if self.identity is not None else None,
            "fusion_start_time": (
                self.identity.start_time if self.identity is not None else None
            ),
            "fusion_start_token": (
                self.identity.start_token if self.identity is not None else None
            ),
            "proxy_pid": os.getpid(),
            "request_id": delivery_id,
            "tool": request_evidence.tool,
            "arguments_sha256": request_evidence.arguments_sha256,
            "request_matches_challenge": request_matches,
            "used_at_unix": time.time(),
        }
        try:
            self._create_marker(authorization.used_path, payload)
        except FileExistsError as exc:
            raise FusionRuntimeGuardError(
                "health identity challenge was already used or consumed concurrently"
            ) from exc
        self._health_identity_consumed = True
        if not request_matches:
            raise FusionRuntimeGuardError(
                "health identity challenge permits only its exact document read"
            )

    def _require_health_identity_still_valid(self) -> None:
        authorization = self._health_identity_authorization
        if authorization is not None and (
            time.time() >= authorization.expires_at_unix
            or time.monotonic() >= authorization.expires_at_monotonic
        ):
            raise FusionRuntimeGuardError(
                "health identity challenge expired before request completion"
            )

    def _authorized_modified_document_title(self) -> str | None:
        """The dirty-recovery-authorized modified window, if one was bound."""
        if self._dirty_recovery_authorization is not None:
            return self._dirty_recovery_authorization.modified_document_title
        return None

    def _verify_dirty_recovery_window_evidence(self, evidence: dict[str, Any]) -> None:
        expected_title = self._authorized_modified_document_title()
        if expected_title is None:
            return
        titles = evidence.get("window_titles")
        blocking = evidence.get("blocking_titles")
        modified_count = evidence.get("modified_document_count")
        modified_windows = evidence.get("modified_document_windows")
        authorized_window = (
            modified_windows[0]
            if isinstance(modified_windows, list) and len(modified_windows) == 1
            else None
        )
        if (
            isinstance(modified_count, bool)
            or not isinstance(modified_count, int)
            or modified_count != 1
            or blocking != []
            or not isinstance(titles, list)
            or any(not isinstance(title, str) for title in titles)
            or titles.count(expected_title) != 1
            or PeekabooWindowProbe._modified_document_titles(titles)
            != [expected_title]
            or not isinstance(authorized_window, dict)
            or set(authorized_window)
            != {
                "title",
                "window_id",
                "bounds",
                "is_main_window",
                "is_minimized",
                "window_index",
            }
            or authorized_window.get("title") != expected_title
            or isinstance(authorized_window.get("window_id"), bool)
            or not isinstance(authorized_window.get("window_id"), int)
            or authorized_window.get("window_id", 0) <= 0
            or not isinstance(authorized_window.get("bounds"), list)
            or len(authorized_window.get("bounds")) != 4
            or any(
                isinstance(value, bool) or not isinstance(value, int | float)
                for value in authorized_window.get("bounds")
            )
            or not all(
                math.isfinite(float(value)) for value in authorized_window.get("bounds")
            )
            or authorized_window.get("bounds")[2] <= 0
            or authorized_window.get("bounds")[3] <= 0
            or authorized_window.get("is_minimized") is not False
            or isinstance(authorized_window.get("window_index"), bool)
            or not isinstance(authorized_window.get("window_index"), int)
            or authorized_window.get("window_index") != 0
        ):
            raise FusionRuntimeGuardError(
                "dirty recovery startup does not have the one exact authorized modified window"
            )
        stable_window = {
            **authorized_window,
            "bounds": list(authorized_window["bounds"]),
        }
        if self._dirty_recovery_window_binding is None:
            self._dirty_recovery_window_binding = stable_window
        elif stable_window != self._dirty_recovery_window_binding:
            raise FusionRuntimeGuardError(
                "dirty recovery authorized window identity or bounds drifted"
            )

    def _consume_dirty_recovery_request(
        self,
        *,
        delivery_id: int | str | None,
        request_evidence: FusionRequestEvidence,
    ) -> None:
        authorization = self._dirty_recovery_authorization
        if authorization is None:
            return
        if self._dirty_recovery_consumed or os.path.lexists(
            self.dirty_recovery_used_path
        ):
            raise FusionRuntimeGuardError(
                "dirty recovery receipt permits exactly one forwarded request"
            )
        if delivery_id is None:
            expected_tool = self._dirty_recovery_bootstrap_phase
            if (
                expected_tool in {"initialize", "tools/list"}
                and request_evidence.tool == expected_tool
                and request_evidence.arguments_sha256 == _EMPTY_ARGUMENTS_SHA256
            ):
                return
            raise FusionRuntimeGuardError(
                "dirty recovery bootstrap order or empty-argument identity is invalid"
            )
        if self._dirty_recovery_bootstrap_phase != "complete":
            raise FusionRuntimeGuardError(
                "dirty recovery forwarded request arrived before bootstrap completed"
            )
        request_matches = (
            request_evidence.tool == authorization.tool
            and request_evidence.arguments_sha256 == authorization.arguments_sha256
            and time.time() < authorization.expires_at_unix
            and time.monotonic() < authorization.expires_at_monotonic
        )
        used_payload = {
            "schema": _DIRTY_RECOVERY_USED_SCHEMA,
            "receipt_sha256": authorization.receipt_sha256,
            "node_id": self.node_id,
            "fusion_pid": self.identity.pid if self.identity is not None else None,
            "fusion_start_time": (
                self.identity.start_time if self.identity is not None else None
            ),
            "fusion_start_token": (
                self.identity.start_token if self.identity is not None else None
            ),
            "proxy_pid": os.getpid(),
            "request_id": delivery_id,
            "tool": request_evidence.tool,
            "arguments_sha256": request_evidence.arguments_sha256,
            "request_matches_authorization": request_matches,
            "used_at_unix": time.time(),
        }
        try:
            self._create_marker(self.dirty_recovery_used_path, used_payload)
        except FileExistsError as exc:
            raise FusionRuntimeGuardError(
                "dirty recovery receipt was consumed concurrently"
            ) from exc
        self._dirty_recovery_consumed = True
        if not request_matches:
            raise FusionRuntimeGuardError(
                "first dirty recovery request does not match its exact authorization"
            )

    def _complete_dirty_recovery_bootstrap_request(
        self, request_evidence: FusionRequestEvidence
    ) -> None:
        if self._dirty_recovery_authorization is None:
            return
        expected_tool = self._dirty_recovery_bootstrap_phase
        if request_evidence.tool != expected_tool:
            raise FusionRuntimeGuardError(
                "dirty recovery bootstrap completion identity drifted"
            )
        self._dirty_recovery_bootstrap_phase = (
            "tools/list" if expected_tool == "initialize" else "complete"
        )

    def _require_dirty_recovery_request_still_valid(
        self, *, delivery_id: int | str | None
    ) -> None:
        authorization = self._dirty_recovery_authorization
        if (
            authorization is not None
            and delivery_id is not None
            and (
                time.time() >= authorization.expires_at_unix
                or time.monotonic() >= authorization.expires_at_monotonic
            )
        ):
            raise FusionRuntimeGuardError(
                "dirty recovery receipt expired before upstream forwarding"
            )

    def _load_matching_marker(self, path: Path, label: str) -> dict[str, Any] | None:
        if not path.is_file():
            return None
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise FusionRuntimeGuardError(f"Fusion {label} marker is invalid") from exc
        if not isinstance(payload, dict):
            raise FusionRuntimeGuardError(f"Fusion {label} marker is invalid")
        if (
            payload.get("fusion_pid") != self.identity.pid
            or payload.get("fusion_start_time") != self.identity.start_time
        ):
            raise FusionRuntimeGuardError(
                f"Fusion {label} marker identity does not match its bound path"
            )
        if payload.get("fusion_start_token") != self.identity.start_token:
            raise FusionRuntimeGuardError(
                f"Fusion {label} marker start token does not match its bound path"
            )
        return payload

    def _load_matching_retirement(self) -> dict[str, Any] | None:
        return self._load_matching_marker(self.retirement_path, "retirement")

    def _load_matching_inflight(self) -> dict[str, Any] | None:
        return self._load_matching_marker(self.inflight_path, "in-flight")

    def _load_matching_quarantine(self) -> dict[str, Any] | None:
        return self._load_matching_marker(self.quarantine_path, "quarantine")

    def _acquire_owner_lease(self) -> None:
        """Acquire this PID's lease and then close the marker-check race.

        An idle cell may keep its already-initialized, non-reconnecting upstream
        session while not owning the Fusion PID.  Every later upstream request
        must therefore reacquire the cross-process lease before revalidating the
        bound process/window.  Retirement, in-flight, and legacy quarantine
        markers are checked only after the flock is held: a crashed former
        owner can release the kernel lock before its durable ambiguity marker
        is observed.  Every such marker is terminal for that Fusion PID.
        """
        if self.identity is None:
            raise FusionRuntimeGuardError("Fusion runtime guard is not active")
        if self.lease is not None:
            return
        lease = FusionOwnerLease(
            self.identity,
            node_id=self.node_id,
            state_directory=self.state_directory,
        )
        lease.acquire()
        try:
            if (
                self._load_matching_retirement() is not None
                or self._load_matching_inflight() is not None
                or self._load_matching_quarantine() is not None
            ):
                self.retired = True
                raise FusionRuntimeRetiredError(
                    "this Fusion PID was retired or left in-flight by an earlier "
                    "MCP runtime, or quarantined by a legacy marker"
                )
        except BaseException:
            lease.release()
            raise
        self.lease = lease

    def release_idle_owner_lease(self) -> bool:
        """Release only a provably idle lease; never erase durable evidence.

        The initialized upstream session emits no background GET/reconnect
        traffic.  A completed client request remains non-idle until its response
        is flushed and acknowledged; only that acknowledgement path releases the
        lease while retaining the locally idle no-reconnect session.
        """
        if self.lease is None:
            return False
        if self.retired:
            raise FusionRuntimeGuardError(
                "retired Fusion runtime lease is not an idle lease"
            )
        if (
            self._request_evidence is not None
            or self._completed_operation_pending_delivery
            or self._pending_delivery_id is not None
            or self._pending_delivery_probe_id is not None
            or self._delivery_flushed
            or self._load_matching_inflight() is not None
        ):
            raise FusionRuntimeGuardError(
                "Fusion owner lease cannot be released while a request is active "
                "or awaiting delivery acknowledgement"
            )
        self.lease.release()
        self.lease = None
        return True

    def _activate(self, *, deadline: float) -> bool:
        """Bind the exact Fusion runtime once, under the caller's deadline.

        Lazy cells invoke this only for the first real upstream operation.  A
        local discovery/window/lease rejection leaves no in-flight marker and
        remains retryable; a pre-existing retirement or in-flight marker still
        retires the bound PID exactly as before.
        """
        if self._activated:
            return False
        if not self._entered:
            raise FusionRuntimeGuardError("Fusion runtime guard is not entered")
        if self.retired:
            raise FusionRuntimeRetiredError(
                "Fusion MCP runtime is retired; start a new Fusion PID before retrying"
            )
        self._startup_deadline = deadline
        try:
            self.identity = self.process_probe.discover(deadline=deadline)
            self._acquire_owner_lease()
            if (
                self.allowed_releases is not None
                and self.identity.release not in self.allowed_releases
            ):
                raise FusionRuntimeGuardError(
                    "Fusion release is not covered by the audited local MCP catalog: "
                    f"{self.identity.release}"
                )
            if self.dirty_recovery_receipt is not None:
                self._dirty_recovery_authorization = (
                    self._load_dirty_recovery_authorization()
                )
            if self.health_attestation_challenge is not None:
                self._health_identity_authorization = (
                    self._load_health_identity_authorization()
                )
            self._window_evidence = self.window_probe.verify(
                self.identity,
                require_clean_start=(
                    self._authorized_modified_document_title() is None
                ),
                deadline=deadline,
            )
            self._verify_dirty_recovery_window_evidence(self._window_evidence)
            if self.lazy_activation:
                # Close the discover-before-flock/window race *before* the
                # activation becomes durable or any request receipt is burned.
                # Failures here are still wholly local and retryable.
                observed = self.process_probe.discover(deadline=deadline)
                if (
                    observed.stable_key != self.identity.stable_key
                    or observed.release != self.identity.release
                ):
                    raise FusionRuntimeGuardError(
                        "Fusion listener/process/release identity changed during "
                        "lazy activation"
                    )
                if (
                    self.allowed_releases is not None
                    and observed.release not in self.allowed_releases
                ):
                    raise FusionRuntimeGuardError(
                        "Fusion release is not covered by the audited local MCP catalog"
                    )
                self._window_evidence = self.window_probe.verify(
                    self.identity,
                    require_clean_start=(
                        self._authorized_modified_document_title() is None
                    ),
                    deadline=deadline,
                )
                self._verify_dirty_recovery_window_evidence(self._window_evidence)
                if self._health_identity_authorization is not None:
                    self._health_preopen_rechecked = True
            # A lazy cell has no separate/eager upstream initialize/tools-list
            # bootstrap.  Its first forwarded stdio tools/call contains the
            # initialize and is the one request authorized by a dirty-recovery
            # receipt.
            if self.lazy_activation:
                self._dirty_recovery_bootstrap_phase = "complete"
            self._activated = True
        except BaseException:
            if self.lease is not None:
                self.lease.release()
                self.lease = None
            if not self.retired:
                self.identity = None
                self._window_evidence = None
                self._dirty_recovery_authorization = None
                self._dirty_recovery_used_path = None
                self._dirty_recovery_window_binding = None
                self._health_identity_authorization = None
                self._health_identity_consumed = False
                self._health_preopen_rechecked = False
                self._health_post_initialize_rechecked = False
            raise
        return True

    def __enter__(self) -> Self:
        if self._entered:
            raise FusionRuntimeGuardError("Fusion runtime guard is already entered")
        self._entered = True
        if self.lazy_activation:
            return self
        deadline = time.monotonic() + self.startup_timeout_seconds
        try:
            self._activate(deadline=deadline)
        except BaseException:
            self._entered = False
            raise
        return self

    def __exit__(self, *_: object) -> None:
        if self.lease is not None:
            self.lease.release()
            self.lease = None
        self._entered = False

    def _verify_bound_runtime(
        self, *, deadline: float, require_clean_start: bool = False
    ) -> None:
        if self.identity is None or self.lease is None:
            raise FusionRuntimeGuardError("Fusion runtime guard is not active")
        try:
            observed = self.process_probe.discover(deadline=deadline)
        except Exception as exc:
            reason = (
                "bound Fusion runtime preflight deadline expired"
                if isinstance(exc, TimeoutError)
                else "bound Fusion listener/process discovery failed"
            )
            self._retire(reason)
            raise FusionRuntimeRetiredError(
                "bound Fusion listener/process is unavailable; this proxy is retired"
            ) from exc
        if observed.stable_key != self.identity.stable_key:
            self._retire("Fusion listener PID or process start token changed")
            raise FusionRuntimeRetiredError(
                "Fusion listener identity changed; this proxy is retired"
            )
        if observed.release != self.identity.release:
            self._retire("Fusion release identity changed")
            raise FusionRuntimeRetiredError(
                "Fusion release identity changed; this proxy is retired"
            )
        if (
            self.allowed_releases is not None
            and observed.release not in self.allowed_releases
        ):
            self._retire("Fusion release left the audited local MCP catalog")
            raise FusionRuntimeRetiredError(
                "Fusion release is no longer covered by the audited local MCP "
                "catalog; this proxy is retired"
            )
        self._window_evidence = self.window_probe.verify(
            self.identity,
            require_clean_start=require_clean_start,
            deadline=deadline,
        )
        self._verify_dirty_recovery_window_evidence(self._window_evidence)

    def _enforce_untitled_preservation_request(
        self, request_evidence: FusionRequestEvidence
    ) -> None:
        evidence = self._window_evidence
        if not isinstance(evidence, dict):
            return
        reported = evidence.get("untitled_document_titles")
        if isinstance(reported, list) and all(
            isinstance(title, str) for title in reported
        ):
            untitled = list(reported)
        else:
            titles = evidence.get("window_titles")
            untitled = (
                PeekabooWindowProbe._untitled_document_titles(titles)
                if isinstance(titles, list)
                and all(isinstance(title, str) for title in titles)
                else []
            )
        if not untitled:
            return
        if request_evidence.preservation_role not in _UNTITLED_ALLOWED_REQUEST_ROLES:
            raise FusionRuntimeGuardError(
                "Fusion has an untitled/never-saved preservation obligation; "
                "this request is not an allowed inspect, destination-preflight, "
                "save-as, readback, or read-only operation"
            )

    def _incident_evidence(self) -> dict[str, Any]:
        if self.identity is None:
            raise FusionRuntimeGuardError("Fusion runtime guard is not bound")
        request = self._request_evidence
        return {
            "fusion_release": self.identity.release,
            "request_id": request.request_id if request is not None else "UNKNOWN",
            "tool": request.tool if request is not None else "UNKNOWN",
            "arguments_sha256": (
                request.arguments_sha256 if request is not None else "UNKNOWN"
            ),
            # The host-local cell intentionally does not inspect a document through
            # MCP after a failure.  These remain UNKNOWN until an external incident
            # collector binds stronger, pre-existing evidence.
            "document_identity": "UNKNOWN",
            "document_save_state": "UNKNOWN",
            "app_log_evidence": {
                "path": "UNKNOWN",
                "sha256": "UNKNOWN",
                "request_observed": "UNKNOWN",
            },
            "window_evidence": self._window_evidence or "UNKNOWN",
        }

    def _retire(self, reason: str) -> None:
        if self.identity is None or self.retired:
            return
        self.retired = True
        self.retirement_reason = reason
        self.state_directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        payload = {
            "schema": "fusion-mcp.retirement.v2",
            "node_id": self.node_id,
            "fusion_pid": self.identity.pid,
            "fusion_start_time": self.identity.start_time,
            "fusion_start_token": self.identity.start_token,
            "retired_at_unix": time.time(),
            "reason": reason[:500],
            **self._incident_evidence(),
        }
        self._create_marker(self.retirement_path, payload)

    def _triage_ambiguous_failure(self, reason: str) -> None:
        """Terminally retire one request whose outcome is not known.

        No post-failure MCP call or external window observation can prove that
        the failed operation did not commit.  The in-flight marker therefore
        remains durable and the bound Fusion PID can never be rebound.
        """
        self._retire(reason)

    def _create_marker(self, path: Path, payload: dict[str, Any]) -> None:
        """Create the first durable marker directly; a torn file fails closed."""
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        descriptor = os.open(path, flags, 0o600)
        try:
            _write_all(
                descriptor,
                (json.dumps(payload, sort_keys=True) + "\n").encode("utf-8"),
            )
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        self._fsync_state_directory()

    def _fsync_state_directory(self) -> None:
        directory_descriptor = os.open(self.state_directory, os.O_RDONLY)
        try:
            os.fsync(directory_descriptor)
        finally:
            os.close(directory_descriptor)

    def _write_inflight(self) -> None:
        if self.identity is None:
            raise FusionRuntimeGuardError("Fusion runtime guard is not bound")
        payload = {
            "schema": "fusion-mcp.in-flight.v2",
            "node_id": self.node_id,
            "fusion_pid": self.identity.pid,
            "fusion_start_time": self.identity.start_time,
            "fusion_start_token": self.identity.start_token,
            "proxy_pid": os.getpid(),
            "started_at_unix": time.time(),
            "phase": "upstream-in-flight",
            **self._incident_evidence(),
        }
        self._create_marker(self.inflight_path, payload)

    def _write_marker(self, path: Path, payload: dict[str, Any]) -> None:
        temporary = path.with_suffix(f".tmp-{os.getpid()}-{uuid.uuid4().hex}")
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        descriptor = os.open(temporary, flags, 0o600)
        try:
            _write_all(
                descriptor,
                (json.dumps(payload, sort_keys=True) + "\n").encode("utf-8"),
            )
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        os.replace(temporary, path)
        self._fsync_state_directory()

    def _set_inflight_phase(self, phase: str) -> None:
        payload = self._load_matching_inflight()
        if payload is None:
            raise FusionRuntimeGuardError("matching in-flight marker is missing")
        payload["phase"] = phase
        payload[f"{phase.replace('-', '_')}_at_unix"] = time.time()
        self._write_marker(self.inflight_path, payload)

    def _clear_inflight(self) -> None:
        if self._load_matching_inflight() is None:
            raise FusionRuntimeGuardError("matching in-flight marker is missing")
        self.inflight_path.unlink()
        self._fsync_state_directory()

    def mark_delivery_flushed(self, request_id: int | str) -> str | None:
        """Record that stdout flush succeeded but client consumption is unknown.

        A durable client-consumption ACK is not part of standard MCP stdio, so a
        flush alone must not erase the crash marker.  The caller emits the
        returned standard MCP ping challenge *after* that flush.  Only its exact
        response or an explicit extension ACK for the exact request completes
        delivery and lets the connection continue.  A later/pipelined request
        proves nothing about consumption of the earlier response.
        """
        if not self._completed_operation_pending_delivery:
            return None
        if request_id != self._pending_delivery_id:
            return None
        self._set_inflight_phase("response-flushed-awaiting-client-ack")
        self._delivery_flushed = True
        probe_id = DELIVERY_PROBE_ID_PREFIX + uuid.uuid4().hex
        self._pending_delivery_probe_id = probe_id
        return probe_id

    def acknowledge_delivery_probe(self, probe_id: int | str) -> bool:
        """Consume one server-originated ping response and release its lease."""
        if not isinstance(probe_id, str):
            return False
        if not probe_id.startswith(DELIVERY_PROBE_ID_PREFIX):
            return False
        if probe_id != self._pending_delivery_probe_id:
            # An explicit exact ACK may have completed delivery while this
            # already-emitted ping response was in flight.
            return True
        pending_request_id = self._pending_delivery_id
        if pending_request_id is None:
            return True
        return self.acknowledge_client_consumption(
            pending_request_id,
            acknowledgement_kind="standard_ping",
        )

    def _write_health_identity_attestation(
        self,
        *,
        request_id: int | str,
        acknowledgement_kind: str,
    ) -> None:
        authorization = self._health_identity_authorization
        if authorization is None:
            return
        try:
            marker = self._load_matching_inflight()
        except BaseException:
            self._retire(
                "health identity attestation could not verify its in-flight marker"
            )
            raise
        request = self._request_evidence
        if (
            self.identity is None
            or self.lease is None
            or self.retired
            or not self._health_identity_consumed
            or not self._health_preopen_rechecked
            or not self._health_post_initialize_rechecked
            or request is None
            or request.request_id != request_id
            or request.tool != HEALTH_TOOL
            or request.arguments_sha256 != HEALTH_ARGUMENTS_SHA256
            or marker is None
            or marker.get("phase") != "response-flushed-awaiting-client-ack"
            or acknowledgement_kind not in {"standard_ping", "explicit_notification"}
        ):
            self._retire(
                "health identity attestation preconditions failed before lease release"
            )
            raise FusionRuntimeGuardError(
                "health identity receipt preconditions are incomplete"
            )
        try:
            self._require_health_identity_still_valid()
        except BaseException:
            self._retire(
                "health identity challenge expired before attestation and lease release"
            )
            raise
        receipt = {
            "schema": HEALTH_RECEIPT_SCHEMA,
            "challenge_sha256": authorization.challenge_sha256,
            "nonce_sha256": authorization.nonce_sha256,
            "incident_id": authorization.incident_id,
            "incident_manifest_sha256": authorization.incident_manifest_sha256,
            "node_id": authorization.node_id,
            "fusion_identity": {
                "pid": self.identity.pid,
                "start_time": self.identity.start_time,
                "start_token": self.identity.start_token,
                "release": self.identity.release,
                "listener": self.identity.listener,
                "hostname": self.identity.hostname,
                "command_sha256": authorization.command_sha256,
            },
            "proxy_pid": os.getpid(),
            "request": {
                "request_id": request_id,
                "request_label": "health-document-read",
                "tool": request.tool,
                "arguments_sha256": request.arguments_sha256,
            },
            "guard_evidence": {
                "owner_lease_held": True,
                "preopen_identity_and_window_rechecked": True,
                "post_initialize_identity_and_window_rechecked": True,
                "selected_operation_completed": True,
                "response_flushed": True,
                "inflight_marker_phase": marker.get("phase"),
            },
            "acknowledgement": {
                "kind": acknowledgement_kind,
                "request_id": request_id,
            },
            "attested_at_unix": time.time(),
        }
        try:
            self._create_marker(authorization.receipt_path, receipt)
        except BaseException as exc:
            self._retire(
                "health identity attestation could not be written before lease release"
            )
            if isinstance(exc, FileExistsError):
                raise FusionRuntimeGuardError(
                    "health identity attestation receipt already exists"
                ) from exc
            raise

    def acknowledge_client_consumption(
        self,
        request_id: int | str,
        *,
        acknowledgement_kind: str = "direct_exact_ack",
    ) -> bool:
        """Clear one completed marker after one exact explicit/probe ACK."""
        if not self._completed_operation_pending_delivery or not self._delivery_flushed:
            return False
        if request_id != self._pending_delivery_id:
            return False
        self._write_health_identity_attestation(
            request_id=request_id,
            acknowledgement_kind=acknowledgement_kind,
        )
        self._clear_inflight()
        self._completed_operation_pending_delivery = False
        self._pending_delivery_id = None
        self._pending_delivery_probe_id = None
        self._delivery_flushed = False
        self._request_evidence = None
        self.release_idle_owner_lease()
        return True

    def retire_ambiguous_delivery(self, reason: str) -> None:
        """Persist a response-boundary failure without touching Fusion again."""
        if not self._completed_operation_pending_delivery:
            return
        self._retire(reason)

    def verify_after_upstream_initialize(self) -> None:
        """Revalidate the bound runtime before the selected first operation.

        Lazy activation puts upstream MCP initialize inside the selected
        request's in-flight boundary.  Initialization can consume enough time
        for a dirty-recovery receipt to expire or for the PID/window binding to
        drift, so the real selected operation must not follow it unchecked.
        """
        deadline = self._active_request_deadline
        if deadline is None or self._request_evidence is None:
            raise FusionRuntimeGuardError(
                "no guarded Fusion request is active after upstream initialize"
            )
        self._require_dirty_recovery_request_still_valid(
            delivery_id=self._request_evidence.request_id
        )
        self._require_health_identity_still_valid()
        self._verify_bound_runtime(
            deadline=deadline,
            require_clean_start=(self._authorized_modified_document_title() is None),
        )
        self._enforce_untitled_preservation_request(self._request_evidence)
        self._require_dirty_recovery_request_still_valid(
            delivery_id=self._request_evidence.request_id
        )
        self._require_health_identity_still_valid()
        if self._health_identity_authorization is not None:
            self._health_post_initialize_rechecked = True

    async def run(
        self,
        operation: Callable[[], Awaitable[_T]],
        *,
        delivery_id: int | str | None,
        request_evidence: FusionRequestEvidence | None = None,
        deadline: float | None = None,
    ) -> _T:
        # A second request must not queue behind an in-flight Fusion request.
        # Queuing would let it cross an unseen timeout boundary and reach a PID
        # that should already be retired.
        try:
            self._request_lock.acquire_nowait()
        except anyio.WouldBlock as exc:
            raise FusionRuntimeGuardError(
                "another Fusion MCP request is in flight or awaiting response delivery"
            ) from exc
        try:
            now = time.monotonic()
            request_deadline = min(
                deadline if deadline is not None else math.inf,
                now + self.timeout_seconds,
                (
                    now + self.startup_timeout_seconds
                    if not self._activated
                    else math.inf
                ),
            )
            if self._completed_operation_pending_delivery:
                raise FusionRuntimeGuardError(
                    "another Fusion MCP request is in flight or awaiting response delivery"
                )
            if self.retired:
                raise FusionRuntimeRetiredError(
                    "Fusion MCP runtime is retired; start a new Fusion PID before retrying"
                )
            activated_now = self._activate(deadline=request_deadline)
            if not activated_now:
                self._acquire_owner_lease()
            request_evidence = request_evidence or FusionRequestEvidence.from_request(
                request_id=delivery_id,
                tool="UNKNOWN",
                arguments=None,
            )
            try:
                self._consume_dirty_recovery_request(
                    delivery_id=delivery_id,
                    request_evidence=request_evidence,
                )
                self._consume_health_identity_request(
                    delivery_id=delivery_id,
                    request_evidence=request_evidence,
                )
                self._request_evidence = request_evidence
                if not activated_now:
                    self._verify_bound_runtime(deadline=request_deadline)
                self._enforce_untitled_preservation_request(request_evidence)
                self._require_dirty_recovery_request_still_valid(
                    delivery_id=delivery_id
                )
                self._require_health_identity_still_valid()
                self._write_inflight()
            except BaseException:
                # A local authorization/window rejection made no upstream call.
                # It must not turn an idle global cell into a permanent owner.
                # Process identity failures retire while the lease is held, and
                # any durable/torn in-flight marker likewise fails closed.
                if not self.retired and self._load_matching_inflight() is None:
                    self._request_evidence = None
                    self.release_idle_owner_lease()
                raise
            try:
                remaining = _remaining_timeout(
                    request_deadline,
                    self.timeout_seconds,
                    "Fusion MCP request",
                )
                self._active_request_deadline = request_deadline
                with anyio.fail_after(remaining):
                    result = await operation()
                if delivery_id is None:
                    self._clear_inflight()
                    self._request_evidence = None
                    self._complete_dirty_recovery_bootstrap_request(request_evidence)
                else:
                    self._completed_operation_pending_delivery = True
                    self._pending_delivery_id = delivery_id
                    self._delivery_flushed = False
                    self._set_inflight_phase("completed-awaiting-response-flush")
                return result
            except BaseException as exc:
                # Cancellation can arrive from a disconnected stdio/SSH client.
                # Shield the durable terminal retirement write before
                # propagating it.  The in-flight marker deliberately remains;
                # neither an external census nor a health challenge may reopen
                # this Fusion PID after an ambiguous delivery.
                with anyio.CancelScope(shield=True):
                    await anyio.to_thread.run_sync(
                        self._triage_ambiguous_failure,
                        f"{type(exc).__name__}: {exc}",
                    )
                raise
            finally:
                self._active_request_deadline = None
        finally:
            self._request_lock.release()
