"""Run a bounded, serial acceptance plan against an MCP stdio command.

The command is launched directly from argv (never through a shell).  The
result distinguishes three independent layers for every tools/call request:

1. process/transport/protocol completion;
2. the MCP ``CallToolResult.isError`` flag;
3. an explicit inner ``success``/``error`` signal in structured or JSON text
   content.

Example::

    python -m fusion_mcp_proxy.acceptance_client \
      --plan acceptance-plan.json --output acceptance-report.json -- \
      /path/to/python -m fusion_mcp_proxy.cell_server ...

Calls are always issued one at a time.  An unexpected failure stops the plan;
the client never queues a later request behind an ambiguous request boundary.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import stat
import tempfile
import time
import uuid
from collections.abc import Iterable, Mapping, Sequence
from datetime import timedelta
from pathlib import Path
from typing import Any

import anyio
from mcp import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client
from mcp.shared.message import SessionMessage
from mcp.types import (
    CallToolResult,
    JSONRPCMessage,
    JSONRPCNotification,
    TextContent,
    Tool,
)

from .cell_server import CLIENT_ACK_NOTIFICATION
from .health_attestation import HealthAttestationError, read_owner_only_json, sha256_hex

DEFAULT_REQUIRED_TOOLS = (
    "fusion_mcp_electronics_read",
    "fusion_mcp_execute",
    "fusion_mcp_read",
    "fusion_mcp_update",
)
PLAN_SCHEMA = "fusion-mcp.stdio-acceptance-plan.v1"
REPORT_SCHEMA = "fusion-mcp.stdio-acceptance-report.v2"
CLIENT_ACK_EXPERIMENTAL_CAPABILITY = "fusionMcpCellDeliveryAck"
CELL_SERVER_NAME_PREFIX = "fusion-mcp-cell-"
_INNER_ERROR_KEYS = frozenset({"error", "exception", "traceback"})
_MAX_INNER_JSON_TEXT_BYTES = 1_000_000
_MAX_INNER_NODES = 10_000
_DEFAULT_MAX_SCHEMA_BYTES = 131_072
_MAX_TOOL_COUNT = 64
_MAX_TOOL_PAGES = 16


class AcceptanceInputError(ValueError):
    """The acceptance plan or client arguments are invalid."""


def _canonical_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")


def _sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _safe_error(exc: BaseException) -> dict[str, str]:
    message = " ".join(str(exc).split())
    return {
        "type": type(exc).__name__,
        "message": message[:1000] or type(exc).__name__,
    }


def _validate_plan(raw: object) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise AcceptanceInputError("acceptance plan must be a JSON object")
    if raw.get("schema") != PLAN_SCHEMA:
        raise AcceptanceInputError(f"acceptance plan schema must be {PLAN_SCHEMA}")

    required_raw = raw.get("required_tools", list(DEFAULT_REQUIRED_TOOLS))
    if (
        not isinstance(required_raw, list)
        or not required_raw
        or any(not isinstance(name, str) or not name for name in required_raw)
        or len(set(required_raw)) != len(required_raw)
    ):
        raise AcceptanceInputError("required_tools must be unique non-empty strings")

    calls_raw = raw.get("calls", [])
    if not isinstance(calls_raw, list):
        raise AcceptanceInputError("calls must be a JSON array")
    calls: list[dict[str, Any]] = []
    identifiers: set[str] = set()
    for index, raw_call in enumerate(calls_raw):
        if not isinstance(raw_call, dict):
            raise AcceptanceInputError(f"calls[{index}] must be a JSON object")
        identifier = raw_call.get("id")
        tool = raw_call.get("tool")
        arguments = raw_call.get("arguments", {})
        if not isinstance(identifier, str) or not identifier:
            raise AcceptanceInputError(f"calls[{index}].id must be non-empty")
        if identifier in identifiers:
            raise AcceptanceInputError(f"duplicate call id: {identifier}")
        identifiers.add(identifier)
        if not isinstance(tool, str) or not tool:
            raise AcceptanceInputError(f"calls[{index}].tool must be non-empty")
        if not isinstance(arguments, dict):
            raise AcceptanceInputError(f"calls[{index}].arguments must be an object")
        expect_mcp_error = raw_call.get("expect_mcp_error", False)
        if not isinstance(expect_mcp_error, bool):
            raise AcceptanceInputError(
                f"calls[{index}].expect_mcp_error must be boolean"
            )
        default_inner: bool | None = None if expect_mcp_error else True
        expect_inner_success = raw_call.get("expect_inner_success", default_inner)
        if expect_inner_success is not None and not isinstance(
            expect_inner_success, bool
        ):
            raise AcceptanceInputError(
                f"calls[{index}].expect_inner_success must be boolean or null"
            )
        capture_response = raw_call.get("capture_response", False)
        if not isinstance(capture_response, bool):
            raise AcceptanceInputError(
                f"calls[{index}].capture_response must be boolean"
            )
        calls.append(
            {
                "id": identifier,
                "tool": tool,
                "arguments": arguments,
                "expect_mcp_error": expect_mcp_error,
                "expect_inner_success": expect_inner_success,
                "capture_response": capture_response,
            }
        )

    return {
        "schema": PLAN_SCHEMA,
        "required_tools": sorted(required_raw),
        "calls": calls,
    }


def load_plan(path: Path) -> dict[str, Any]:
    """Load and validate one bounded JSON acceptance plan."""
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise AcceptanceInputError(f"cannot read acceptance plan: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise AcceptanceInputError("acceptance plan is not valid JSON") from exc
    return _validate_plan(raw)


def _nonempty_error_value(value: object) -> bool:
    return value not in (None, False, "", [], {})


def _inner_json_values(result: CallToolResult) -> list[object]:
    values: list[object] = []
    if result.structuredContent is not None:
        values.append(result.structuredContent)
    for content in result.content:
        if not isinstance(content, TextContent):
            continue
        encoded = content.text.encode("utf-8", errors="replace")
        if len(encoded) > _MAX_INNER_JSON_TEXT_BYTES:
            continue
        try:
            candidate: object = json.loads(content.text)
        except json.JSONDecodeError:
            continue
        # Some adapters wrap their JSON object in one JSON string layer.
        if isinstance(candidate, str):
            try:
                candidate = json.loads(candidate)
            except json.JSONDecodeError:
                pass
        values.append(candidate)
    return values


def analyze_inner_result(result: CallToolResult) -> dict[str, Any]:
    """Classify explicit inner success/error signals without guessing."""
    explicit_success: list[bool] = []
    error_paths: list[str] = []
    roots = _inner_json_values(result)
    stack: list[tuple[str, object]] = [
        (f"$[{index}]", value) for index, value in enumerate(roots)
    ]
    visited = 0
    while stack and visited < _MAX_INNER_NODES:
        path, value = stack.pop()
        visited += 1
        if isinstance(value, Mapping):
            for key, child in value.items():
                key_text = str(key)
                child_path = f"{path}.{key_text}"
                lowered = key_text.casefold()
                if lowered == "success" and isinstance(child, bool):
                    explicit_success.append(child)
                if lowered in _INNER_ERROR_KEYS and _nonempty_error_value(child):
                    error_paths.append(child_path)
                stack.append((child_path, child))
        elif isinstance(value, Sequence) and not isinstance(
            value, (str, bytes, bytearray)
        ):
            stack.extend(
                (f"{path}[{index}]", child) for index, child in enumerate(value)
            )

    truncated = bool(stack)
    if False in explicit_success or error_paths:
        status = "error"
    elif explicit_success and all(explicit_success):
        status = "success"
    else:
        status = "unreported"
    return {
        "status": status,
        "explicit_success_values": explicit_success,
        "error_paths": sorted(set(error_paths)),
        "json_root_count": len(roots),
        "nodes_examined": visited,
        "analysis_truncated": truncated,
    }


def _bounded_response(
    result: CallToolResult,
    *,
    capture: bool,
    max_response_bytes: int,
) -> dict[str, Any]:
    payload = result.model_dump(mode="json", by_alias=True, exclude_none=True)
    encoded = _canonical_bytes(payload)
    summary: dict[str, Any] = {
        "bytes": len(encoded),
        "sha256": _sha256(encoded),
        "captured": capture and len(encoded) <= max_response_bytes,
    }
    if summary["captured"]:
        summary["payload"] = payload
    elif capture:
        summary["omission_reason"] = "response exceeds max_response_bytes"
    else:
        summary["omission_reason"] = "capture_response is false"
    return summary


def _tool_summary(
    tools: Iterable[Tool], *, max_schema_bytes: int
) -> list[dict[str, Any]]:
    """Return content-addressed schemas without an unbounded report field."""
    summaries: list[dict[str, Any]] = []
    for tool in sorted(tools, key=lambda candidate: candidate.name):
        encoded = _canonical_bytes(tool.inputSchema)
        captured = len(encoded) <= max_schema_bytes
        schema: dict[str, Any] = {
            "bytes": len(encoded),
            "sha256": _sha256(encoded),
            "captured": captured,
        }
        if captured:
            schema["payload"] = tool.inputSchema
        else:
            schema["omission_reason"] = "schema exceeds max_schema_bytes"
        summaries.append(
            {
                "name": tool.name,
                "has_nonempty_input_schema": bool(tool.inputSchema),
                # Keep the top-level digest for compatibility with v1 readers.
                "input_schema_sha256": schema["sha256"],
                "input_schema": schema,
            }
        )
    return summaries


def _production_cell_identity(
    server_name: object,
    delivery_ack_method: str | None,
    *,
    expected_server_name: str | None = None,
) -> dict[str, Any]:
    """Validate the two non-negotiable production acceptance identities."""
    prefix_matches = (
        isinstance(server_name, str)
        and server_name.startswith(CELL_SERVER_NAME_PREFIX)
        and len(server_name) > len(CELL_SERVER_NAME_PREFIX)
    )
    exact_matches = expected_server_name is None or server_name == expected_server_name
    valid_server_name = prefix_matches and exact_matches
    ack_advertised = delivery_ack_method == CLIENT_ACK_NOTIFICATION
    return {
        "required": True,
        "status": "success" if valid_server_name and ack_advertised else "error",
        "server_name_prefix": CELL_SERVER_NAME_PREFIX,
        "server_name_matches": valid_server_name,
        "expected_server_name": expected_server_name,
        "server_name_exact_match": exact_matches,
        "delivery_ack_advertised": ack_advertised,
    }


def _delivery_ack_method(experimental: object) -> str | None:
    """Return an ACK method only when the server advertises the extension."""
    if not isinstance(experimental, Mapping):
        return None
    capability = experimental.get(CLIENT_ACK_EXPERIMENTAL_CAPABILITY)
    if not isinstance(capability, Mapping) or capability.get("version") != "1":
        return None
    method = capability.get("notification")
    return method if method == CLIENT_ACK_NOTIFICATION else None


async def _list_all_tools(session: ClientSession) -> list[Tool]:
    tools: list[Tool] = []
    cursor: str | None = None
    for _ in range(_MAX_TOOL_PAGES):
        result = await session.list_tools(cursor)
        tools.extend(result.tools)
        if len(tools) > _MAX_TOOL_COUNT:
            raise AcceptanceInputError(
                f"tool surface exceeds the {_MAX_TOOL_COUNT}-tool report bound"
            )
        cursor = result.nextCursor
        if cursor is None:
            return tools
    raise AcceptanceInputError(
        f"tool pagination exceeds the {_MAX_TOOL_PAGES}-page report bound"
    )


async def run_acceptance(
    plan: object,
    command_argv: Sequence[str],
    *,
    timeout_seconds: float = 150.0,
    cwd: Path | None = None,
    max_response_bytes: int = 65_536,
    max_schema_bytes: int = _DEFAULT_MAX_SCHEMA_BYTES,
    stderr_tail_chars: int = 4000,
    expected_server_name: str | None = None,
    identity_attestation_path: Path | None = None,
) -> dict[str, Any]:
    """Launch one stdio command and execute a validated serial plan."""
    validated = _validate_plan(plan)
    if not command_argv or not command_argv[0]:
        raise AcceptanceInputError("stdio command argv must not be empty")
    if not math.isfinite(timeout_seconds) or not 0 < timeout_seconds <= 600:
        raise AcceptanceInputError(
            "timeout_seconds must be finite and between 0 and 600"
        )
    if max_response_bytes <= 0:
        raise AcceptanceInputError("max_response_bytes must be positive")
    if max_schema_bytes <= 0:
        raise AcceptanceInputError("max_schema_bytes must be positive")
    if stderr_tail_chars < 0:
        raise AcceptanceInputError("stderr_tail_chars must not be negative")
    if expected_server_name is not None and (
        not expected_server_name.startswith(CELL_SERVER_NAME_PREFIX)
        or len(expected_server_name) <= len(CELL_SERVER_NAME_PREFIX)
    ):
        raise AcceptanceInputError("expected_server_name is not a Fusion cell name")
    if identity_attestation_path is not None:
        identity_attestation_path = Path(
            os.path.abspath(identity_attestation_path.expanduser())
        )

    argv = [str(value) for value in command_argv]
    argv_bytes = b"\0".join(value.encode("utf-8") for value in argv)
    report: dict[str, Any] = {
        "schema": REPORT_SCHEMA,
        "status": "running",
        "started_at_unix": time.time(),
        "plan_sha256": _sha256(_canonical_bytes(validated)),
        "command": {
            "executable": argv[0],
            "argument_count": len(argv) - 1,
            "argv_sha256": _sha256(argv_bytes),
            "cwd": str(cwd.resolve()) if cwd is not None else None,
            "shell_used": False,
        },
        "initialize": {"status": "not_started"},
        "tools_list": {"status": "not_started"},
        "calls_planned": len(validated["calls"]),
        "calls": [],
    }
    phase = "process_start"
    with tempfile.TemporaryFile(mode="w+", encoding="utf-8") as errlog:
        try:
            parameters = StdioServerParameters(
                command=argv[0],
                args=argv[1:],
                cwd=cwd,
            )
            async with stdio_client(parameters, errlog=errlog) as (
                read_stream,
                write_stream,
            ):
                async with ClientSession(
                    read_stream,
                    write_stream,
                    read_timeout_seconds=timedelta(seconds=timeout_seconds),
                ) as session:
                    phase = "initialize"
                    initialized = await session.initialize()
                    report["initialize"] = {
                        "status": "success",
                        "protocol_version": str(initialized.protocolVersion),
                        "server": initialized.serverInfo.model_dump(
                            mode="json", exclude_none=True
                        ),
                        "capabilities": initialized.capabilities.model_dump(
                            mode="json", exclude_none=True
                        ),
                    }
                    delivery_ack_method = _delivery_ack_method(
                        initialized.capabilities.experimental
                    )
                    report["initialize"]["delivery_ack_extension"] = {
                        "advertised": delivery_ack_method is not None,
                        "method": delivery_ack_method,
                    }
                    production_identity = _production_cell_identity(
                        initialized.serverInfo.name,
                        delivery_ack_method,
                        expected_server_name=expected_server_name,
                    )
                    report["initialize"]["production_acceptance"] = production_identity

                    tools_pass = False
                    if production_identity["status"] != "success":
                        report["stop_reason"] = (
                            "server is not an ACK-capable production Fusion MCP cell"
                        )
                    else:
                        phase = "tools_list"
                        tools = await _list_all_tools(session)
                        summaries = _tool_summary(
                            tools,
                            max_schema_bytes=max_schema_bytes,
                        )
                        names = {row["name"] for row in summaries}
                        missing = sorted(set(validated["required_tools"]) - names)
                        empty_schema = sorted(
                            row["name"]
                            for row in summaries
                            if row["name"] in validated["required_tools"]
                            and not row["has_nonempty_input_schema"]
                        )
                        oversized_schema = sorted(
                            row["name"]
                            for row in summaries
                            if row["name"] in validated["required_tools"]
                            and not row["input_schema"]["captured"]
                        )
                        tools_pass = (
                            not missing and not empty_schema and not oversized_schema
                        )
                        report["tools_list"] = {
                            "status": "success" if tools_pass else "error",
                            "tools": summaries,
                            "required_tools": validated["required_tools"],
                            "missing_required_tools": missing,
                            "required_tools_with_empty_schema": empty_schema,
                            "required_tools_with_oversized_schema": oversized_schema,
                            "max_schema_bytes": max_schema_bytes,
                        }
                        if not tools_pass:
                            report["stop_reason"] = (
                                "required tool surface is incomplete or not bounded"
                            )

                    if tools_pass:
                        for call in validated["calls"]:
                            phase = f"call:{call['id']}"
                            started = time.monotonic()
                            # Capture the private SDK counter only for the
                            # explicitly advertised cell extension. Ordinary
                            # MCP clients and servers have no delivery ACK.
                            request_id = (
                                session._request_id
                                if delivery_ack_method is not None
                                else None
                            )
                            call_report: dict[str, Any] = {
                                "id": call["id"],
                                "tool": call["tool"],
                                "arguments_sha256": _sha256(
                                    _canonical_bytes(call["arguments"])
                                ),
                                "expect_mcp_error": call["expect_mcp_error"],
                                "expect_inner_success": call["expect_inner_success"],
                                "layers": {
                                    "transport_protocol": {"status": "running"},
                                    "mcp_result": {"status": "not_started"},
                                    "inner_result": {"status": "not_started"},
                                },
                            }
                            report["calls"].append(call_report)
                            try:
                                result = await session.call_tool(
                                    call["tool"],
                                    call["arguments"],
                                    read_timeout_seconds=timedelta(
                                        seconds=timeout_seconds
                                    ),
                                )
                            except Exception as exc:
                                call_report["layers"]["transport_protocol"] = {
                                    "status": "error",
                                    "response_received": False,
                                    "error": _safe_error(exc),
                                }
                                call_report["verdict"] = "fail"
                                call_report["duration_ms"] = round(
                                    (time.monotonic() - started) * 1000, 3
                                )
                                report["stop_reason"] = (
                                    "transport/protocol failure; later calls suppressed"
                                )
                                break

                            inner = analyze_inner_result(result)
                            actual_mcp_error = bool(result.isError)
                            mcp_matches = actual_mcp_error == call["expect_mcp_error"]
                            expected_inner = call["expect_inner_success"]
                            if expected_inner is None:
                                inner_matches = True
                            elif expected_inner:
                                inner_matches = inner["status"] == "success"
                            else:
                                inner_matches = inner["status"] == "error"
                            call_report["layers"] = {
                                "transport_protocol": {
                                    "status": "success",
                                    "response_received": True,
                                },
                                "mcp_result": {
                                    "status": (
                                        "error" if actual_mcp_error else "success"
                                    ),
                                    "is_error": actual_mcp_error,
                                    "matches_expectation": mcp_matches,
                                },
                                "inner_result": {
                                    **inner,
                                    "matches_expectation": inner_matches,
                                },
                            }
                            call_report["response"] = _bounded_response(
                                result,
                                capture=call["capture_response"],
                                max_response_bytes=max_response_bytes,
                            )
                            passed = mcp_matches and inner_matches
                            ack_started = time.monotonic()
                            call_report["delivery_ack"] = {
                                "status": "running",
                                "explicit_notification_sent": False,
                                "confirmation": "standard_ping",
                                "confirmed": False,
                            }
                            ack_sent = False
                            try:
                                # Production identity validation above proves
                                # both values exist. Keep this local check so a
                                # refactor cannot silently weaken the boundary.
                                if delivery_ack_method is None or request_id is None:
                                    raise RuntimeError(
                                        "production delivery ACK identity is unavailable"
                                    )
                                await session._write_stream.send(
                                    SessionMessage(
                                        JSONRPCMessage(
                                            JSONRPCNotification(
                                                jsonrpc="2.0",
                                                method=delivery_ack_method,
                                                params={"requestId": request_id},
                                            )
                                        )
                                    )
                                )
                                ack_sent = True
                                # The session write stream is ordered. A ping
                                # response proves the preceding ACK was read,
                                # including for the final call before EOF.
                                await session.send_ping()
                            except Exception as exc:
                                call_report["delivery_ack"] = {
                                    "status": "error",
                                    "explicit_notification_sent": ack_sent,
                                    "confirmation": "standard_ping",
                                    "confirmed": False,
                                    "error": _safe_error(exc),
                                    "duration_ms": round(
                                        (time.monotonic() - ack_started) * 1000, 3
                                    ),
                                }
                                call_report["delivery_ack_sent"] = ack_sent
                                passed = False
                                report["stop_reason"] = (
                                    "delivery ACK confirmation failed; "
                                    "later calls suppressed"
                                )
                            else:
                                call_report["delivery_ack"] = {
                                    "status": "success",
                                    "explicit_notification_sent": True,
                                    "confirmation": "standard_ping",
                                    "confirmed": True,
                                    "duration_ms": round(
                                        (time.monotonic() - ack_started) * 1000, 3
                                    ),
                                }
                                call_report["delivery_ack_sent"] = True
                            call_report["verdict"] = "pass" if passed else "fail"
                            call_report["duration_ms"] = round(
                                (time.monotonic() - started) * 1000, 3
                            )
                            if not passed and "stop_reason" not in report:
                                report["stop_reason"] = (
                                    "unexpected MCP or inner result; later calls suppressed"
                                )
                            if not passed:
                                break
        except Exception as exc:
            report["runtime_error"] = {
                "phase": phase,
                **_safe_error(exc),
            }
            if phase == "initialize":
                report["initialize"] = {
                    "status": "error",
                    "error": _safe_error(exc),
                }
            elif phase == "tools_list":
                report["tools_list"] = {
                    "status": "error",
                    "error": _safe_error(exc),
                }
            report.setdefault(
                "stop_reason",
                "process/transport/protocol failure; later calls suppressed",
            )
        finally:
            errlog.flush()
            errlog.seek(0)
            stderr_text = errlog.read()
            stderr_bytes = stderr_text.encode("utf-8", errors="replace")
            report["child_stderr"] = {
                "bytes": len(stderr_bytes),
                "sha256": _sha256(stderr_bytes),
                "tail": (stderr_text[-stderr_tail_chars:] if stderr_tail_chars else ""),
            }

    if identity_attestation_path is not None:
        try:
            attestation, encoded = read_owner_only_json(
                identity_attestation_path,
                label="health identity attestation receipt",
            )
        except HealthAttestationError as exc:
            report["identity_attestation"] = {
                "status": "error",
                "path": str(identity_attestation_path),
                "error": _safe_error(exc),
            }
            report.setdefault(
                "stop_reason",
                "health identity attestation receipt is unavailable or unsafe",
            )
        else:
            report["identity_attestation"] = {
                "status": "success",
                "path": str(identity_attestation_path),
                "bytes": len(encoded),
                "sha256": sha256_hex(encoded),
                "payload": attestation,
            }

    report["calls_completed"] = len(report["calls"])
    calls_pass = report["calls_completed"] == report["calls_planned"] and all(
        row.get("verdict") == "pass" for row in report["calls"]
    )
    passed = (
        report["initialize"].get("status") == "success"
        and report["tools_list"].get("status") == "success"
        and calls_pass
        and (
            identity_attestation_path is None
            or report.get("identity_attestation", {}).get("status") == "success"
        )
        and "runtime_error" not in report
    )
    report["status"] = "pass" if passed else "fail"
    report["finished_at_unix"] = time.time()
    return report


def _write_report(path: Path, report: dict[str, Any]) -> None:
    """Atomically replace one owner-only acceptance evidence file."""
    path = Path(os.path.abspath(path.expanduser()))
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    if path.is_symlink():
        raise AcceptanceInputError("acceptance report path must not be a symlink")
    if path.exists():
        metadata = path.stat()
        if not stat.S_ISREG(metadata.st_mode) or metadata.st_uid != os.geteuid():
            raise AcceptanceInputError(
                "existing acceptance report must be an owner-held regular file"
            )
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}-{uuid.uuid4().hex}")
    encoded = (
        json.dumps(
            report,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    )
    try:
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        descriptor = os.open(temporary, flags, 0o600)
        try:
            os.fchmod(descriptor, 0o600)
            with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
                descriptor = -1
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
        finally:
            if descriptor >= 0:
                os.close(descriptor)
        os.replace(temporary, path)
        directory_descriptor = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory_descriptor)
        finally:
            os.close(directory_descriptor)
    finally:
        temporary.unlink(missing_ok=True)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--cwd", type=Path)
    parser.add_argument("--timeout-seconds", type=float, default=150.0)
    parser.add_argument(
        "--expected-server-name",
        help="Require one exact fusion-mcp-cell-* server name before tools/list",
    )
    parser.add_argument("--max-response-bytes", type=int, default=65_536)
    parser.add_argument(
        "--max-schema-bytes", type=int, default=_DEFAULT_MAX_SCHEMA_BYTES
    )
    parser.add_argument("--stderr-tail-chars", type=int, default=4000)
    parser.add_argument(
        "command",
        nargs=argparse.REMAINDER,
        help="stdio server command and arguments, preceded by --",
    )
    return parser


def main() -> None:
    parser = _parser()
    args = parser.parse_args()
    command = args.command
    if command and command[0] == "--":
        command = command[1:]
    try:
        plan = load_plan(args.plan.expanduser().resolve())

        async def execute() -> dict[str, Any]:
            return await run_acceptance(
                plan,
                command,
                timeout_seconds=args.timeout_seconds,
                cwd=args.cwd.expanduser().resolve() if args.cwd else None,
                max_response_bytes=args.max_response_bytes,
                max_schema_bytes=args.max_schema_bytes,
                stderr_tail_chars=args.stderr_tail_chars,
                expected_server_name=args.expected_server_name,
            )

        report = anyio.run(execute)
    except AcceptanceInputError as exc:
        parser.error(str(exc))
    if args.output is not None:
        _write_report(args.output, report)
    print(json.dumps(report, ensure_ascii=False, sort_keys=True))
    raise SystemExit(0 if report["status"] == "pass" else 1)


if __name__ == "__main__":
    main()
