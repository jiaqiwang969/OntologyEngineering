#include <QAbstractButton>
#include <QAbstractItemModel>
#include <QAbstractItemView>
#include <QApplication>
#include <QCoreApplication>
#include <QDialog>
#include <QDialogButtonBox>
#include <QGuiApplication>
#include <QItemSelectionModel>
#include <QLabel>
#include <QLineEdit>
#include <QMetaMethod>
#include <QMetaObject>
#include <QMetaProperty>
#include <QModelIndex>
#include <QObject>
#include <QPersistentModelIndex>
#include <QPointer>
#include <QPoint>
#include <QPushButton>
#include <QRadioButton>
#include <QRect>
#include <QScreen>
#include <QSlider>
#include <QTableWidget>
#include <QThread>
#include <QTimer>
#include <QTreeView>
#include <QWidget>
#include <QWindow>

#include <Core/Application/Application.h>
#include <Core/Application/Product.h>
#include <Core/UserInterface/Command.h>
#include <Core/UserInterface/CommandCreatedEvent.h>
#include <Core/UserInterface/CommandCreatedEventArgs.h>
#include <Core/UserInterface/CommandCreatedEventHandler.h>
#include <Core/UserInterface/CommandDefinition.h>
#include <Core/UserInterface/CommandDefinitions.h>
#include <Core/UserInterface/CommandInput.h>
#include <Core/UserInterface/CommandInputs.h>
#include <Core/UserInterface/SelectionCommandInput.h>
#include <Core/UserInterface/UserInterface.h>
#include <Fusion/Components/Component.h>
#include <Fusion/Components/Joint.h>
#include <Fusion/Fusion/Design.h>
#include <CoreGraphics/CoreGraphics.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <limits>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <memory>
#include <pthread.h>
#include <objc/message.h>
#include <objc/runtime.h>
#include <sstream>
#include <string>
#include <utility>
#include <unistd.h>
#include <vector>

#if defined(__aarch64__)
extern "C" void cad_agent_call_x8_sret_2(void* function,
                                          void* argument0,
                                          void* argument1,
                                          void* output);

__asm__(
    ".text\n"
    ".p2align 2\n"
    ".globl _cad_agent_call_x8_sret_2\n"
    "_cad_agent_call_x8_sret_2:\n"
    "mov x16, x0\n"
    "mov x0, x1\n"
    "mov x1, x2\n"
    "mov x8, x3\n"
    "br x16\n");
#endif

namespace {

std::string jsonEscape(const QString& value) {
    const QByteArray utf8 = value.toUtf8();
    std::ostringstream output;
    for (const unsigned char ch : utf8) {
        switch (ch) {
            case '"':
                output << "\\\"";
                break;
            case '\\':
                output << "\\\\";
                break;
            case '\b':
                output << "\\b";
                break;
            case '\f':
                output << "\\f";
                break;
            case '\n':
                output << "\\n";
                break;
            case '\r':
                output << "\\r";
                break;
            case '\t':
                output << "\\t";
                break;
            default:
                if (ch < 0x20) {
                    output << "\\u" << std::hex << std::setw(4)
                           << std::setfill('0') << static_cast<int>(ch)
                           << std::dec;
                } else {
                    output << static_cast<char>(ch);
                }
        }
    }
    return output.str();
}

std::string quoted(const QString& value) {
    return "\"" + jsonEscape(value) + "\"";
}

std::string quoted(const std::string& value) {
    return quoted(QString::fromUtf8(value.c_str(),
                                    static_cast<qsizetype>(value.size())));
}

std::string pointerString(const void* pointer) {
    std::ostringstream output;
    output << "0x" << std::hex << reinterpret_cast<std::uintptr_t>(pointer);
    return output.str();
}

const char* methodTypeName(QMetaMethod::MethodType type) {
    switch (type) {
        case QMetaMethod::Method:
            return "method";
        case QMetaMethod::Signal:
            return "signal";
        case QMetaMethod::Slot:
            return "slot";
        case QMetaMethod::Constructor:
            return "constructor";
    }
    return "unknown";
}

const char* accessName(QMetaMethod::Access access) {
    switch (access) {
        case QMetaMethod::Private:
            return "private";
        case QMetaMethod::Protected:
            return "protected";
        case QMetaMethod::Public:
            return "public";
    }
    return "unknown";
}

void appendMetaObject(std::ostringstream& output, const QObject* object) {
    const QMetaObject* meta = object->metaObject();
    output << ",\"meta_object\":{"
           << "\"class\":" << quoted(QString::fromLatin1(meta->className()))
           << ",\"method_offset\":" << meta->methodOffset()
           << ",\"method_count\":" << meta->methodCount()
           << ",\"property_offset\":" << meta->propertyOffset()
           << ",\"property_count\":" << meta->propertyCount()
           << ",\"methods\":[";

    bool firstMethod = true;
    for (int index = meta->methodOffset(); index < meta->methodCount(); ++index) {
        const QMetaMethod method = meta->method(index);
        if (!firstMethod) {
            output << ",";
        }
        firstMethod = false;
        output << "{"
               << "\"index\":" << index << ","
               << "\"signature\":"
               << quoted(QString::fromLatin1(method.methodSignature())) << ","
               << "\"name\":" << quoted(QString::fromLatin1(method.name()))
               << ",\"type\":\"" << methodTypeName(method.methodType()) << "\""
               << ",\"access\":\"" << accessName(method.access()) << "\""
               << ",\"return_type\":"
               << quoted(QString::fromLatin1(method.typeName() == nullptr
                                                 ? ""
                                                 : method.typeName()))
               << "}";
    }
    output << "],\"properties\":[";

    bool firstProperty = true;
    for (int index = meta->propertyOffset(); index < meta->propertyCount();
         ++index) {
        const QMetaProperty property = meta->property(index);
        if (!firstProperty) {
            output << ",";
        }
        firstProperty = false;
        output << "{"
               << "\"index\":" << index << ","
               << "\"name\":" << quoted(QString::fromLatin1(property.name()))
               << ",\"type\":"
               << quoted(QString::fromLatin1(property.typeName() == nullptr
                                                 ? ""
                                                 : property.typeName()))
               << ",\"readable\":" << (property.isReadable() ? "true" : "false")
               << ",\"writable\":" << (property.isWritable() ? "true" : "false")
               << "}";
    }
    output << "]}";
}

bool looksLikeMotionStudy(const QWidget* widget) {
    if (widget == nullptr) {
        return false;
    }
    const QString className =
        QString::fromLatin1(widget->metaObject()->className());
    const QString title = widget->windowTitle();
    return className.contains(QStringLiteral("MotionStudy"),
                              Qt::CaseInsensitive) ||
           title.contains(QStringLiteral("Motion Study"),
                          Qt::CaseInsensitive) ||
           title.contains(QStringLiteral("运动分析"), Qt::CaseInsensitive);
}

QAbstractButton* motionStudyButton(QWidget* dialog,
                                   const QString& english,
                                   const QString& chinese) {
    if (dialog == nullptr) {
        return nullptr;
    }
    const auto buttons = dialog->findChildren<QAbstractButton*>();
    for (QAbstractButton* button : buttons) {
        const QString text = button->text();
        if (text.compare(english, Qt::CaseInsensitive) == 0 ||
            text == chinese) {
            return button;
        }
    }
    return nullptr;
}

bool motionStudyDialogReady(QWidget* dialog) {
    return dialog != nullptr && dialog->isVisible() &&
           dialog->findChildren<QTableWidget*>().size() == 1 &&
           dialog->findChildren<QSlider*>().size() == 1 &&
           motionStudyButton(
               dialog, QStringLiteral("OK"), QStringLiteral("确定")) !=
               nullptr &&
           motionStudyButton(dialog,
                             QStringLiteral("Cancel"),
                             QStringLiteral("取消")) != nullptr;
}

bool isExactMotionStudyDialog(const QWidget* widget) {
    return widget != nullptr && widget->isVisible() &&
           QString::fromLatin1(widget->metaObject()->className()) ==
               QStringLiteral("Na::QTMotionStudyDlg") &&
           motionStudyDialogReady(const_cast<QWidget*>(widget));
}

bool looksLikeFileRecovery(const QWidget* widget) {
    if (widget == nullptr) {
        return false;
    }
    const QString className =
        QString::fromLatin1(widget->metaObject()->className());
    return className == QStringLiteral("Nu::QTFileRecovery") &&
           widget->objectName() == QStringLiteral("QTFileRecovery") &&
           widget->isWindow() && widget->isModal();
}

QAbstractButton* fileRecoveryCloseButton(QWidget* dialog) {
    if (dialog == nullptr) {
        return nullptr;
    }
    return dialog->findChild<QAbstractButton*>(
        QStringLiteral("CloseButton2"));
}

struct LoadedImage {
    const mach_header* header = nullptr;
    std::uintptr_t base = 0;
    std::string path;
};

LoadedImage findLoadedImage(const std::string& pathSuffix) {
    const std::uint32_t count = _dyld_image_count();
    for (std::uint32_t index = 0; index < count; ++index) {
        const char* name = _dyld_get_image_name(index);
        if (name == nullptr) {
            continue;
        }
        const std::string path(name);
        if (path.size() < pathSuffix.size() ||
            path.compare(path.size() - pathSuffix.size(),
                         pathSuffix.size(),
                         pathSuffix) != 0) {
            continue;
        }
        const mach_header* header = _dyld_get_image_header(index);
        return {
            header,
            reinterpret_cast<std::uintptr_t>(header),
            path,
        };
    }
    return {};
}

bool loadedImageUuidMatches(
    const mach_header* header,
    const std::array<std::uint8_t, 16>& expected) {
    if (header == nullptr || header->magic != MH_MAGIC_64) {
        return false;
    }
    const auto* header64 = reinterpret_cast<const mach_header_64*>(header);
    const auto* command = reinterpret_cast<const load_command*>(
        reinterpret_cast<const std::uint8_t*>(header64) +
        sizeof(mach_header_64));
    for (std::uint32_t index = 0; index < header64->ncmds; ++index) {
        if (command->cmd == LC_UUID &&
            command->cmdsize >= sizeof(uuid_command)) {
            const auto* uuid = reinterpret_cast<const uuid_command*>(command);
            return std::memcmp(uuid->uuid,
                               expected.data(),
                               expected.size()) == 0;
        }
        if (command->cmdsize < sizeof(load_command)) {
            return false;
        }
        command = reinterpret_cast<const load_command*>(
            reinterpret_cast<const std::uint8_t*>(command) +
            command->cmdsize);
    }
    return false;
}

struct JointInjectionResult {
    int code = -100;
    std::string fusionVersion;
    std::string xlayerPath;
    std::string fusionXlayerPath;
    std::string naFusionUiPath;
    std::string nuClientBasePath;
    std::string nsDataModelPath;
    bool xlayerUuidMatches = false;
    bool fusionXlayerUuidMatches = false;
    bool naFusionUiUuidMatches = false;
    bool nuClientBaseUuidMatches = false;
    bool nsDataModelUuidMatches = false;
    bool helperPrefixMatches = false;
    bool callbackThunkMatches = false;
    bool selectionAccessorPrefixMatches = false;
    bool commandInputChangedPrefixMatches = false;
    bool jointOccurrenceAccessorPrefixMatches = false;
    bool strongRefConstructorPrefixMatches = false;
    bool strongRefDestructorPrefixMatches = false;
    bool motionStudySelectJointPrefixMatches = false;
    bool directDialogAppendPrefixMatches = false;
    bool directDialogFacadeAppendPrefixMatches = false;
    bool internalSelectionInputResolved = false;
    bool nativeCommandInputMatches = false;
    bool nativeDialogFacadeResolved = false;
    bool nativeDialogMatches = false;
    bool nativeDialogCallbackMatches = false;
    bool nativeEventGuardReady = false;
    bool selectionHasFocus = false;
    bool internalJointOccurrenceResolved = false;
    bool strongRefConstructed = false;
    bool motionStudySelectJointInvoked = false;
    bool commandInputChangedInvoked = false;
    bool directDialogAppendMode = false;
    bool directDialogAppendInvoked = false;
    std::string commandId;
    std::string inputId;
    std::string inputObjectType;
    std::size_t selectionMinimum = 0;
    std::size_t selectionMaximum = 0;
    std::size_t selectionBefore = 0;
    std::size_t selectionAfter = 0;
    std::size_t tokenMatchCount = 0;
    std::string jointName;
};

struct GripSnapshot {
    double step = 0.0;
    double plotValue = 0.0;
    double nativeValue = 0.0;
    int direction = -1;
    int style = -1;
    bool deleted = false;
};

struct PlotPointValue {
    double step = 0.0;
    double value = 0.0;
};

struct KeyframeInjectionResult {
    int code = -100;
    bool naFusionUiUuidMatches = false;
    bool selectCurvePrefixMatches = false;
    bool valueToDevicePrefixMatches = false;
    bool deviceToValuePrefixMatches = false;
    bool curvePickerSelectPrefixMatches = false;
    bool setValueTextPrefixMatches = false;
    bool setStepTextPrefixMatches = false;
    bool isStepValidPrefixMatches = false;
    bool coordStepChangedPrefixMatches = false;
    bool coordValueChangedPrefixMatches = false;
    bool getDofValuePrefixMatches = false;
    bool currentPositionPrefixMatches = false;
    bool dialogLayoutMatches = false;
    bool dialogVtableMatches = false;
    bool plotWidgetVtableMatches = false;
    bool rowVectorMatches = false;
    bool straightCurveVtableMatches = false;
    bool pickerVtablesMatch = false;
    bool pickerRelationshipsMatch = false;
    bool gripStorageMatches = false;
    bool gripPointersMatch = false;
    bool defaultEndpointsMatch = false;
    bool selectCurveInvoked = false;
    bool curvePickerSelectInvoked = false;
    bool editorResolved = false;
    bool editorClassMatches = false;
    bool valueEditResolved = false;
    bool stepEditResolved = false;
    bool parsedAngleMatches = false;
    bool valueTextSet = false;
    bool stepTextSet = false;
    bool stepValidated = false;
    bool coordStepChangedInvoked = false;
    bool coordValueChangedInvoked = false;
    bool selectedGripMatches = false;
    bool requestedStepMatches = false;
    bool requestedAngleMatches = false;
    int requestedStep = 0;
    int currentPosition = -1;
    double requestedAngleDegrees = 0.0;
    double requestedAngleRadians = 0.0;
    double parsedAngleRadians = 0.0;
    double rowCurrentNativeValue = 0.0;
    std::size_t rowCount = 0;
    std::size_t gripsBefore = 0;
    std::size_t gripsAfter = 0;
    QString editorClass;
    QString valueText;
    QString stepText;
    GripSnapshot selectedGrip;
    std::vector<GripSnapshot> grips;
};

struct MotionPointSpec {
    int step = 0;
    double angleDegrees = 0.0;
};

struct MotionJointSpec {
    std::string entityToken;
    std::string expectedName;
    std::vector<MotionPointSpec> points;
};

struct CurveReadbackResult {
    int code = -100;
    bool naFusionUiUuidMatches = false;
    bool dialogVtableMatches = false;
    bool rowVectorMatches = false;
    bool rowPointerMatches = false;
    bool straightCurveVtableMatches = false;
    bool curveDomainMatches = false;
    bool gripStorageMatches = false;
    bool gripPointersMatch = false;
    std::size_t rowCount = 0;
    std::vector<GripSnapshot> grips;
};

struct PersistedCurvePointSnapshot {
    double step = 0.0;
    double plotValue = 0.0;
    double nativeValue = 0.0;
    bool driver = false;
    bool deleted = false;
    std::size_t dependentPointCount = 0;
};

struct PersistedOperandSnapshot {
    std::string entityToken;
    std::string expectedName;
    std::string apiName;
    std::size_t tokenMatchCount = 0;
    bool apiJointResolved = false;
    bool internalJointResolved = false;
    bool operandJointResolved = false;
    bool jointMatches = false;
    int dofType = -1;
    double initialDofValue = 0.0;
    double currentDofValue = 0.0;
    bool visible = false;
    bool curveStorageMatches = false;
    bool pointsMatch = false;
    std::vector<PersistedCurvePointSnapshot> points;
};

struct PersistedMotionStudyReadbackResult {
    int code = -100;
    std::string fusionVersion;
    std::string fusionXlayerPath;
    std::string nsComponentPath;
    std::string nsDataModelPath;
    std::string nsTypesPath;
    bool fusionXlayerUuidMatches = false;
    bool nsComponentUuidMatches = false;
    bool nsDataModelUuidMatches = false;
    bool nsTypesUuidMatches = false;
    bool internalComponentPrefixMatches = false;
    bool jointOccurrencePrefixMatches = false;
    bool motionStudiesCountPrefixMatches = false;
    bool managedChildPrefixMatches = false;
    bool motionStudyOperandCountPrefixMatches = false;
    bool motionStudyOperandAtPrefixMatches = false;
    bool strongRefGetPrefixMatches = false;
    bool curveGripPointPrefixMatches = false;
    bool curveValuePrefixMatches = false;
    bool curveDriverPrefixMatches = false;
    bool curveDeletedPrefixMatches = false;
    bool pointXPrefixMatches = false;
    bool pointYPrefixMatches = false;
    bool rootComponentResolved = false;
    bool internalComponentResolved = false;
    bool motionStudiesResolved = false;
    bool motionStudiesVtableMatches = false;
    bool motionStudyResolved = false;
    bool motionStudyVtableMatches = false;
    std::size_t motionStudyCount = 0;
    std::size_t motionStudyIndex = 0;
    std::size_t operandCount = 0;
    std::size_t pointCount = 0;
    bool exactRecipeMatches = false;
    std::vector<PersistedOperandSnapshot> operands;
};

JointInjectionResult addJointToken(
    QWidget* dialog,
    const std::string& entityToken,
    bool directDialogAppend = false) noexcept {
    JointInjectionResult result;
    result.directDialogAppendMode = directDialogAppend;
    try {
        if (pthread_main_np() == 0 || dialog == nullptr ||
            entityToken.empty() || !isExactMotionStudyDialog(dialog)) {
            result.code = -1;
            return result;
        }

        const LoadedImage xlayer =
            findLoadedImage("/Libraries/Neutron/XLayerUI10.dylib");
        const LoadedImage fusionXlayer = findLoadedImage(
            "/Libraries/Applications/Fusion/FusionXLayer10.dylib");
        const LoadedImage naFusionUi = findLoadedImage(
            "/Libraries/Applications/Fusion/NaFusionUI10.dylib");
        const LoadedImage nuClientBase =
            findLoadedImage("/Libraries/Neutron/NuClientBase10.dylib");
        const LoadedImage nsDataModel =
            findLoadedImage("/Libraries/Neutron/NsDataModel10.dylib");
        result.xlayerPath = xlayer.path;
        result.fusionXlayerPath = fusionXlayer.path;
        result.naFusionUiPath = naFusionUi.path;
        result.nuClientBasePath = nuClientBase.path;
        result.nsDataModelPath = nsDataModel.path;

        constexpr std::array<std::uint8_t, 16> kExpectedXLayerUuid = {
            0x34, 0x1d, 0x49, 0x98, 0x39, 0x96, 0x3f, 0xd6,
            0x84, 0x53, 0xa2, 0x77, 0x3b, 0xa7, 0xfd, 0x97,
        };
        constexpr std::array<std::uint8_t, 16> kExpectedNaFusionUiUuid = {
            0x45, 0xf2, 0xe0, 0xc4, 0x1a, 0x4f, 0x36, 0xb8,
            0xa6, 0xd8, 0x63, 0x33, 0xa6, 0x8f, 0xba, 0xd1,
        };
        constexpr std::array<std::uint8_t, 16>
            kExpectedFusionXlayerUuid = {
                0xa7, 0xa5, 0x17, 0x68, 0xfe, 0xc5, 0x3f, 0x63,
                0x82, 0x53, 0x4e, 0x5b, 0x2f, 0x67, 0x08, 0xfb,
            };
        constexpr std::array<std::uint8_t, 16>
            kExpectedNuClientBaseUuid = {
                0xec, 0x0b, 0x3c, 0xd5, 0x12, 0xa4, 0x31, 0x4a,
                0xbf, 0xfe, 0x56, 0x46, 0x30, 0xc6, 0x9f, 0xfe,
            };
        constexpr std::array<std::uint8_t, 16>
            kExpectedNsDataModelUuid = {
                0xf1, 0x82, 0x10, 0xea, 0xcc, 0x00, 0x3a, 0x24,
                0x87, 0xf1, 0xfd, 0x48, 0xf9, 0x0f, 0x27, 0xca,
            };
        result.xlayerUuidMatches =
            loadedImageUuidMatches(xlayer.header, kExpectedXLayerUuid);
        result.fusionXlayerUuidMatches =
            loadedImageUuidMatches(fusionXlayer.header,
                                   kExpectedFusionXlayerUuid);
        result.naFusionUiUuidMatches =
            loadedImageUuidMatches(naFusionUi.header,
                                   kExpectedNaFusionUiUuid);
        result.nuClientBaseUuidMatches =
            loadedImageUuidMatches(nuClientBase.header,
                                   kExpectedNuClientBaseUuid);
        result.nsDataModelUuidMatches =
            loadedImageUuidMatches(nsDataModel.header,
                                   kExpectedNsDataModelUuid);
        if (!result.xlayerUuidMatches ||
            !result.fusionXlayerUuidMatches ||
            !result.naFusionUiUuidMatches ||
            !result.nuClientBaseUuidMatches ||
            !result.nsDataModelUuidMatches) {
            result.code = -2;
            return result;
        }

        constexpr std::uintptr_t kToApiCommandOffset = 0x000bffcc;
        constexpr std::uintptr_t kCallbackThunkOffset = 0x00427fd4;
        constexpr std::uintptr_t kSelectionAccessorOffset = 0x00134610;
        constexpr std::uintptr_t kCommandInputChangedOffset = 0x001baa48;
        constexpr std::uintptr_t kJointOccurrenceAccessorOffset =
            0x0024eb18;
        constexpr std::uintptr_t kStrongRefConstructorOffset =
            0x002a7010;
        constexpr std::uintptr_t kStrongRefDestructorOffset =
            0x002a71f4;
        constexpr std::uintptr_t kMotionStudySelectJointOffset =
            0x004282b4;
        constexpr std::uintptr_t kDirectDialogAppendOffset =
            0x0007ddb0;
        constexpr std::uintptr_t kDirectDialogFacadeAppendOffset =
            0x0167e5f0;
        constexpr std::array<std::uint8_t, 32> kExpectedHelperPrefix = {
            0xff, 0xc3, 0x00, 0xd1, 0xf4, 0x4f, 0x01, 0xa9,
            0xfd, 0x7b, 0x02, 0xa9, 0xfd, 0x83, 0x00, 0x91,
            0xf3, 0x03, 0x00, 0xaa, 0xe8, 0x0e, 0x00, 0xb0,
            0x08, 0x09, 0x41, 0xf9, 0x08, 0x01, 0x40, 0xf9,
        };
        const auto* helperAddress = reinterpret_cast<const std::uint8_t*>(
            xlayer.base + kToApiCommandOffset);
        result.helperPrefixMatches =
            std::memcmp(helperAddress,
                        kExpectedHelperPrefix.data(),
                        kExpectedHelperPrefix.size()) == 0;
        if (!result.helperPrefixMatches) {
            result.code = -3;
            return result;
        }
        constexpr std::array<std::uint8_t, 32>
            kExpectedSelectionAccessorPrefix = {
                0xff, 0x83, 0x00, 0xd1, 0xfd, 0x7b, 0x01, 0xa9,
                0xfd, 0x43, 0x00, 0x91, 0x48, 0x0b, 0x00, 0x90,
                0x08, 0x09, 0x41, 0xf9, 0x08, 0x01, 0x40, 0xf9,
                0xe8, 0x07, 0x00, 0xf9, 0xe8, 0x07, 0x40, 0xf9,
            };
        constexpr std::array<std::uint8_t, 32>
            kExpectedCommandInputChangedPrefix = {
                0xff, 0x83, 0x01, 0xd1, 0xf4, 0x4f, 0x04, 0xa9,
                0xfd, 0x7b, 0x05, 0xa9, 0xfd, 0x43, 0x01, 0x91,
                0xf3, 0x03, 0x00, 0xaa, 0x88, 0x86, 0x00, 0xd0,
                0x08, 0x19, 0x40, 0xf9, 0x08, 0x01, 0x40, 0xf9,
            };
        constexpr std::array<std::uint8_t, 32>
            kExpectedJointOccurrenceAccessorPrefix = {
                0xf8, 0x5f, 0xbc, 0xa9, 0xf6, 0x57, 0x01, 0xa9,
                0xf4, 0x4f, 0x02, 0xa9, 0xfd, 0x7b, 0x03, 0xa9,
                0xfd, 0xc3, 0x00, 0x91, 0xff, 0x83, 0x0c, 0xd1,
                0xf4, 0x03, 0x00, 0xaa, 0x68, 0x63, 0x00, 0xb0,
            };
        constexpr std::array<std::uint8_t, 32>
            kExpectedStrongRefConstructorPrefix = {
                0xff, 0xc3, 0x00, 0xd1, 0xf4, 0x4f, 0x01, 0xa9,
                0xfd, 0x7b, 0x02, 0xa9, 0xfd, 0x83, 0x00, 0x91,
                0xf3, 0x03, 0x00, 0xaa, 0x28, 0x1f, 0x00, 0xf0,
                0x08, 0xad, 0x43, 0xf9, 0x08, 0x01, 0x40, 0xf9,
            };
        constexpr std::array<std::uint8_t, 32>
            kExpectedStrongRefDestructorPrefix = {
                0xff, 0xc3, 0x00, 0xd1, 0xf4, 0x4f, 0x01, 0xa9,
                0xfd, 0x7b, 0x02, 0xa9, 0xfd, 0x83, 0x00, 0x91,
                0xf3, 0x03, 0x00, 0xaa, 0x28, 0x1f, 0x00, 0xf0,
                0x08, 0xad, 0x43, 0xf9, 0x08, 0x01, 0x40, 0xf9,
            };
        constexpr std::array<std::uint8_t, 32>
            kExpectedMotionStudySelectJointPrefix = {
                0xff, 0x83, 0x06, 0xd1, 0xf6, 0x57, 0x17, 0xa9,
                0xf4, 0x4f, 0x18, 0xa9, 0xfd, 0x7b, 0x19, 0xa9,
                0xfd, 0x43, 0x06, 0x91, 0xf4, 0x03, 0x01, 0xaa,
                0xf3, 0x03, 0x00, 0xaa, 0x88, 0xe9, 0x00, 0xb0,
            };
        constexpr std::array<std::uint8_t, 16>
            kExpectedDirectDialogAppendPrefix = {
            0xff, 0x43, 0x02, 0xd1, 0xf8, 0x5f, 0x05, 0xa9,
            0xf6, 0x57, 0x06, 0xa9, 0xf4, 0x4f, 0x07, 0xa9,
        };
        constexpr std::array<std::uint8_t, 64>
            kExpectedDirectDialogFacadeAppendPrefix = {
                0xff, 0x03, 0x01, 0xd1, 0xf4, 0x4f, 0x02, 0xa9,
                0xfd, 0x7b, 0x03, 0xa9, 0xfd, 0xc3, 0x00, 0x91,
                0xc8, 0x56, 0x00, 0xf0, 0x08, 0x15, 0x40, 0xf9,
                0x08, 0x01, 0x40, 0xf9, 0xe8, 0x0f, 0x00, 0xf9,
                0x13, 0x00, 0x40, 0xf9, 0xe0, 0x23, 0x00, 0x91,
                0x95, 0x12, 0x06, 0x94, 0xe1, 0x23, 0x00, 0x91,
                0xe0, 0x03, 0x13, 0xaa, 0xe3, 0xfd, 0xa7, 0x97,
                0xe0, 0x23, 0x00, 0x91, 0x93, 0x12, 0x06, 0x94,
            };
        result.selectionAccessorPrefixMatches =
            std::memcmp(
                reinterpret_cast<const std::uint8_t*>(
                    xlayer.base + kSelectionAccessorOffset),
                kExpectedSelectionAccessorPrefix.data(),
                kExpectedSelectionAccessorPrefix.size()) == 0;
        result.commandInputChangedPrefixMatches =
            std::memcmp(
                reinterpret_cast<const std::uint8_t*>(
                    nuClientBase.base + kCommandInputChangedOffset),
                kExpectedCommandInputChangedPrefix.data(),
                kExpectedCommandInputChangedPrefix.size()) == 0;
        result.jointOccurrenceAccessorPrefixMatches =
            std::memcmp(
                reinterpret_cast<const std::uint8_t*>(
                    fusionXlayer.base + kJointOccurrenceAccessorOffset),
                kExpectedJointOccurrenceAccessorPrefix.data(),
                kExpectedJointOccurrenceAccessorPrefix.size()) == 0;
        result.strongRefConstructorPrefixMatches =
            std::memcmp(
                reinterpret_cast<const std::uint8_t*>(
                    nsDataModel.base + kStrongRefConstructorOffset),
                kExpectedStrongRefConstructorPrefix.data(),
                kExpectedStrongRefConstructorPrefix.size()) == 0;
        result.strongRefDestructorPrefixMatches =
            std::memcmp(
                reinterpret_cast<const std::uint8_t*>(
                    nsDataModel.base + kStrongRefDestructorOffset),
                kExpectedStrongRefDestructorPrefix.data(),
                kExpectedStrongRefDestructorPrefix.size()) == 0;
        result.motionStudySelectJointPrefixMatches =
            std::memcmp(
                reinterpret_cast<const std::uint8_t*>(
                    naFusionUi.base + kMotionStudySelectJointOffset),
                kExpectedMotionStudySelectJointPrefix.data(),
                kExpectedMotionStudySelectJointPrefix.size()) == 0;
        result.directDialogAppendPrefixMatches =
            std::memcmp(
                reinterpret_cast<const std::uint8_t*>(
                    naFusionUi.base + kDirectDialogAppendOffset),
                kExpectedDirectDialogAppendPrefix.data(),
                kExpectedDirectDialogAppendPrefix.size()) == 0;
        result.directDialogFacadeAppendPrefixMatches =
            std::memcmp(
                reinterpret_cast<const std::uint8_t*>(
                    naFusionUi.base +
                    kDirectDialogFacadeAppendOffset),
                kExpectedDirectDialogFacadeAppendPrefix.data(),
                kExpectedDirectDialogFacadeAppendPrefix.size()) == 0;
        if (!result.selectionAccessorPrefixMatches ||
            !result.commandInputChangedPrefixMatches ||
            !result.jointOccurrenceAccessorPrefixMatches ||
            !result.strongRefConstructorPrefixMatches ||
            !result.strongRefDestructorPrefixMatches ||
            !result.motionStudySelectJointPrefixMatches ||
            (directDialogAppend &&
             (!result.directDialogAppendPrefixMatches ||
              !result.directDialogFacadeAppendPrefixMatches))) {
            result.code = -23;
            return result;
        }

        auto* callback = *reinterpret_cast<void**>(
            reinterpret_cast<char*>(dialog) + 0x58);
        if (callback == nullptr) {
            result.code = -4;
            return result;
        }
        auto* callbackVtable = *reinterpret_cast<std::uintptr_t**>(callback);
        result.callbackThunkMatches =
            callbackVtable != nullptr &&
            callbackVtable[0] ==
                naFusionUi.base + kCallbackThunkOffset;
        if (!result.callbackThunkMatches) {
            result.code = -5;
            return result;
        }

        using ToApiCommand =
            adsk::core::Command* (*)(const void* xInterfaceObject);
        const auto toApiCommand = reinterpret_cast<ToApiCommand>(
            xlayer.base + kToApiCommandOffset);
        auto* nativeCommand =
            reinterpret_cast<char*>(callback) - 0x620;
        adsk::core::Command* rawCommand =
            toApiCommand(nativeCommand + 0x10);
        if (rawCommand == nullptr) {
            result.code = -6;
            return result;
        }
        adsk::core::Ptr<adsk::core::Command> command(rawCommand, true);

        const auto definition = command->parentCommandDefinition();
        if (!definition) {
            result.code = -7;
            return result;
        }
        result.commandId = definition->id();
        if (result.commandId != "FusionMotionStudyCommand") {
            result.code = -8;
            return result;
        }

        const auto inputs = command->commandInputs();
        if (!inputs) {
            result.code = -9;
            return result;
        }
        const auto input = inputs->itemById("MotionStudyInput");
        if (!input) {
            result.code = -10;
            return result;
        }
        result.inputId = input->id();
        result.inputObjectType = input->objectType();
        const auto selection =
            input->cast<adsk::core::SelectionCommandInput>();
        if (!selection || !selection->isValid()) {
            result.code = -11;
            return result;
        }
        if (!selection->getSelectionLimits(result.selectionMinimum,
                                           result.selectionMaximum) ||
            result.selectionMinimum != 0 ||
            result.selectionMaximum != 1) {
            result.code = -12;
            return result;
        }
        result.selectionBefore = selection->selectionCount();
        if (!directDialogAppend && result.selectionBefore != 0) {
            result.code = -13;
            return result;
        }

        const auto application = adsk::core::Application::get();
        if (!application) {
            result.code = -14;
            return result;
        }
        result.fusionVersion = application->version();
        if (result.fusionVersion != "2704.1.36") {
            result.code = -15;
            return result;
        }
        const auto product = application->activeProduct();
        if (!product) {
            result.code = -16;
            return result;
        }
        const auto design = product->cast<adsk::fusion::Design>();
        if (!design) {
            result.code = -17;
            return result;
        }

        adsk::core::Ptr<adsk::fusion::Joint> joint;
        for (const auto& candidate :
             design->findEntityByToken(entityToken)) {
            if (!candidate) {
                continue;
            }
            const auto candidateJoint =
                candidate->cast<adsk::fusion::Joint>();
            if (!candidateJoint || !candidateJoint->isValid()) {
                continue;
            }
            joint = candidateJoint;
            ++result.tokenMatchCount;
        }
        if (result.tokenMatchCount != 1 || !joint) {
            result.code = -18;
            return result;
        }
        result.jointName = joint->name();

        using ToInternalSelectionInput =
            void* (*)(const adsk::core::SelectionCommandInput*);
        const auto toInternalSelectionInput =
            reinterpret_cast<ToInternalSelectionInput>(
                xlayer.base + kSelectionAccessorOffset);
        void* internalSelectionInput =
            toInternalSelectionInput(selection.get());
        result.internalSelectionInputResolved =
            internalSelectionInput != nullptr;
        if (!result.internalSelectionInputResolved) {
            result.code = -24;
            return result;
        }
        result.nativeCommandInputMatches =
            *reinterpret_cast<void**>(nativeCommand + 0x628) ==
            internalSelectionInput;
        void* nativeDialogFacade =
            *reinterpret_cast<void**>(nativeCommand + 0x630);
        result.nativeDialogFacadeResolved =
            nativeDialogFacade != nullptr;
        result.nativeDialogMatches =
            result.nativeDialogFacadeResolved &&
            *reinterpret_cast<void**>(nativeDialogFacade) == dialog;
        result.nativeDialogCallbackMatches =
            result.nativeDialogFacadeResolved &&
            *reinterpret_cast<void**>(
                reinterpret_cast<std::uint8_t*>(
                    nativeDialogFacade) +
                sizeof(void*)) == callback &&
            *reinterpret_cast<void**>(
                reinterpret_cast<std::uint8_t*>(dialog) + 0x58) ==
                callback;
        result.nativeEventGuardReady =
            *reinterpret_cast<const std::uint8_t*>(
                nativeCommand + 0x662) == 1;
        result.selectionHasFocus = selection->hasFocus();
        if (!result.nativeCommandInputMatches ||
            !result.nativeDialogFacadeResolved ||
            !result.nativeDialogMatches ||
            !result.nativeDialogCallbackMatches ||
            !result.nativeEventGuardReady ||
            !result.selectionHasFocus) {
            result.code = -27;
            return result;
        }

        // Public SelectionCommandInput::addSelection creates a generic
        // Ns::LogicalSelection. MotionStudyCmd accepts only the specialized
        // Ns::Comp::JointOccurrenceSelection. Follow Fusion's own
        // MotionStudyCmd::onSelectJoints route so the native command creates
        // that exact subtype, then emit the ordinary input-changed event.
        using ToInternalJointOccurrence = void* (*)(const void*);
        const auto toInternalJointOccurrence =
            reinterpret_cast<ToInternalJointOccurrence>(
                fusionXlayer.base +
                kJointOccurrenceAccessorOffset);
        const auto* publicJoint = reinterpret_cast<const std::uint8_t*>(
            joint.get());
        void* internalJointOccurrence =
            toInternalJointOccurrence(publicJoint + sizeof(void*));
        result.internalJointOccurrenceResolved =
            internalJointOccurrence != nullptr;
        if (!result.internalJointOccurrenceResolved) {
            result.code = -25;
            return result;
        }

        struct alignas(void*) OpaqueStrongRef {
            void* target = nullptr;
            void* crossSegmentReference = nullptr;
        };
        static_assert(sizeof(OpaqueStrongRef) == 16);

        using StrongRefConstructor = void (*)(void*, const void*);
        using StrongRefDestructor = void (*)(void*);
        const auto strongRefConstructor =
            reinterpret_cast<StrongRefConstructor>(
                nsDataModel.base + kStrongRefConstructorOffset);
        const auto strongRefDestructor =
            reinterpret_cast<StrongRefDestructor>(
                nsDataModel.base + kStrongRefDestructorOffset);

        OpaqueStrongRef strongJoint;
        strongRefConstructor(&strongJoint, internalJointOccurrence);
        struct StrongRefScope final {
            void* value = nullptr;
            StrongRefDestructor destroy = nullptr;
            ~StrongRefScope() {
                if (value != nullptr && destroy != nullptr) {
                    destroy(value);
                }
            }
        } strongRefScope{&strongJoint, strongRefDestructor};
        result.strongRefConstructed =
            strongJoint.target == internalJointOccurrence &&
            strongJoint.crossSegmentReference == nullptr;
        if (!result.strongRefConstructed) {
            result.code = -26;
            return result;
        }

        if (directDialogAppend) {
            using DirectDialogAppend = void (*)(void*, void*);
            const auto directDialogAppendFunction =
                reinterpret_cast<DirectDialogAppend>(
                    naFusionUi.base +
                    kDirectDialogFacadeAppendOffset);
            directDialogAppendFunction(nativeDialogFacade, &strongJoint);
            result.directDialogAppendInvoked = true;
            result.selectionAfter = selection->selectionCount();
            result.code = 0;
            return result;
        }

        using MotionStudySelectJoint = void (*)(void*, void*);
        const auto motionStudySelectJoint =
            reinterpret_cast<MotionStudySelectJoint>(
                naFusionUi.base + kMotionStudySelectJointOffset);
        motionStudySelectJoint(nativeCommand, &strongJoint);
        result.motionStudySelectJointInvoked = true;

        result.selectionAfter = selection->selectionCount();
        if (result.selectionAfter != result.selectionBefore + 1) {
            result.code = -20;
            return result;
        }

        using CommandInputChanged = void (*)(void*);
        const auto commandInputChanged =
            reinterpret_cast<CommandInputChanged>(
                nuClientBase.base + kCommandInputChangedOffset);
        commandInputChanged(internalSelectionInput);
        result.commandInputChangedInvoked = true;

        result.code = 0;
        return result;
    } catch (...) {
        result.code = -99;
        return result;
    }
}

using Prefix16 = std::array<std::uint8_t, 16>;

bool prefixMatches16(std::uintptr_t address,
                     const Prefix16& expected) {
    return address != 0 &&
           std::memcmp(reinterpret_cast<const void*>(address),
                       expected.data(),
                       expected.size()) == 0;
}

GripSnapshot snapshotGrip(const void* grip) {
    GripSnapshot snapshot;
    if (grip == nullptr) {
        return snapshot;
    }
    const auto* bytes = reinterpret_cast<const std::uint8_t*>(grip);
    snapshot.step = *reinterpret_cast<const double*>(bytes + 0x50);
    snapshot.plotValue = *reinterpret_cast<const double*>(bytes + 0x58);
    snapshot.nativeValue = *reinterpret_cast<const double*>(bytes + 0x70);
    snapshot.direction = *reinterpret_cast<const int*>(bytes + 0x3c);
    snapshot.style = *reinterpret_cast<const int*>(bytes + 0x40);
    snapshot.deleted = *reinterpret_cast<const bool*>(bytes + 0x60);
    return snapshot;
}

KeyframeInjectionResult addKeyframe(QWidget* dialog,
                                    int rowIndex,
                                    int requestedStep,
                                    double requestedAngleDegrees) noexcept {
    KeyframeInjectionResult result;
    result.requestedStep = requestedStep;
    result.requestedAngleDegrees = requestedAngleDegrees;
    result.requestedAngleRadians =
        requestedAngleDegrees * std::acos(-1.0) / 180.0;
    try {
        if (pthread_main_np() == 0 || dialog == nullptr ||
            !isExactMotionStudyDialog(dialog) || rowIndex < 0 ||
            requestedStep <= 0 || requestedStep >= 100 ||
            !std::isfinite(requestedAngleDegrees)) {
            result.code = -1;
            return result;
        }

        const LoadedImage naFusionUi = findLoadedImage(
            "/Libraries/Applications/Fusion/NaFusionUI10.dylib");
        constexpr std::array<std::uint8_t, 16>
            kExpectedNaFusionUiUuid = {
                0x45, 0xf2, 0xe0, 0xc4, 0x1a, 0x4f, 0x36, 0xb8,
                0xa6, 0xd8, 0x63, 0x33, 0xa6, 0x8f, 0xba, 0xd1,
            };
        result.naFusionUiUuidMatches =
            loadedImageUuidMatches(naFusionUi.header,
                                   kExpectedNaFusionUiUuid);
        if (!result.naFusionUiUuidMatches) {
            result.code = -2;
            return result;
        }

        constexpr std::uintptr_t kSelectCurveOffset = 0x0007dfd8;
        constexpr std::uintptr_t kValueToDeviceOffset = 0x000c6f60;
        constexpr std::uintptr_t kDeviceToValueOffset = 0x000c6ff0;
        constexpr std::uintptr_t kCurvePickerSelectOffset = 0x000ce78c;
        constexpr std::uintptr_t kSetValueTextOffset = 0x000d19f8;
        constexpr std::uintptr_t kSetStepTextOffset = 0x000d1a54;
        constexpr std::uintptr_t kIsStepValidOffset = 0x000d0fbc;
        constexpr std::uintptr_t kCoordStepChangedOffset = 0x000d16a8;
        constexpr std::uintptr_t kCoordValueChangedOffset = 0x000d117c;
        constexpr std::uintptr_t kGetDofValueOffset = 0x0007fc10;
        constexpr std::uintptr_t kCurrentPositionOffset = 0x0007c290;

        constexpr Prefix16 kSelectCurvePrefix = {
            0xff, 0xc3, 0x00, 0xd1, 0xf4, 0x4f, 0x01, 0xa9,
            0xfd, 0x7b, 0x02, 0xa9, 0xfd, 0x83, 0x00, 0x91,
        };
        constexpr Prefix16 kValueToDevicePrefix = {
            0xff, 0xc3, 0x01, 0xd1, 0xf4, 0x4f, 0x05, 0xa9,
            0xfd, 0x7b, 0x06, 0xa9, 0xfd, 0x83, 0x01, 0x91,
        };
        constexpr Prefix16 kDeviceToValuePrefix = {
            0xff, 0x03, 0x02, 0xd1, 0xe9, 0x23, 0x05, 0x6d,
            0xf4, 0x4f, 0x06, 0xa9, 0xfd, 0x7b, 0x07, 0xa9,
        };
        constexpr Prefix16 kCurvePickerSelectPrefix = {
            0xff, 0x43, 0x03, 0xd1, 0xe9, 0x23, 0x07, 0x6d,
            0xfa, 0x67, 0x08, 0xa9, 0xf8, 0x5f, 0x09, 0xa9,
        };
        constexpr Prefix16 kSetValueTextPrefix = {
            0xff, 0xc3, 0x00, 0xd1, 0xf4, 0x4f, 0x01, 0xa9,
            0xfd, 0x7b, 0x02, 0xa9, 0xfd, 0x83, 0x00, 0x91,
        };
        constexpr Prefix16 kSetStepTextPrefix = {
            0xff, 0x83, 0x00, 0xd1, 0xfd, 0x7b, 0x01, 0xa9,
            0xfd, 0x43, 0x00, 0x91, 0x48, 0x04, 0x01, 0x90,
        };
        constexpr Prefix16 kIsStepValidPrefix = {
            0xff, 0x43, 0x01, 0xd1, 0xe9, 0x23, 0x02, 0x6d,
            0xf4, 0x4f, 0x03, 0xa9, 0xfd, 0x7b, 0x04, 0xa9,
        };
        constexpr Prefix16 kCoordStepChangedPrefix = {
            0xff, 0x83, 0x01, 0xd1, 0xf6, 0x57, 0x03, 0xa9,
            0xf4, 0x4f, 0x04, 0xa9, 0xfd, 0x7b, 0x05, 0xa9,
        };
        constexpr Prefix16 kCoordValueChangedPrefix = {
            0xff, 0xc3, 0x03, 0xd1, 0xef, 0x3b, 0x08, 0x6d,
            0xed, 0x33, 0x09, 0x6d, 0xeb, 0x2b, 0x0a, 0x6d,
        };
        constexpr Prefix16 kGetDofValuePrefix = {
            0xff, 0x83, 0x03, 0xd1, 0xe9, 0x23, 0x08, 0x6d,
            0xfa, 0x67, 0x09, 0xa9, 0xf8, 0x5f, 0x0a, 0xa9,
        };
        constexpr Prefix16 kCurrentPositionPrefix = {
            0xff, 0x83, 0x00, 0xd1, 0xfd, 0x7b, 0x01, 0xa9,
            0xfd, 0x43, 0x00, 0x91, 0xe8, 0x06, 0x01, 0xb0,
        };

        result.selectCurvePrefixMatches = prefixMatches16(
            naFusionUi.base + kSelectCurveOffset,
            kSelectCurvePrefix);
        result.valueToDevicePrefixMatches = prefixMatches16(
            naFusionUi.base + kValueToDeviceOffset,
            kValueToDevicePrefix);
        result.deviceToValuePrefixMatches = prefixMatches16(
            naFusionUi.base + kDeviceToValueOffset,
            kDeviceToValuePrefix);
        result.curvePickerSelectPrefixMatches = prefixMatches16(
            naFusionUi.base + kCurvePickerSelectOffset,
            kCurvePickerSelectPrefix);
        result.setValueTextPrefixMatches = prefixMatches16(
            naFusionUi.base + kSetValueTextOffset,
            kSetValueTextPrefix);
        result.setStepTextPrefixMatches = prefixMatches16(
            naFusionUi.base + kSetStepTextOffset,
            kSetStepTextPrefix);
        result.isStepValidPrefixMatches = prefixMatches16(
            naFusionUi.base + kIsStepValidOffset,
            kIsStepValidPrefix);
        result.coordStepChangedPrefixMatches = prefixMatches16(
            naFusionUi.base + kCoordStepChangedOffset,
            kCoordStepChangedPrefix);
        result.coordValueChangedPrefixMatches = prefixMatches16(
            naFusionUi.base + kCoordValueChangedOffset,
            kCoordValueChangedPrefix);
        result.getDofValuePrefixMatches = prefixMatches16(
            naFusionUi.base + kGetDofValueOffset,
            kGetDofValuePrefix);
        result.currentPositionPrefixMatches = prefixMatches16(
            naFusionUi.base + kCurrentPositionOffset,
            kCurrentPositionPrefix);
        if (!result.selectCurvePrefixMatches ||
            !result.valueToDevicePrefixMatches ||
            !result.deviceToValuePrefixMatches ||
            !result.curvePickerSelectPrefixMatches ||
            !result.setValueTextPrefixMatches ||
            !result.setStepTextPrefixMatches ||
            !result.isStepValidPrefixMatches ||
            !result.coordStepChangedPrefixMatches ||
            !result.coordValueChangedPrefixMatches ||
            !result.getDofValuePrefixMatches ||
            !result.currentPositionPrefixMatches) {
            result.code = -3;
            return result;
        }

        auto* dialogBytes = reinterpret_cast<std::uint8_t*>(dialog);
        auto* plotWidget =
            *reinterpret_cast<void**>(dialogBytes + 0xd8);
        auto* gripPicker =
            *reinterpret_cast<void**>(dialogBytes + 0xe0);
        auto* curvePicker =
            *reinterpret_cast<void**>(dialogBytes + 0xe8);
        result.dialogVtableMatches =
            *reinterpret_cast<std::uintptr_t*>(dialog) ==
            naFusionUi.base + 0x022cfe78;
        result.plotWidgetVtableMatches =
            plotWidget != nullptr &&
            *reinterpret_cast<std::uintptr_t*>(plotWidget) ==
                naFusionUi.base + 0x0215b050;
        result.dialogLayoutMatches =
            result.dialogVtableMatches &&
            result.plotWidgetVtableMatches && gripPicker != nullptr &&
            curvePicker != nullptr &&
            *reinterpret_cast<void**>(
                reinterpret_cast<std::uint8_t*>(gripPicker) + 0x10) ==
                plotWidget &&
            *reinterpret_cast<void**>(
                reinterpret_cast<std::uint8_t*>(curvePicker) + 0x10) ==
                plotWidget &&
            *reinterpret_cast<void**>(
                reinterpret_cast<std::uint8_t*>(curvePicker) + 0x18) ==
                gripPicker;
        if (!result.dialogLayoutMatches) {
            result.code = -4;
            return result;
        }

        const auto gripPickerVtable =
            *reinterpret_cast<std::uintptr_t*>(gripPicker);
        const auto curvePickerVtable =
            *reinterpret_cast<std::uintptr_t*>(curvePicker);
        result.pickerVtablesMatch =
            gripPickerVtable == naFusionUi.base + 0x0215b590 &&
            curvePickerVtable == naFusionUi.base + 0x0215b420;
        result.pickerRelationshipsMatch = result.dialogLayoutMatches;
        if (!result.pickerVtablesMatch) {
            result.code = -5;
            return result;
        }

        const auto rowsBeginAddress = reinterpret_cast<std::uintptr_t>(
            *reinterpret_cast<void**>(dialogBytes + 0xc0));
        const auto rowsEndAddress = reinterpret_cast<std::uintptr_t>(
            *reinterpret_cast<void**>(dialogBytes + 0xc8));
        const bool rowAddressesValid =
            rowsBeginAddress != 0 && rowsEndAddress != 0 &&
            rowsBeginAddress % alignof(void*) == 0 &&
            rowsEndAddress % alignof(void*) == 0 &&
            rowsEndAddress >= rowsBeginAddress &&
            (rowsEndAddress - rowsBeginAddress) % sizeof(void*) == 0 &&
            (rowsEndAddress - rowsBeginAddress) / sizeof(void*) <= 64;
        auto** rowsBegin = reinterpret_cast<void**>(rowsBeginAddress);
        const auto tables = dialog->findChildren<QTableWidget*>();
        result.rowCount = rowAddressesValid
                              ? static_cast<std::size_t>(
                                    (rowsEndAddress - rowsBeginAddress) /
                                    sizeof(void*))
                              : 0;
        result.rowVectorMatches =
            rowAddressesValid && tables.size() == 1 &&
            static_cast<std::size_t>(tables.front()->rowCount()) ==
                result.rowCount &&
            static_cast<std::size_t>(rowIndex) < result.rowCount;
        if (!result.rowVectorMatches) {
            result.code = -6;
            return result;
        }

        void* row = rowsBegin[rowIndex];
        void* curve = row == nullptr
                          ? nullptr
                          : *reinterpret_cast<void**>(
                                reinterpret_cast<std::uint8_t*>(row) +
                                0x30);
        result.straightCurveVtableMatches =
            curve != nullptr &&
            *reinterpret_cast<std::uintptr_t*>(curve) ==
                naFusionUi.base + 0x0215b340;
        if (!result.straightCurveVtableMatches) {
            result.code = -7;
            return result;
        }

        const auto* curveBytes =
            reinterpret_cast<const std::uint8_t*>(curve);
        result.defaultEndpointsMatch =
            std::abs(*reinterpret_cast<const double*>(curveBytes + 0x70)) <
                1.0e-9 &&
            std::abs(*reinterpret_cast<const double*>(curveBytes + 0x78) -
                     100.0) < 1.0e-9;
        if (!result.defaultEndpointsMatch) {
            result.code = -8;
            return result;
        }

        using SelectCurve = void (*)(void*, void*);
        using ValueToDevice = QPoint (*)(void*, const PlotPointValue&);
        using DeviceToValue = PlotPointValue (*)(void*, const QPoint&);
        using CurvePickerSelect = void (*)(void*, void*, const QPoint&);
        using SetText = void (*)(void*, QString);
        using IsStepValid = bool (*)(void*);
        using CoordStepChanged = void (*)(void*);
        using CoordValueChanged = void (*)(void*, bool);
        using GetDofValue = double (*)(void*, void*, QString);
        using CurrentPosition = int (*)(void*);

        const auto selectCurve = reinterpret_cast<SelectCurve>(
            naFusionUi.base + kSelectCurveOffset);
        const auto valueToDevice = reinterpret_cast<ValueToDevice>(
            naFusionUi.base + kValueToDeviceOffset);
        const auto deviceToValue = reinterpret_cast<DeviceToValue>(
            naFusionUi.base + kDeviceToValueOffset);
        const auto curvePickerSelect =
            reinterpret_cast<CurvePickerSelect>(
                naFusionUi.base + kCurvePickerSelectOffset);
        const auto setValueText = reinterpret_cast<SetText>(
            naFusionUi.base + kSetValueTextOffset);
        const auto setStepText = reinterpret_cast<SetText>(
            naFusionUi.base + kSetStepTextOffset);
        const auto isStepValid = reinterpret_cast<IsStepValid>(
            naFusionUi.base + kIsStepValidOffset);
        const auto coordStepChanged =
            reinterpret_cast<CoordStepChanged>(
                naFusionUi.base + kCoordStepChangedOffset);
        const auto coordValueChanged =
            reinterpret_cast<CoordValueChanged>(
                naFusionUi.base + kCoordValueChangedOffset);
        const auto getDofValue = reinterpret_cast<GetDofValue>(
            naFusionUi.base + kGetDofValueOffset);
        const auto currentPosition = reinterpret_cast<CurrentPosition>(
            naFusionUi.base + kCurrentPositionOffset);

        const auto collectGrips = [&]() {
            std::vector<void*> grips;
            const auto* storage =
                reinterpret_cast<const std::uint8_t*>(curve) + 0x48;
            const auto headerAddress = reinterpret_cast<std::uintptr_t>(
                *reinterpret_cast<void* const*>(storage));
            const auto dataAddress = reinterpret_cast<std::uintptr_t>(
                *reinterpret_cast<void* const*>(storage + 0x08));
            const auto size =
                *reinterpret_cast<const std::int64_t*>(storage + 0x10);
            result.gripStorageMatches =
                size >= 0 && size <= 512 &&
                (size == 0 ||
                 (headerAddress != 0 && dataAddress != 0 &&
                  headerAddress % alignof(void*) == 0 &&
                  dataAddress % alignof(void*) == 0));
            if (!result.gripStorageMatches) {
                return grips;
            }
            auto** data = reinterpret_cast<void**>(dataAddress);
            result.gripPointersMatch = true;
            for (std::int64_t index = 0; index < size; ++index) {
                void* grip = data[index];
                const auto gripAddress =
                    reinterpret_cast<std::uintptr_t>(grip);
                if (grip == nullptr ||
                    gripAddress % alignof(void*) != 0 ||
                    *reinterpret_cast<std::uintptr_t*>(grip) !=
                        naFusionUi.base + 0x0215b540 ||
                    *reinterpret_cast<void**>(
                        reinterpret_cast<std::uint8_t*>(grip) + 0x30) !=
                        curve) {
                    result.gripPointersMatch = false;
                    grips.clear();
                    return grips;
                }
                grips.push_back(grip);
            }
            return grips;
        };

        selectCurve(dialog, curve);
        result.selectCurveInvoked = true;
        const std::vector<void*> before = collectGrips();
        result.gripsBefore = before.size();
        if (!result.gripStorageMatches || !result.gripPointersMatch) {
            result.code = -19;
            return result;
        }
        for (void* grip : before) {
            const GripSnapshot snapshot = snapshotGrip(grip);
            if (!snapshot.deleted && snapshot.style == 0 &&
                snapshot.direction == 1 &&
                std::abs(snapshot.step - requestedStep) < 1.0e-9) {
                result.code = -11;
                return result;
            }
        }

        PlotPointValue valuePoint;
        valuePoint.step = static_cast<double>(requestedStep) + 0.5;
        valuePoint.value = 0.0;
        const QPoint projected = valueToDevice(plotWidget, valuePoint);
        QPoint selectedDevicePoint;
        bool devicePointFound = false;
        double bestDistance = 1.0e100;
        for (int delta = -12; delta <= 12; ++delta) {
            const QPoint candidate(projected.x() + delta, projected.y());
            const PlotPointValue roundTrip =
                deviceToValue(plotWidget, candidate);
            if (!std::isfinite(roundTrip.step) ||
                static_cast<int>(roundTrip.step) != requestedStep) {
                continue;
            }
            const double distance =
                std::abs(roundTrip.step - valuePoint.step);
            if (!devicePointFound || distance < bestDistance) {
                selectedDevicePoint = candidate;
                bestDistance = distance;
                devicePointFound = true;
            }
        }
        if (!devicePointFound) {
            result.code = -12;
            return result;
        }

        curvePickerSelect(curvePicker, curve, selectedDevicePoint);
        result.curvePickerSelectInvoked = true;
        const std::vector<void*> afterCreate = collectGrips();
        result.gripsAfter = afterCreate.size();
        if (!result.gripStorageMatches || !result.gripPointersMatch ||
            afterCreate.size() != before.size() + 1) {
            result.code = -13;
            return result;
        }

        void* selectedGrip = *reinterpret_cast<void**>(
            reinterpret_cast<std::uint8_t*>(gripPicker) + 0x20);
        const bool selectedInAfter =
            std::find(afterCreate.begin(),
                      afterCreate.end(),
                      selectedGrip) != afterCreate.end();
        const bool selectedWasAbsent =
            std::find(before.begin(), before.end(), selectedGrip) ==
            before.end();
        result.selectedGripMatches =
            selectedGrip != nullptr && selectedInAfter &&
            selectedWasAbsent &&
            *reinterpret_cast<std::uintptr_t*>(selectedGrip) ==
                naFusionUi.base + 0x0215b540 &&
            *reinterpret_cast<void**>(
                reinterpret_cast<std::uint8_t*>(selectedGrip) + 0x30) ==
                curve;
        if (!result.selectedGripMatches) {
            result.code = -14;
            return result;
        }

        void* editor = *reinterpret_cast<void**>(
            reinterpret_cast<std::uint8_t*>(gripPicker) + 0x48);
        result.editorResolved = editor != nullptr;
        if (!result.editorResolved ||
            *reinterpret_cast<std::uintptr_t*>(editor) !=
                naFusionUi.base + 0x022cc2a0) {
            result.code = -9;
            return result;
        }
        auto* editorObject = reinterpret_cast<QObject*>(editor);
        result.editorClass = QString::fromLatin1(
            editorObject->metaObject()->className());
        result.editorClassMatches =
            result.editorClass == QStringLiteral("ChangeParamWidget");
        auto* valueEdit = qobject_cast<QLineEdit*>(
            reinterpret_cast<QObject*>(
                *reinterpret_cast<void**>(
                    reinterpret_cast<std::uint8_t*>(editor) + 0x28)));
        auto* stepEdit = qobject_cast<QLineEdit*>(
            reinterpret_cast<QObject*>(
                *reinterpret_cast<void**>(
                    reinterpret_cast<std::uint8_t*>(editor) + 0x30)));
        result.valueEditResolved = valueEdit != nullptr;
        result.stepEditResolved = stepEdit != nullptr;
        if (!result.editorClassMatches || !result.valueEditResolved ||
            !result.stepEditResolved) {
            result.code = -10;
            return result;
        }

        result.stepText = QString::number(requestedStep);
        setStepText(editor, result.stepText);
        result.stepTextSet = stepEdit->text() == result.stepText;
        result.stepValidated = isStepValid(gripPicker);
        if (!result.stepTextSet || !result.stepValidated) {
            result.code = -15;
            return result;
        }
        coordStepChanged(gripPicker);
        result.coordStepChangedInvoked = true;
        result.currentPosition = currentPosition(dialog);
        result.requestedStepMatches =
            result.currentPosition == requestedStep &&
            std::abs(snapshotGrip(selectedGrip).step - requestedStep) <
                1.0e-9;
        if (!result.requestedStepMatches) {
            result.code = -16;
            return result;
        }

        result.valueText =
            QString::number(requestedAngleDegrees, 'g', 15);
        setValueText(editor, result.valueText);
        result.valueTextSet = valueEdit->text() == result.valueText;
        result.parsedAngleRadians =
            getDofValue(dialog, selectedGrip, result.valueText);
        result.parsedAngleMatches =
            std::isfinite(result.parsedAngleRadians) &&
            std::abs(result.parsedAngleRadians -
                     result.requestedAngleRadians) < 1.0e-8;
        if (!result.valueTextSet || !result.parsedAngleMatches) {
            result.code = -17;
            return result;
        }
        coordValueChanged(gripPicker, false);
        result.coordValueChangedInvoked = true;

        result.selectedGrip = snapshotGrip(selectedGrip);
        result.rowCurrentNativeValue = *reinterpret_cast<const double*>(
            reinterpret_cast<const std::uint8_t*>(row) + 0x28);
        result.requestedAngleMatches =
            std::abs(result.selectedGrip.nativeValue -
                     result.requestedAngleRadians) < 1.0e-8 &&
            std::abs(result.rowCurrentNativeValue -
                     result.requestedAngleRadians) < 1.0e-8;
        result.grips.clear();
        for (void* grip : collectGrips()) {
            result.grips.push_back(snapshotGrip(grip));
        }
        if (!result.requestedAngleMatches ||
            result.grips.size() != result.gripsAfter) {
            result.code = -18;
            return result;
        }

        result.code = 0;
        return result;
    } catch (...) {
        result.code = -99;
        return result;
    }
}

CurveReadbackResult readCurveGrips(QWidget* dialog,
                                   int rowIndex) noexcept {
    CurveReadbackResult result;
    try {
        if (pthread_main_np() == 0 || dialog == nullptr || rowIndex < 0 ||
            !isExactMotionStudyDialog(dialog)) {
            result.code = -1;
            return result;
        }

        const LoadedImage naFusionUi = findLoadedImage(
            "/Libraries/Applications/Fusion/NaFusionUI10.dylib");
        constexpr std::array<std::uint8_t, 16>
            kExpectedNaFusionUiUuid = {
                0x45, 0xf2, 0xe0, 0xc4, 0x1a, 0x4f, 0x36, 0xb8,
                0xa6, 0xd8, 0x63, 0x33, 0xa6, 0x8f, 0xba, 0xd1,
            };
        result.naFusionUiUuidMatches =
            loadedImageUuidMatches(naFusionUi.header,
                                   kExpectedNaFusionUiUuid);
        if (!result.naFusionUiUuidMatches) {
            result.code = -2;
            return result;
        }

        result.dialogVtableMatches =
            *reinterpret_cast<std::uintptr_t*>(dialog) ==
            naFusionUi.base + 0x022cfe78;
        if (!result.dialogVtableMatches) {
            result.code = -3;
            return result;
        }

        auto* dialogBytes = reinterpret_cast<std::uint8_t*>(dialog);
        const auto rowsBeginAddress = reinterpret_cast<std::uintptr_t>(
            *reinterpret_cast<void**>(dialogBytes + 0xc0));
        const auto rowsEndAddress = reinterpret_cast<std::uintptr_t>(
            *reinterpret_cast<void**>(dialogBytes + 0xc8));
        const bool rowAddressesValid =
            rowsBeginAddress != 0 && rowsEndAddress != 0 &&
            rowsBeginAddress % alignof(void*) == 0 &&
            rowsEndAddress % alignof(void*) == 0 &&
            rowsEndAddress >= rowsBeginAddress &&
            (rowsEndAddress - rowsBeginAddress) % sizeof(void*) == 0 &&
            (rowsEndAddress - rowsBeginAddress) / sizeof(void*) <= 64;
        result.rowCount = rowAddressesValid
                              ? static_cast<std::size_t>(
                                    (rowsEndAddress - rowsBeginAddress) /
                                    sizeof(void*))
                              : 0;
        const auto tables = dialog->findChildren<QTableWidget*>();
        result.rowVectorMatches =
            rowAddressesValid && tables.size() == 1 &&
            static_cast<std::size_t>(tables.front()->rowCount()) ==
                result.rowCount &&
            static_cast<std::size_t>(rowIndex) < result.rowCount;
        if (!result.rowVectorMatches) {
            result.code = -4;
            return result;
        }

        auto** rows = reinterpret_cast<void**>(rowsBeginAddress);
        void* row = rows[rowIndex];
        const auto rowAddress = reinterpret_cast<std::uintptr_t>(row);
        result.rowPointerMatches =
            row != nullptr && rowAddress % alignof(void*) == 0;
        if (!result.rowPointerMatches) {
            result.code = -5;
            return result;
        }

        void* curve = *reinterpret_cast<void**>(
            reinterpret_cast<std::uint8_t*>(row) + 0x30);
        result.straightCurveVtableMatches =
            curve != nullptr &&
            *reinterpret_cast<std::uintptr_t*>(curve) ==
                naFusionUi.base + 0x0215b340;
        if (!result.straightCurveVtableMatches) {
            result.code = -6;
            return result;
        }

        const auto* curveBytes =
            reinterpret_cast<const std::uint8_t*>(curve);
        result.curveDomainMatches =
            std::abs(*reinterpret_cast<const double*>(curveBytes + 0x70)) <
                1.0e-9 &&
            std::abs(*reinterpret_cast<const double*>(curveBytes + 0x78) -
                     100.0) < 1.0e-9;
        if (!result.curveDomainMatches) {
            result.code = -7;
            return result;
        }

        const auto* storage = curveBytes + 0x48;
        const auto headerAddress = reinterpret_cast<std::uintptr_t>(
            *reinterpret_cast<void* const*>(storage));
        const auto dataAddress = reinterpret_cast<std::uintptr_t>(
            *reinterpret_cast<void* const*>(storage + 0x08));
        const auto size =
            *reinterpret_cast<const std::int64_t*>(storage + 0x10);
        result.gripStorageMatches =
            size >= 0 && size <= 512 &&
            (size == 0 ||
             (headerAddress != 0 && dataAddress != 0 &&
              headerAddress % alignof(void*) == 0 &&
              dataAddress % alignof(void*) == 0));
        if (!result.gripStorageMatches) {
            result.code = -8;
            return result;
        }

        auto** data = reinterpret_cast<void**>(dataAddress);
        result.gripPointersMatch = true;
        for (std::int64_t index = 0; index < size; ++index) {
            void* grip = data[index];
            const auto gripAddress =
                reinterpret_cast<std::uintptr_t>(grip);
            if (grip == nullptr || gripAddress % alignof(void*) != 0 ||
                *reinterpret_cast<std::uintptr_t*>(grip) !=
                    naFusionUi.base + 0x0215b540 ||
                *reinterpret_cast<void**>(
                    reinterpret_cast<std::uint8_t*>(grip) + 0x30) !=
                    curve) {
                result.gripPointersMatch = false;
                result.grips.clear();
                result.code = -9;
                return result;
            }
            result.grips.push_back(snapshotGrip(grip));
        }

        result.code = 0;
        return result;
    } catch (...) {
        result.code = -99;
        return result;
    }
}

const char* jsonBool(bool value) {
    return value ? "true" : "false";
}

bool writeTextAtomically(const std::string& outputPath,
                         const std::string& contents) {
    if (outputPath.empty()) {
        return false;
    }
    const std::string temporaryPath = outputPath + ".tmp";
    std::ofstream file(temporaryPath,
                       std::ios::out | std::ios::trunc);
    if (!file.is_open()) {
        return false;
    }
    file << contents;
    file.flush();
    const bool writeSucceeded = file.good();
    file.close();
    if (!writeSucceeded) {
        std::remove(temporaryPath.c_str());
        return false;
    }
    if (std::rename(temporaryPath.c_str(), outputPath.c_str()) != 0) {
        std::remove(temporaryPath.c_str());
        return false;
    }
    return true;
}

PersistedMotionStudyReadbackResult readPersistedMotionStudy(
    const std::vector<MotionJointSpec>& specs) noexcept {
    PersistedMotionStudyReadbackResult result;
    try {
        if (pthread_main_np() == 0 || specs.empty() || specs.size() > 64) {
            result.code = -1;
            return result;
        }

        const auto application = adsk::core::Application::get();
        if (!application) {
            result.code = -2;
            return result;
        }
        result.fusionVersion = application->version();
        if (result.fusionVersion != "2704.1.36") {
            result.code = -3;
            return result;
        }
        const auto product = application->activeProduct();
        const auto design =
            product ? product->cast<adsk::fusion::Design>() : nullptr;
        const auto root = design ? design->rootComponent() : nullptr;
        result.rootComponentResolved = root && root->isValid();
        if (!result.rootComponentResolved) {
            result.code = -4;
            return result;
        }

        const LoadedImage fusionXlayer = findLoadedImage(
            "/Libraries/Applications/Fusion/FusionXLayer10.dylib");
        const LoadedImage nsComponent =
            findLoadedImage("/Libraries/Neutron/NsComponent10.dylib");
        const LoadedImage nsDataModel =
            findLoadedImage("/Libraries/Neutron/NsDataModel10.dylib");
        const LoadedImage nsTypes =
            findLoadedImage("/Libraries/Neutron/NsTypes10.dylib");
        result.fusionXlayerPath = fusionXlayer.path;
        result.nsComponentPath = nsComponent.path;
        result.nsDataModelPath = nsDataModel.path;
        result.nsTypesPath = nsTypes.path;

        constexpr std::array<std::uint8_t, 16>
            kExpectedFusionXlayerUuid = {
                0xa7, 0xa5, 0x17, 0x68, 0xfe, 0xc5, 0x3f, 0x63,
                0x82, 0x53, 0x4e, 0x5b, 0x2f, 0x67, 0x08, 0xfb,
            };
        constexpr std::array<std::uint8_t, 16>
            kExpectedNsComponentUuid = {
                0x14, 0x86, 0x08, 0xf9, 0xe4, 0xd5, 0x33, 0x84,
                0xa2, 0xe5, 0x6a, 0xe0, 0x36, 0xc7, 0x51, 0xda,
            };
        constexpr std::array<std::uint8_t, 16>
            kExpectedNsDataModelUuid = {
                0xf1, 0x82, 0x10, 0xea, 0xcc, 0x00, 0x3a, 0x24,
                0x87, 0xf1, 0xfd, 0x48, 0xf9, 0x0f, 0x27, 0xca,
            };
        constexpr std::array<std::uint8_t, 16> kExpectedNsTypesUuid = {
            0xed, 0x5d, 0xd4, 0x4b, 0xbd, 0x4c, 0x36, 0xb3,
            0x9e, 0x85, 0xdf, 0x24, 0xfa, 0xf0, 0x1b, 0x11,
        };
        result.fusionXlayerUuidMatches = loadedImageUuidMatches(
            fusionXlayer.header, kExpectedFusionXlayerUuid);
        result.nsComponentUuidMatches = loadedImageUuidMatches(
            nsComponent.header, kExpectedNsComponentUuid);
        result.nsDataModelUuidMatches = loadedImageUuidMatches(
            nsDataModel.header, kExpectedNsDataModelUuid);
        result.nsTypesUuidMatches =
            loadedImageUuidMatches(nsTypes.header, kExpectedNsTypesUuid);
        if (!result.fusionXlayerUuidMatches ||
            !result.nsComponentUuidMatches ||
            !result.nsDataModelUuidMatches ||
            !result.nsTypesUuidMatches) {
            result.code = -5;
            return result;
        }

        constexpr std::uintptr_t kInternalComponentOffset = 0x002243a8;
        constexpr std::uintptr_t kJointOccurrenceOffset = 0x0024eb18;
        constexpr std::uintptr_t kMotionStudiesCountOffset = 0x000d8450;
        constexpr std::uintptr_t kManagedChildOffset = 0x001b63d0;
        constexpr std::uintptr_t kMotionStudyOperandCountOffset =
            0x000dbfc8;
        constexpr std::uintptr_t kMotionStudyOperandAtOffset = 0x000dc024;
        constexpr std::uintptr_t kStrongRefGetOffset = 0x002a8150;
        constexpr std::uintptr_t kCurveGripPointOffset = 0x000d97b4;
        constexpr std::uintptr_t kCurveValueOffset = 0x000d97fc;
        constexpr std::uintptr_t kCurveDeletedOffset = 0x000d9844;
        constexpr std::uintptr_t kCurveDriverOffset = 0x000d98d4;
        constexpr std::uintptr_t kPointXOffset = 0x00106614;
        constexpr std::uintptr_t kPointYOffset = 0x001066a4;
        using Prefix32 = std::array<std::uint8_t, 32>;
        const auto prefixMatches32 = [](std::uintptr_t address,
                                        const Prefix32& expected) {
            return address != 0 &&
                   std::memcmp(reinterpret_cast<const void*>(address),
                               expected.data(), expected.size()) == 0;
        };
        constexpr Prefix32 kInternalComponentPrefix = {
            0xff, 0x83, 0x00, 0xd1, 0xfd, 0x7b, 0x01, 0xa9,
            0xfd, 0x43, 0x00, 0x91, 0xa8, 0x64, 0x00, 0xf0,
            0x08, 0x35, 0x46, 0xf9, 0x08, 0x01, 0x40, 0xf9,
            0xe8, 0x07, 0x00, 0xf9, 0xe8, 0x07, 0x40, 0xf9,
        };
        constexpr Prefix32 kJointOccurrencePrefix = {
            0xf8, 0x5f, 0xbc, 0xa9, 0xf6, 0x57, 0x01, 0xa9,
            0xf4, 0x4f, 0x02, 0xa9, 0xfd, 0x7b, 0x03, 0xa9,
            0xfd, 0xc3, 0x00, 0x91, 0xff, 0x83, 0x0c, 0xd1,
            0xf4, 0x03, 0x00, 0xaa, 0x68, 0x63, 0x00, 0xb0,
        };
        constexpr Prefix32 kMotionStudiesCountPrefix = {
            0xff, 0x43, 0x01, 0xd1, 0xf6, 0x57, 0x02, 0xa9,
            0xf4, 0x4f, 0x03, 0xa9, 0xfd, 0x7b, 0x04, 0xa9,
            0xfd, 0x03, 0x01, 0x91, 0xf3, 0x03, 0x00, 0xaa,
            0xe8, 0x11, 0x00, 0x90, 0x08, 0xdd, 0x45, 0xf9,
        };
        constexpr Prefix32 kManagedChildPrefix = {
            0xff, 0x83, 0x00, 0xd1, 0xfd, 0x7b, 0x01, 0xa9,
            0xfd, 0x43, 0x00, 0x91, 0xc8, 0x26, 0x00, 0x90,
            0x08, 0xad, 0x43, 0xf9, 0x08, 0x01, 0x40, 0xf9,
            0xe8, 0x07, 0x00, 0xf9, 0x08, 0xa4, 0x40, 0xf9,
        };
        constexpr Prefix32 kMotionStudyOperandCountPrefix = {
            0xff, 0x83, 0x00, 0xd1, 0xfd, 0x7b, 0x01, 0xa9,
            0xfd, 0x43, 0x00, 0x91, 0xc8, 0x11, 0x00, 0xb0,
            0x08, 0xdd, 0x45, 0xf9, 0x08, 0x01, 0x40, 0xf9,
            0xe8, 0x07, 0x00, 0xf9, 0x09, 0x20, 0x55, 0xa9,
        };
        constexpr Prefix32 kMotionStudyOperandAtPrefix = {
            0xff, 0x83, 0x00, 0xd1, 0xfd, 0x7b, 0x01, 0xa9,
            0xfd, 0x43, 0x00, 0x91, 0xc8, 0x11, 0x00, 0x90,
            0x08, 0xdd, 0x45, 0xf9, 0x08, 0x01, 0x40, 0xf9,
            0xe8, 0x07, 0x00, 0xf9, 0x08, 0xa8, 0x40, 0xf9,
        };
        constexpr Prefix32 kStrongRefGetPrefix = {
            0xff, 0x03, 0x01, 0xd1, 0xf6, 0x57, 0x01, 0xa9,
            0xf4, 0x4f, 0x02, 0xa9, 0xfd, 0x7b, 0x03, 0xa9,
            0xfd, 0xc3, 0x00, 0x91, 0xf4, 0x03, 0x01, 0xaa,
            0xf3, 0x03, 0x00, 0xaa, 0x28, 0x1f, 0x00, 0xd0,
        };
        constexpr Prefix32 kCurveGripPointPrefix = {
            0xff, 0x83, 0x00, 0xd1, 0xfd, 0x7b, 0x01, 0xa9,
            0xfd, 0x43, 0x00, 0x91, 0xc8, 0x11, 0x00, 0xf0,
            0x08, 0xdd, 0x45, 0xf9, 0x08, 0x01, 0x40, 0xf9,
            0xe8, 0x07, 0x00, 0xf9, 0x00, 0x0c, 0x40, 0xf9,
        };
        constexpr Prefix32 kCurveValuePrefix = {
            0xff, 0x83, 0x00, 0xd1, 0xfd, 0x7b, 0x01, 0xa9,
            0xfd, 0x43, 0x00, 0x91, 0xc8, 0x11, 0x00, 0xf0,
            0x08, 0xdd, 0x45, 0xf9, 0x08, 0x01, 0x40, 0xf9,
            0xe8, 0x07, 0x00, 0xf9, 0x00, 0x10, 0x40, 0xfd,
        };
        constexpr Prefix32 kCurveDeletedPrefix = {
            0xff, 0x83, 0x00, 0xd1, 0xfd, 0x7b, 0x01, 0xa9,
            0xfd, 0x43, 0x00, 0x91, 0xc8, 0x11, 0x00, 0xf0,
            0x08, 0xdd, 0x45, 0xf9, 0x08, 0x01, 0x40, 0xf9,
            0xe8, 0x07, 0x00, 0xf9, 0x00, 0xa4, 0x40, 0x39,
        };
        constexpr Prefix32 kCurveDriverPrefix = {
            0xff, 0x83, 0x00, 0xd1, 0xfd, 0x7b, 0x01, 0xa9,
            0xfd, 0x43, 0x00, 0x91, 0xc8, 0x11, 0x00, 0xf0,
            0x08, 0xdd, 0x45, 0xf9, 0x08, 0x01, 0x40, 0xf9,
            0xe8, 0x07, 0x00, 0xf9, 0x00, 0xa0, 0x40, 0x39,
        };
        constexpr Prefix32 kPointXPrefix = {
            0xff, 0x83, 0x00, 0xd1, 0xfd, 0x7b, 0x01, 0xa9,
            0xfd, 0x43, 0x00, 0x91, 0x68, 0x04, 0x00, 0xf0,
            0x08, 0xd9, 0x45, 0xf9, 0x08, 0x01, 0x40, 0xf9,
            0xe8, 0x07, 0x00, 0xf9, 0x00, 0x18, 0x40, 0xbd,
        };
        constexpr Prefix32 kPointYPrefix = {
            0xff, 0x83, 0x00, 0xd1, 0xfd, 0x7b, 0x01, 0xa9,
            0xfd, 0x43, 0x00, 0x91, 0x68, 0x04, 0x00, 0xf0,
            0x08, 0xd9, 0x45, 0xf9, 0x08, 0x01, 0x40, 0xf9,
            0xe8, 0x07, 0x00, 0xf9, 0x00, 0x1c, 0x40, 0xbd,
        };

        result.internalComponentPrefixMatches = prefixMatches32(
            fusionXlayer.base + kInternalComponentOffset,
            kInternalComponentPrefix);
        result.jointOccurrencePrefixMatches = prefixMatches32(
            fusionXlayer.base + kJointOccurrenceOffset,
            kJointOccurrencePrefix);
        result.motionStudiesCountPrefixMatches = prefixMatches32(
            nsComponent.base + kMotionStudiesCountOffset,
            kMotionStudiesCountPrefix);
        result.managedChildPrefixMatches = prefixMatches32(
            nsDataModel.base + kManagedChildOffset,
            kManagedChildPrefix);
        result.motionStudyOperandCountPrefixMatches = prefixMatches32(
            nsComponent.base + kMotionStudyOperandCountOffset,
            kMotionStudyOperandCountPrefix);
        result.motionStudyOperandAtPrefixMatches = prefixMatches32(
            nsComponent.base + kMotionStudyOperandAtOffset,
            kMotionStudyOperandAtPrefix);
        result.strongRefGetPrefixMatches = prefixMatches32(
            nsDataModel.base + kStrongRefGetOffset,
            kStrongRefGetPrefix);
        result.curveGripPointPrefixMatches = prefixMatches32(
            nsComponent.base + kCurveGripPointOffset,
            kCurveGripPointPrefix);
        result.curveValuePrefixMatches = prefixMatches32(
            nsComponent.base + kCurveValueOffset,
            kCurveValuePrefix);
        result.curveDeletedPrefixMatches = prefixMatches32(
            nsComponent.base + kCurveDeletedOffset,
            kCurveDeletedPrefix);
        result.curveDriverPrefixMatches = prefixMatches32(
            nsComponent.base + kCurveDriverOffset,
            kCurveDriverPrefix);
        result.pointXPrefixMatches = prefixMatches32(
            nsTypes.base + kPointXOffset, kPointXPrefix);
        result.pointYPrefixMatches = prefixMatches32(
            nsTypes.base + kPointYOffset, kPointYPrefix);
        if (!result.internalComponentPrefixMatches ||
            !result.jointOccurrencePrefixMatches ||
            !result.motionStudiesCountPrefixMatches ||
            !result.managedChildPrefixMatches ||
            !result.motionStudyOperandCountPrefixMatches ||
            !result.motionStudyOperandAtPrefixMatches ||
            !result.strongRefGetPrefixMatches ||
            !result.curveGripPointPrefixMatches ||
            !result.curveValuePrefixMatches ||
            !result.curveDeletedPrefixMatches ||
            !result.curveDriverPrefixMatches ||
            !result.pointXPrefixMatches || !result.pointYPrefixMatches) {
            result.code = -6;
            return result;
        }

        using InternalComponent = void* (*)(const void*);
        using InternalJointOccurrence = void* (*)(const void*);
        using StrongRefGet = void* (*)(const void*, bool);
        using MotionStudiesCount = std::uint32_t (*)(const void*);
        using ManagedChild = const void* (*)(const void*, std::uint32_t);
        using OperandCount = std::size_t (*)(void*);
        using OperandAt = void* (*)(void*, std::uint32_t);
        using CurveGripPoint = void* (*)(const void*);
        using CurveValue = double (*)(const void*);
        using CurveFlag = bool (*)(const void*);
        using PointCoordinate = float (*)(const void*);

        const auto internalComponent = reinterpret_cast<InternalComponent>(
            fusionXlayer.base + kInternalComponentOffset);
        const auto internalJointOccurrence =
            reinterpret_cast<InternalJointOccurrence>(
                fusionXlayer.base + kJointOccurrenceOffset);
        const auto strongRefGet = reinterpret_cast<StrongRefGet>(
            nsDataModel.base + kStrongRefGetOffset);
        const auto motionStudiesCount =
            reinterpret_cast<MotionStudiesCount>(
            nsComponent.base + kMotionStudiesCountOffset);
        const auto managedChild = reinterpret_cast<ManagedChild>(
            nsDataModel.base + kManagedChildOffset);
        const auto motionStudyOperandCount =
            reinterpret_cast<OperandCount>(
            nsComponent.base + kMotionStudyOperandCountOffset);
        const auto motionStudyOperandAt = reinterpret_cast<OperandAt>(
            nsComponent.base + kMotionStudyOperandAtOffset);
        const auto curveGripPoint = reinterpret_cast<CurveGripPoint>(
            nsComponent.base + kCurveGripPointOffset);
        const auto curveValue = reinterpret_cast<CurveValue>(
            nsComponent.base + kCurveValueOffset);
        const auto curveDeleted = reinterpret_cast<CurveFlag>(
            nsComponent.base + kCurveDeletedOffset);
        const auto curveDriver = reinterpret_cast<CurveFlag>(
            nsComponent.base + kCurveDriverOffset);
        const auto pointX = reinterpret_cast<PointCoordinate>(
            nsTypes.base + kPointXOffset);
        const auto pointY = reinterpret_cast<PointCoordinate>(
            nsTypes.base + kPointYOffset);

        void* component = internalComponent(root.get());
        result.internalComponentResolved = component != nullptr;
        if (!result.internalComponentResolved) {
            result.code = -7;
            return result;
        }

        const auto* componentBytes =
            reinterpret_cast<const std::uint8_t*>(component);
        void* motionStudies = strongRefGet(componentBytes + 0x590, true);
        result.motionStudiesResolved = motionStudies != nullptr;
        result.motionStudiesVtableMatches =
            motionStudies != nullptr &&
            *reinterpret_cast<const std::uintptr_t*>(motionStudies) ==
                nsComponent.base + 0x0031e6a8;
        if (!result.motionStudiesResolved ||
            !result.motionStudiesVtableMatches) {
            result.code = -8;
            return result;
        }
        result.motionStudyCount = motionStudiesCount(motionStudies);
        if (result.motionStudyCount != 1) {
            result.code = -9;
            return result;
        }

        result.motionStudyIndex = 0;
        const void* borrowedStudyRef = managedChild(motionStudies, 0);
        void* motionStudy = borrowedStudyRef
                                ? strongRefGet(borrowedStudyRef, true)
                                : nullptr;
        result.motionStudyResolved = motionStudy != nullptr;
        result.motionStudyVtableMatches =
            motionStudy != nullptr &&
            *reinterpret_cast<const std::uintptr_t*>(motionStudy) ==
                nsComponent.base + 0x0031ea58;
        if (!result.motionStudyResolved ||
            !result.motionStudyVtableMatches) {
            result.code = -10;
            return result;
        }
        result.operandCount = motionStudyOperandCount(motionStudy);
        if (result.operandCount != specs.size()) {
            result.code = -11;
            return result;
        }

        bool exactRecipeMatches = true;
        result.operands.reserve(specs.size());
        for (std::size_t operandIndex = 0;
             operandIndex < specs.size(); ++operandIndex) {
            const MotionJointSpec& spec = specs[operandIndex];
            PersistedOperandSnapshot snapshot;
            snapshot.entityToken = spec.entityToken;
            snapshot.expectedName = spec.expectedName;
            void* operand = motionStudyOperandAt(
                motionStudy, static_cast<std::uint32_t>(operandIndex));
            if (operand == nullptr) {
                exactRecipeMatches = false;
                result.operands.push_back(std::move(snapshot));
                continue;
            }
            auto* operandBytes = reinterpret_cast<std::uint8_t*>(operand);

            adsk::core::Ptr<adsk::fusion::Joint> apiJoint;
            for (const auto& candidate :
                 design->findEntityByToken(spec.entityToken)) {
                if (!candidate) {
                    continue;
                }
                const auto joint = candidate->cast<adsk::fusion::Joint>();
                if (!joint || !joint->isValid()) {
                    continue;
                }
                apiJoint = joint;
                ++snapshot.tokenMatchCount;
            }
            snapshot.apiJointResolved =
                snapshot.tokenMatchCount == 1 && apiJoint;
            if (snapshot.apiJointResolved) {
                snapshot.apiName = apiJoint->name();
                const auto* publicJoint =
                    reinterpret_cast<const std::uint8_t*>(apiJoint.get());
                void* expectedInternalJoint = internalJointOccurrence(
                    publicJoint + sizeof(void*));
                snapshot.internalJointResolved =
                    expectedInternalJoint != nullptr;
                void* operandJoint = strongRefGet(
                    operandBytes + 0x18, true);
                snapshot.operandJointResolved = operandJoint != nullptr;
                snapshot.jointMatches =
                    expectedInternalJoint != nullptr &&
                    operandJoint == expectedInternalJoint;
            }
            snapshot.dofType =
                *reinterpret_cast<const int*>(operandBytes + 0x28);
            snapshot.initialDofValue =
                *reinterpret_cast<const double*>(operandBytes + 0x30);
            snapshot.currentDofValue =
                *reinterpret_cast<const double*>(operandBytes + 0x38);
            snapshot.visible =
                *reinterpret_cast<const bool*>(operandBytes + 0x40);

            const auto curveBegin = reinterpret_cast<std::uintptr_t>(
                *reinterpret_cast<void**>(operandBytes + 0x48));
            const auto curveEnd = reinterpret_cast<std::uintptr_t>(
                *reinterpret_cast<void**>(operandBytes + 0x50));
            const auto curveCapacityEnd = reinterpret_cast<std::uintptr_t>(
                *reinterpret_cast<void**>(operandBytes + 0x58));
            constexpr std::size_t kCurveDataSize = 0x48;
            const bool emptyCurveStorage =
                curveBegin == 0 && curveEnd == 0 && curveCapacityEnd == 0;
            const bool populatedCurveStorage =
                curveBegin != 0 && curveEnd >= curveBegin &&
                curveCapacityEnd >= curveEnd &&
                (curveEnd - curveBegin) % kCurveDataSize == 0 &&
                (curveCapacityEnd - curveBegin) % kCurveDataSize == 0 &&
                (curveEnd - curveBegin) / kCurveDataSize <= 256;
            snapshot.curveStorageMatches =
                emptyCurveStorage || populatedCurveStorage;
            const std::size_t storedPointCount = populatedCurveStorage
                ? (curveEnd - curveBegin) / kCurveDataSize
                : 0;
            bool pointsMatch = snapshot.curveStorageMatches &&
                               storedPointCount == spec.points.size();
            snapshot.points.reserve(storedPointCount);
            for (std::size_t pointIndex = 0;
                 pointIndex < storedPointCount; ++pointIndex) {
                const auto* curveData = reinterpret_cast<const void*>(
                    curveBegin + pointIndex * kCurveDataSize);
                PersistedCurvePointSnapshot pointSnapshot;
                void* gripPoint = curveGripPoint(curveData);
                if (gripPoint == nullptr) {
                    pointsMatch = false;
                } else {
                    pointSnapshot.step =
                        static_cast<double>(pointX(gripPoint));
                    pointSnapshot.plotValue =
                        static_cast<double>(pointY(gripPoint));
                }
                pointSnapshot.nativeValue = curveValue(curveData);
                pointSnapshot.driver = curveDriver(curveData);
                pointSnapshot.deleted = curveDeleted(curveData);

                const auto* curveBytes =
                    reinterpret_cast<const std::uint8_t*>(curveData);
                const auto dependentBegin =
                    reinterpret_cast<std::uintptr_t>(
                        *reinterpret_cast<void* const*>(
                            curveBytes + 0x30));
                const auto dependentEnd =
                    reinterpret_cast<std::uintptr_t>(
                        *reinterpret_cast<void* const*>(
                            curveBytes + 0x38));
                const auto dependentCapacityEnd =
                    reinterpret_cast<std::uintptr_t>(
                        *reinterpret_cast<void* const*>(
                            curveBytes + 0x40));
                constexpr std::size_t kPoint2fSize = 0x20;
                const bool emptyDependentStorage =
                    dependentBegin == 0 && dependentEnd == 0 &&
                    dependentCapacityEnd == 0;
                const bool validDependentStorage =
                    dependentBegin != 0 && dependentEnd >= dependentBegin &&
                    dependentCapacityEnd >= dependentEnd &&
                    (dependentEnd - dependentBegin) % kPoint2fSize == 0 &&
                    (dependentCapacityEnd - dependentBegin) %
                            kPoint2fSize ==
                        0 &&
                    (dependentEnd - dependentBegin) / kPoint2fSize <= 64;
                if (emptyDependentStorage) {
                    pointSnapshot.dependentPointCount = 0;
                } else if (validDependentStorage) {
                    pointSnapshot.dependentPointCount =
                        (dependentEnd - dependentBegin) / kPoint2fSize;
                } else {
                    pointSnapshot.dependentPointCount =
                        static_cast<std::size_t>(-1);
                    pointsMatch = false;
                }

                if (pointIndex < spec.points.size()) {
                    const MotionPointSpec& expected = spec.points[pointIndex];
                    const double expectedRadians =
                        expected.angleDegrees * std::acos(-1.0) / 180.0;
                    pointsMatch = pointsMatch &&
                        std::abs(pointSnapshot.step - expected.step) <
                            1.0e-6 &&
                        std::abs(pointSnapshot.nativeValue -
                                 expectedRadians) < 1.0e-8 &&
                        !pointSnapshot.deleted &&
                        pointSnapshot.dependentPointCount == 0;
                } else {
                    pointsMatch = false;
                }
                snapshot.points.push_back(pointSnapshot);
            }
            snapshot.pointsMatch = pointsMatch;
            result.pointCount += snapshot.points.size();
            const bool operandMatches =
                snapshot.apiJointResolved &&
                snapshot.apiName == snapshot.expectedName &&
                snapshot.internalJointResolved &&
                snapshot.operandJointResolved && snapshot.jointMatches &&
                snapshot.curveStorageMatches && snapshot.pointsMatch;
            exactRecipeMatches = exactRecipeMatches && operandMatches;
            result.operands.push_back(std::move(snapshot));
        }

        std::size_t expectedPointCount = 0;
        for (const MotionJointSpec& spec : specs) {
            expectedPointCount += spec.points.size();
        }
        result.exactRecipeMatches = exactRecipeMatches &&
            result.pointCount == expectedPointCount;
        result.code = result.exactRecipeMatches ? 0 : -12;
        return result;
    } catch (...) {
        result.code = -99;
        return result;
    }
}

void appendPersistedMotionStudyReadback(
    std::ostringstream& output,
    const PersistedMotionStudyReadbackResult& result) {
    output
        << "{\"schema\":\"cad-agent.motion-study-persisted-readback.v1\""
        << ",\"code\":" << result.code
        << ",\"fusion_version\":" << quoted(result.fusionVersion)
        << ",\"paths\":{"
        << "\"fusion_xlayer\":" << quoted(result.fusionXlayerPath)
        << ",\"ns_component\":" << quoted(result.nsComponentPath)
        << ",\"ns_data_model\":" << quoted(result.nsDataModelPath)
        << ",\"ns_types\":" << quoted(result.nsTypesPath)
        << "},\"uuid_gates\":{"
        << "\"fusion_xlayer\":"
        << jsonBool(result.fusionXlayerUuidMatches)
        << ",\"ns_component\":"
        << jsonBool(result.nsComponentUuidMatches)
        << ",\"ns_data_model\":"
        << jsonBool(result.nsDataModelUuidMatches)
        << ",\"ns_types\":" << jsonBool(result.nsTypesUuidMatches)
        << "},\"prefix_gates\":{"
        << "\"internal_component\":"
        << jsonBool(result.internalComponentPrefixMatches)
        << ",\"joint_occurrence\":"
        << jsonBool(result.jointOccurrencePrefixMatches)
        << ",\"motion_studies_count\":"
        << jsonBool(result.motionStudiesCountPrefixMatches)
        << ",\"managed_child\":"
        << jsonBool(result.managedChildPrefixMatches)
        << ",\"motion_study_operand_count\":"
        << jsonBool(result.motionStudyOperandCountPrefixMatches)
        << ",\"motion_study_operand_at\":"
        << jsonBool(result.motionStudyOperandAtPrefixMatches)
        << ",\"strong_ref_get\":"
        << jsonBool(result.strongRefGetPrefixMatches)
        << ",\"curve_grip_point\":"
        << jsonBool(result.curveGripPointPrefixMatches)
        << ",\"curve_value\":"
        << jsonBool(result.curveValuePrefixMatches)
        << ",\"curve_driver\":"
        << jsonBool(result.curveDriverPrefixMatches)
        << ",\"curve_deleted\":"
        << jsonBool(result.curveDeletedPrefixMatches)
        << ",\"point_x\":" << jsonBool(result.pointXPrefixMatches)
        << ",\"point_y\":" << jsonBool(result.pointYPrefixMatches)
        << "},\"native_readback\":{"
        << "\"root_component_resolved\":"
        << jsonBool(result.rootComponentResolved)
        << ",\"internal_component_resolved\":"
        << jsonBool(result.internalComponentResolved)
        << ",\"motion_studies_resolved\":"
        << jsonBool(result.motionStudiesResolved)
        << ",\"motion_studies_vtable_matches\":"
        << jsonBool(result.motionStudiesVtableMatches)
        << ",\"motion_study_resolved\":"
        << jsonBool(result.motionStudyResolved)
        << ",\"motion_study_vtable_matches\":"
        << jsonBool(result.motionStudyVtableMatches)
        << ",\"motion_study_count\":" << result.motionStudyCount
        << ",\"motion_study_index\":" << result.motionStudyIndex
        << ",\"operand_count\":" << result.operandCount
        << ",\"point_count\":" << result.pointCount
        << ",\"borrowed_embedded_refs_not_destroyed\":true"
        << "},\"operands\":[";
    for (std::size_t operandIndex = 0;
         operandIndex < result.operands.size(); ++operandIndex) {
        if (operandIndex != 0) {
            output << ",";
        }
        const PersistedOperandSnapshot& operand =
            result.operands[operandIndex];
        output << "{\"index\":" << operandIndex
               << ",\"entity_token\":" << quoted(operand.entityToken)
               << ",\"expected_name\":" << quoted(operand.expectedName)
               << ",\"api_name\":" << quoted(operand.apiName)
               << ",\"token_match_count\":" << operand.tokenMatchCount
               << ",\"api_joint_resolved\":"
               << jsonBool(operand.apiJointResolved)
               << ",\"internal_joint_resolved\":"
               << jsonBool(operand.internalJointResolved)
               << ",\"operand_joint_resolved\":"
               << jsonBool(operand.operandJointResolved)
               << ",\"joint_matches\":"
               << jsonBool(operand.jointMatches)
               << ",\"dof_type\":" << operand.dofType
               << std::setprecision(17)
               << ",\"initial_dof_value\":" << operand.initialDofValue
               << ",\"current_dof_value\":" << operand.currentDofValue
               << ",\"visible\":" << jsonBool(operand.visible)
               << ",\"curve_storage_matches\":"
               << jsonBool(operand.curveStorageMatches)
               << ",\"points_match\":"
               << jsonBool(operand.pointsMatch)
               << ",\"points\":[";
        for (std::size_t pointIndex = 0;
             pointIndex < operand.points.size(); ++pointIndex) {
            if (pointIndex != 0) {
                output << ",";
            }
            const PersistedCurvePointSnapshot& point =
                operand.points[pointIndex];
            output << std::setprecision(17)
                   << "{\"step\":" << point.step
                   << ",\"plot_value\":" << point.plotValue
                   << ",\"native_value\":" << point.nativeValue
                   << ",\"driver\":" << jsonBool(point.driver)
                   << ",\"deleted\":" << jsonBool(point.deleted)
                   << ",\"dependent_point_count\":"
                   << point.dependentPointCount << "}";
        }
        output << "]}";
    }
    output << "],\"exact_recipe_matches\":"
           << jsonBool(result.exactRecipeMatches)
           << ",\"accepted\":"
           << jsonBool(result.code == 0 && result.exactRecipeMatches)
           << "}";
}

void appendGripSnapshot(std::ostringstream& output,
                        const GripSnapshot& grip) {
    output << std::setprecision(17)
           << "{\"step\":" << grip.step
           << ",\"plot_value\":" << grip.plotValue
           << ",\"native_value\":" << grip.nativeValue
           << ",\"direction\":" << grip.direction
           << ",\"style\":" << grip.style
           << ",\"deleted\":" << jsonBool(grip.deleted) << "}";
}

void appendCurveReadback(std::ostringstream& output,
                         const CurveReadbackResult& readback) {
    output
        << "{\"code\":" << readback.code
        << ",\"na_fusion_ui_uuid_matches\":"
        << jsonBool(readback.naFusionUiUuidMatches)
        << ",\"dialog_vtable_matches\":"
        << jsonBool(readback.dialogVtableMatches)
        << ",\"row_vector_matches\":"
        << jsonBool(readback.rowVectorMatches)
        << ",\"row_pointer_matches\":"
        << jsonBool(readback.rowPointerMatches)
        << ",\"straight_curve_vtable_matches\":"
        << jsonBool(readback.straightCurveVtableMatches)
        << ",\"curve_domain_matches\":"
        << jsonBool(readback.curveDomainMatches)
        << ",\"grip_storage_matches\":"
        << jsonBool(readback.gripStorageMatches)
        << ",\"grip_pointers_match\":"
        << jsonBool(readback.gripPointersMatch)
        << ",\"row_count\":" << readback.rowCount
        << ",\"grips\":[";
    for (std::size_t index = 0; index < readback.grips.size(); ++index) {
        if (index != 0) {
            output << ",";
        }
        appendGripSnapshot(output, readback.grips[index]);
    }
    output << "]}";
}

void appendJointInjection(std::ostringstream& output,
                          const JointInjectionResult& injection) {
    output
        << "{\"code\":" << injection.code
        << ",\"fusion_version\":" << quoted(injection.fusionVersion)
        << ",\"xlayer_path\":" << quoted(injection.xlayerPath)
        << ",\"fusion_xlayer_path\":"
        << quoted(injection.fusionXlayerPath)
        << ",\"na_fusion_ui_path\":" << quoted(injection.naFusionUiPath)
        << ",\"nu_client_base_path\":"
        << quoted(injection.nuClientBasePath)
        << ",\"ns_data_model_path\":"
        << quoted(injection.nsDataModelPath)
        << ",\"xlayer_uuid_matches\":"
        << jsonBool(injection.xlayerUuidMatches)
        << ",\"fusion_xlayer_uuid_matches\":"
        << jsonBool(injection.fusionXlayerUuidMatches)
        << ",\"na_fusion_ui_uuid_matches\":"
        << jsonBool(injection.naFusionUiUuidMatches)
        << ",\"nu_client_base_uuid_matches\":"
        << jsonBool(injection.nuClientBaseUuidMatches)
        << ",\"ns_data_model_uuid_matches\":"
        << jsonBool(injection.nsDataModelUuidMatches)
        << ",\"helper_prefix_matches\":"
        << jsonBool(injection.helperPrefixMatches)
        << ",\"callback_thunk_matches\":"
        << jsonBool(injection.callbackThunkMatches)
        << ",\"selection_accessor_prefix_matches\":"
        << jsonBool(injection.selectionAccessorPrefixMatches)
        << ",\"command_input_changed_prefix_matches\":"
        << jsonBool(injection.commandInputChangedPrefixMatches)
        << ",\"joint_occurrence_accessor_prefix_matches\":"
        << jsonBool(injection.jointOccurrenceAccessorPrefixMatches)
        << ",\"strong_ref_constructor_prefix_matches\":"
        << jsonBool(injection.strongRefConstructorPrefixMatches)
        << ",\"strong_ref_destructor_prefix_matches\":"
        << jsonBool(injection.strongRefDestructorPrefixMatches)
        << ",\"motion_study_select_joint_prefix_matches\":"
        << jsonBool(injection.motionStudySelectJointPrefixMatches)
        << ",\"direct_dialog_append_prefix_matches\":"
        << jsonBool(injection.directDialogAppendPrefixMatches)
        << ",\"direct_dialog_facade_append_prefix_matches\":"
        << jsonBool(injection.directDialogFacadeAppendPrefixMatches)
        << ",\"internal_selection_input_resolved\":"
        << jsonBool(injection.internalSelectionInputResolved)
        << ",\"native_command_input_matches\":"
        << jsonBool(injection.nativeCommandInputMatches)
        << ",\"native_dialog_facade_resolved\":"
        << jsonBool(injection.nativeDialogFacadeResolved)
        << ",\"native_dialog_matches\":"
        << jsonBool(injection.nativeDialogMatches)
        << ",\"native_dialog_callback_matches\":"
        << jsonBool(injection.nativeDialogCallbackMatches)
        << ",\"native_event_guard_ready\":"
        << jsonBool(injection.nativeEventGuardReady)
        << ",\"selection_has_focus\":"
        << jsonBool(injection.selectionHasFocus)
        << ",\"internal_joint_occurrence_resolved\":"
        << jsonBool(injection.internalJointOccurrenceResolved)
        << ",\"strong_ref_constructed\":"
        << jsonBool(injection.strongRefConstructed)
        << ",\"motion_study_select_joint_invoked\":"
        << jsonBool(injection.motionStudySelectJointInvoked)
        << ",\"command_input_changed_invoked\":"
        << jsonBool(injection.commandInputChangedInvoked)
        << ",\"direct_dialog_append_mode\":"
        << jsonBool(injection.directDialogAppendMode)
        << ",\"direct_dialog_append_invoked\":"
        << jsonBool(injection.directDialogAppendInvoked)
        << ",\"command_id\":" << quoted(injection.commandId)
        << ",\"input_id\":" << quoted(injection.inputId)
        << ",\"input_object_type\":" << quoted(injection.inputObjectType)
        << ",\"selection_minimum\":" << injection.selectionMinimum
        << ",\"selection_maximum\":" << injection.selectionMaximum
        << ",\"selection_before\":" << injection.selectionBefore
        << ",\"selection_after\":" << injection.selectionAfter
        << ",\"token_match_count\":" << injection.tokenMatchCount
        << ",\"joint_name\":" << quoted(injection.jointName) << "}";
}

void appendKeyframeInjection(std::ostringstream& output,
                             const KeyframeInjectionResult& injection) {
    output
        << std::setprecision(17)
        << "{\"code\":" << injection.code
        << ",\"na_fusion_ui_uuid_matches\":"
        << jsonBool(injection.naFusionUiUuidMatches)
        << ",\"function_prefixes\":{"
        << "\"select_curve\":"
        << jsonBool(injection.selectCurvePrefixMatches)
        << ",\"value_to_device\":"
        << jsonBool(injection.valueToDevicePrefixMatches)
        << ",\"device_to_value\":"
        << jsonBool(injection.deviceToValuePrefixMatches)
        << ",\"curve_picker_select\":"
        << jsonBool(injection.curvePickerSelectPrefixMatches)
        << ",\"set_value_text\":"
        << jsonBool(injection.setValueTextPrefixMatches)
        << ",\"set_step_text\":"
        << jsonBool(injection.setStepTextPrefixMatches)
        << ",\"is_step_valid\":"
        << jsonBool(injection.isStepValidPrefixMatches)
        << ",\"coord_step_changed\":"
        << jsonBool(injection.coordStepChangedPrefixMatches)
        << ",\"coord_value_changed\":"
        << jsonBool(injection.coordValueChangedPrefixMatches)
        << ",\"get_dof_value\":"
        << jsonBool(injection.getDofValuePrefixMatches)
        << ",\"current_position\":"
        << jsonBool(injection.currentPositionPrefixMatches) << "}"
        << ",\"layout\":{"
        << "\"dialog\":" << jsonBool(injection.dialogLayoutMatches)
        << ",\"dialog_vtable\":"
        << jsonBool(injection.dialogVtableMatches)
        << ",\"plot_widget_vtable\":"
        << jsonBool(injection.plotWidgetVtableMatches)
        << ",\"row_vector\":" << jsonBool(injection.rowVectorMatches)
        << ",\"straight_curve_vtable\":"
        << jsonBool(injection.straightCurveVtableMatches)
        << ",\"picker_vtables\":"
        << jsonBool(injection.pickerVtablesMatch)
        << ",\"picker_relationships\":"
        << jsonBool(injection.pickerRelationshipsMatch)
        << ",\"grip_storage\":"
        << jsonBool(injection.gripStorageMatches)
        << ",\"grip_pointers\":"
        << jsonBool(injection.gripPointersMatch)
        << ",\"default_endpoints\":"
        << jsonBool(injection.defaultEndpointsMatch) << "}"
        << ",\"editor\":{"
        << "\"resolved\":" << jsonBool(injection.editorResolved)
        << ",\"class\":" << quoted(injection.editorClass)
        << ",\"class_matches\":"
        << jsonBool(injection.editorClassMatches)
        << ",\"value_edit_resolved\":"
        << jsonBool(injection.valueEditResolved)
        << ",\"step_edit_resolved\":"
        << jsonBool(injection.stepEditResolved) << "}"
        << ",\"actions\":{"
        << "\"select_curve_invoked\":"
        << jsonBool(injection.selectCurveInvoked)
        << ",\"curve_picker_select_invoked\":"
        << jsonBool(injection.curvePickerSelectInvoked)
        << ",\"value_text_set\":" << jsonBool(injection.valueTextSet)
        << ",\"step_text_set\":" << jsonBool(injection.stepTextSet)
        << ",\"step_validated\":" << jsonBool(injection.stepValidated)
        << ",\"coord_step_changed_invoked\":"
        << jsonBool(injection.coordStepChangedInvoked)
        << ",\"coord_value_changed_invoked\":"
        << jsonBool(injection.coordValueChangedInvoked) << "}"
        << ",\"readback\":{"
        << "\"selected_grip_matches\":"
        << jsonBool(injection.selectedGripMatches)
        << ",\"requested_step_matches\":"
        << jsonBool(injection.requestedStepMatches)
        << ",\"requested_angle_matches\":"
        << jsonBool(injection.requestedAngleMatches)
        << ",\"parsed_angle_matches\":"
        << jsonBool(injection.parsedAngleMatches)
        << ",\"requested_step\":" << injection.requestedStep
        << ",\"current_position\":" << injection.currentPosition
        << ",\"requested_angle_degrees\":"
        << injection.requestedAngleDegrees
        << ",\"requested_angle_radians\":"
        << injection.requestedAngleRadians
        << ",\"parsed_angle_radians\":"
        << injection.parsedAngleRadians
        << ",\"row_current_native_value\":"
        << injection.rowCurrentNativeValue
        << ",\"row_count\":" << injection.rowCount
        << ",\"grips_before\":" << injection.gripsBefore
        << ",\"grips_after\":" << injection.gripsAfter
        << ",\"value_text\":" << quoted(injection.valueText)
        << ",\"step_text\":" << quoted(injection.stepText)
        << ",\"selected_grip\":";
    appendGripSnapshot(output, injection.selectedGrip);
    output << ",\"grips\":[";
    for (std::size_t index = 0; index < injection.grips.size(); ++index) {
        if (index != 0) {
            output << ",";
        }
        appendGripSnapshot(output, injection.grips[index]);
    }
    output << "]}}";
}

void appendObject(std::ostringstream& output,
                  const QObject* object,
                  const std::string& path,
                  int depth,
                  bool& first) {
    if (object == nullptr || depth > 18) {
        return;
    }

    if (!first) {
        output << ",";
    }
    first = false;

    const QWidget* widget = qobject_cast<const QWidget*>(object);
    output << "{"
           << "\"path\":\"" << path << "\","
           << "\"address\":\"" << pointerString(object) << "\","
           << "\"class\":" << quoted(
                  QString::fromLatin1(object->metaObject()->className()))
           << ",\"object_name\":" << quoted(object->objectName());

    if (widget != nullptr) {
        const QRect geometry = widget->geometry();
        output << ",\"window_title\":" << quoted(widget->windowTitle())
               << ",\"accessible_name\":" << quoted(widget->accessibleName())
               << ",\"accessible_description\":"
               << quoted(widget->accessibleDescription())
               << ",\"visible\":" << (widget->isVisible() ? "true" : "false")
               << ",\"enabled\":" << (widget->isEnabled() ? "true" : "false")
               << ",\"geometry\":{"
               << "\"x\":" << geometry.x() << ","
               << "\"y\":" << geometry.y() << ","
               << "\"width\":" << geometry.width() << ","
               << "\"height\":" << geometry.height() << "}";
    }

    if (const auto* button = qobject_cast<const QAbstractButton*>(object)) {
        output << ",\"button_text\":" << quoted(button->text())
               << ",\"checked\":" << (button->isChecked() ? "true" : "false");
    }
    if (const auto* slider = qobject_cast<const QSlider*>(object)) {
        output << ",\"slider\":{"
               << "\"minimum\":" << slider->minimum() << ","
               << "\"maximum\":" << slider->maximum() << ","
               << "\"value\":" << slider->value() << ","
               << "\"orientation\":"
               << (slider->orientation() == Qt::Horizontal
                       ? "\"horizontal\""
                       : "\"vertical\"")
               << "}";
    }
    if (const auto* table = qobject_cast<const QTableWidget*>(object)) {
        output << ",\"table\":{"
               << "\"rows\":" << table->rowCount() << ","
               << "\"columns\":" << table->columnCount() << ","
               << "\"current_row\":" << table->currentRow() << ","
               << "\"current_column\":" << table->currentColumn()
               << ",\"headers\":[";
        for (int column = 0; column < table->columnCount(); ++column) {
            if (column != 0) {
                output << ",";
            }
            const QTableWidgetItem* header =
                table->horizontalHeaderItem(column);
            output << quoted(header == nullptr ? QString() : header->text());
        }
        output << "],\"cells\":[";
        bool firstCell = true;
        for (int row = 0; row < table->rowCount(); ++row) {
            for (int column = 0; column < table->columnCount(); ++column) {
                const QTableWidgetItem* item = table->item(row, column);
                if (item == nullptr) {
                    continue;
                }
                if (!firstCell) {
                    output << ",";
                }
                firstCell = false;
                output << "{"
                       << "\"row\":" << row << ","
                       << "\"column\":" << column << ","
                       << "\"text\":" << quoted(item->text()) << ","
                       << "\"check_state\":"
                       << static_cast<int>(item->checkState()) << ","
                       << "\"flags\":"
                       << static_cast<unsigned int>(item->flags().toInt())
                       << "}";
            }
        }
        output << "]}";
    }
    if (const auto* label = qobject_cast<const QLabel*>(object)) {
        output << ",\"label_text\":" << quoted(label->text());
    }
    if (looksLikeMotionStudy(widget)) {
        appendMetaObject(output, object);
    }

    output << "}";

    const QObjectList children = object->children();
    for (qsizetype index = 0; index < children.size(); ++index) {
        appendObject(output,
                     children.at(index),
                     path + "/" + std::to_string(index),
                     depth + 1,
                     first);
    }
}

bool cancelDialog(QWidget* dialog) {
    if (dialog == nullptr) {
        return false;
    }

    const auto boxes = dialog->findChildren<QDialogButtonBox*>();
    for (QDialogButtonBox* box : boxes) {
        if (QPushButton* cancel = box->button(QDialogButtonBox::Cancel)) {
            cancel->click();
            return true;
        }
    }

    if (QAbstractButton* cancel =
            motionStudyButton(dialog,
                              QStringLiteral("Cancel"),
                              QStringLiteral("取消"))) {
        cancel->click();
        return true;
    }
    return false;
}

class ProbeController final : public QObject {
public:
    ProbeController(std::string outputPath,
                    int pollIntervalMs,
                    int timeoutMs,
                    bool cancelAfterDump,
                    int readyDelayMs = 0)
        : outputPath_(std::move(outputPath)),
          pollIntervalMs_(std::max(50, pollIntervalMs)),
          timeoutMs_(std::max(250, timeoutMs)),
          cancelAfterDump_(cancelAfterDump),
          readyDelayMs_(std::max(0, readyDelayMs)) {}

    void start() {
        elapsedMs_ = 0;
        poll();
    }

private:
    void finish(const char* status, QWidget* dialog) {
        std::ostringstream prefix;
        prefix << "{"
               << "\"schema\":\"cad-agent.motion-study-qt-probe.v1\","
               << "\"status\":\"" << status << "\","
               << "\"qt_version\":\"" << qVersion() << "\","
               << "\"main_thread\":"
               << ((QCoreApplication::instance() != nullptr &&
                    QCoreApplication::instance()->thread() ==
                        QThread::currentThread())
                       ? "true"
                       : "false")
               << ",\"elapsed_ms\":" << elapsedMs_ << ","
               << "\"dialog_found\":" << (dialog != nullptr ? "true" : "false")
               << ",\"dialog_ready\":"
               << (motionStudyDialogReady(dialog) ? "true" : "false")
               << ",\"objects\":[";

        bool first = true;
        if (dialog != nullptr) {
            appendObject(prefix, dialog, "0", 0, first);
        }
        prefix << "]";

        const auto writeResult = [this, &prefix](const char* phase,
                                                 bool cancelled) {
            std::ofstream file(outputPath_, std::ios::out | std::ios::trunc);
            file << prefix.str()
                 << ",\"phase\":\"" << phase << "\""
                 << ",\"cancel_requested\":"
                 << (cancelAfterDump_ ? "true" : "false")
                 << ",\"cancel_dispatched\":"
                 << (cancelled ? "true" : "false") << "}\n";
            file.close();
        };

        writeResult("before-cancel", false);
        bool cancelled = false;
        if (dialog != nullptr && cancelAfterDump_ &&
            motionStudyDialogReady(dialog)) {
            cancelled = cancelDialog(dialog);
        }
        writeResult("complete", cancelled);
        deleteLater();
    }

    void poll() {
        const auto widgets = QApplication::topLevelWidgets();
        QWidget* motionStudy = nullptr;
        for (QWidget* widget : widgets) {
            if (looksLikeMotionStudy(widget)) {
                motionStudy = widget;
                if (motionStudyDialogReady(widget)) {
                    if (readyDelayMs_ > 0) {
                        QPointer<QWidget> guarded(widget);
                        QTimer::singleShot(
                            readyDelayMs_,
                            this,
                            [this, guarded]() {
                                finish(guarded == nullptr
                                           ? "dialog-lost"
                                           : "dialog-found-delayed",
                                       guarded.data());
                            });
                    } else {
                        finish("dialog-found", widget);
                    }
                    return;
                }
            }
        }

        if (elapsedMs_ >= timeoutMs_) {
            finish("timeout", motionStudy);
            return;
        }

        elapsedMs_ += pollIntervalMs_;
        QTimer::singleShot(
            pollIntervalMs_, this, [this]() { poll(); });
    }

    std::string outputPath_;
    int pollIntervalMs_;
    int timeoutMs_;
    bool cancelAfterDump_;
    int readyDelayMs_;
    int elapsedMs_ = 0;
};

class JointTokenProbeController final : public QObject {
public:
    JointTokenProbeController(std::string entityToken,
                              std::string outputPath,
                              int pollIntervalMs,
                              int timeoutMs,
                              int settleMs)
        : entityToken_(std::move(entityToken)),
          outputPath_(std::move(outputPath)),
          pollIntervalMs_(std::max(50, pollIntervalMs)),
          timeoutMs_(std::max(250, timeoutMs)),
          settleMs_(std::max(50, settleMs)) {}

    void start() {
        elapsedMs_ = 0;
        writeCheckpoint("armed", nullptr, -1);
        poll();
    }

private:
    void writeCheckpoint(const char* status,
                         const QWidget* dialog,
                         int tableRows) const {
        std::ofstream file(outputPath_, std::ios::out | std::ios::trunc);
        file << "{"
             << "\"schema\":\"cad-agent.motion-study-joint-token-probe.v1\","
             << "\"status\":\"" << status << "\","
             << "\"qt_version\":\"" << qVersion() << "\","
             << "\"main_thread\":"
             << ((QCoreApplication::instance() != nullptr &&
                  QCoreApplication::instance()->thread() ==
                      QThread::currentThread())
                     ? "true"
                     : "false")
             << ",\"elapsed_ms\":" << elapsedMs_
             << ",\"dialog_found\":"
             << (dialog != nullptr ? "true" : "false")
             << ",\"dialog_class\":"
             << quoted(dialog == nullptr
                           ? QString()
                           : QString::fromLatin1(
                                 dialog->metaObject()->className()))
             << ",\"table_rows\":" << tableRows
             << "}\n";
        file.close();
    }

    void finish(const char* status,
                QWidget* dialog,
                const JointInjectionResult& injection,
                int rowsBefore,
                int rowsAfter) {
        const bool rowDeltaAccepted =
            injection.code == 0 && rowsBefore == 0 && rowsAfter == 1;

        std::ostringstream output;
        output
            << "{"
            << "\"schema\":\"cad-agent.motion-study-joint-token-probe.v1\","
            << "\"status\":\"" << status << "\","
            << "\"qt_version\":\"" << qVersion() << "\","
            << "\"main_thread\":"
            << ((QCoreApplication::instance() != nullptr &&
                 QCoreApplication::instance()->thread() ==
                     QThread::currentThread())
                    ? "true"
                    : "false")
            << ",\"elapsed_ms\":" << elapsedMs_
            << ",\"dialog_found\":"
            << (dialog != nullptr ? "true" : "false")
            << ",\"dialog_class\":"
            << quoted(dialog == nullptr
                          ? QString()
                          : QString::fromLatin1(
                                dialog->metaObject()->className()))
            << ",\"dialog_ready\":"
            << (isExactMotionStudyDialog(dialog) ? "true" : "false")
            << ",\"entity_token\":" << quoted(entityToken_)
            << ",\"injection\":{"
            << "\"code\":" << injection.code
            << ",\"fusion_version\":"
            << quoted(injection.fusionVersion)
            << ",\"xlayer_path\":" << quoted(injection.xlayerPath)
            << ",\"fusion_xlayer_path\":"
            << quoted(injection.fusionXlayerPath)
            << ",\"na_fusion_ui_path\":"
            << quoted(injection.naFusionUiPath)
            << ",\"nu_client_base_path\":"
            << quoted(injection.nuClientBasePath)
            << ",\"ns_data_model_path\":"
            << quoted(injection.nsDataModelPath)
            << ",\"xlayer_uuid_matches\":"
            << (injection.xlayerUuidMatches ? "true" : "false")
            << ",\"fusion_xlayer_uuid_matches\":"
            << (injection.fusionXlayerUuidMatches ? "true" : "false")
            << ",\"na_fusion_ui_uuid_matches\":"
            << (injection.naFusionUiUuidMatches ? "true" : "false")
            << ",\"nu_client_base_uuid_matches\":"
            << (injection.nuClientBaseUuidMatches ? "true" : "false")
            << ",\"ns_data_model_uuid_matches\":"
            << (injection.nsDataModelUuidMatches ? "true" : "false")
            << ",\"helper_prefix_matches\":"
            << (injection.helperPrefixMatches ? "true" : "false")
            << ",\"callback_thunk_matches\":"
            << (injection.callbackThunkMatches ? "true" : "false")
            << ",\"selection_accessor_prefix_matches\":"
            << (injection.selectionAccessorPrefixMatches
                    ? "true"
                    : "false")
            << ",\"command_input_changed_prefix_matches\":"
            << (injection.commandInputChangedPrefixMatches
                    ? "true"
                    : "false")
            << ",\"joint_occurrence_accessor_prefix_matches\":"
            << (injection.jointOccurrenceAccessorPrefixMatches
                    ? "true"
                    : "false")
            << ",\"strong_ref_constructor_prefix_matches\":"
            << (injection.strongRefConstructorPrefixMatches
                    ? "true"
                    : "false")
            << ",\"strong_ref_destructor_prefix_matches\":"
            << (injection.strongRefDestructorPrefixMatches
                    ? "true"
                    : "false")
            << ",\"motion_study_select_joint_prefix_matches\":"
            << (injection.motionStudySelectJointPrefixMatches
                    ? "true"
                    : "false")
            << ",\"internal_selection_input_resolved\":"
            << (injection.internalSelectionInputResolved
                    ? "true"
                    : "false")
            << ",\"native_command_input_matches\":"
            << (injection.nativeCommandInputMatches
                    ? "true"
                    : "false")
            << ",\"native_dialog_facade_resolved\":"
            << (injection.nativeDialogFacadeResolved
                    ? "true"
                    : "false")
            << ",\"native_dialog_matches\":"
            << (injection.nativeDialogMatches ? "true" : "false")
            << ",\"native_dialog_callback_matches\":"
            << (injection.nativeDialogCallbackMatches
                    ? "true"
                    : "false")
            << ",\"native_event_guard_ready\":"
            << (injection.nativeEventGuardReady ? "true" : "false")
            << ",\"selection_has_focus\":"
            << (injection.selectionHasFocus ? "true" : "false")
            << ",\"internal_joint_occurrence_resolved\":"
            << (injection.internalJointOccurrenceResolved
                    ? "true"
                    : "false")
            << ",\"strong_ref_constructed\":"
            << (injection.strongRefConstructed
                    ? "true"
                    : "false")
            << ",\"motion_study_select_joint_invoked\":"
            << (injection.motionStudySelectJointInvoked
                    ? "true"
                    : "false")
            << ",\"command_input_changed_invoked\":"
            << (injection.commandInputChangedInvoked
                    ? "true"
                    : "false")
            << ",\"command_id\":" << quoted(injection.commandId)
            << ",\"input_id\":" << quoted(injection.inputId)
            << ",\"input_object_type\":"
            << quoted(injection.inputObjectType)
            << ",\"selection_minimum\":"
            << injection.selectionMinimum
            << ",\"selection_maximum\":"
            << injection.selectionMaximum
            << ",\"selection_before\":"
            << injection.selectionBefore
            << ",\"selection_after\":"
            << injection.selectionAfter
            << ",\"token_match_count\":"
            << injection.tokenMatchCount
            << ",\"joint_name\":" << quoted(injection.jointName)
            << "}"
            << ",\"table_rows_before\":" << rowsBefore
            << ",\"table_rows_after\":" << rowsAfter
            << ",\"row_delta_accepted\":"
            << (rowDeltaAccepted ? "true" : "false");

        bool cancelQueued = false;
        if (dialog != nullptr && isExactMotionStudyDialog(dialog)) {
            cancelQueued = QMetaObject::invokeMethod(
                dialog, "onDialogCancel", Qt::QueuedConnection);
        }
        output << ",\"cancel_method\":\"onDialogCancel\","
               << "\"cancel_connection\":\"queued\","
               << "\"cancel_queued\":"
               << (cancelQueued ? "true" : "false")
               << ",\"accepted\":"
               << (rowDeltaAccepted && cancelQueued ? "true" : "false")
               << "}\n";

        std::ofstream file(outputPath_, std::ios::out | std::ios::trunc);
        file << output.str();
        file.close();
        deleteLater();
    }

    void inject(QWidget* dialog, QTableWidget* table) {
        const int rowsBefore = table->rowCount();
        writeCheckpoint("dialog-found-before-injection",
                        dialog,
                        rowsBefore);
        const JointInjectionResult injection =
            addJointToken(dialog, entityToken_);
        writeCheckpoint("dialog-found-after-injection",
                        dialog,
                        table->rowCount());
        if (injection.code != 0) {
            finish("injection-rejected",
                   dialog,
                   injection,
                   rowsBefore,
                   table->rowCount());
            return;
        }

        const QPointer<QWidget> guardedDialog(dialog);
        const QPointer<QTableWidget> guardedTable(table);
        QTimer::singleShot(
            settleMs_,
            this,
            [this,
             guardedDialog,
             guardedTable,
             injection,
             rowsBefore]() {
                if (guardedDialog == nullptr ||
                    guardedTable == nullptr) {
                    finish("dialog-lost",
                           guardedDialog.data(),
                           injection,
                           rowsBefore,
                           -1);
                    return;
                }
                const int rowsAfter = guardedTable->rowCount();
                finish(rowsBefore == 0 && rowsAfter == 1
                           ? "joint-row-added"
                           : "row-delta-rejected",
                       guardedDialog.data(),
                       injection,
                       rowsBefore,
                       rowsAfter);
            });
    }

    void poll() {
        const auto widgets = QApplication::topLevelWidgets();
        for (QWidget* widget : widgets) {
            if (!isExactMotionStudyDialog(widget)) {
                continue;
            }
            const auto tables =
                widget->findChildren<QTableWidget*>();
            if (tables.size() != 1) {
                JointInjectionResult rejected;
                rejected.code = -21;
                finish("table-cardinality-rejected",
                       widget,
                       rejected,
                       -1,
                       -1);
                return;
            }
            inject(widget, tables.front());
            return;
        }

        if (elapsedMs_ >= timeoutMs_) {
            JointInjectionResult timeout;
            timeout.code = -22;
            finish("timeout", nullptr, timeout, -1, -1);
            return;
        }

        elapsedMs_ += pollIntervalMs_;
        QTimer::singleShot(
            pollIntervalMs_, this, [this]() { poll(); });
    }

    std::string entityToken_;
    std::string outputPath_;
    int pollIntervalMs_;
    int timeoutMs_;
    int settleMs_;
    int elapsedMs_ = 0;
};

class JointKeyframeProbeController final : public QObject {
public:
    JointKeyframeProbeController(std::string entityToken,
                                 int step,
                                 double angleDegrees,
                                 std::string outputPath,
                                 int pollIntervalMs,
                                 int timeoutMs,
                                 int settleMs)
        : entityToken_(std::move(entityToken)),
          step_(step),
          angleDegrees_(angleDegrees),
          outputPath_(std::move(outputPath)),
          pollIntervalMs_(std::max(50, pollIntervalMs)),
          timeoutMs_(std::max(250, timeoutMs)),
          settleMs_(std::max(50, settleMs)) {}

    void start() {
        elapsedMs_ = 0;
        writeCheckpoint("armed", nullptr, -1);
        poll();
    }

private:
    void writeCheckpoint(const char* status,
                         const QWidget* dialog,
                         int tableRows) const {
        std::ofstream file(outputPath_, std::ios::out | std::ios::trunc);
        file << "{"
             << "\"schema\":\"cad-agent.motion-study-joint-keyframe-probe.v1\","
             << "\"phase\":\"checkpoint\","
             << "\"status\":\"" << status << "\","
             << "\"qt_version\":\"" << qVersion() << "\","
             << "\"main_thread\":"
             << jsonBool(QCoreApplication::instance() != nullptr &&
                         QCoreApplication::instance()->thread() ==
                             QThread::currentThread())
             << ",\"elapsed_ms\":" << elapsedMs_
             << ",\"dialog_found\":" << jsonBool(dialog != nullptr)
             << ",\"table_rows\":" << tableRows << "}\n";
        file.close();
    }

    std::string makeReport(const char* status,
                           const char* phase,
                           QWidget* dialog,
                           const JointInjectionResult& joint,
                           const KeyframeInjectionResult& keyframe,
                           int rowsBefore,
                           int rowsAfter,
                           bool cancelQueued) const {
        const bool rowDeltaAccepted =
            joint.code == 0 && rowsBefore == 0 && rowsAfter == 1;
        const bool injectionAccepted =
            rowDeltaAccepted && keyframe.code == 0;

        std::ostringstream output;
        output
            << std::setprecision(17)
            << "{"
            << "\"schema\":\"cad-agent.motion-study-joint-keyframe-probe.v1\","
            << "\"phase\":\"" << phase << "\","
            << "\"status\":\"" << status << "\","
            << "\"qt_version\":\"" << qVersion() << "\","
            << "\"main_thread\":"
            << jsonBool(QCoreApplication::instance() != nullptr &&
                        QCoreApplication::instance()->thread() ==
                            QThread::currentThread())
            << ",\"elapsed_ms\":" << elapsedMs_
            << ",\"dialog_found\":" << jsonBool(dialog != nullptr)
            << ",\"dialog_class\":"
            << quoted(dialog == nullptr
                          ? QString()
                          : QString::fromLatin1(
                                dialog->metaObject()->className()))
            << ",\"dialog_ready\":"
            << jsonBool(isExactMotionStudyDialog(dialog))
            << ",\"entity_token\":" << quoted(entityToken_)
            << ",\"requested_step\":" << step_
            << ",\"requested_angle_degrees\":" << angleDegrees_
            << ",\"table_rows_before\":" << rowsBefore
            << ",\"table_rows_after\":" << rowsAfter
            << ",\"row_delta_accepted\":"
            << jsonBool(rowDeltaAccepted)
            << ",\"joint_injection\":";
        appendJointInjection(output, joint);
        output << ",\"keyframe_injection\":";
        appendKeyframeInjection(output, keyframe);
        output
            << ",\"injection_accepted\":"
            << jsonBool(injectionAccepted)
            << ",\"cancel_method\":\"onDialogCancel\","
            << "\"cancel_connection\":\"queued\","
            << "\"cancel_queued\":" << jsonBool(cancelQueued)
            << ",\"pre_cancel_probe_accepted\":"
            << jsonBool(injectionAccepted && cancelQueued)
            << ",\"post_cancel_verification_required\":true"
            << "}\n";
        return output.str();
    }

    void finish(const char* status,
                QWidget* dialog,
                const JointInjectionResult& joint,
                const KeyframeInjectionResult& keyframe,
                int rowsBefore,
                int rowsAfter) {
        {
            std::ofstream file(outputPath_,
                               std::ios::out | std::ios::trunc);
            file << makeReport(status,
                               "before-cancel",
                               dialog,
                               joint,
                               keyframe,
                               rowsBefore,
                               rowsAfter,
                               false);
            file.close();
        }

        bool cancelQueued = false;
        if (dialog != nullptr && isExactMotionStudyDialog(dialog)) {
            cancelQueued = QMetaObject::invokeMethod(
                dialog, "onDialogCancel", Qt::QueuedConnection);
        }

        {
            std::ofstream file(outputPath_,
                               std::ios::out | std::ios::trunc);
            file << makeReport(status,
                               "cancel-queued",
                               dialog,
                               joint,
                               keyframe,
                               rowsBefore,
                               rowsAfter,
                               cancelQueued);
            file.close();
        }
        deleteLater();
    }

    void inject(QWidget* dialog, QTableWidget* table) {
        const int rowsBefore = table->rowCount();
        if (rowsBefore != 0) {
            JointInjectionResult joint;
            joint.code = -30;
            KeyframeInjectionResult keyframe;
            keyframe.code = -30;
            finish("baseline-row-count-rejected",
                   dialog,
                   joint,
                   keyframe,
                   rowsBefore,
                   rowsBefore);
            return;
        }

        writeCheckpoint("dialog-found-before-joint",
                        dialog,
                        rowsBefore);
        const JointInjectionResult joint =
            addJointToken(dialog, entityToken_);
        if (joint.code != 0) {
            KeyframeInjectionResult keyframe;
            keyframe.code = -31;
            finish("joint-injection-rejected",
                   dialog,
                   joint,
                   keyframe,
                   rowsBefore,
                   table->rowCount());
            return;
        }

        const QPointer<QWidget> guardedDialog(dialog);
        const QPointer<QTableWidget> guardedTable(table);
        QTimer::singleShot(
            settleMs_,
            this,
            [this, guardedDialog, guardedTable, joint, rowsBefore]() {
                if (guardedDialog == nullptr ||
                    guardedTable == nullptr) {
                    KeyframeInjectionResult keyframe;
                    keyframe.code = -32;
                    finish("dialog-lost-after-joint",
                           guardedDialog.data(),
                           joint,
                           keyframe,
                           rowsBefore,
                           -1);
                    return;
                }

                const int rowsAfter = guardedTable->rowCount();
                if (rowsAfter != 1) {
                    KeyframeInjectionResult keyframe;
                    keyframe.code = -33;
                    finish("joint-row-delta-rejected",
                           guardedDialog.data(),
                           joint,
                           keyframe,
                           rowsBefore,
                           rowsAfter);
                    return;
                }

                writeCheckpoint("joint-row-ready-before-keyframe",
                                guardedDialog.data(),
                                rowsAfter);
                const KeyframeInjectionResult keyframe =
                    addKeyframe(guardedDialog.data(),
                                0,
                                step_,
                                angleDegrees_);
                finish(keyframe.code == 0
                           ? "keyframe-injected"
                           : "keyframe-injection-rejected",
                       guardedDialog.data(),
                       joint,
                       keyframe,
                       rowsBefore,
                       guardedTable->rowCount());
            });
    }

    void poll() {
        const auto widgets = QApplication::topLevelWidgets();
        for (QWidget* widget : widgets) {
            if (!isExactMotionStudyDialog(widget)) {
                continue;
            }
            const auto tables = widget->findChildren<QTableWidget*>();
            if (tables.size() != 1) {
                JointInjectionResult joint;
                joint.code = -34;
                KeyframeInjectionResult keyframe;
                keyframe.code = -34;
                finish("table-cardinality-rejected",
                       widget,
                       joint,
                       keyframe,
                       -1,
                       -1);
                return;
            }
            inject(widget, tables.front());
            return;
        }

        if (elapsedMs_ >= timeoutMs_) {
            JointInjectionResult joint;
            joint.code = -35;
            KeyframeInjectionResult keyframe;
            keyframe.code = -35;
            finish("timeout", nullptr, joint, keyframe, -1, -1);
            return;
        }

        elapsedMs_ += pollIntervalMs_;
        QTimer::singleShot(
            pollIntervalMs_, this, [this]() { poll(); });
    }

    std::string entityToken_;
    int step_;
    double angleDegrees_;
    std::string outputPath_;
    int pollIntervalMs_;
    int timeoutMs_;
    int settleMs_;
    int elapsedMs_ = 0;
};

class MotionStudyProgramController final : public QObject {
public:
    MotionStudyProgramController(std::vector<MotionJointSpec> specs,
                                 std::string outputPath,
                                 int pollIntervalMs,
                                 int timeoutMs,
                                 int settleMs,
                                 bool commitOnSuccess)
        : specs_(std::move(specs)),
          outputPath_(std::move(outputPath)),
          pollIntervalMs_(std::max(50, pollIntervalMs)),
          timeoutMs_(std::max(250, timeoutMs)),
          settleMs_(std::max(50, settleMs)),
          pointSettleMs_(std::max(25, std::min(100, settleMs))),
          commitOnSuccess_(commitOnSuccess),
          keyframeResults_(specs_.size()) {}

    void start() {
        elapsedMs_ = 0;
        writeCheckpoint("armed");
        poll();
    }

private:
    std::size_t expectedPointCount() const {
        std::size_t count = 0;
        for (const MotionJointSpec& spec : specs_) {
            count += spec.points.size();
        }
        return count;
    }

    std::size_t actualPointResultCount() const {
        std::size_t count = 0;
        for (const auto& results : keyframeResults_) {
            count += results.size();
        }
        return count;
    }

    bool curveMatches(std::size_t jointIndex) const {
        if (jointIndex >= specs_.size() ||
            jointIndex >= keyframeResults_.size() ||
            keyframeResults_[jointIndex].size() !=
                specs_[jointIndex].points.size() ||
            keyframeResults_[jointIndex].empty() ||
            jointIndex >= finalCurveReadbacks_.size() ||
            finalCurveReadbacks_[jointIndex].code != 0) {
            return false;
        }
        for (const KeyframeInjectionResult& pointResult :
             keyframeResults_[jointIndex]) {
            if (pointResult.code != 0) {
                return false;
            }
        }

        const auto& grips = finalCurveReadbacks_[jointIndex].grips;
        std::vector<bool> matched(specs_[jointIndex].points.size(), false);
        std::size_t mainGripCount = 0;
        for (const GripSnapshot& grip : grips) {
            if (grip.deleted) {
                return false;
            }
            if (grip.style == 1 && grip.direction == 4) {
                continue;
            }
            if (grip.style != 0 || grip.direction != 1) {
                return false;
            }
            ++mainGripCount;
            bool found = false;
            for (std::size_t pointIndex = 0;
                 pointIndex < specs_[jointIndex].points.size();
                 ++pointIndex) {
                const MotionPointSpec& point =
                    specs_[jointIndex].points[pointIndex];
                const double expectedRadians =
                    point.angleDegrees * std::acos(-1.0) / 180.0;
                if (!matched[pointIndex] &&
                    std::abs(grip.step - point.step) < 1.0e-9 &&
                    std::abs(grip.nativeValue - expectedRadians) <
                        1.0e-8) {
                    matched[pointIndex] = true;
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false;
            }
        }
        return mainGripCount == specs_[jointIndex].points.size() &&
               std::all_of(matched.begin(),
                           matched.end(),
                           [](bool value) { return value; });
    }

    void collectFinalCurveReadbacks() {
        finalCurveReadbacks_.clear();
        if (dialog_ == nullptr ||
            !isExactMotionStudyDialog(dialog_.data())) {
            return;
        }
        finalCurveReadbacks_.reserve(specs_.size());
        for (std::size_t jointIndex = 0;
             jointIndex < specs_.size();
             ++jointIndex) {
            finalCurveReadbacks_.push_back(
                readCurveGrips(dialog_.data(),
                               static_cast<int>(jointIndex)));
        }
    }

    bool programVerified() const {
        if (dialog_ == nullptr || table_ == nullptr ||
            !isExactMotionStudyDialog(dialog_.data()) ||
            table_->rowCount() != static_cast<int>(specs_.size()) ||
            jointResults_.size() != specs_.size() ||
            actualPointResultCount() != expectedPointCount()) {
            return false;
        }
        if (finalCurveReadbacks_.size() != specs_.size()) {
            return false;
        }
        QAbstractButton* ok = motionStudyButton(
            dialog_.data(), QStringLiteral("OK"), QStringLiteral("确定"));
        if (ok == nullptr || !ok->isEnabled()) {
            return false;
        }
        for (std::size_t jointIndex = 0;
             jointIndex < specs_.size();
             ++jointIndex) {
            const JointInjectionResult& joint = jointResults_[jointIndex];
            if (joint.code != 0 ||
                joint.jointName != specs_[jointIndex].expectedName ||
                !joint.directDialogAppendMode ||
                !joint.directDialogAppendPrefixMatches ||
                !joint.directDialogFacadeAppendPrefixMatches ||
                !joint.directDialogAppendInvoked ||
                !curveMatches(jointIndex)) {
                return false;
            }
        }
        return true;
    }

    void writeCheckpoint(const char* status) const {
        std::ofstream file(outputPath_, std::ios::out | std::ios::trunc);
        file << "{"
             << "\"schema\":\"cad-agent.motion-study-program.v1\","
             << "\"phase\":\"checkpoint\","
             << "\"status\":\"" << status << "\","
             << "\"qt_version\":\"" << qVersion() << "\","
             << "\"main_thread\":"
             << jsonBool(QCoreApplication::instance() != nullptr &&
                         QCoreApplication::instance()->thread() ==
                             QThread::currentThread())
             << ",\"elapsed_ms\":" << elapsedMs_
             << ",\"current_joint_index\":" << jointIndex_
             << ",\"current_point_index\":" << pointIndex_
             << ",\"joint_results\":" << jointResults_.size()
             << ",\"point_results\":" << actualPointResultCount()
             << ",\"dialog_found\":" << jsonBool(dialog_ != nullptr)
             << ",\"table_rows\":"
             << (table_ == nullptr ? -1 : table_->rowCount())
             << "}\n";
        file.close();
    }

    std::string makeReport(const char* status,
                           const char* phase,
                           const char* actionMethod,
                           bool actionQueued,
                           bool verified,
                           bool preActionReportWritten) const {
        std::ostringstream output;
        output
            << std::setprecision(17)
            << "{"
            << "\"schema\":\"cad-agent.motion-study-program.v1\","
            << "\"phase\":\"" << phase << "\","
            << "\"status\":\"" << status << "\","
            << "\"qt_version\":\"" << qVersion() << "\","
            << "\"main_thread\":"
            << jsonBool(QCoreApplication::instance() != nullptr &&
                        QCoreApplication::instance()->thread() ==
                            QThread::currentThread())
            << ",\"elapsed_ms\":" << elapsedMs_
            << ",\"commit_requested\":"
            << jsonBool(commitOnSuccess_)
            << ",\"dialog_found\":" << jsonBool(dialog_ != nullptr)
            << ",\"dialog_class\":"
            << quoted(dialog_ == nullptr
                          ? QString()
                          : QString::fromLatin1(
                                dialog_->metaObject()->className()))
            << ",\"dialog_ready\":"
            << jsonBool(isExactMotionStudyDialog(dialog_.data()))
            << ",\"expected_joint_count\":" << specs_.size()
            << ",\"expected_point_count\":" << expectedPointCount()
            << ",\"table_rows\":"
            << (table_ == nullptr ? -1 : table_->rowCount())
            << ",\"joint_result_count\":" << jointResults_.size()
            << ",\"point_result_count\":"
            << actualPointResultCount()
            << ",\"program_verified\":" << jsonBool(verified)
            << ",\"pre_action_report_written\":"
            << jsonBool(preActionReportWritten)
            << ",\"joints\":[";

        for (std::size_t jointIndex = 0;
             jointIndex < specs_.size();
             ++jointIndex) {
            if (jointIndex != 0) {
                output << ",";
            }
            const MotionJointSpec& spec = specs_[jointIndex];
            output
                << "{\"row_index\":" << jointIndex
                << ",\"entity_token\":" << quoted(spec.entityToken)
                << ",\"expected_name\":" << quoted(spec.expectedName)
                << ",\"expected_points\":[";
            for (std::size_t pointIndex = 0;
                 pointIndex < spec.points.size();
                 ++pointIndex) {
                if (pointIndex != 0) {
                    output << ",";
                }
                output << "{\"step\":" << spec.points[pointIndex].step
                       << ",\"angle_degrees\":"
                       << spec.points[pointIndex].angleDegrees << "}";
            }
            output << "]";

            output << ",\"joint_injection\":";
            if (jointIndex < jointResults_.size()) {
                appendJointInjection(output, jointResults_[jointIndex]);
            } else {
                output << "null";
            }

            output << ",\"keyframe_injections\":[";
            if (jointIndex < keyframeResults_.size()) {
                for (std::size_t pointIndex = 0;
                     pointIndex < keyframeResults_[jointIndex].size();
                     ++pointIndex) {
                    if (pointIndex != 0) {
                        output << ",";
                    }
                    appendKeyframeInjection(
                        output,
                        keyframeResults_[jointIndex][pointIndex]);
                }
            }
            output << "]";

            std::size_t totalGripCount = 0;
            std::size_t mainGripCount = 0;
            std::size_t dependentGripCount = 0;
            if (jointIndex < finalCurveReadbacks_.size() &&
                finalCurveReadbacks_[jointIndex].code == 0) {
                const auto& grips =
                    finalCurveReadbacks_[jointIndex].grips;
                totalGripCount = grips.size();
                for (const GripSnapshot& grip : grips) {
                    if (!grip.deleted && grip.style == 0 &&
                        grip.direction == 1) {
                        ++mainGripCount;
                    } else if (!grip.deleted && grip.style == 1 &&
                               grip.direction == 4) {
                        ++dependentGripCount;
                    }
                }
            }
            output
                << ",\"final_curve_readback\":";
            if (jointIndex < finalCurveReadbacks_.size()) {
                appendCurveReadback(output,
                                    finalCurveReadbacks_[jointIndex]);
            } else {
                output << "null";
            }
            output
                << ",\"curve_summary\":{"
                << "\"accepted\":" << jsonBool(curveMatches(jointIndex))
                << ",\"total_grips\":" << totalGripCount
                << ",\"main_grips\":" << mainGripCount
                << ",\"dependent_grips\":" << dependentGripCount
                << "}}";
        }

        output
            << "]"
            << ",\"dialog_action_method\":\"" << actionMethod << "\","
            << "\"dialog_action_connection\":\"queued\","
            << "\"dialog_action_queued\":" << jsonBool(actionQueued)
            << ",\"pre_action_accepted\":"
            << jsonBool(verified && preActionReportWritten &&
                        actionQueued)
            << ",\"post_action_verification_required\":true"
            << "}\n";
        return output.str();
    }

    bool writeReportAtomically(const std::string& contents) const {
        const std::string temporaryPath = outputPath_ + ".tmp";
        std::ofstream file(temporaryPath,
                           std::ios::out | std::ios::trunc);
        if (!file.is_open()) {
            return false;
        }
        file << contents;
        file.flush();
        const bool writeSucceeded = file.good();
        file.close();
        if (!writeSucceeded) {
            std::remove(temporaryPath.c_str());
            return false;
        }
        if (std::rename(temporaryPath.c_str(), outputPath_.c_str()) != 0) {
            std::remove(temporaryPath.c_str());
            return false;
        }
        return true;
    }

    void finish(const char* status) {
        if (finished_) {
            return;
        }
        finished_ = true;
        collectFinalCurveReadbacks();
        const bool verified = programVerified();
        const char* effectiveStatus =
            verified ? "program-verified" : status;
        const char* plannedActionMethod =
            verified && commitOnSuccess_ ? "onDialogOK" : "onDialogCancel";
        const bool preActionReportWritten = writeReportAtomically(
            makeReport(effectiveStatus,
                       "before-action",
                       plannedActionMethod,
                       false,
                       verified,
                       true));
        const char* actionMethod =
            preActionReportWritten ? plannedActionMethod
                                   : "onDialogCancel";

        bool actionQueued = false;
        if (dialog_ != nullptr &&
            isExactMotionStudyDialog(dialog_.data())) {
            actionQueued = QMetaObject::invokeMethod(
                dialog_.data(), actionMethod, Qt::QueuedConnection);
        }

        if (preActionReportWritten) {
            writeReportAtomically(
                makeReport(effectiveStatus,
                           "action-queued",
                           actionMethod,
                           actionQueued,
                           verified,
                           true));
        }
        deleteLater();
    }

    void addCurrentPoint() {
        if (finished_) {
            return;
        }
        if (dialog_ == nullptr || table_ == nullptr ||
            !isExactMotionStudyDialog(dialog_.data())) {
            finish("dialog-lost-before-keyframe");
            return;
        }
        if (jointIndex_ >= specs_.size()) {
            finish(programVerified() ? "program-verified"
                                     : "program-verification-rejected");
            return;
        }
        if (table_->rowCount() != static_cast<int>(jointIndex_ + 1)) {
            finish("table-row-count-rejected-before-keyframe");
            return;
        }
        if (pointIndex_ >= specs_[jointIndex_].points.size()) {
            ++jointIndex_;
            pointIndex_ = 0;
            QTimer::singleShot(
                pointSettleMs_, this, [this]() { addCurrentJoint(); });
            return;
        }

        const MotionPointSpec& point =
            specs_[jointIndex_].points[pointIndex_];
        const KeyframeInjectionResult result =
            addKeyframe(dialog_.data(),
                        static_cast<int>(jointIndex_),
                        point.step,
                        point.angleDegrees);
        keyframeResults_[jointIndex_].push_back(result);
        if (result.code != 0) {
            finish("keyframe-injection-rejected");
            return;
        }

        ++pointIndex_;
        writeCheckpoint("keyframe-added");
        QTimer::singleShot(
            pointSettleMs_, this, [this]() { addCurrentPoint(); });
    }

    void addCurrentJoint() {
        if (finished_) {
            return;
        }
        if (dialog_ == nullptr || table_ == nullptr ||
            !isExactMotionStudyDialog(dialog_.data())) {
            finish("dialog-lost-before-joint");
            return;
        }
        if (jointIndex_ >= specs_.size()) {
            finish(programVerified() ? "program-verified"
                                     : "program-verification-rejected");
            return;
        }
        if (table_->rowCount() != static_cast<int>(jointIndex_)) {
            finish("table-row-count-rejected-before-joint");
            return;
        }

        const JointInjectionResult result =
            addJointToken(dialog_.data(),
                          specs_[jointIndex_].entityToken,
                          true);
        jointResults_.push_back(result);
        if (result.code != 0 ||
            result.jointName != specs_[jointIndex_].expectedName) {
            finish("joint-injection-rejected");
            return;
        }

        writeCheckpoint("joint-added-awaiting-row");
        QTimer::singleShot(
            settleMs_,
            this,
            [this]() {
                if (finished_) {
                    return;
                }
                if (dialog_ == nullptr || table_ == nullptr ||
                    !isExactMotionStudyDialog(dialog_.data())) {
                    finish("dialog-lost-after-joint");
                    return;
                }
                if (table_->rowCount() !=
                    static_cast<int>(jointIndex_ + 1)) {
                    finish("joint-row-delta-rejected");
                    return;
                }
                pointIndex_ = 0;
                addCurrentPoint();
            });
    }

    void begin(QWidget* dialog, QTableWidget* table) {
        dialog_ = dialog;
        table_ = table;
        if (table_->rowCount() != 0) {
            finish("baseline-row-count-rejected");
            return;
        }
        jointIndex_ = 0;
        pointIndex_ = 0;
        writeCheckpoint("dialog-ready");
        addCurrentJoint();
    }

    void poll() {
        if (finished_) {
            return;
        }
        const auto widgets = QApplication::topLevelWidgets();
        for (QWidget* widget : widgets) {
            if (!isExactMotionStudyDialog(widget)) {
                continue;
            }
            const auto tables = widget->findChildren<QTableWidget*>();
            if (tables.size() != 1) {
                dialog_ = widget;
                finish("table-cardinality-rejected");
                return;
            }
            begin(widget, tables.front());
            return;
        }

        if (elapsedMs_ >= timeoutMs_) {
            finish("timeout");
            return;
        }
        elapsedMs_ += pollIntervalMs_;
        QTimer::singleShot(
            pollIntervalMs_, this, [this]() { poll(); });
    }

    std::vector<MotionJointSpec> specs_;
    std::string outputPath_;
    int pollIntervalMs_;
    int timeoutMs_;
    int settleMs_;
    int pointSettleMs_;
    bool commitOnSuccess_;
    QPointer<QWidget> dialog_;
    QPointer<QTableWidget> table_;
    std::vector<JointInjectionResult> jointResults_;
    std::vector<std::vector<KeyframeInjectionResult>> keyframeResults_;
    std::vector<CurveReadbackResult> finalCurveReadbacks_;
    std::size_t jointIndex_ = 0;
    std::size_t pointIndex_ = 0;
    int elapsedMs_ = 0;
    bool finished_ = false;
};

class MotionStudyReopenReadbackController final : public QObject {
public:
    MotionStudyReopenReadbackController(
        std::vector<MotionJointSpec> specs,
        std::string outputPath,
        int pollIntervalMs,
        int timeoutMs,
        int settleMs)
        : specs_(std::move(specs)),
          outputPath_(std::move(outputPath)),
          pollIntervalMs_(std::max(50, pollIntervalMs)),
          timeoutMs_(std::max(250, timeoutMs)),
          settleMs_(std::max(50, settleMs)) {}

    void start() {
        elapsedMs_ = 0;
        writeCheckpoint("armed");
        poll();
    }

private:
    std::size_t expectedPointCount() const {
        std::size_t count = 0;
        for (const MotionJointSpec& spec : specs_) {
            count += spec.points.size();
        }
        return count;
    }

    bool rowNameMatches(std::size_t rowIndex) const {
        if (rowIndex >= specs_.size() ||
            rowIndex >= rowTexts_.size()) {
            return false;
        }
        const QString expected = QString::fromUtf8(
            specs_[rowIndex].expectedName.c_str(),
            static_cast<qsizetype>(
                specs_[rowIndex].expectedName.size()));
        return std::any_of(
            rowTexts_[rowIndex].begin(),
            rowTexts_[rowIndex].end(),
            [&expected](const QString& value) {
                return value.trimmed() == expected;
            });
    }

    bool curveMatches(std::size_t rowIndex) const {
        if (rowIndex >= specs_.size() ||
            rowIndex >= readbacks_.size() ||
            readbacks_[rowIndex].code != 0) {
            return false;
        }
        const auto& expectedPoints = specs_[rowIndex].points;
        const auto& grips = readbacks_[rowIndex].grips;
        std::vector<bool> matched(expectedPoints.size(), false);
        std::size_t mainGripCount = 0;
        std::size_t dependentGripCount = 0;
        for (const GripSnapshot& grip : grips) {
            if (grip.deleted) {
                return false;
            }
            if (grip.style == 1 && grip.direction == 4) {
                ++dependentGripCount;
                continue;
            }
            if (grip.style != 0 || grip.direction != 1) {
                return false;
            }
            ++mainGripCount;
            bool found = false;
            for (std::size_t pointIndex = 0;
                 pointIndex < expectedPoints.size();
                 ++pointIndex) {
                const MotionPointSpec& point =
                    expectedPoints[pointIndex];
                const double expectedRadians =
                    point.angleDegrees * std::acos(-1.0) / 180.0;
                if (!matched[pointIndex] &&
                    std::abs(grip.step - point.step) < 1.0e-9 &&
                    std::abs(grip.nativeValue - expectedRadians) <
                        1.0e-8) {
                    matched[pointIndex] = true;
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false;
            }
        }
        return mainGripCount == expectedPoints.size() &&
               dependentGripCount == 0 &&
               std::all_of(matched.begin(),
                           matched.end(),
                           [](bool value) { return value; });
    }

    std::size_t observedMainGripCount() const {
        std::size_t count = 0;
        for (const CurveReadbackResult& readback : readbacks_) {
            for (const GripSnapshot& grip : readback.grips) {
                if (!grip.deleted && grip.style == 0 &&
                    grip.direction == 1) {
                    ++count;
                }
            }
        }
        return count;
    }

    std::size_t observedDependentGripCount() const {
        std::size_t count = 0;
        for (const CurveReadbackResult& readback : readbacks_) {
            for (const GripSnapshot& grip : readback.grips) {
                if (!grip.deleted && grip.style == 1 &&
                    grip.direction == 4) {
                    ++count;
                }
            }
        }
        return count;
    }

    bool verified() const {
        if (dialog_ == nullptr || table_ == nullptr ||
            !isExactMotionStudyDialog(dialog_.data()) ||
            table_->rowCount() != static_cast<int>(specs_.size()) ||
            rowTexts_.size() != specs_.size() ||
            readbacks_.size() != specs_.size() ||
            observedMainGripCount() != expectedPointCount() ||
            observedDependentGripCount() != 0) {
            return false;
        }
        for (std::size_t rowIndex = 0;
             rowIndex < specs_.size();
             ++rowIndex) {
            if (!rowNameMatches(rowIndex) ||
                !curveMatches(rowIndex)) {
                return false;
            }
        }
        return true;
    }

    void writeCheckpoint(const char* status) const {
        std::ostringstream output;
        output
            << "{\"schema\":\"cad-agent.motion-study-reopen-readback.v1\""
            << ",\"phase\":\"checkpoint\""
            << ",\"status\":" << quoted(std::string(status))
            << ",\"elapsed_ms\":" << elapsedMs_
            << ",\"dialog_found\":" << jsonBool(dialog_ != nullptr)
            << ",\"table_rows\":"
            << (table_ == nullptr ? -1 : table_->rowCount())
            << "}\n";
        writeTextAtomically(outputPath_, output.str());
    }

    std::string makeReport(const char* status,
                           bool accepted,
                           bool reportWritten,
                           bool cancelQueued) const {
        const std::size_t implicitEndpointCount = specs_.size() * 2;
        const std::size_t mainGripCount = observedMainGripCount();
        const std::size_t dependentGripCount =
            observedDependentGripCount();
        std::ostringstream output;
        output
            << std::setprecision(17)
            << "{\"schema\":\"cad-agent.motion-study-reopen-readback.v1\""
            << ",\"phase\":\"before-cancel\""
            << ",\"status\":" << quoted(std::string(status))
            << ",\"qt_version\":" << quoted(std::string(qVersion()))
            << ",\"main_thread\":"
            << jsonBool(QCoreApplication::instance() != nullptr &&
                        QCoreApplication::instance()->thread() ==
                            QThread::currentThread())
            << ",\"elapsed_ms\":" << elapsedMs_
            << ",\"read_only\":true"
            << ",\"dialog_found\":" << jsonBool(dialog_ != nullptr)
            << ",\"dialog_ready\":"
            << jsonBool(isExactMotionStudyDialog(dialog_.data()))
            << ",\"table_rows\":"
            << (table_ == nullptr ? -1 : table_->rowCount())
            << ",\"expected_joint_count\":" << specs_.size()
            << ",\"expected_internal_keyframe_count\":"
            << expectedPointCount()
            << ",\"observed_internal_keyframe_count\":"
            << mainGripCount
            << ",\"implicit_endpoint_count\":"
            << implicitEndpointCount
            << ",\"observed_motion_node_count\":"
            << (mainGripCount + implicitEndpointCount)
            << ",\"dependent_grip_count\":"
            << dependentGripCount
            << ",\"curves\":[";
        for (std::size_t rowIndex = 0;
             rowIndex < specs_.size();
             ++rowIndex) {
            if (rowIndex != 0) {
                output << ",";
            }
            const MotionJointSpec& spec = specs_[rowIndex];
            output
                << "{\"row_index\":" << rowIndex
                << ",\"expected_name\":" << quoted(spec.expectedName)
                << ",\"row_name_matches\":"
                << jsonBool(rowNameMatches(rowIndex))
                << ",\"row_cells\":[";
            if (rowIndex < rowTexts_.size()) {
                for (std::size_t column = 0;
                     column < rowTexts_[rowIndex].size();
                     ++column) {
                    if (column != 0) {
                        output << ",";
                    }
                    output << quoted(rowTexts_[rowIndex][column]);
                }
            }
            output << "],\"expected_points\":[";
            for (std::size_t pointIndex = 0;
                 pointIndex < spec.points.size();
                 ++pointIndex) {
                if (pointIndex != 0) {
                    output << ",";
                }
                output
                    << "{\"step\":" << spec.points[pointIndex].step
                    << ",\"angle_degrees\":"
                    << spec.points[pointIndex].angleDegrees << "}";
            }
            output << "],\"curve_matches\":"
                   << jsonBool(curveMatches(rowIndex))
                   << ",\"native_curve_readback\":";
            if (rowIndex < readbacks_.size()) {
                appendCurveReadback(output, readbacks_[rowIndex]);
            } else {
                output << "null";
            }
            output << "}";
        }
        output
            << "]"
            << ",\"accepted\":" << jsonBool(accepted)
            << ",\"pre_action_report_written\":"
            << jsonBool(reportWritten)
            << ",\"dialog_action_method\":\"onDialogCancel\""
            << ",\"dialog_action_connection\":\"queued\""
            << ",\"dialog_action_queued\":"
            << jsonBool(cancelQueued)
            << "}\n";
        return output.str();
    }

    void finish(const char* status) {
        if (finished_) {
            return;
        }
        finished_ = true;
        const bool accepted = verified();
        const char* effectiveStatus =
            accepted ? "reopen-program-verified" : status;
        const bool reportWritten = writeTextAtomically(
            outputPath_,
            makeReport(effectiveStatus,
                       accepted,
                       true,
                       false));
        bool cancelQueued = false;
        if (dialog_ != nullptr &&
            isExactMotionStudyDialog(dialog_.data())) {
            cancelQueued = QMetaObject::invokeMethod(
                dialog_.data(),
                "onDialogCancel",
                Qt::QueuedConnection);
        }
        if (reportWritten) {
            writeTextAtomically(
                outputPath_,
                makeReport(effectiveStatus,
                           accepted,
                           true,
                           cancelQueued));
        }
        deleteLater();
    }

    void capture() {
        if (finished_) {
            return;
        }
        if (dialog_ == nullptr || table_ == nullptr ||
            !isExactMotionStudyDialog(dialog_.data()) ||
            table_->rowCount() != static_cast<int>(specs_.size())) {
            finish("dialog-or-row-count-rejected");
            return;
        }

        rowTexts_.clear();
        readbacks_.clear();
        rowTexts_.reserve(specs_.size());
        readbacks_.reserve(specs_.size());
        for (std::size_t rowIndex = 0;
             rowIndex < specs_.size();
             ++rowIndex) {
            std::vector<QString> cells;
            cells.reserve(static_cast<std::size_t>(
                std::max(0, table_->columnCount())));
            for (int column = 0;
                 column < table_->columnCount();
                 ++column) {
                const QTableWidgetItem* item = table_->item(
                    static_cast<int>(rowIndex), column);
                cells.push_back(item == nullptr ? QString()
                                                : item->text());
            }
            rowTexts_.push_back(std::move(cells));
            readbacks_.push_back(readCurveGrips(
                dialog_.data(), static_cast<int>(rowIndex)));
        }
        finish("reopen-program-verification-rejected");
    }

    void poll() {
        if (finished_) {
            return;
        }
        const auto widgets = QApplication::topLevelWidgets();
        for (QWidget* widget : widgets) {
            if (!isExactMotionStudyDialog(widget)) {
                continue;
            }
            const auto tables = widget->findChildren<QTableWidget*>();
            if (tables.size() != 1) {
                dialog_ = widget;
                finish("table-cardinality-rejected");
                return;
            }
            dialog_ = widget;
            table_ = tables.front();
            if (table_->rowCount() == static_cast<int>(specs_.size())) {
                writeCheckpoint("rows-restored");
                QTimer::singleShot(
                    settleMs_, this, [this]() { capture(); });
                return;
            }
        }

        if (elapsedMs_ >= timeoutMs_) {
            finish("timeout-awaiting-restored-rows");
            return;
        }
        elapsedMs_ += pollIntervalMs_;
        QTimer::singleShot(
            pollIntervalMs_, this, [this]() { poll(); });
    }

    std::vector<MotionJointSpec> specs_;
    std::string outputPath_;
    int pollIntervalMs_;
    int timeoutMs_;
    int settleMs_;
    QPointer<QWidget> dialog_;
    QPointer<QTableWidget> table_;
    std::vector<std::vector<QString>> rowTexts_;
    std::vector<CurveReadbackResult> readbacks_;
    int elapsedMs_ = 0;
    bool finished_ = false;
};

QString normalizedBrowserText(QString value) {
    value = value.trimmed();
    value.remove(QLatin1Char('&'));
    while (value.endsWith(QStringLiteral("...")) ||
           value.endsWith(QChar(0x2026))) {
        if (value.endsWith(QChar(0x2026))) {
            value.chop(1);
        } else {
            value.chop(3);
        }
        value = value.trimmed();
    }
    return value;
}

bool isMotionStudiesFolderText(const QString& value) {
    const QString normalized = normalizedBrowserText(value);
    return normalized.compare(QStringLiteral("Motion Studies"),
                              Qt::CaseInsensitive) == 0 ||
           normalized.compare(QStringLiteral("Motion Study"),
                              Qt::CaseInsensitive) == 0 ||
           normalized == QStringLiteral("运动分析");
}

struct BrowserMotionStudyCandidate {
    QPointer<QTreeView> view;
    QPersistentModelIndex folderIndex;
    QPersistentModelIndex studyIndex;
    QString folderText;
    QString studyText;
};

void collectBrowserMotionStudyCandidates(
    QTreeView* view,
    const QModelIndex& parent,
    const QString& expectedStudyName,
    int depth,
    int& nodeBudget,
    int& folderCount,
    std::vector<BrowserMotionStudyCandidate>& candidates) {
    if (view == nullptr || view->model() == nullptr || depth > 32 ||
        nodeBudget <= 0) {
        return;
    }

    QAbstractItemModel* model = view->model();
    if (model->canFetchMore(parent)) {
        model->fetchMore(parent);
    }
    const int rows = std::min(model->rowCount(parent), nodeBudget);
    for (int row = 0; row < rows && nodeBudget > 0; ++row) {
        --nodeBudget;
        const QModelIndex index = model->index(row, 0, parent);
        if (!index.isValid()) {
            continue;
        }
        const QString text = normalizedBrowserText(
            model->data(index, Qt::DisplayRole).toString());
        if (isMotionStudiesFolderText(text)) {
            ++folderCount;
            view->setExpanded(index, true);
            if (model->canFetchMore(index)) {
                model->fetchMore(index);
            }
            const int childRows = model->rowCount(index);
            for (int childRow = 0; childRow < childRows; ++childRow) {
                const QModelIndex child = model->index(childRow, 0, index);
                if (!child.isValid() ||
                    !(model->flags(child) & Qt::ItemIsSelectable)) {
                    continue;
                }
                const QString childText = normalizedBrowserText(
                    model->data(child, Qt::DisplayRole).toString());
                if (childText.isEmpty() ||
                    (!expectedStudyName.isEmpty() &&
                     childText.compare(expectedStudyName,
                                       Qt::CaseInsensitive) != 0)) {
                    continue;
                }
                candidates.push_back({view,
                                      QPersistentModelIndex(index),
                                      QPersistentModelIndex(child),
                                      text,
                                      childText});
            }
        }
        collectBrowserMotionStudyCandidates(view,
                                            index,
                                            expectedStudyName,
                                            depth + 1,
                                            nodeBudget,
                                            folderCount,
                                            candidates);
    }
}

std::vector<BrowserMotionStudyCandidate> findBrowserMotionStudyCandidates(
    const QString& expectedStudyName,
    int& folderCount) {
    folderCount = 0;
    std::vector<BrowserMotionStudyCandidate> candidates;
    const auto widgets = QApplication::allWidgets();
    for (QWidget* widget : widgets) {
        auto* view = qobject_cast<QTreeView*>(widget);
        if (view == nullptr || view->model() == nullptr) {
            continue;
        }
        int nodeBudget = 4096;
        collectBrowserMotionStudyCandidates(view,
                                            view->rootIndex(),
                                            expectedStudyName,
                                            0,
                                            nodeBudget,
                                            folderCount,
                                            candidates);
    }

    std::vector<BrowserMotionStudyCandidate> unique;
    for (const BrowserMotionStudyCandidate& candidate : candidates) {
        const bool duplicate = std::any_of(
            unique.begin(),
            unique.end(),
            [&candidate](const BrowserMotionStudyCandidate& existing) {
                return existing.studyIndex == candidate.studyIndex;
            });
        if (!duplicate) {
            unique.push_back(candidate);
        }
    }
    return unique;
}

std::vector<QWidget*> exactMotionStudyDialogs() {
    std::vector<QWidget*> dialogs;
    const auto widgets = QApplication::topLevelWidgets();
    for (QWidget* widget : widgets) {
        if (isExactMotionStudyDialog(widget)) {
            dialogs.push_back(widget);
        }
    }
    return dialogs;
}

std::vector<QRadioButton*> orderedMotionStudyModeButtons(QWidget* dialog) {
    std::vector<QRadioButton*> buttons;
    if (dialog == nullptr) {
        return buttons;
    }
    const auto found = dialog->findChildren<QRadioButton*>();
    buttons.assign(found.begin(), found.end());
    std::sort(buttons.begin(),
              buttons.end(),
              [](const QRadioButton* left, const QRadioButton* right) {
                  const QPoint leftPosition = left->mapToGlobal(QPoint());
                  const QPoint rightPosition = right->mapToGlobal(QPoint());
                  if (leftPosition.y() != rightPosition.y()) {
                      return leftPosition.y() < rightPosition.y();
                  }
                  return leftPosition.x() < rightPosition.x();
              });
    return buttons;
}

struct NativeMotionStudyDialogState {
    struct WidgetEvidence {
        bool found = false;
        bool visible = false;
        bool hidden = true;
        bool enabled = false;
        bool window = false;
        bool minimized = false;
        bool activeWindow = false;
        bool intersectsScreen = false;
        int localX = 0;
        int localY = 0;
        int globalX = 0;
        int globalY = 0;
        int frameX = 0;
        int frameY = 0;
        int frameWidth = 0;
        int frameHeight = 0;
        int width = 0;
        int height = 0;
        QString className;
        QString objectName;
        QString screenName;
    };

    bool found = false;
    bool exact = false;
    bool releaseMatches = false;
    bool imageUuidMatches = false;
    bool dialogVtableMatches = false;
    bool currentPositionPrefixMatches = false;
    bool privateStateReadable = false;
    bool animationTaskPresent = false;
    int tableRows = -1;
    int currentPosition = -1;
    int checkedModeIndex = -1;
    std::size_t modeButtonCount = 0;
    bool playSlotPresent = false;
    bool stopSlotPresent = false;
    bool repeatSlotPresent = false;
    bool moveToStartSlotPresent = false;
    QString dialogClass;
    WidgetEvidence dialogWidget;
    WidgetEvidence containingWindow;
    std::vector<WidgetEvidence> parentChain;
};

NativeMotionStudyDialogState::WidgetEvidence snapshotWidgetEvidence(
    QWidget* widget) noexcept {
    NativeMotionStudyDialogState::WidgetEvidence evidence;
    try {
        evidence.found = widget != nullptr;
        if (widget == nullptr) {
            return evidence;
        }
        evidence.className = QString::fromLatin1(
            widget->metaObject()->className());
        evidence.objectName = widget->objectName();
        evidence.visible = widget->isVisible();
        evidence.hidden = widget->isHidden();
        evidence.enabled = widget->isEnabled();
        evidence.window = widget->isWindow();
        evidence.minimized = widget->isMinimized();
        evidence.activeWindow = widget->isActiveWindow();
        const QRect local = widget->geometry();
        const QRect frame = widget->frameGeometry();
        const QPoint global = widget->mapToGlobal(QPoint(0, 0));
        const QRect globalRect(global, widget->size());
        evidence.localX = local.x();
        evidence.localY = local.y();
        evidence.globalX = global.x();
        evidence.globalY = global.y();
        evidence.frameX = frame.x();
        evidence.frameY = frame.y();
        evidence.frameWidth = frame.width();
        evidence.frameHeight = frame.height();
        evidence.width = globalRect.width();
        evidence.height = globalRect.height();
        for (QScreen* screen : QGuiApplication::screens()) {
            if (screen != nullptr &&
                screen->availableGeometry().intersects(globalRect)) {
                evidence.intersectsScreen = true;
                evidence.screenName = screen->name();
                break;
            }
        }
    } catch (...) {
    }
    return evidence;
}

struct NativeCocoaWindowEvidence {
    bool platformCocoa = false;
    bool qWindowFound = false;
    bool existingPlatformHandle = false;
    bool winIdRead = false;
    bool nativeViewValid = false;
    bool nativeWindowValid = false;
    bool nativePanelValid = false;
    bool requiredSelectorsPresent = false;
    bool applicationWindowMember = false;
    bool applicationActive = false;
    bool visible = false;
    bool keyWindow = false;
    bool mainWindow = false;
    bool miniaturized = false;
    bool canBecomeKeyWindow = false;
    bool onActiveSpace = false;
    bool qWindowVisible = false;
    bool qWindowActive = false;
    bool qWindowExposed = false;
    std::uintptr_t nativeViewIdentity = 0;
    std::uintptr_t nativeWindowIdentity = 0;
    long long windowNumber = -1;
    unsigned long long collectionBehavior = 0;
    QString nativeViewClass;
    QString nativeWindowClass;
};

struct NativeCGWindowEvidence {
    bool querySucceeded = false;
    long long resultCardinality = 0;
    bool exactCardinality = false;
    bool windowNumberPresent = false;
    bool exactWindowNumber = false;
    bool ownerPidPresent = false;
    bool ownerPidMatches = false;
    bool onscreenKeyPresent = false;
    bool onscreenValueValid = false;
    bool onscreen = false;
    bool boundsPresent = false;
    long long windowNumber = -1;
    long long ownerPid = -1;
    double boundsX = 0.0;
    double boundsY = 0.0;
    double boundsWidth = 0.0;
    double boundsHeight = 0.0;
};

template <typename Return, typename... Arguments>
Return sendObjc(id receiver, SEL selector, Arguments... arguments) {
    using Function = Return (*)(id, SEL, Arguments...);
    return reinterpret_cast<Function>(objc_msgSend)(
        receiver, selector, arguments...);
}

NativeCocoaWindowEvidence inspectExistingCocoaWindow(
    QWidget* dialog) noexcept {
    NativeCocoaWindowEvidence evidence;
    try {
        evidence.platformCocoa =
            QGuiApplication::platformName() == QStringLiteral("cocoa");
        QWidget* windowWidget = dialog ? dialog->window() : nullptr;
        QWindow* qWindow = windowWidget
            ? windowWidget->windowHandle()
            : nullptr;
        evidence.qWindowFound = qWindow != nullptr;
        evidence.existingPlatformHandle =
            qWindow != nullptr && qWindow->handle() != nullptr;
        if (!evidence.platformCocoa ||
            !evidence.existingPlatformHandle) {
            return evidence;
        }
        evidence.qWindowVisible = qWindow->isVisible();
        evidence.qWindowActive = qWindow->isActive();
        evidence.qWindowExposed = qWindow->isExposed();
        const WId nativeId = qWindow->winId();
        evidence.winIdRead = nativeId != 0;
        if (!evidence.winIdRead) {
            return evidence;
        }
        id nativeObject = reinterpret_cast<id>(
            static_cast<std::uintptr_t>(nativeId));
        Class nsViewClass = static_cast<Class>(objc_getClass("NSView"));
        Class nsWindowClass = static_cast<Class>(objc_getClass("NSWindow"));
        Class nsPanelClass = static_cast<Class>(objc_getClass("NSPanel"));
        const SEL respondsToSelector =
            sel_registerName("respondsToSelector:");
        const SEL isKindOfClass = sel_registerName("isKindOfClass:");
        id nativeWindow = nil;
        const SEL windowSelector = sel_registerName("window");
        if (nsViewClass != Nil && sendObjc<BOOL>(
                nativeObject, respondsToSelector, isKindOfClass) &&
            sendObjc<BOOL>(nativeObject, isKindOfClass,
                           nsViewClass) &&
            sendObjc<BOOL>(nativeObject, respondsToSelector,
                           windowSelector)) {
            evidence.nativeViewValid = true;
            evidence.nativeViewIdentity =
                reinterpret_cast<std::uintptr_t>(nativeObject);
            evidence.nativeViewClass = QString::fromUtf8(
                object_getClassName(nativeObject));
            nativeWindow = sendObjc<id>(nativeObject,
                                        windowSelector);
        }
        evidence.nativeWindowValid = nativeWindow != nil &&
            nsWindowClass != Nil && sendObjc<BOOL>(
                nativeWindow, respondsToSelector,
                isKindOfClass) && sendObjc<BOOL>(
                nativeWindow, isKindOfClass, nsWindowClass);
        if (!evidence.nativeWindowValid) {
            return evidence;
        }
        evidence.nativePanelValid = nsPanelClass != Nil &&
            sendObjc<BOOL>(nativeWindow, respondsToSelector,
                           isKindOfClass) &&
            sendObjc<BOOL>(nativeWindow, isKindOfClass, nsPanelClass);
        constexpr std::array<const char*, 11> kWindowSelectors = {
            "isVisible", "isKeyWindow", "isMainWindow",
            "isMiniaturized", "canBecomeKeyWindow", "windowNumber",
            "orderFrontRegardless", "makeKeyAndOrderFront:",
            "isOnActiveSpace", "collectionBehavior",
            "setCollectionBehavior:",
        };
        evidence.requiredSelectorsPresent = std::all_of(
            kWindowSelectors.begin(), kWindowSelectors.end(),
            [nativeWindow, respondsToSelector](const char* name) {
                return sendObjc<BOOL>(
                    nativeWindow, respondsToSelector,
                    sel_registerName(name));
            });
        if (!evidence.requiredSelectorsPresent) {
            return evidence;
        }
        evidence.nativeWindowIdentity =
            reinterpret_cast<std::uintptr_t>(nativeWindow);
        evidence.nativeWindowClass = QString::fromUtf8(
            object_getClassName(nativeWindow));
        Class nsApplicationClass = reinterpret_cast<Class>(
            objc_getClass("NSApplication"));
        const SEL sharedApplication =
            sel_registerName("sharedApplication");
        const SEL windows = sel_registerName("windows");
        const SEL containsObject = sel_registerName("containsObject:");
        id applicationClassObject =
            reinterpret_cast<id>(nsApplicationClass);
        id application = nsApplicationClass != Nil &&
            sendObjc<BOOL>(applicationClassObject,
                           respondsToSelector,
                           sharedApplication)
            ? sendObjc<id>(applicationClassObject,
                           sharedApplication)
            : nil;
        id applicationWindows = application != nil &&
            sendObjc<BOOL>(application, respondsToSelector, windows)
            ? sendObjc<id>(application, windows)
            : nil;
        evidence.applicationWindowMember =
            applicationWindows != nil &&
            sendObjc<BOOL>(applicationWindows,
                           respondsToSelector,
                           containsObject) &&
            sendObjc<BOOL>(applicationWindows, containsObject,
                nativeWindow);
        const SEL isActive = sel_registerName("isActive");
        evidence.applicationActive = application != nil &&
            sendObjc<BOOL>(application, respondsToSelector,
                           isActive) &&
            sendObjc<BOOL>(application, isActive);
        evidence.visible = sendObjc<BOOL>(
            nativeWindow, sel_registerName("isVisible"));
        evidence.keyWindow = sendObjc<BOOL>(
            nativeWindow, sel_registerName("isKeyWindow"));
        evidence.mainWindow = sendObjc<BOOL>(
            nativeWindow, sel_registerName("isMainWindow"));
        evidence.miniaturized = sendObjc<BOOL>(
            nativeWindow, sel_registerName("isMiniaturized"));
        evidence.canBecomeKeyWindow = sendObjc<BOOL>(
            nativeWindow, sel_registerName("canBecomeKeyWindow"));
        evidence.onActiveSpace = sendObjc<BOOL>(
            nativeWindow, sel_registerName("isOnActiveSpace"));
        evidence.collectionBehavior =
            static_cast<unsigned long long>(sendObjc<unsigned long>(
                nativeWindow,
                sel_registerName("collectionBehavior")));
        evidence.windowNumber = static_cast<long long>(
            sendObjc<long>(nativeWindow,
                           sel_registerName("windowNumber")));
    } catch (...) {
    }
    return evidence;
}

NativeCGWindowEvidence inspectCGWindow(
    long long expectedWindowNumber) noexcept {
    NativeCGWindowEvidence evidence;
    if (expectedWindowNumber <= 0 ||
        static_cast<unsigned long long>(expectedWindowNumber) >
            static_cast<unsigned long long>(
                std::numeric_limits<CGWindowID>::max())) {
        return evidence;
    }
    CFArrayRef windows = CGWindowListCopyWindowInfo(
        kCGWindowListOptionAll, kCGNullWindowID);
    if (windows == nullptr) {
        return evidence;
    }
    evidence.querySucceeded = true;
    const CFIndex count = CFArrayGetCount(windows);
    for (CFIndex index = 0; index < count; ++index) {
        const void* rawEntry = CFArrayGetValueAtIndex(windows, index);
        if (rawEntry != nullptr &&
            CFGetTypeID(rawEntry) == CFDictionaryGetTypeID()) {
            CFDictionaryRef entry =
                static_cast<CFDictionaryRef>(rawEntry);
            const void* rawValue = nullptr;
            long long candidateWindowNumber = -1;
            const bool candidateNumberValid =
                CFDictionaryGetValueIfPresent(
                    entry, kCGWindowNumber, &rawValue) &&
                rawValue != nullptr &&
                CFGetTypeID(rawValue) == CFNumberGetTypeID() &&
                CFNumberGetValue(static_cast<CFNumberRef>(rawValue),
                                 kCFNumberLongLongType,
                                 &candidateWindowNumber);
            if (!candidateNumberValid ||
                candidateWindowNumber != expectedWindowNumber) {
                continue;
            }
            ++evidence.resultCardinality;
            evidence.windowNumber = candidateWindowNumber;
            evidence.windowNumberPresent = true;
            evidence.exactWindowNumber = true;
            rawValue = nullptr;
            if (CFDictionaryGetValueIfPresent(
                    entry, kCGWindowOwnerPID, &rawValue) &&
                rawValue != nullptr &&
                CFGetTypeID(rawValue) == CFNumberGetTypeID() &&
                CFNumberGetValue(static_cast<CFNumberRef>(rawValue),
                                 kCFNumberLongLongType,
                                 &evidence.ownerPid)) {
                evidence.ownerPidPresent = true;
                evidence.ownerPidMatches =
                    evidence.ownerPid ==
                        static_cast<long long>(getpid());
            }
            rawValue = nullptr;
            evidence.onscreenKeyPresent =
                CFDictionaryGetValueIfPresent(
                    entry, kCGWindowIsOnscreen, &rawValue);
            if (evidence.onscreenKeyPresent && rawValue != nullptr &&
                CFGetTypeID(rawValue) == CFBooleanGetTypeID()) {
                evidence.onscreenValueValid = true;
                evidence.onscreen = CFBooleanGetValue(
                    static_cast<CFBooleanRef>(rawValue));
            }
            rawValue = nullptr;
            if (CFDictionaryGetValueIfPresent(
                    entry, kCGWindowBounds, &rawValue) &&
                rawValue != nullptr &&
                CFGetTypeID(rawValue) == CFDictionaryGetTypeID()) {
                CGRect bounds = CGRectZero;
                evidence.boundsPresent =
                    CGRectMakeWithDictionaryRepresentation(
                        static_cast<CFDictionaryRef>(rawValue),
                        &bounds);
                if (evidence.boundsPresent) {
                    evidence.boundsX = bounds.origin.x;
                    evidence.boundsY = bounds.origin.y;
                    evidence.boundsWidth = bounds.size.width;
                    evidence.boundsHeight = bounds.size.height;
                }
            }
        }
    }
    evidence.exactCardinality = evidence.resultCardinality == 1;
    CFRelease(windows);
    return evidence;
}

void appendNativeCocoaWindowEvidence(
    std::ostringstream& output,
    const NativeCocoaWindowEvidence& evidence) {
    output
        << "{\"platform_cocoa\":" << jsonBool(evidence.platformCocoa)
        << ",\"qwindow_found\":" << jsonBool(evidence.qWindowFound)
        << ",\"existing_platform_handle\":"
        << jsonBool(evidence.existingPlatformHandle)
        << ",\"win_id_read\":" << jsonBool(evidence.winIdRead)
        << ",\"native_view_valid\":"
        << jsonBool(evidence.nativeViewValid)
        << ",\"native_view_identity_nonzero\":"
        << jsonBool(evidence.nativeViewIdentity != 0)
        << ",\"native_view_class\":"
        << quoted(evidence.nativeViewClass)
        << ",\"native_window_valid\":"
        << jsonBool(evidence.nativeWindowValid)
        << ",\"native_panel_valid\":"
        << jsonBool(evidence.nativePanelValid)
        << ",\"required_selectors_present\":"
        << jsonBool(evidence.requiredSelectorsPresent)
        << ",\"application_window_member\":"
        << jsonBool(evidence.applicationWindowMember)
        << ",\"application_active\":"
        << jsonBool(evidence.applicationActive)
        << ",\"native_window_class\":"
        << quoted(evidence.nativeWindowClass)
        << ",\"visible\":" << jsonBool(evidence.visible)
        << ",\"key_window\":" << jsonBool(evidence.keyWindow)
        << ",\"main_window\":" << jsonBool(evidence.mainWindow)
        << ",\"miniaturized\":" << jsonBool(evidence.miniaturized)
        << ",\"can_become_key_window\":"
        << jsonBool(evidence.canBecomeKeyWindow)
        << ",\"on_active_space\":"
        << jsonBool(evidence.onActiveSpace)
        << ",\"collection_behavior\":"
        << evidence.collectionBehavior
        << ",\"qwindow_visible\":"
        << jsonBool(evidence.qWindowVisible)
        << ",\"qwindow_active\":"
        << jsonBool(evidence.qWindowActive)
        << ",\"qwindow_exposed\":"
        << jsonBool(evidence.qWindowExposed)
        << ",\"window_number\":" << evidence.windowNumber << "}";
}

void appendNativeCGWindowEvidence(
    std::ostringstream& output,
    const NativeCGWindowEvidence& evidence) {
    output
        << "{\"query_succeeded\":"
        << jsonBool(evidence.querySucceeded)
        << ",\"result_cardinality\":" << evidence.resultCardinality
        << ",\"exact_cardinality\":"
        << jsonBool(evidence.exactCardinality)
        << ",\"window_number_present\":"
        << jsonBool(evidence.windowNumberPresent)
        << ",\"exact_window_number\":"
        << jsonBool(evidence.exactWindowNumber)
        << ",\"owner_pid_present\":"
        << jsonBool(evidence.ownerPidPresent)
        << ",\"owner_pid_matches\":"
        << jsonBool(evidence.ownerPidMatches)
        << ",\"onscreen_key_present\":"
        << jsonBool(evidence.onscreenKeyPresent)
        << ",\"onscreen_value_valid\":"
        << jsonBool(evidence.onscreenValueValid)
        << ",\"onscreen\":" << jsonBool(evidence.onscreen)
        << ",\"bounds_present\":"
        << jsonBool(evidence.boundsPresent)
        << ",\"window_number\":" << evidence.windowNumber
        << ",\"owner_pid\":" << evidence.ownerPid
        << ",\"bounds\":{\"x\":" << evidence.boundsX
        << ",\"y\":" << evidence.boundsY
        << ",\"width\":" << evidence.boundsWidth
        << ",\"height\":" << evidence.boundsHeight << "}}";
}

NativeMotionStudyDialogState inspectNativeMotionStudyDialog(
    QWidget* dialog) noexcept {
    NativeMotionStudyDialogState state;
    try {
        state.found = dialog != nullptr;
        state.dialogWidget = snapshotWidgetEvidence(dialog);
        if (dialog != nullptr) {
            state.containingWindow = snapshotWidgetEvidence(
                dialog->window());
            std::vector<QWidget*> visited;
            QWidget* parent = dialog->parentWidget();
            for (int depth = 0; parent != nullptr && depth < 16;
                 ++depth) {
                if (std::find(visited.begin(), visited.end(), parent) !=
                    visited.end()) {
                    break;
                }
                visited.push_back(parent);
                state.parentChain.push_back(
                    snapshotWidgetEvidence(parent));
                parent = parent->parentWidget();
            }
        }
        state.exact = isExactMotionStudyDialog(dialog);
        if (!state.exact) {
            return state;
        }
        state.dialogClass = QString::fromLatin1(
            dialog->metaObject()->className());
        const auto tables = dialog->findChildren<QTableWidget*>();
        if (tables.size() == 1) {
            state.tableRows = tables.front()->rowCount();
        }

        const QMetaObject* meta = dialog->metaObject();
        state.playSlotPresent = meta->indexOfMethod("onPlay()") >= 0;
        state.stopSlotPresent = meta->indexOfMethod("onStop()") >= 0;
        state.repeatSlotPresent = meta->indexOfMethod("onRepeat()") >= 0;
        state.moveToStartSlotPresent =
            meta->indexOfMethod("onMoveToStart()") >= 0;

        const auto modeButtons = orderedMotionStudyModeButtons(dialog);
        state.modeButtonCount = modeButtons.size();
        for (std::size_t index = 0; index < modeButtons.size(); ++index) {
            if (modeButtons[index] != nullptr &&
                modeButtons[index]->isChecked()) {
                state.checkedModeIndex = static_cast<int>(index);
                break;
            }
        }

        const auto application = adsk::core::Application::get();
        state.releaseMatches = application &&
            application->version() == "2704.1.36";
        const LoadedImage naFusionUi = findLoadedImage(
            "/Libraries/Applications/Fusion/NaFusionUI10.dylib");
        constexpr std::array<std::uint8_t, 16>
            kExpectedNaFusionUiUuid = {
                0x45, 0xf2, 0xe0, 0xc4, 0x1a, 0x4f, 0x36, 0xb8,
                0xa6, 0xd8, 0x63, 0x33, 0xa6, 0x8f, 0xba, 0xd1,
            };
        state.imageUuidMatches = loadedImageUuidMatches(
            naFusionUi.header, kExpectedNaFusionUiUuid);
        state.dialogVtableMatches = naFusionUi.base != 0 &&
            *reinterpret_cast<std::uintptr_t*>(dialog) ==
                naFusionUi.base + 0x022cfe78;

        constexpr std::uintptr_t kCurrentPositionOffset = 0x0007c290;
        constexpr Prefix16 kCurrentPositionPrefix = {
            0xff, 0x83, 0x00, 0xd1, 0xfd, 0x7b, 0x01, 0xa9,
            0xfd, 0x43, 0x00, 0x91, 0xe8, 0x06, 0x01, 0xb0,
        };
        state.currentPositionPrefixMatches = naFusionUi.base != 0 &&
            std::memcmp(
                reinterpret_cast<const void*>(
                    naFusionUi.base + kCurrentPositionOffset),
                kCurrentPositionPrefix.data(),
                kCurrentPositionPrefix.size()) == 0;
        state.privateStateReadable = state.releaseMatches &&
            state.imageUuidMatches && state.dialogVtableMatches &&
            state.currentPositionPrefixMatches;
        if (state.privateStateReadable) {
            using CurrentPosition = int (*)(void*);
            const auto currentPosition = reinterpret_cast<CurrentPosition>(
                naFusionUi.base + kCurrentPositionOffset);
            state.currentPosition = currentPosition(dialog);
            state.animationTaskPresent =
                *reinterpret_cast<void**>(
                    reinterpret_cast<std::uint8_t*>(dialog) + 0x118) !=
                nullptr;
        }
        return state;
    } catch (...) {
        return state;
    }
}

void appendWidgetEvidence(
    std::ostringstream& output,
    const NativeMotionStudyDialogState::WidgetEvidence& evidence) {
    output
        << "{\"found\":" << jsonBool(evidence.found)
        << ",\"class\":" << quoted(evidence.className)
        << ",\"object_name\":" << quoted(evidence.objectName)
        << ",\"visible\":" << jsonBool(evidence.visible)
        << ",\"hidden\":" << jsonBool(evidence.hidden)
        << ",\"enabled\":" << jsonBool(evidence.enabled)
        << ",\"is_window\":" << jsonBool(evidence.window)
        << ",\"minimized\":" << jsonBool(evidence.minimized)
        << ",\"active_window\":" << jsonBool(evidence.activeWindow)
        << ",\"intersects_screen\":"
        << jsonBool(evidence.intersectsScreen)
        << ",\"screen\":" << quoted(evidence.screenName)
        << ",\"local_rect\":{\"x\":" << evidence.localX
        << ",\"y\":" << evidence.localY
        << ",\"width\":" << evidence.width
        << ",\"height\":" << evidence.height << "}"
        << ",\"global_rect\":{\"x\":" << evidence.globalX
        << ",\"y\":" << evidence.globalY
        << ",\"width\":" << evidence.width
        << ",\"height\":" << evidence.height << "}"
        << ",\"frame_rect\":{\"x\":" << evidence.frameX
        << ",\"y\":" << evidence.frameY
        << ",\"width\":" << evidence.frameWidth
        << ",\"height\":" << evidence.frameHeight << "}}";
}

void appendNativeMotionStudyDialogState(
    std::ostringstream& output,
    const NativeMotionStudyDialogState& state) {
    output
        << "{\"found\":" << jsonBool(state.found)
        << ",\"exact\":" << jsonBool(state.exact)
        << ",\"class\":" << quoted(state.dialogClass)
        << ",\"table_rows\":" << state.tableRows
        << ",\"release_matches\":"
        << jsonBool(state.releaseMatches)
        << ",\"image_uuid_matches\":"
        << jsonBool(state.imageUuidMatches)
        << ",\"dialog_vtable_matches\":"
        << jsonBool(state.dialogVtableMatches)
        << ",\"current_position_prefix_matches\":"
        << jsonBool(state.currentPositionPrefixMatches)
        << ",\"private_state_readable\":"
        << jsonBool(state.privateStateReadable)
        << ",\"animation_task_present\":"
        << jsonBool(state.animationTaskPresent)
        << ",\"current_position\":" << state.currentPosition
        << ",\"mode_button_count\":" << state.modeButtonCount
        << ",\"checked_mode_index\":" << state.checkedModeIndex
        << ",\"dialog_widget\":";
    appendWidgetEvidence(output, state.dialogWidget);
    output << ",\"containing_window\":";
    appendWidgetEvidence(output, state.containingWindow);
    output << ",\"parent_chain\":[";
    for (std::size_t index = 0; index < state.parentChain.size();
         ++index) {
        if (index != 0) {
            output << ",";
        }
        appendWidgetEvidence(output, state.parentChain[index]);
    }
    output
        << "]"
        << ",\"native_slots\":{"
        << "\"play\":" << jsonBool(state.playSlotPresent)
        << ",\"stop\":" << jsonBool(state.stopSlotPresent)
        << ",\"repeat\":" << jsonBool(state.repeatSlotPresent)
        << ",\"move_to_start\":"
        << jsonBool(state.moveToStartSlotPresent)
        << "}}";
}

bool gNativeMotionStudyEditControllerActive = false;
bool gNativeMotionStudyControlControllerActive = false;

class NativeMotionStudyEditController final : public QObject {
public:
    NativeMotionStudyEditController(QString expectedStudyName,
                                    int expectedRowCount,
                                    std::string outputPath,
                                    int pollIntervalMs,
                                    int timeoutMs,
                                    int selectionSettleMs)
        : expectedStudyName_(std::move(expectedStudyName)),
          expectedRowCount_(expectedRowCount),
          outputPath_(std::move(outputPath)),
          pollIntervalMs_(std::max(50, pollIntervalMs)),
          timeoutMs_(std::max(500, timeoutMs)),
          selectionSettleMs_(std::max(50, selectionSettleMs)) {}

    void start() {
        elapsedMs_ = 0;
        writeCheckpoint("armed");
        pollForBrowserStudy();
    }

private:
    void writeCheckpoint(const char* status) const {
        std::ostringstream output;
        output
            << "{\"schema\":\"cad-agent.motion-study-native-ui.v1\""
            << ",\"phase\":\"checkpoint\""
            << ",\"status\":" << quoted(std::string(status))
            << ",\"elapsed_ms\":" << elapsedMs_
            << ",\"folder_count\":" << folderCount_
            << ",\"candidate_count\":" << candidateCount_
            << ",\"browser_selection_applied\":"
            << jsonBool(browserSelectionApplied_)
            << ",\"edit_command_executed\":"
            << jsonBool(editCommandExecuted_) << "}\n";
        writeTextAtomically(outputPath_, output.str());
    }

    std::string makeReport(const char* status,
                           bool cleanupQueued,
                           bool dialogLeftVisible) const {
        std::ostringstream output;
        output
            << "{\"schema\":\"cad-agent.motion-study-native-ui.v1\""
            << ",\"phase\":\"complete\""
            << ",\"status\":" << quoted(std::string(status))
            << ",\"qt_version\":" << quoted(std::string(qVersion()))
            << ",\"main_thread\":"
            << jsonBool(QCoreApplication::instance() != nullptr &&
                        QCoreApplication::instance()->thread() ==
                            QThread::currentThread())
            << ",\"route\":\"Fusion Browser model selection + "
               "EditMotionStudyCmd\""
            << ",\"mouse_input_used\":false"
            << ",\"curve_write_requested\":false"
            << ",\"elapsed_ms\":" << elapsedMs_
            << ",\"expected_study_name\":"
            << quoted(expectedStudyName_)
            << ",\"expected_row_count\":" << expectedRowCount_
            << ",\"folder_count\":" << folderCount_
            << ",\"candidate_count\":" << candidateCount_
            << ",\"browser_view_class\":"
            << quoted(browserViewClass_)
            << ",\"browser_view_object_name\":"
            << quoted(browserViewObjectName_)
            << ",\"folder_text\":" << quoted(folderText_)
            << ",\"study_text\":" << quoted(studyText_)
            << ",\"browser_selection_applied\":"
            << jsonBool(browserSelectionApplied_)
            << ",\"browser_current_index_matches\":"
            << jsonBool(browserCurrentIndexMatches_)
            << ",\"selected_row_count\":" << selectedRowCount_
            << ",\"edit_command_definition_found\":"
            << jsonBool(editCommandDefinitionFound_)
            << ",\"edit_command_execute_result\":"
            << jsonBool(editCommandExecuted_)
            << ",\"dialog_state\":";
        appendNativeMotionStudyDialogState(output, dialogState_);
        output
            << ",\"dialog_left_visible\":"
            << jsonBool(dialogLeftVisible)
            << ",\"failure_cleanup_cancel_queued\":"
            << jsonBool(cleanupQueued)
            << ",\"accepted\":"
            << jsonBool(dialogLeftVisible && dialogState_.exact &&
                        dialogState_.tableRows == expectedRowCount_)
            << "}\n";
        return output.str();
    }

    void finish(const char* status, bool leaveDialogVisible) {
        if (finished_) {
            return;
        }
        finished_ = true;
        bool cleanupQueued = false;
        if (dialog_ != nullptr) {
            dialogState_ = inspectNativeMotionStudyDialog(dialog_.data());
        }
        if (!leaveDialogVisible && dialog_ != nullptr &&
            isExactMotionStudyDialog(dialog_.data())) {
            cleanupQueued = QMetaObject::invokeMethod(
                dialog_.data(),
                "onDialogCancel",
                Qt::QueuedConnection);
        }
        writeTextAtomically(outputPath_,
                            makeReport(status,
                                       cleanupQueued,
                                       leaveDialogVisible));
        gNativeMotionStudyEditControllerActive = false;
        deleteLater();
    }

    void pollForBrowserStudy() {
        if (finished_) {
            return;
        }

        const auto existingDialogs = exactMotionStudyDialogs();
        if (existingDialogs.size() == 1) {
            dialog_ = existingDialogs.front();
            dialogState_ = inspectNativeMotionStudyDialog(dialog_.data());
            if (dialogState_.tableRows == expectedRowCount_) {
                finish("native-edit-dialog-already-visible", true);
            } else {
                finish("unexpected-preexisting-motion-study-dialog",
                       false);
            }
            return;
        }
        if (existingDialogs.size() > 1) {
            finish("motion-study-dialog-cardinality-rejected", false);
            return;
        }

        int folderCount = 0;
        auto candidates = findBrowserMotionStudyCandidates(
            expectedStudyName_, folderCount);
        folderCount_ = folderCount;
        candidateCount_ = candidates.size();
        if (candidateCount_ == 1) {
            candidate_ = candidates.front();
            QTreeView* view = candidate_.view.data();
            if (view == nullptr || !candidate_.studyIndex.isValid() ||
                view->selectionModel() == nullptr) {
                finish("browser-candidate-invalid", false);
                return;
            }

            browserViewClass_ = QString::fromLatin1(
                view->metaObject()->className());
            browserViewObjectName_ = view->objectName();
            folderText_ = candidate_.folderText;
            studyText_ = candidate_.studyText;
            view->setExpanded(candidate_.folderIndex, true);
            view->scrollTo(candidate_.studyIndex,
                           QAbstractItemView::PositionAtCenter);
            const auto flags = QItemSelectionModel::ClearAndSelect |
                               QItemSelectionModel::Rows;
            view->selectionModel()->setCurrentIndex(
                candidate_.studyIndex, flags);
            view->selectionModel()->select(candidate_.studyIndex, flags);
            view->setCurrentIndex(candidate_.studyIndex);
            view->setFocus(Qt::OtherFocusReason);
            browserSelectionApplied_ = true;
            browserCurrentIndexMatches_ =
                view->currentIndex() == candidate_.studyIndex;
            selectedRowCount_ =
                view->selectionModel()->selectedRows().size();
            writeCheckpoint("browser-study-selected");
            QTimer::singleShot(selectionSettleMs_, this, [this]() {
                executeEditCommand();
            });
            return;
        }
        if (candidateCount_ > 1) {
            finish("browser-motion-study-ambiguous", false);
            return;
        }

        if (elapsedMs_ >= timeoutMs_) {
            finish(folderCount_ == 0
                       ? "timeout-awaiting-motion-studies-folder"
                       : "timeout-awaiting-motion-study-item",
                   false);
            return;
        }
        elapsedMs_ += pollIntervalMs_;
        QTimer::singleShot(pollIntervalMs_, this, [this]() {
            pollForBrowserStudy();
        });
    }

    void executeEditCommand() {
        if (finished_) {
            return;
        }
        QTreeView* view = candidate_.view.data();
        if (view == nullptr || !candidate_.studyIndex.isValid() ||
            view->selectionModel() == nullptr) {
            finish("browser-selection-lost-before-edit", false);
            return;
        }
        browserCurrentIndexMatches_ =
            view->currentIndex() == candidate_.studyIndex;
        selectedRowCount_ =
            view->selectionModel()->selectedRows().size();
        if (!browserCurrentIndexMatches_ || selectedRowCount_ != 1) {
            finish("browser-selection-not-stable", false);
            return;
        }

        const auto application = adsk::core::Application::get();
        const auto ui = application ? application->userInterface() : nullptr;
        const auto definitions = ui ? ui->commandDefinitions() : nullptr;
        const auto edit = definitions
            ? definitions->itemById("EditMotionStudyCmd")
            : nullptr;
        editCommandDefinitionFound_ = edit && edit->isValid();
        if (!editCommandDefinitionFound_) {
            finish("edit-motion-study-command-not-found", false);
            return;
        }
        editCommandExecuted_ = edit->execute();
        writeCheckpoint("edit-command-dispatched");
        if (!editCommandExecuted_) {
            finish("edit-motion-study-command-rejected", false);
            return;
        }
        QTimer::singleShot(pollIntervalMs_, this, [this]() {
            pollForDialog();
        });
    }

    void pollForDialog() {
        if (finished_) {
            return;
        }
        const auto dialogs = exactMotionStudyDialogs();
        if (dialogs.size() > 1) {
            finish("motion-study-dialog-cardinality-rejected", false);
            return;
        }
        if (dialogs.size() == 1) {
            dialog_ = dialogs.front();
            dialogState_ = inspectNativeMotionStudyDialog(dialog_.data());
            if (dialogState_.tableRows == expectedRowCount_) {
                finish("native-edit-dialog-visible", true);
                return;
            }
        }

        if (elapsedMs_ >= timeoutMs_) {
            finish(dialog_ == nullptr
                       ? "timeout-awaiting-native-edit-dialog"
                       : "native-edit-row-count-rejected",
                   false);
            return;
        }
        elapsedMs_ += pollIntervalMs_;
        QTimer::singleShot(pollIntervalMs_, this, [this]() {
            pollForDialog();
        });
    }

    QString expectedStudyName_;
    int expectedRowCount_;
    std::string outputPath_;
    int pollIntervalMs_;
    int timeoutMs_;
    int selectionSettleMs_;
    BrowserMotionStudyCandidate candidate_;
    QPointer<QWidget> dialog_;
    NativeMotionStudyDialogState dialogState_;
    QString browserViewClass_;
    QString browserViewObjectName_;
    QString folderText_;
    QString studyText_;
    int elapsedMs_ = 0;
    int folderCount_ = 0;
    std::size_t candidateCount_ = 0;
    int selectedRowCount_ = 0;
    bool browserSelectionApplied_ = false;
    bool browserCurrentIndexMatches_ = false;
    bool editCommandDefinitionFound_ = false;
    bool editCommandExecuted_ = false;
    bool finished_ = false;
};

bool prefixHexMatches(std::uintptr_t address,
                      const char* expectedHex,
                      std::size_t byteCount) {
    if (address == 0 || expectedHex == nullptr ||
        std::strlen(expectedHex) != byteCount * 2) {
        return false;
    }
    const auto hexValue = [](char value) -> int {
        if (value >= '0' && value <= '9') {
            return value - '0';
        }
        if (value >= 'a' && value <= 'f') {
            return value - 'a' + 10;
        }
        if (value >= 'A' && value <= 'F') {
            return value - 'A' + 10;
        }
        return -1;
    };
    const auto* actual = reinterpret_cast<const std::uint8_t*>(address);
    for (std::size_t index = 0; index < byteCount; ++index) {
        const int high = hexValue(expectedHex[index * 2]);
        const int low = hexValue(expectedHex[index * 2 + 1]);
        if (high < 0 || low < 0 ||
            actual[index] != static_cast<std::uint8_t>(
                                 (high << 4) | low)) {
            return false;
        }
    }
    return true;
}

struct alignas(16) OpaqueObjectPath {
    std::array<std::uint8_t, 0x30> bytes{};
};

struct alignas(8) OpaqueStrongRef {
    std::array<std::uint8_t, 0x10> bytes{};
};

static_assert(sizeof(OpaqueObjectPath) == 0x30);
static_assert(sizeof(OpaqueStrongRef) == 0x10);

bool gNativeMotionStudyDirectEditControllerActive = false;

class NativeMotionStudyDirectEditController final : public QObject {
public:
    NativeMotionStudyDirectEditController(std::string outputPath,
                                          int expectedRowCount,
                                          int expectedPointCount,
                                          int pollIntervalMs,
                                          int timeoutMs)
        : outputPath_(std::move(outputPath)),
          expectedRowCount_(expectedRowCount),
          expectedPointCount_(expectedPointCount),
          pollIntervalMs_(std::max(50, pollIntervalMs)),
          timeoutMs_(std::max(500, timeoutMs)) {}

    void start() {
        writeCheckpoint("armed");
        if (!prepareAndExecute()) {
            finish(status_.empty() ? "direct-edit-prepare-rejected"
                                   : status_.c_str(),
                   false);
            return;
        }
        QTimer::singleShot(pollIntervalMs_, this, [this]() {
            pollForDialog();
        });
    }

private:
    using ObjectPathConstruct = void (*)(void*);
    using ObjectPathDestroy = void (*)(void*);
    using InternalComponent = void* (*)(const void*);
    using StrongRefGet = void* (*)(const void*, bool);
    using StrongRefDestroy = void (*)(void*);
    using MotionStudiesCount = std::uint32_t (*)(const void*);
    using ManagedChild = const void* (*)(const void*, std::uint32_t);
    using ActiveSelectionSet = void* (*)();
    using SelectionMutation = void (*)(void*, const void*, bool);
    using SelectionContains = bool (*)(const void*, const void*);
    using SelectionMotionStudy = void* (*)(const void*);
    using LogicalSelectionSession = void* (*)(const void*);
    using SessionSelection = void* (*)(const void*);
    using SessionSelectionManager = void* (*)(const void*);
    using ActiveSessionSelectionManager = void* (*)();
    using ManagerSelectionSet = void* (*)(const void*);
    using SelectionSessionState = std::uint32_t (*)(const void*);
    using DisplaySelectedSelection = bool (*)(const void*);

    bool reject(const char* status) {
        status_ = status;
        return false;
    }

    bool gateImagesAndFunctions() {
        const auto application = adsk::core::Application::get();
        fusionVersion_ = application ? application->version() : "";
        releaseMatches_ = fusionVersion_ == "2704.1.36";
        if (!releaseMatches_) {
            return reject("fusion-release-rejected");
        }

        fusionXlayer_ = findLoadedImage(
            "/Libraries/Applications/Fusion/FusionXLayer10.dylib");
        nsBaseCore_ = findLoadedImage(
            "/Libraries/Neutron/NsBaseCore10.dylib");
        nsDataModel_ = findLoadedImage(
            "/Libraries/Neutron/NsDataModel10.dylib");
        nsComponent_ = findLoadedImage(
            "/Libraries/Neutron/NsComponent10.dylib");
        nuClientBase_ = findLoadedImage(
            "/Libraries/Neutron/NuClientBase10.dylib");
        naFusionUi_ = findLoadedImage(
            "/Libraries/Applications/Fusion/NaFusionUI10.dylib");

        constexpr std::array<std::uint8_t, 16> kFusionXlayerUuid = {
            0xa7, 0xa5, 0x17, 0x68, 0xfe, 0xc5, 0x3f, 0x63,
            0x82, 0x53, 0x4e, 0x5b, 0x2f, 0x67, 0x08, 0xfb,
        };
        constexpr std::array<std::uint8_t, 16> kNsBaseCoreUuid = {
            0xb1, 0x95, 0x11, 0x96, 0x9f, 0x1d, 0x38, 0x73,
            0xaa, 0xc1, 0xb9, 0xf7, 0xce, 0x0b, 0xde, 0x9c,
        };
        constexpr std::array<std::uint8_t, 16> kNsDataModelUuid = {
            0xf1, 0x82, 0x10, 0xea, 0xcc, 0x00, 0x3a, 0x24,
            0x87, 0xf1, 0xfd, 0x48, 0xf9, 0x0f, 0x27, 0xca,
        };
        constexpr std::array<std::uint8_t, 16> kNsComponentUuid = {
            0x14, 0x86, 0x08, 0xf9, 0xe4, 0xd5, 0x33, 0x84,
            0xa2, 0xe5, 0x6a, 0xe0, 0x36, 0xc7, 0x51, 0xda,
        };
        constexpr std::array<std::uint8_t, 16> kNuClientBaseUuid = {
            0xec, 0x0b, 0x3c, 0xd5, 0x12, 0xa4, 0x31, 0x4a,
            0xbf, 0xfe, 0x56, 0x46, 0x30, 0xc6, 0x9f, 0xfe,
        };
        constexpr std::array<std::uint8_t, 16> kNaFusionUiUuid = {
            0x45, 0xf2, 0xe0, 0xc4, 0x1a, 0x4f, 0x36, 0xb8,
            0xa6, 0xd8, 0x63, 0x33, 0xa6, 0x8f, 0xba, 0xd1,
        };
        imageUuidGates_ = {
            loadedImageUuidMatches(fusionXlayer_.header,
                                   kFusionXlayerUuid),
            loadedImageUuidMatches(nsBaseCore_.header,
                                   kNsBaseCoreUuid),
            loadedImageUuidMatches(nsDataModel_.header,
                                   kNsDataModelUuid),
            loadedImageUuidMatches(nsComponent_.header,
                                   kNsComponentUuid),
            loadedImageUuidMatches(nuClientBase_.header,
                                   kNuClientBaseUuid),
            loadedImageUuidMatches(naFusionUi_.header,
                                   kNaFusionUiUuid),
        };
        if (!std::all_of(imageUuidGates_.begin(),
                         imageUuidGates_.end(),
                         [](bool value) { return value; })) {
            return reject("image-uuid-gate-rejected");
        }

        constexpr std::uintptr_t kInternalComponent = 0x002243a8;
        constexpr std::uintptr_t kObjectPathC1 = 0x00210bdc;
        constexpr std::uintptr_t kObjectPathD1 = 0x00210cac;
        constexpr std::uintptr_t kManagedObjectPath = 0x001b485c;
        constexpr std::uintptr_t kCreateSelection = 0x000da830;
        constexpr std::uintptr_t kStrongRefGet = 0x002a8150;
        constexpr std::uintptr_t kStrongRefD2 = 0x002a71f4;
        constexpr std::uintptr_t kStudiesCount = 0x000d8450;
        constexpr std::uintptr_t kManagedChild = 0x001b63d0;
        constexpr std::uintptr_t kActiveSelectionSet = 0x00313f64;
        constexpr std::uintptr_t kSelectionAdd = 0x0032aa9c;
        constexpr std::uintptr_t kSelectionContains = 0x0032ac60;
        constexpr std::uintptr_t kSelectionRemove = 0x0032ae34;
        constexpr std::uintptr_t kSelectionMotionStudy = 0x001f88f4;
        constexpr std::uintptr_t kLogicalSelectionSession = 0x0031871c;
        constexpr std::uintptr_t kSessionSelection = 0x0032a48c;
        constexpr std::uintptr_t kSessionSelectionManager = 0x00317d84;
        constexpr std::uintptr_t kActiveSessionSelectionManager =
            0x00313ee0;
        constexpr std::uintptr_t kManagerSelectionSet = 0x00313b40;
        constexpr std::uintptr_t kSelectionSessionState = 0x00317e6c;
        constexpr std::uintptr_t kDisplaySelectedSelection = 0x00314a38;
        constexpr std::uintptr_t kEditPostActivate = 0x003b7078;

        constexpr std::size_t kGateSize = 68;
        prefixGates_ = {
            prefixHexMatches(
                fusionXlayer_.base + kInternalComponent,
                "ff8300d1fd7b01a9fd430091a86400f0083546f9080140f9e80700f9e80740f9a96400f0293546f9290140f93f0108eba100005400200091fd7b41a9ff8300918b57ff17",
                kGateSize),
            prefixHexMatches(
                nsBaseCore_.base + kObjectPathC1,
                "ff8300d1fd7b01a9fd430091080d009008e147f9080140f9e80700f9880d009008813491080000f900e4006f0080803c0080813c1f2800b9e80740f9090d009029e147f9",
                kGateSize),
            prefixHexMatches(
                nsBaseCore_.base + kObjectPathD1,
                "ffc300d1f44f01a9fd7b02a9fd830091f30300aa080d009008e147f9080140f9e80700f9880d009008813491080000f9000440f9600000b4600a00f907b80294e80740f9",
                kGateSize),
            prefixHexMatches(
                nsDataModel_.base + kManagedObjectPath,
                "ff4301d1f65702a9f44f03a9fd7b04a9fd030191f40301aaf60300aaf30308aac82600d008ad43f9080140f9e80f00f9e00313aa85c20e94e00314aac4c90e94f50300aa",
                kGateSize),
            prefixHexMatches(
                nsComponent_.base + kCreateSelection,
                "ff0302d1f65705a9f44f06a9fd7b07a9fdc30191f50301aaf40300aaf30308aac81100d008dd45f9080140f9a8831df8c81100d0089942f908410091e9630091e8ff01a9",
                kGateSize),
            prefixHexMatches(
                nsDataModel_.base + kStrongRefGet,
                "ff0301d1f65701a9f44f02a9fd7b03a9fdc30091f40301aaf30300aa281f00d008ad43f9080140f9e80700f9150440f9f50000b4e00315aa9c540094800000b4e10300aa",
                kGateSize),
            prefixHexMatches(
                nsDataModel_.base + kStrongRefD2,
                "ffc300d1f44f01a9fd7b02a9fd830091f30300aa281f00f008ad43f9080140f9e80700f9010080d21300009460220091010080d234f6ff97e80740f9291f00f029ad43f9",
                kGateSize),
            prefixHexMatches(
                nsComponent_.base + kStudiesCount,
                "ff4301d1f65702a9f44f03a9fd7b04a9fd030191f30300aae811009008dd45f9080140f9e80f00f908cc40f9083940f90060069100013fd6140080522004003415008052",
                kGateSize),
            prefixHexMatches(
                nsDataModel_.base + kManagedChild,
                "ff8300d1fd7b01a9fd430091c826009008ad43f9080140f9e80700f908a440f9e90740f9ca2600904aad43f94a0140f95f0109eba10000540051218bfd7b41a9ff830091",
                kGateSize),
            prefixHexMatches(
                nuClientBase_.base + kActiveSelectionSet,
                "ff8300d1fd7b01a9fd430091c87b00b0081940f9080140f9e80700f9d8ffff97c00100b4088840f9680100b4098440f90801098b080500d1097840f90afd46d34ad97d92",
                kGateSize),
            prefixHexMatches(
                nsDataModel_.base + kSelectionAdd,
                "ff0301d1f65701a9f44f02a9fd7b03a9fdc30091f50302aaf40301aaf30300aa281b009008ad43f9080140f9e80700f9e00301aa010080529ff5fd97a00200b435010037",
                kGateSize),
            prefixHexMatches(
                nsDataModel_.base + kSelectionContains,
                "ffc300d1f44f01a9fd7b02a9fd830091f30300aa281b009008ad43f9080140f9e80700f9e00301aa0100805231f5fd97e00300f960c20091e1030091c6b2f3971f0000f1",
                kGateSize),
            prefixHexMatches(
                nsDataModel_.base + kSelectionRemove,
                "ff0301d1f65701a9f44f02a9fd7b03a9fdc30091f50302aaf40301aaf30300aa281b009008ad43f9080140f9e80700f9e00301aa01008052b9f4fd97c00200b435010034",
                kGateSize),
            prefixHexMatches(
                nsComponent_.base + kSelectionMotionStudy,
                "ff8300d1fd7b01a9fd430091e808009008dd45f9080140f9e80700f959720294e80740f9e908009029dd45f9290140f93f0108eb81000054fd7b41a9ff8300917588fb17",
                kGateSize),
            prefixHexMatches(
                naFusionUi_.base + kEditPostActivate,
                "ffc301d1f65704a9f44f05a9fd7b06a9fd830191f30300aa08ed00d0081540f9080140f9a8831df84f1c519468a259390810003730595194c00600b4f40300aa009e5194",
                kGateSize),
            prefixHexMatches(
                nsDataModel_.base + kSessionSelection,
                "ff8300d1fd7b01a9fd430091281b009008ad43f9080140f9e80700f9000840f9e80740f9291b009029ad43f9290140f93f0108eb81000054fd7b41a9ff830091c0035fd6",
                kGateSize),
            prefixHexMatches(
                nuClientBase_.base + kSessionSelectionManager,
                "ff8300d1fd7b01a9fd430091a87b00b0081940f9080140f9e80700f9000c40f9e80740f9a97b00b0291940f9290140f93f0108eb81000054fd7b41a9ff830091c0035fd6",
                kGateSize),
            prefixHexMatches(
                nuClientBase_.base + kActiveSessionSelectionManager,
                "ff8300d1fd7b01a9fd430091c87b00b0081940f9080140f9e80700f90000801221008052ea4b0094800100b458510094400100b4e80740f9c97b00b0291940f9290140f9",
                kGateSize),
            prefixHexMatches(
                nuClientBase_.base + kManagerSelectionSet,
                "ff8300d1fd7b01a9fd430091c87b00b0081940f9080140f9e80700f9088840f9680100b4098440f90801098b080500d1097840f90afd46d34ad97d9229696af808214092",
                kGateSize),
            prefixHexMatches(
                nuClientBase_.base + kSelectionSessionState,
                "ff8300d1fd7b01a9fd430091a87b00b0081940f9080140f9e80700f9002040b9e80740f9a97b00b0291940f9290140f93f0108eb81000054fd7b41a9ff830091c0035fd6",
                kGateSize),
            prefixHexMatches(
                nuClientBase_.base + kDisplaySelectedSelection,
                "ff8300d1fd7b01a9fd430091c87b0090081940f9080140f9e80700f9004c4539e80740f9c97b0090291940f9290140f93f0108eb81000054fd7b41a9ff830091c0035fd6",
                kGateSize),
            prefixHexMatches(
                nsDataModel_.base + kLogicalSelectionSession,
                "ff8300d1fd7b01a9fd430091a81b00d008ad43f9080140f9e80700f9001c41f9e80740f9a91b00d029ad43f9290140f93f0108eb81000054fd7b41a9ff830091c0035fd6",
                kGateSize),
        };
        if (!std::all_of(prefixGates_.begin(),
                         prefixGates_.end(),
                         [](bool value) { return value; })) {
            return reject("private-abi-68-byte-gate-rejected");
        }

        internalComponent_ = reinterpret_cast<InternalComponent>(
            fusionXlayer_.base + kInternalComponent);
        objectPathConstruct_ = reinterpret_cast<ObjectPathConstruct>(
            nsBaseCore_.base + kObjectPathC1);
        objectPathDestroy_ = reinterpret_cast<ObjectPathDestroy>(
            nsBaseCore_.base + kObjectPathD1);
        managedObjectPath_ = reinterpret_cast<void*>(
            nsDataModel_.base + kManagedObjectPath);
        createSelection_ = reinterpret_cast<void*>(
            nsComponent_.base + kCreateSelection);
        strongRefGet_ = reinterpret_cast<StrongRefGet>(
            nsDataModel_.base + kStrongRefGet);
        strongRefDestroy_ = reinterpret_cast<StrongRefDestroy>(
            nsDataModel_.base + kStrongRefD2);
        motionStudiesCount_ = reinterpret_cast<MotionStudiesCount>(
            nsComponent_.base + kStudiesCount);
        managedChild_ = reinterpret_cast<ManagedChild>(
            nsDataModel_.base + kManagedChild);
        activeSelectionSet_ = reinterpret_cast<ActiveSelectionSet>(
            nuClientBase_.base + kActiveSelectionSet);
        selectionAdd_ = reinterpret_cast<SelectionMutation>(
            nsDataModel_.base + kSelectionAdd);
        selectionContains_ = reinterpret_cast<SelectionContains>(
            nsDataModel_.base + kSelectionContains);
        selectionRemove_ = reinterpret_cast<SelectionMutation>(
            nsDataModel_.base + kSelectionRemove);
        selectionMotionStudy_ = reinterpret_cast<SelectionMotionStudy>(
            nsComponent_.base + kSelectionMotionStudy);
        logicalSelectionSession_ =
            reinterpret_cast<LogicalSelectionSession>(
                nsDataModel_.base + kLogicalSelectionSession);
        sessionSelection_ = reinterpret_cast<SessionSelection>(
            nsDataModel_.base + kSessionSelection);
        sessionSelectionManager_ =
            reinterpret_cast<SessionSelectionManager>(
                nuClientBase_.base + kSessionSelectionManager);
        activeSessionSelectionManager_ =
            reinterpret_cast<ActiveSessionSelectionManager>(
                nuClientBase_.base +
                kActiveSessionSelectionManager);
        managerSelectionSet_ = reinterpret_cast<ManagerSelectionSet>(
            nuClientBase_.base + kManagerSelectionSet);
        selectionSessionState_ =
            reinterpret_cast<SelectionSessionState>(
                nuClientBase_.base + kSelectionSessionState);
        displaySelectedSelection_ =
            reinterpret_cast<DisplaySelectedSelection>(
                nuClientBase_.base + kDisplaySelectedSelection);
        return true;
    }

    bool resolveUniqueMotionStudy() {
        const auto application = adsk::core::Application::get();
        const auto product = application ? application->activeProduct()
                                         : nullptr;
        const auto design = product
            ? product->cast<adsk::fusion::Design>()
            : nullptr;
        const auto root = design ? design->rootComponent() : nullptr;
        rootComponentResolved_ = root && root->isValid();
        if (!rootComponentResolved_) {
            return reject("active-root-component-not-found");
        }
        void* component = internalComponent_(root.get());
        internalComponentResolved_ = component != nullptr;
        if (!internalComponentResolved_) {
            return reject("internal-component-not-found");
        }
        const auto* componentBytes =
            reinterpret_cast<const std::uint8_t*>(component);
        motionStudies_ = strongRefGet_(componentBytes + 0x590, true);
        motionStudiesVptrMatches_ = motionStudies_ != nullptr &&
            *reinterpret_cast<std::uintptr_t*>(motionStudies_) ==
                nsComponent_.base + 0x0031e6a8;
        if (!motionStudiesVptrMatches_) {
            return reject("motion-studies-vptr-rejected");
        }
        motionStudyCount_ = motionStudiesCount_(motionStudies_);
        if (motionStudyCount_ != 1) {
            return reject("motion-study-cardinality-rejected");
        }
        const void* borrowed = managedChild_(motionStudies_, 0);
        motionStudy_ = borrowed ? strongRefGet_(borrowed, true) : nullptr;
        motionStudyVptrMatches_ = motionStudy_ != nullptr &&
            *reinterpret_cast<std::uintptr_t*>(motionStudy_) ==
                nsComponent_.base + 0x0031ea58;
        if (!motionStudyVptrMatches_) {
            return reject("motion-study-vptr-rejected");
        }
        return true;
    }

    bool createAndInstallSelection() {
#if !defined(__aarch64__)
        return reject("arm64-required");
#else
        objectPathConstruct_(&seedPath_);
        seedPathConstructed_ = true;
        seedPathVptrMatches_ =
            *reinterpret_cast<std::uintptr_t*>(&seedPath_) ==
                nsBaseCore_.base + 0x003c0d20;
        if (!seedPathVptrMatches_) {
            return reject("seed-object-path-vptr-rejected");
        }

        cad_agent_call_x8_sret_2(managedObjectPath_,
                                 motionStudy_,
                                 &seedPath_,
                                 &fullPath_);
        fullPathConstructed_ = true;
        fullPathVptrMatches_ =
            *reinterpret_cast<std::uintptr_t*>(&fullPath_) ==
                nsBaseCore_.base + 0x003c0d20;
        objectPathDestroy_(&seedPath_);
        seedPathConstructed_ = false;
        if (!fullPathVptrMatches_) {
            return reject("full-object-path-vptr-rejected");
        }

        cad_agent_call_x8_sret_2(createSelection_,
                                 motionStudy_,
                                 &fullPath_,
                                 &selectionHolder_);
        selectionHolderConstructed_ = true;
        objectPathDestroy_(&fullPath_);
        fullPathConstructed_ = false;

        selection_ = strongRefGet_(&selectionHolder_, true);
        selectionResolved_ = selection_ != nullptr;
        if (!selectionResolved_) {
            return reject("motion-study-selection-not-created");
        }
        const auto* selectionBytes =
            reinterpret_cast<const std::uint8_t*>(selection_);
        selectionVptrsMatch_ =
            *reinterpret_cast<const std::uintptr_t*>(selectionBytes) ==
                nsComponent_.base + 0x0032c9b0 &&
            *reinterpret_cast<const std::uintptr_t*>(
                selectionBytes + 0x78) ==
                nsComponent_.base + 0x0032cae8 &&
            *reinterpret_cast<const std::uintptr_t*>(
                selectionBytes + 0xb0) ==
                nsComponent_.base + 0x0032cb48;
        if (!selectionVptrsMatch_) {
            return reject("motion-study-selection-coherence-rejected");
        }
        selectionStudyMatches_ =
            selectionMotionStudy_(selection_) == motionStudy_;
        if (!selectionStudyMatches_) {
            return reject("motion-study-selection-coherence-rejected");
        }

        selectionSet_ = activeSelectionSet_();
        selectionSetVptrMatches_ = selectionSet_ != nullptr &&
            *reinterpret_cast<std::uintptr_t*>(selectionSet_) ==
                nsDataModel_.base + 0x006a8bb0;
        if (!selectionSetVptrMatches_) {
            return reject("active-selection-set-vptr-rejected");
        }
        selectionContainedBefore_ = selectionContains_(
            selectionSet_, &selectionHolder_);
        if (selectionContainedBefore_) {
            return reject("equivalent-selection-already-present");
        }
        selectionAddAttempted_ = true;
        selectionAdd_(selectionSet_, &selectionHolder_, false);
        selectionAdded_ = true;
        selectionContainedAfterAdd_ = selectionContains_(
            selectionSet_, &selectionHolder_);
        if (!selectionContainedAfterAdd_) {
            return reject("selection-add-not-observed");
        }
        return validateSelectionSessionCoherence();
#endif
    }

    bool validateSelectionSessionCoherence() {
        selectionSession_ = logicalSelectionSession_(selection_);
        selectionSessionResolved_ = selectionSession_ != nullptr;
        activeSessionSelectionManagerResolved_ =
            activeSessionSelectionManager_();
        activeSessionSelectionManagerVptrMatches_ =
            activeSessionSelectionManagerResolved_ != nullptr &&
            *reinterpret_cast<std::uintptr_t*>(
                activeSessionSelectionManagerResolved_) ==
                nuClientBase_.base + 0x012b3138;
        if (!activeSessionSelectionManagerVptrMatches_) {
            return reject("active-selection-session-manager-vptr-rejected");
        }
        managerSelectionSetResolved_ =
            managerSelectionSet_(
                activeSessionSelectionManagerResolved_);
        managerSelectionSetMatches_ =
            managerSelectionSetResolved_ != nullptr &&
            managerSelectionSetResolved_ == selectionSet_;
        if (!managerSelectionSetMatches_) {
            return reject("selection-manager-selection-set-mismatch");
        }

        displaySelectedSelectionRead_ = true;
        displaySelectedSelectionEnabled_ = displaySelectedSelection_(
            activeSessionSelectionManagerResolved_);
        if (!selectionSessionResolved_) {
            selectionSessionOptionalAbsent_ = true;
            selectionSessionCoherenceAccepted_ =
                selectionContainedAfterAdd_ &&
                managerSelectionSetMatches_;
            return selectionSessionCoherenceAccepted_;
        }

        const std::uintptr_t selectionSessionVptr =
            *reinterpret_cast<std::uintptr_t*>(selectionSession_);
        selectionSessionVptrMatches_ =
            selectionSessionVptr ==
                nuClientBase_.base + 0x012b34a8 ||
            selectionSessionVptr ==
                nuClientBase_.base + 0x012b2460;
        if (!selectionSessionVptrMatches_) {
            return reject("selection-session-vptr-rejected");
        }

        sessionSelectionMatches_ =
            sessionSelection_(selectionSession_) == selection_;
        if (!sessionSelectionMatches_) {
            return reject("selection-session-selection-mismatch");
        }

        selectionSessionManager_ =
            sessionSelectionManager_(selectionSession_);
        selectionSessionManagerResolved_ =
            selectionSessionManager_ != nullptr;
        selectionSessionManagerVptrMatches_ =
            selectionSessionManagerResolved_ &&
            *reinterpret_cast<std::uintptr_t*>(
                selectionSessionManager_) ==
                nuClientBase_.base + 0x012b3138;
        if (!selectionSessionManagerVptrMatches_) {
            return reject("selection-session-manager-vptr-rejected");
        }
        activeSessionSelectionManagerMatches_ =
            activeSessionSelectionManagerResolved_ ==
                selectionSessionManager_;
        if (!activeSessionSelectionManagerMatches_) {
            return reject("active-selection-session-manager-mismatch");
        }

        selectionSessionStateValue_ =
            selectionSessionState_(selectionSession_);
        selectionSessionSelectedState_ =
            selectionSessionStateValue_ == 0x1u;
        if (!selectionSessionSelectedState_) {
            return reject("selection-session-state-not-exactly-selected");
        }
        selectionSessionCoherenceAccepted_ = true;
        return true;
    }

    bool executeNativeEdit() {
        const auto application = adsk::core::Application::get();
        const auto ui = application ? application->userInterface() : nullptr;
        const auto definitions = ui ? ui->commandDefinitions() : nullptr;
        const auto edit = definitions
            ? definitions->itemById("EditMotionStudyCmd")
            : nullptr;
        editCommandDefinitionFound_ = edit && edit->isValid();
        if (!editCommandDefinitionFound_) {
            return reject("edit-motion-study-command-not-found");
        }
        editCommandExecuted_ = edit->execute();
        if (!editCommandExecuted_) {
            return reject("edit-motion-study-command-rejected");
        }
        selectionSetVptrMatchesAfterEditExecute_ =
            selectionSet_ != nullptr &&
            *reinterpret_cast<std::uintptr_t*>(selectionSet_) ==
                nsDataModel_.base + 0x006a8bb0;
        if (!selectionSetVptrMatchesAfterEditExecute_ ||
            !selectionHolderConstructed_ ||
            selectionContains_ == nullptr ||
            logicalSelectionSession_ == nullptr) {
            return reject("post-edit-execute-selection-snapshot-rejected");
        }
        selectionContainedAfterEditExecute_ =
            selectionContains_(selectionSet_, &selectionHolder_);
        selectionContainmentAfterEditExecuteRead_ = true;
        selectionSessionAbsentAfterEditExecute_ =
            logicalSelectionSession_(selection_) == nullptr;
        selectionSessionAfterEditExecuteRead_ = true;
        return true;
    }

    bool prepareAndExecute() noexcept {
        try {
            const auto application = adsk::core::Application::get();
            const auto ui = application
                ? application->userInterface()
                : nullptr;
            activeCommandBefore_ = ui ? ui->activeCommand() : "";
            selectCommandActiveBefore_ =
                activeCommandBefore_ == "SelectCommand";
            if (!selectCommandActiveBefore_) {
                return reject("select-command-not-active");
            }
            if (!exactMotionStudyDialogs().empty()) {
                return reject("preexisting-motion-study-dialog-rejected");
            }
            if (!gateImagesAndFunctions() ||
                !resolveUniqueMotionStudy() ||
                !createAndInstallSelection() ||
                !executeNativeEdit()) {
                return false;
            }
            writeCheckpoint("selection-installed-edit-dispatched");
            return true;
        } catch (...) {
            return reject("direct-edit-exception");
        }
    }

    bool validateDialogCoherence(QWidget* dialog) noexcept {
        try {
            if (!isExactMotionStudyDialog(dialog)) {
                return false;
            }
            const auto tables = dialog->findChildren<QTableWidget*>();
            dialogRowCount_ = tables.size() == 1
                ? tables.front()->rowCount()
                : -1;
            if (dialogRowCount_ != expectedRowCount_ ||
                *reinterpret_cast<std::uintptr_t*>(dialog) !=
                    naFusionUi_.base + 0x022cfe78) {
                return false;
            }
            auto* dialogBytes = reinterpret_cast<std::uint8_t*>(dialog);
            void* callback = *reinterpret_cast<void**>(
                dialogBytes + 0x58);
            const auto callbackAddress =
                reinterpret_cast<std::uintptr_t>(callback);
            if (callback == nullptr ||
                callbackAddress < 0x620 ||
                callbackAddress % alignof(void*) != 0) {
                return false;
            }
            auto* edit = reinterpret_cast<std::uint8_t*>(
                callbackAddress - 0x620);
            editCommandVptrMatches_ =
                *reinterpret_cast<std::uintptr_t*>(edit) ==
                    naFusionUi_.base + 0x0217c1d0;
            void* facade = *reinterpret_cast<void**>(edit + 0x630);
            facadeCoherent_ = facade != nullptr &&
                *reinterpret_cast<void**>(facade) == dialog &&
                *reinterpret_cast<void**>(
                    reinterpret_cast<std::uint8_t*>(facade) + 0x8) ==
                    callback;
            editStudyMatches_ =
                *reinterpret_cast<void**>(edit + 0x660) == motionStudy_;
            editPostActivated_ =
                *reinterpret_cast<std::uint8_t*>(edit + 0x668) == 1;
            curveReadbackCodes_.clear();
            observedMainGripCount_ = 0;
            observedDependentGripCount_ = 0;
            curveReadbacksValid_ = true;
            for (int rowIndex = 0; rowIndex < expectedRowCount_;
                 ++rowIndex) {
                const CurveReadbackResult readback =
                    readCurveGrips(dialog, rowIndex);
                curveReadbackCodes_.push_back(readback.code);
                if (readback.code != 0) {
                    curveReadbacksValid_ = false;
                    continue;
                }
                for (const GripSnapshot& grip : readback.grips) {
                    if (grip.deleted) {
                        curveReadbacksValid_ = false;
                    } else if (grip.style == 0 && grip.direction == 1) {
                        ++observedMainGripCount_;
                    } else if (grip.style == 1 &&
                               grip.direction == 4) {
                        ++observedDependentGripCount_;
                    } else {
                        curveReadbacksValid_ = false;
                    }
                }
            }
            curveCountsMatch_ = curveReadbacksValid_ &&
                observedMainGripCount_ ==
                    static_cast<std::size_t>(expectedPointCount_) &&
                observedDependentGripCount_ == 0;
            return editCommandVptrMatches_ && facadeCoherent_ &&
                   editStudyMatches_ && editPostActivated_ &&
                   curveCountsMatch_;
        } catch (...) {
            return false;
        }
    }

    void cleanupSelectionAndOpaqueObjects() noexcept {
        try {
            if (selectionAddAttempted_ &&
                selectionHolderConstructed_ &&
                selectionSet_ != nullptr &&
                selectionContains_ != nullptr) {
                if (selection_ != nullptr &&
                    logicalSelectionSession_ != nullptr) {
                    void* sessionBeforeCleanup =
                        logicalSelectionSession_(selection_);
                    selectionSessionBeforeCleanupRead_ = true;
                    selectionSessionAbsentBeforeCleanup_ =
                        sessionBeforeCleanup == nullptr;
                    selectionSessionCleanupPrecondition_ =
                        selectionSessionAbsentBeforeCleanup_ ||
                        (sessionBeforeCleanup == selectionSession_ &&
                         selectionSessionCoherenceAccepted_ &&
                         selectionSessionStateValue_ == 0x1u);
                }
                selectionSetVptrMatchesAtCleanup_ =
                    *reinterpret_cast<std::uintptr_t*>(selectionSet_) ==
                        nsDataModel_.base + 0x006a8bb0;
                if (selectionSetVptrMatchesAtCleanup_) {
                    selectionContainedBeforeCleanup_ =
                        selectionContains_(selectionSet_,
                                           &selectionHolder_);
                    if (selectionContainedBeforeCleanup_ &&
                        selectionRemove_ != nullptr) {
                        selectionRemove_(selectionSet_,
                                         &selectionHolder_,
                                         false);
                        selectionRemoved_ = true;
                    }
                    selectionAbsentAtCleanupEnd_ =
                        !selectionContains_(selectionSet_,
                                            &selectionHolder_);
                    if (selectionAbsentAtCleanupEnd_) {
                        selectionAdded_ = false;
                        if (selection_ != nullptr &&
                            logicalSelectionSession_ != nullptr) {
                            selectionSessionAfterCleanupRead_ = true;
                            selectionSessionAbsentAfterCleanup_ =
                                logicalSelectionSession_(selection_) ==
                                nullptr;
                        }
                    }
                    const bool sessionCleanupClosure =
                        selectionSessionBeforeCleanupRead_ &&
                        selectionSessionCleanupPrecondition_ &&
                        selectionSessionAfterCleanupRead_ &&
                        selectionSessionAbsentAfterCleanup_;
                    selectionRemovedByControllerObserved_ =
                        selectionContainmentAfterEditExecuteRead_ &&
                        selectionContainedAfterEditExecute_ &&
                        selectionContainedBeforeCleanup_ &&
                        selectionRemoved_ &&
                        selectionAbsentAtCleanupEnd_ &&
                        sessionCleanupClosure;
                    selectionConsumedByEditCommand_ =
                        selectionContainedAfterAdd_ &&
                        selectionSessionCoherenceAccepted_ &&
                        editCommandExecuted_ &&
                        selectionContainmentAfterEditExecuteRead_ &&
                        !selectionContainedAfterEditExecute_ &&
                        selectionSessionAfterEditExecuteRead_ &&
                        selectionSessionAbsentAfterEditExecute_ &&
                        editCommandVptrMatches_ &&
                        facadeCoherent_ && editStudyMatches_ &&
                        editPostActivated_ &&
                        !selectionContainedBeforeCleanup_ &&
                        !selectionRemoved_ &&
                        selectionAbsentAtCleanupEnd_ &&
                        selectionSessionBeforeCleanupRead_ &&
                        selectionSessionAbsentBeforeCleanup_ &&
                        selectionSessionAfterCleanupRead_ &&
                        selectionSessionAbsentAfterCleanup_;
                    selectionAbsentAfterAsyncEditActivation_ =
                        selectionContainedAfterAdd_ &&
                        selectionSessionCoherenceAccepted_ &&
                        editCommandExecuted_ &&
                        selectionContainmentAfterEditExecuteRead_ &&
                        selectionContainedAfterEditExecute_ &&
                        selectionSessionAfterEditExecuteRead_ &&
                        selectionSessionAbsentAfterEditExecute_ &&
                        editCommandVptrMatches_ &&
                        facadeCoherent_ && editStudyMatches_ &&
                        editPostActivated_ &&
                        !selectionContainedBeforeCleanup_ &&
                        !selectionRemoved_ &&
                        selectionAbsentAtCleanupEnd_ &&
                        selectionSessionBeforeCleanupRead_ &&
                        selectionSessionAbsentBeforeCleanup_ &&
                        selectionSessionAfterCleanupRead_ &&
                        selectionSessionAbsentAfterCleanup_;
                    selectionCleanupAuthorityAccepted_ =
                        selectionRemovedByControllerObserved_ ||
                        selectionConsumedByEditCommand_ ||
                        selectionAbsentAfterAsyncEditActivation_;
                }
            }
        } catch (...) {
            selectionAbsentAtCleanupEnd_ = false;
            selectionCleanupAuthorityAccepted_ = false;
        }
        try {
            if (selectionHolderConstructed_ &&
                strongRefDestroy_ != nullptr) {
                const bool safeWithoutSelectionAdd =
                    !selectionAddAttempted_;
                const bool safeAfterSelectionCleanup =
                    selectionAbsentAtCleanupEnd_ &&
                    selectionSessionBeforeCleanupRead_ &&
                    selectionSessionCleanupPrecondition_ &&
                    selectionSessionAfterCleanupRead_ &&
                    selectionSessionAbsentAfterCleanup_;
                if (safeWithoutSelectionAdd ||
                    safeAfterSelectionCleanup) {
                    strongRefDestroy_(&selectionHolder_);
                    selectionHolderConstructed_ = false;
                    selectionHolderDestroyed_ = true;
                } else {
                    selectionHolderDestroyDeferred_ = true;
                }
            }
        } catch (...) {
        }
        try {
            if (fullPathConstructed_ && objectPathDestroy_ != nullptr) {
                objectPathDestroy_(&fullPath_);
                fullPathConstructed_ = false;
            }
        } catch (...) {
        }
        try {
            if (seedPathConstructed_ && objectPathDestroy_ != nullptr) {
                objectPathDestroy_(&seedPath_);
                seedPathConstructed_ = false;
            }
        } catch (...) {
        }
    }

    void writeCheckpoint(const char* status) const {
        std::ostringstream output;
        output
            << "{\"schema\":\"cad-agent.motion-study-native-direct.v1\""
            << ",\"phase\":\"checkpoint\""
            << ",\"status\":" << quoted(std::string(status))
            << ",\"elapsed_ms\":" << elapsedMs_
            << ",\"selection_added\":" << jsonBool(selectionAdded_)
            << ",\"edit_command_executed\":"
            << jsonBool(editCommandExecuted_) << "}\n";
        writeTextAtomically(outputPath_, output.str());
    }

    std::string makeReport(const char* status,
                           bool dialogLeftVisible) const {
        std::ostringstream output;
        output
            << "{\"schema\":\"cad-agent.motion-study-native-direct.v1\""
            << ",\"phase\":\"complete\""
            << ",\"status\":" << quoted(std::string(status))
            << ",\"fusion_version\":" << quoted(fusionVersion_)
            << ",\"qt_version\":" << quoted(std::string(qVersion()))
            << ",\"main_thread\":"
            << jsonBool(QCoreApplication::instance() != nullptr &&
                        QCoreApplication::instance()->thread() ==
                            QThread::currentThread())
            << ",\"route\":\"MotionStudy::onCreateLogicalSelection + "
               "active SelectionSet + EditMotionStudyCmd\""
            << ",\"mouse_input_used\":false"
            << ",\"curve_write_requested\":false"
            << ",\"elapsed_ms\":" << elapsedMs_
            << ",\"active_command_before\":"
            << quoted(activeCommandBefore_)
            << ",\"select_command_active_before\":"
            << jsonBool(selectCommandActiveBefore_)
            << ",\"expected_row_count\":" << expectedRowCount_
            << ",\"observed_row_count\":" << dialogRowCount_
            << ",\"expected_main_grip_count\":"
            << expectedPointCount_
            << ",\"observed_main_grip_count\":"
            << observedMainGripCount_
            << ",\"observed_dependent_grip_count\":"
            << observedDependentGripCount_
            << ",\"curve_readbacks_valid\":"
            << jsonBool(curveReadbacksValid_)
            << ",\"curve_counts_match\":"
            << jsonBool(curveCountsMatch_)
            << ",\"curve_readback_codes\":[";
        for (std::size_t index = 0;
             index < curveReadbackCodes_.size(); ++index) {
            if (index != 0) {
                output << ",";
            }
            output << curveReadbackCodes_[index];
        }
        output
            << "]"
            << ",\"release_matches\":" << jsonBool(releaseMatches_)
            << ",\"uuid_gates\":[";
        for (std::size_t index = 0; index < imageUuidGates_.size();
             ++index) {
            if (index != 0) {
                output << ",";
            }
            output << jsonBool(imageUuidGates_[index]);
        }
        output << "],\"prefix_68_byte_gates\":[";
        for (std::size_t index = 0; index < prefixGates_.size(); ++index) {
            if (index != 0) {
                output << ",";
            }
            output << jsonBool(prefixGates_[index]);
        }
        output
            << "]"
            << ",\"root_component_resolved\":"
            << jsonBool(rootComponentResolved_)
            << ",\"internal_component_resolved\":"
            << jsonBool(internalComponentResolved_)
            << ",\"motion_studies_vptr_matches\":"
            << jsonBool(motionStudiesVptrMatches_)
            << ",\"motion_study_count\":" << motionStudyCount_
            << ",\"motion_study_vptr_matches\":"
            << jsonBool(motionStudyVptrMatches_)
            << ",\"seed_path_vptr_matches\":"
            << jsonBool(seedPathVptrMatches_)
            << ",\"full_path_vptr_matches\":"
            << jsonBool(fullPathVptrMatches_)
            << ",\"selection_resolved\":"
            << jsonBool(selectionResolved_)
            << ",\"selection_session_resolved\":"
            << jsonBool(selectionSessionResolved_)
            << ",\"selection_session_vptr_matches\":"
            << jsonBool(selectionSessionVptrMatches_)
            << ",\"session_selection_matches\":"
            << jsonBool(sessionSelectionMatches_)
            << ",\"selection_session_manager_resolved\":"
            << jsonBool(selectionSessionManagerResolved_)
            << ",\"selection_session_manager_vptr_matches\":"
            << jsonBool(selectionSessionManagerVptrMatches_)
            << ",\"active_session_selection_manager_resolved\":"
            << jsonBool(activeSessionSelectionManagerResolved_ != nullptr)
            << ",\"active_session_selection_manager_vptr_matches\":"
            << jsonBool(activeSessionSelectionManagerVptrMatches_)
            << ",\"active_session_selection_manager_matches\":"
            << jsonBool(activeSessionSelectionManagerMatches_)
            << ",\"manager_selection_set_resolved\":"
            << jsonBool(managerSelectionSetResolved_ != nullptr)
            << ",\"manager_selection_set_matches\":"
            << jsonBool(managerSelectionSetMatches_)
            << ",\"selection_session_state\":"
            << selectionSessionStateValue_
            << ",\"selection_session_selected_state\":"
            << jsonBool(selectionSessionSelectedState_)
            << ",\"display_selected_selection_read\":"
            << jsonBool(displaySelectedSelectionRead_)
            << ",\"display_selected_selection_enabled\":"
            << jsonBool(displaySelectedSelectionEnabled_)
            << ",\"selection_session_optional_absent\":"
            << jsonBool(selectionSessionOptionalAbsent_)
            << ",\"selection_session_optional_coherent\":"
            << jsonBool(selectionSessionCoherenceAccepted_)
            << ",\"selection_vptrs_match\":"
            << jsonBool(selectionVptrsMatch_)
            << ",\"selection_study_matches\":"
            << jsonBool(selectionStudyMatches_)
            << ",\"selection_set_vptr_matches\":"
            << jsonBool(selectionSetVptrMatches_)
            << ",\"selection_contained_before\":"
            << jsonBool(selectionContainedBefore_)
            << ",\"selection_contained_after_add\":"
            << jsonBool(selectionContainedAfterAdd_)
            << ",\"selection_add_attempted\":"
            << jsonBool(selectionAddAttempted_)
            << ",\"edit_command_definition_found\":"
            << jsonBool(editCommandDefinitionFound_)
            << ",\"edit_command_execute_result\":"
            << jsonBool(editCommandExecuted_)
            << ",\"selection_set_vptr_matches_after_edit_execute\":"
            << jsonBool(selectionSetVptrMatchesAfterEditExecute_)
            << ",\"selection_containment_after_edit_execute_read\":"
            << jsonBool(selectionContainmentAfterEditExecuteRead_)
            << ",\"selection_contained_after_edit_execute\":"
            << jsonBool(selectionContainedAfterEditExecute_)
            << ",\"selection_session_after_edit_execute_read\":"
            << jsonBool(selectionSessionAfterEditExecuteRead_)
            << ",\"selection_session_absent_after_edit_execute\":"
            << jsonBool(selectionSessionAbsentAfterEditExecute_)
            << ",\"edit_command_vptr_matches\":"
            << jsonBool(editCommandVptrMatches_)
            << ",\"facade_coherent\":" << jsonBool(facadeCoherent_)
            << ",\"edit_study_matches\":"
            << jsonBool(editStudyMatches_)
            << ",\"edit_post_activated\":"
            << jsonBool(editPostActivated_)
            << ",\"selection_set_vptr_matches_at_cleanup\":"
            << jsonBool(selectionSetVptrMatchesAtCleanup_)
            << ",\"selection_contained_before_cleanup\":"
            << jsonBool(selectionContainedBeforeCleanup_)
            << ",\"selection_remove_called_by_controller\":"
            << jsonBool(selectionRemoved_)
            << ",\"selection_removed_by_controller_observed\":"
            << jsonBool(selectionRemovedByControllerObserved_)
            << ",\"selection_consumed_by_edit_command\":"
            << jsonBool(selectionConsumedByEditCommand_)
            << ",\"selection_absent_after_async_edit_activation\":"
            << jsonBool(selectionAbsentAfterAsyncEditActivation_)
            << ",\"selection_cleanup_authority_accepted\":"
            << jsonBool(selectionCleanupAuthorityAccepted_)
            << ",\"selection_absent_at_cleanup_end\":"
            << jsonBool(selectionAbsentAtCleanupEnd_)
            << ",\"selection_session_before_cleanup_read\":"
            << jsonBool(selectionSessionBeforeCleanupRead_)
            << ",\"selection_session_absent_before_cleanup\":"
            << jsonBool(selectionSessionAbsentBeforeCleanup_)
            << ",\"selection_session_cleanup_precondition\":"
            << jsonBool(selectionSessionCleanupPrecondition_)
            << ",\"selection_session_after_cleanup_read\":"
            << jsonBool(selectionSessionAfterCleanupRead_)
            << ",\"selection_session_absent_after_cleanup\":"
            << jsonBool(selectionSessionAbsentAfterCleanup_)
            << ",\"selection_holder_destroyed\":"
            << jsonBool(selectionHolderDestroyed_)
            << ",\"selection_holder_destroy_deferred\":"
            << jsonBool(selectionHolderDestroyDeferred_)
            << ",\"failure_dialog_cancel_candidates\":"
            << failureDialogCancelCandidates_
            << ",\"failure_dialog_cancel_dispatched\":"
            << failureDialogCancelDispatched_
            << ",\"post_cleanup_dialog_cardinality\":"
            << postCleanupDialogCardinality_
            << ",\"post_cleanup_dialog_matches\":"
            << jsonBool(postCleanupDialogMatches_)
            << ",\"post_cleanup_dialog_visible\":"
            << jsonBool(postCleanupDialogVisible_)
            << ",\"post_cleanup_dialog_row_count\":"
            << postCleanupDialogRowCount_
            << ",\"dialog_left_visible\":"
            << jsonBool(dialogLeftVisible)
            << ",\"accepted\":"
            << jsonBool(dialogLeftVisible &&
                        selectCommandActiveBefore_ &&
                        dialogRowCount_ == expectedRowCount_ &&
                        curveCountsMatch_ &&
                        selectionSessionCoherenceAccepted_ &&
                        activeSessionSelectionManagerVptrMatches_ &&
                        managerSelectionSetMatches_ &&
                        selectionSetVptrMatchesAfterEditExecute_ &&
                        selectionContainmentAfterEditExecuteRead_ &&
                        selectionSessionAfterEditExecuteRead_ &&
                        editCommandVptrMatches_ && facadeCoherent_ &&
                        editStudyMatches_ && editPostActivated_ &&
                        selectionSetVptrMatchesAtCleanup_ &&
                        selectionContainedAfterAdd_ &&
                        selectionCleanupAuthorityAccepted_ &&
                        selectionAbsentAtCleanupEnd_ &&
                        selectionSessionBeforeCleanupRead_ &&
                        selectionSessionCleanupPrecondition_ &&
                        selectionSessionAfterCleanupRead_ &&
                        selectionSessionAbsentAfterCleanup_ &&
                        selectionHolderDestroyed_ &&
                        postCleanupDialogCardinality_ == 1 &&
                        postCleanupDialogMatches_ &&
                        postCleanupDialogVisible_ &&
                        postCleanupDialogRowCount_ == expectedRowCount_)
            << "}\n";
        return output.str();
    }

    bool isOwnedNativeEditDialog(QWidget* dialog) const noexcept {
        try {
            if (!editCommandExecuted_ || motionStudy_ == nullptr ||
                naFusionUi_.base == 0 ||
                !isExactMotionStudyDialog(dialog) ||
                *reinterpret_cast<std::uintptr_t*>(dialog) !=
                    naFusionUi_.base + 0x022cfe78) {
                return false;
            }
            auto* dialogBytes = reinterpret_cast<std::uint8_t*>(dialog);
            void* callback = *reinterpret_cast<void**>(
                dialogBytes + 0x58);
            const auto callbackAddress =
                reinterpret_cast<std::uintptr_t>(callback);
            if (callback == nullptr || callbackAddress < 0x620 ||
                callbackAddress % alignof(void*) != 0) {
                return false;
            }
            auto* edit = reinterpret_cast<std::uint8_t*>(
                callbackAddress - 0x620);
            return *reinterpret_cast<std::uintptr_t*>(edit) ==
                       naFusionUi_.base + 0x0217c1d0 &&
                   *reinterpret_cast<void**>(edit + 0x660) ==
                       motionStudy_;
        } catch (...) {
            return false;
        }
    }

    void queueFailureDialogCancel() noexcept {
        QWidget* dialog = dialog_.data();
        if (!isOwnedNativeEditDialog(dialog)) {
            return;
        }
        ++failureDialogCancelCandidates_;
        try {
            if (QMetaObject::invokeMethod(dialog,
                                          "onDialogCancel",
                                          Qt::QueuedConnection)) {
                ++failureDialogCancelDispatched_;
            }
        } catch (...) {
        }
    }

    void capturePostCleanupDialogState() noexcept {
        try {
            const auto dialogs = exactMotionStudyDialogs();
            postCleanupDialogCardinality_ = dialogs.size();
            if (dialogs.size() != 1 || dialogs.front() == nullptr) {
                return;
            }
            QWidget* dialog = dialogs.front();
            postCleanupDialogMatches_ = dialog == dialog_.data();
            postCleanupDialogVisible_ = dialog->isVisible();
            const auto tables = dialog->findChildren<QTableWidget*>();
            postCleanupDialogRowCount_ = tables.size() == 1
                ? tables.front()->rowCount()
                : -1;
        } catch (...) {
        }
    }

    void finish(const char* status, bool leaveDialogVisibleRequested) {
        if (finished_) {
            return;
        }
        finished_ = true;
        if (!leaveDialogVisibleRequested) {
            queueFailureDialogCancel();
        }
        cleanupSelectionAndOpaqueObjects();
        const bool cleanupAccepted =
            selectionSetVptrMatchesAtCleanup_ &&
            selectionContainedAfterAdd_ &&
            selectionCleanupAuthorityAccepted_ &&
            selectionAbsentAtCleanupEnd_ &&
            selectionSessionBeforeCleanupRead_ &&
            selectionSessionCleanupPrecondition_ &&
            selectionSessionAfterCleanupRead_ &&
            selectionSessionAbsentAfterCleanup_ &&
            selectionHolderDestroyed_;
        if (leaveDialogVisibleRequested && !cleanupAccepted) {
            queueFailureDialogCancel();
            leaveDialogVisibleRequested = false;
            status = "native-edit-selection-cleanup-rejected";
        }
        capturePostCleanupDialogState();
        bool dialogLeftVisible = leaveDialogVisibleRequested &&
            postCleanupDialogCardinality_ == 1 &&
            postCleanupDialogMatches_ &&
            postCleanupDialogVisible_ &&
            postCleanupDialogRowCount_ == expectedRowCount_;
        if (leaveDialogVisibleRequested && !dialogLeftVisible) {
            queueFailureDialogCancel();
            status = "native-edit-dialog-lost-after-cleanup";
        }
        writeTextAtomically(outputPath_,
                            makeReport(status, dialogLeftVisible));
        gNativeMotionStudyDirectEditControllerActive = false;
        deleteLater();
    }

    void pollForDialog() {
        if (finished_) {
            return;
        }
        const auto dialogs = exactMotionStudyDialogs();
        if (dialogs.size() > 1) {
            finish("motion-study-dialog-cardinality-rejected", false);
            return;
        }
        if (dialogs.size() == 1) {
            dialog_ = dialogs.front();
            if (validateDialogCoherence(dialog_.data())) {
                finish("native-edit-dialog-visible", true);
                return;
            }
        }
        if (elapsedMs_ >= timeoutMs_) {
            finish(dialog_ == nullptr
                       ? "timeout-awaiting-native-edit-dialog"
                       : "native-edit-dialog-coherence-rejected",
                   false);
            return;
        }
        elapsedMs_ += pollIntervalMs_;
        QTimer::singleShot(pollIntervalMs_, this, [this]() {
            pollForDialog();
        });
    }

    std::string outputPath_;
    int expectedRowCount_;
    int expectedPointCount_;
    int pollIntervalMs_;
    int timeoutMs_;
    int elapsedMs_ = 0;
    std::string status_;
    std::string fusionVersion_;
    LoadedImage fusionXlayer_;
    LoadedImage nsBaseCore_;
    LoadedImage nsDataModel_;
    LoadedImage nsComponent_;
    LoadedImage nuClientBase_;
    LoadedImage naFusionUi_;
    std::array<bool, 6> imageUuidGates_{};
    std::array<bool, 22> prefixGates_{};
    ObjectPathConstruct objectPathConstruct_ = nullptr;
    ObjectPathDestroy objectPathDestroy_ = nullptr;
    InternalComponent internalComponent_ = nullptr;
    StrongRefGet strongRefGet_ = nullptr;
    StrongRefDestroy strongRefDestroy_ = nullptr;
    MotionStudiesCount motionStudiesCount_ = nullptr;
    ManagedChild managedChild_ = nullptr;
    ActiveSelectionSet activeSelectionSet_ = nullptr;
    SelectionMutation selectionAdd_ = nullptr;
    SelectionMutation selectionRemove_ = nullptr;
    SelectionContains selectionContains_ = nullptr;
    SelectionMotionStudy selectionMotionStudy_ = nullptr;
    LogicalSelectionSession logicalSelectionSession_ = nullptr;
    SessionSelection sessionSelection_ = nullptr;
    SessionSelectionManager sessionSelectionManager_ = nullptr;
    ActiveSessionSelectionManager activeSessionSelectionManager_ =
        nullptr;
    ManagerSelectionSet managerSelectionSet_ = nullptr;
    SelectionSessionState selectionSessionState_ = nullptr;
    DisplaySelectedSelection displaySelectedSelection_ = nullptr;
    void* managedObjectPath_ = nullptr;
    void* createSelection_ = nullptr;
    void* motionStudies_ = nullptr;
    void* motionStudy_ = nullptr;
    void* selection_ = nullptr;
    void* selectionSet_ = nullptr;
    void* selectionSession_ = nullptr;
    void* selectionSessionManager_ = nullptr;
    void* activeSessionSelectionManagerResolved_ = nullptr;
    void* managerSelectionSetResolved_ = nullptr;
    OpaqueObjectPath seedPath_;
    OpaqueObjectPath fullPath_;
    OpaqueStrongRef selectionHolder_;
    QPointer<QWidget> dialog_;
    std::string activeCommandBefore_;
    std::vector<int> curveReadbackCodes_;
    std::size_t motionStudyCount_ = 0;
    std::size_t observedMainGripCount_ = 0;
    std::size_t observedDependentGripCount_ = 0;
    std::size_t failureDialogCancelCandidates_ = 0;
    std::size_t failureDialogCancelDispatched_ = 0;
    std::size_t postCleanupDialogCardinality_ = 0;
    std::uint32_t selectionSessionStateValue_ = 0;
    int dialogRowCount_ = -1;
    int postCleanupDialogRowCount_ = -1;
    bool releaseMatches_ = false;
    bool selectCommandActiveBefore_ = false;
    bool rootComponentResolved_ = false;
    bool internalComponentResolved_ = false;
    bool motionStudiesVptrMatches_ = false;
    bool motionStudyVptrMatches_ = false;
    bool seedPathConstructed_ = false;
    bool fullPathConstructed_ = false;
    bool seedPathVptrMatches_ = false;
    bool fullPathVptrMatches_ = false;
    bool selectionHolderConstructed_ = false;
    bool selectionHolderDestroyed_ = false;
    bool selectionResolved_ = false;
    bool selectionSessionResolved_ = false;
    bool selectionSessionVptrMatches_ = false;
    bool sessionSelectionMatches_ = false;
    bool selectionSessionManagerResolved_ = false;
    bool selectionSessionManagerVptrMatches_ = false;
    bool activeSessionSelectionManagerVptrMatches_ = false;
    bool activeSessionSelectionManagerMatches_ = false;
    bool managerSelectionSetMatches_ = false;
    bool selectionSessionSelectedState_ = false;
    bool selectionSessionOptionalAbsent_ = false;
    bool displaySelectedSelectionRead_ = false;
    bool displaySelectedSelectionEnabled_ = false;
    bool selectionSessionCoherenceAccepted_ = false;
    bool selectionSessionBeforeCleanupRead_ = false;
    bool selectionSessionAbsentBeforeCleanup_ = false;
    bool selectionSessionCleanupPrecondition_ = false;
    bool selectionSessionAfterCleanupRead_ = false;
    bool selectionSessionAbsentAfterCleanup_ = false;
    bool selectionHolderDestroyDeferred_ = false;
    bool selectionVptrsMatch_ = false;
    bool selectionStudyMatches_ = false;
    bool selectionSetVptrMatches_ = false;
    bool selectionContainedBefore_ = false;
    bool selectionContainedAfterAdd_ = false;
    bool selectionAddAttempted_ = false;
    bool selectionAdded_ = false;
    bool selectionSetVptrMatchesAtCleanup_ = false;
    bool selectionContainedBeforeCleanup_ = false;
    bool selectionRemoved_ = false;
    bool selectionRemovedByControllerObserved_ = false;
    bool selectionConsumedByEditCommand_ = false;
    bool selectionAbsentAfterAsyncEditActivation_ = false;
    bool selectionCleanupAuthorityAccepted_ = false;
    bool selectionAbsentAtCleanupEnd_ = false;
    bool editCommandDefinitionFound_ = false;
    bool editCommandExecuted_ = false;
    bool selectionSetVptrMatchesAfterEditExecute_ = false;
    bool selectionContainmentAfterEditExecuteRead_ = false;
    bool selectionContainedAfterEditExecute_ = false;
    bool selectionSessionAfterEditExecuteRead_ = false;
    bool selectionSessionAbsentAfterEditExecute_ = false;
    bool editCommandVptrMatches_ = false;
    bool facadeCoherent_ = false;
    bool editStudyMatches_ = false;
    bool editPostActivated_ = false;
    bool curveReadbacksValid_ = false;
    bool curveCountsMatch_ = false;
    bool postCleanupDialogMatches_ = false;
    bool postCleanupDialogVisible_ = false;
    bool finished_ = false;
};

class NativeMotionStudyControlController final : public QObject {
public:
    NativeMotionStudyControlController(std::string action,
                                       std::string outputPath,
                                       int settleMs)
        : action_(std::move(action)),
          outputPath_(std::move(outputPath)),
          settleMs_(std::max(25, settleMs)) {}

    void start() {
        const auto dialogs = exactMotionStudyDialogs();
        dialogCardinality_ = dialogs.size();
        if (dialogs.size() != 1) {
            finish(dialogs.empty() ? "native-dialog-not-found"
                                   : "native-dialog-ambiguous");
            return;
        }
        dialog_ = dialogs.front();
        before_ = inspectNativeMotionStudyDialog(dialog_.data());

        if (action_ == "query") {
            actionAccepted_ = true;
            finish("state-queried");
            return;
        }

        if (action_ == "reveal-activate-app") {
            invokedMethod_ =
                "NSApplication::activateIgnoringOtherApps + "
                "QWindow::raise/requestActivate + "
                "NSWindow::orderFrontRegardless/"
                "makeKeyAndOrderFront";
            actionAccepted_ = revealActivateApplicationExactDialog();
            if (!actionAccepted_) {
                finish("application-reveal-rejected");
                return;
            }
        } else if (action_ == "reveal-active-space") {
            invokedMethod_ =
                "NSPanel::setCollectionBehavior(original|0x2) + "
                "QWindow::raise/requestActivate + "
                "NSWindow::orderFrontRegardless/"
                "makeKeyAndOrderFront + exact restore";
            actionAccepted_ = revealActiveSpaceExactDialog();
            if (!actionAccepted_) {
                finish("active-space-reveal-rejected");
                return;
            }
        } else if (action_ == "reveal-native") {
            invokedMethod_ =
                "QWindow::raise/requestActivate + "
                "NSWindow::orderFrontRegardless/"
                "makeKeyAndOrderFront";
            actionAccepted_ = revealNativeExactDialog();
            if (!actionAccepted_) {
                finish("native-window-reveal-rejected");
                return;
            }
        } else if (action_ == "reveal") {
            invokedMethod_ =
                "QWidget::show/showNormal/raise/activateWindow";
            actionAccepted_ = revealExactDialog();
            if (!actionAccepted_) {
                finish("native-dialog-reveal-rejected");
                return;
            }
        } else if (action_ == "mode-once" || action_ == "mode-loop" ||
            action_ == "mode-oscillate") {
            const auto modeButtons = orderedMotionStudyModeButtons(
                dialog_.data());
            const std::size_t index = action_ == "mode-once"
                                          ? 0
                                          : (action_ == "mode-loop" ? 1 : 2);
            if (modeButtons.size() != 3 || index >= modeButtons.size() ||
                modeButtons[index] == nullptr ||
                !modeButtons[index]->isEnabled()) {
                finish("native-mode-control-rejected");
                return;
            }
            invokedMethod_ = "QRadioButton::click";
            modeButtons[index]->click();
            actionAccepted_ = true;
        } else {
            const char* method = nullptr;
            if (action_ == "play") {
                method = "onPlay";
            } else if (action_ == "stop") {
                method = "onStop";
            } else if (action_ == "repeat") {
                method = "onRepeat";
            } else if (action_ == "move-start") {
                method = "onMoveToStart";
            } else if (action_ == "cancel") {
                method = "onDialogCancel";
            }
            if (method == nullptr) {
                finish("unsupported-action");
                return;
            }
            invokedMethod_ = method;
            actionAccepted_ = QMetaObject::invokeMethod(
                dialog_.data(), method, Qt::QueuedConnection);
            if (!actionAccepted_) {
                finish("native-slot-dispatch-rejected");
                return;
            }
        }

        QTimer::singleShot(settleMs_, this, [this]() {
            finish("native-control-dispatched");
        });
    }

private:
    static constexpr unsigned long long
        kCanJoinAllSpacesBehavior = 0x1ULL;
    static constexpr unsigned long long
        kMoveToActiveSpaceBehavior = 0x2ULL;
    static constexpr unsigned long long kTransientBehavior = 0x8ULL;

    static bool cgWindowEvidenceAuthoritative(
        const NativeCGWindowEvidence& evidence) noexcept {
        return evidence.querySucceeded && evidence.exactCardinality &&
            evidence.windowNumberPresent &&
            evidence.exactWindowNumber && evidence.ownerPidPresent &&
            evidence.ownerPidMatches && evidence.onscreenKeyPresent &&
            evidence.onscreenValueValid && evidence.onscreen;
    }

    bool nativeQtAssociationStable() const noexcept {
        QWidget* dialog = dialog_.data();
        QWidget* windowWidget = nativeWindowWidget_.data();
        QWindow* qWindow = nativeQWindow_.data();
        return dialog != nullptr && windowWidget != nullptr &&
            qWindow != nullptr && dialog->window() == windowWidget &&
            windowWidget->windowHandle() == qWindow &&
            qWindow->handle() != nullptr;
    }

    bool nativeEvidenceMatchesOriginal(
        const NativeCocoaWindowEvidence& evidence) const noexcept {
        return nativeQtAssociationStable() &&
            evidence.nativeViewValid && evidence.nativeWindowValid &&
            evidence.requiredSelectorsPresent &&
            evidence.applicationWindowMember &&
            evidence.nativeViewIdentity == nativeViewIdentity_ &&
            evidence.nativeWindowIdentity == nativeWindowIdentity_ &&
            evidence.windowNumber == nativeWindowNumber_;
    }

    bool activateOwningApplication() noexcept {
        try {
            if (!nativeQtAssociationStable()) {
                return false;
            }
            NativeCocoaWindowEvidence fresh =
                inspectExistingCocoaWindow(dialog_.data());
            if (!nativeEvidenceMatchesOriginal(fresh) ||
                !fresh.nativePanelValid) {
                return false;
            }
            if (fresh.applicationActive) {
                applicationActivationNotRequired_ = true;
                applicationActivationObservedImmediately_ = true;
                return true;
            }

            Class nsApplicationClass = reinterpret_cast<Class>(
                objc_getClass("NSApplication"));
            if (nsApplicationClass == Nil) {
                return false;
            }
            const SEL respondsToSelector =
                sel_registerName("respondsToSelector:");
            const SEL sharedApplication =
                sel_registerName("sharedApplication");
            const SEL activateIgnoringOtherApps =
                sel_registerName("activateIgnoringOtherApps:");
            id applicationClassObject =
                reinterpret_cast<id>(nsApplicationClass);
            if (!sendObjc<BOOL>(applicationClassObject,
                                respondsToSelector,
                                sharedApplication)) {
                return false;
            }
            id application = sendObjc<id>(applicationClassObject,
                                          sharedApplication);
            applicationActivationSelectorPresent_ =
                application != nil &&
                sendObjc<BOOL>(application, respondsToSelector,
                               activateIgnoringOtherApps);
            if (!applicationActivationSelectorPresent_) {
                return false;
            }

            applicationActivationCalled_ = true;
            sendObjc<void>(application, activateIgnoringOtherApps,
                           static_cast<BOOL>(true));
            if (!nativeQtAssociationStable()) {
                return false;
            }
            fresh = inspectExistingCocoaWindow(dialog_.data());
            applicationActivationObservedImmediately_ =
                nativeEvidenceMatchesOriginal(fresh) &&
                fresh.nativePanelValid && fresh.applicationActive;
            return nativeEvidenceMatchesOriginal(fresh) &&
                fresh.nativePanelValid;
        } catch (...) {
            return false;
        }
    }

    bool revealActivateApplicationExactDialog() noexcept {
        try {
            QWidget* dialog = dialog_.data();
            if (dialog == nullptr || !before_.privateStateReadable ||
                !isExactMotionStudyDialog(dialog) ||
                !before_.dialogWidget.visible) {
                return false;
            }
            nativeWindowWidget_ = QPointer<QWidget>(dialog->window());
            if (nativeWindowWidget_ == nullptr) {
                return false;
            }
            nativeQWindow_ = QPointer<QWindow>(
                nativeWindowWidget_->windowHandle());
            if (nativeQWindow_ == nullptr ||
                nativeQWindow_->handle() == nullptr) {
                return false;
            }
            applicationRevealBefore_ =
                inspectExistingCocoaWindow(dialog);
            nativeBefore_ = applicationRevealBefore_;
            if (!applicationRevealBefore_.platformCocoa ||
                !applicationRevealBefore_.nativeViewValid ||
                !applicationRevealBefore_.nativeWindowValid ||
                !applicationRevealBefore_.nativePanelValid ||
                !applicationRevealBefore_.requiredSelectorsPresent ||
                !applicationRevealBefore_.applicationWindowMember ||
                applicationRevealBefore_.nativeViewIdentity == 0 ||
                applicationRevealBefore_.nativeWindowIdentity == 0 ||
                applicationRevealBefore_.windowNumber <= 0 ||
                !applicationRevealBefore_.qWindowVisible ||
                applicationRevealBefore_.miniaturized ||
                !applicationRevealBefore_.canBecomeKeyWindow ||
                !applicationRevealBefore_.onActiveSpace ||
                (applicationRevealBefore_.collectionBehavior &
                 kMoveToActiveSpaceBehavior) == 0) {
                return false;
            }
            nativeWindowIdentity_ =
                applicationRevealBefore_.nativeWindowIdentity;
            nativeViewIdentity_ =
                applicationRevealBefore_.nativeViewIdentity;
            nativeWindowNumber_ =
                applicationRevealBefore_.windowNumber;
            applicationRevealCGBefore_ = inspectCGWindow(
                nativeWindowNumber_);

            if (!activateOwningApplication()) {
                return false;
            }
            const bool nativeRevealAccepted =
                revealNativeExactDialog(true);
            nativeBefore_ = applicationRevealBefore_;
            return nativeRevealAccepted;
        } catch (...) {
            return false;
        }
    }

    bool restoreActiveSpaceCollectionBehaviorBestEffort() noexcept {
        if (!activeSpaceCleanupArmed_) {
            activeSpaceRestorationNotRequired_ =
                !activeSpaceRestorationRequired_;
            return !activeSpaceRestorationRequired_ ||
                activeSpaceRestorationSucceeded_;
        }
        activeSpaceRestorationAttempted_ = true;
        ++activeSpaceRestorationAttemptCount_;
        try {
            if (!nativeQtAssociationStable()) {
                return false;
            }
            NativeCocoaWindowEvidence fresh =
                inspectExistingCocoaWindow(dialog_.data());
            if (!nativeEvidenceMatchesOriginal(fresh) ||
                !fresh.nativePanelValid) {
                return false;
            }
            if (fresh.collectionBehavior ==
                activeSpaceOriginalBehavior_) {
                activeSpaceAfterRestore_ = fresh;
                activeSpaceRestorationSucceeded_ = true;
                activeSpaceCleanupArmed_ = false;
                return true;
            }
            if (fresh.collectionBehavior !=
                activeSpaceDesiredBehavior_) {
                activeSpaceRestorationConcurrentBehaviorMismatch_ =
                    true;
                if ((fresh.collectionBehavior &
                     kMoveToActiveSpaceBehavior) == 0) {
                    activeSpaceAfterRestore_ = fresh;
                    activeSpaceCleanupArmed_ = false;
                    return false;
                }
                activeSpaceRestorationMaskedCleanupAttempted_ = true;
                activeSpaceRestorationSetterCalled_ = true;
                id currentWindow = reinterpret_cast<id>(
                    fresh.nativeWindowIdentity);
                const unsigned long long cleanupBehavior =
                    fresh.collectionBehavior &
                    ~kMoveToActiveSpaceBehavior;
                sendObjc<void>(
                    currentWindow,
                    sel_registerName("setCollectionBehavior:"),
                    static_cast<unsigned long>(cleanupBehavior));
                if (!nativeQtAssociationStable()) {
                    return false;
                }
                activeSpaceAfterRestore_ =
                    inspectExistingCocoaWindow(dialog_.data());
                activeSpaceRestorationMaskedCleanupSucceeded_ =
                    nativeEvidenceMatchesOriginal(
                        activeSpaceAfterRestore_) &&
                    activeSpaceAfterRestore_.nativePanelValid &&
                    (activeSpaceAfterRestore_.collectionBehavior &
                     kMoveToActiveSpaceBehavior) == 0;
                if (activeSpaceRestorationMaskedCleanupSucceeded_) {
                    activeSpaceCleanupArmed_ = false;
                }
                activeSpaceRestorationSucceeded_ =
                    activeSpaceRestorationMaskedCleanupSucceeded_ &&
                    activeSpaceAfterRestore_.collectionBehavior ==
                        activeSpaceOriginalBehavior_;
                return activeSpaceRestorationSucceeded_;
            }
            activeSpaceRestorationSetterCalled_ = true;
            id currentWindow = reinterpret_cast<id>(
                fresh.nativeWindowIdentity);
            sendObjc<void>(
                currentWindow,
                sel_registerName("setCollectionBehavior:"),
                static_cast<unsigned long>(
                    activeSpaceOriginalBehavior_));

            if (!nativeQtAssociationStable()) {
                return false;
            }
            activeSpaceAfterRestore_ = inspectExistingCocoaWindow(
                dialog_.data());
            activeSpaceRestorationSucceeded_ =
                nativeEvidenceMatchesOriginal(
                    activeSpaceAfterRestore_) &&
                activeSpaceAfterRestore_.nativePanelValid &&
                activeSpaceAfterRestore_.collectionBehavior ==
                    activeSpaceOriginalBehavior_;
            if (activeSpaceRestorationSucceeded_) {
                activeSpaceCleanupArmed_ = false;
            }
            return activeSpaceRestorationSucceeded_;
        } catch (...) {
            return false;
        }
    }

    bool revealActiveSpaceExactDialog() noexcept {
        bool accepted = false;
        try {
            do {
                QWidget* dialog = dialog_.data();
                if (dialog == nullptr || !before_.privateStateReadable ||
                    !isExactMotionStudyDialog(dialog) ||
                    !before_.dialogWidget.visible) {
                    break;
                }
                nativeWindowWidget_ = QPointer<QWidget>(dialog->window());
                if (nativeWindowWidget_ == nullptr) {
                    break;
                }
                nativeQWindow_ = QPointer<QWindow>(
                    nativeWindowWidget_->windowHandle());
                if (nativeQWindow_ == nullptr ||
                    nativeQWindow_->handle() == nullptr) {
                    break;
                }
                activeSpaceBefore_ = inspectExistingCocoaWindow(dialog);
                nativeBefore_ = activeSpaceBefore_;
                if (!activeSpaceBefore_.platformCocoa ||
                    !activeSpaceBefore_.nativeViewValid ||
                    !activeSpaceBefore_.nativeWindowValid ||
                    !activeSpaceBefore_.nativePanelValid ||
                    !activeSpaceBefore_.requiredSelectorsPresent ||
                    !activeSpaceBefore_.applicationWindowMember ||
                    activeSpaceBefore_.nativeViewIdentity == 0 ||
                    activeSpaceBefore_.nativeWindowIdentity == 0 ||
                    activeSpaceBefore_.windowNumber <= 0 ||
                    !activeSpaceBefore_.qWindowVisible ||
                    activeSpaceBefore_.miniaturized ||
                    !activeSpaceBefore_.canBecomeKeyWindow) {
                    break;
                }
                nativeWindowIdentity_ =
                    activeSpaceBefore_.nativeWindowIdentity;
                nativeViewIdentity_ =
                    activeSpaceBefore_.nativeViewIdentity;
                nativeWindowNumber_ = activeSpaceBefore_.windowNumber;
                activeSpaceCGBefore_ = inspectCGWindow(
                    nativeWindowNumber_);
                activeSpaceOriginalBehavior_ =
                    activeSpaceBefore_.collectionBehavior;
                activeSpaceDesiredBehavior_ =
                    activeSpaceOriginalBehavior_ |
                    kMoveToActiveSpaceBehavior;
                activeSpaceInitiallyOnActiveSpace_ =
                    activeSpaceBefore_.onActiveSpace;
                activeSpaceCanJoinAllSpacesConflict_ =
                    (activeSpaceOriginalBehavior_ &
                     kCanJoinAllSpacesBehavior) != 0;
                activeSpaceMoveAlreadyPresent_ =
                    (activeSpaceOriginalBehavior_ &
                     kMoveToActiveSpaceBehavior) != 0;
                activeSpaceTransientPresent_ =
                    (activeSpaceOriginalBehavior_ &
                     kTransientBehavior) != 0;
                activeSpaceMoveRequested_ =
                    !activeSpaceInitiallyOnActiveSpace_;
                if (!activeSpaceTransientPresent_ ||
                    activeSpaceCanJoinAllSpacesConflict_) {
                    break;
                }

                if (activeSpaceMoveRequested_ &&
                    !activeSpaceMoveAlreadyPresent_) {
                    NativeCocoaWindowEvidence fresh =
                        inspectExistingCocoaWindow(dialog_.data());
                    if (!nativeEvidenceMatchesOriginal(fresh) ||
                        !fresh.nativePanelValid ||
                        fresh.collectionBehavior !=
                            activeSpaceOriginalBehavior_) {
                        break;
                    }

                    // Arm exact restoration before the first flag setter.
                    activeSpaceRestorationRequired_ = true;
                    activeSpaceCleanupArmed_ = true;
                    activeSpaceCollectionBehaviorWriteAttempted_ = true;
                    id currentWindow = reinterpret_cast<id>(
                        fresh.nativeWindowIdentity);
                    sendObjc<void>(
                        currentWindow,
                        sel_registerName("setCollectionBehavior:"),
                        static_cast<unsigned long>(
                            activeSpaceDesiredBehavior_));

                    if (!nativeQtAssociationStable()) {
                        break;
                    }
                    activeSpaceApplied_ =
                        inspectExistingCocoaWindow(dialog_.data());
                    activeSpaceCollectionBehaviorWriteObserved_ =
                        nativeEvidenceMatchesOriginal(
                            activeSpaceApplied_) &&
                        activeSpaceApplied_.nativePanelValid &&
                        activeSpaceApplied_.collectionBehavior ==
                            activeSpaceDesiredBehavior_;
                    if (!activeSpaceCollectionBehaviorWriteObserved_) {
                        break;
                    }
                    activeSpaceCollectionBehaviorApplied_ = true;
                } else {
                    activeSpaceRestorationNotRequired_ = true;
                    activeSpaceApplied_ = activeSpaceBefore_;
                }

                const bool nativeRevealAccepted =
                    revealNativeExactDialog(true);
                nativeBefore_ = activeSpaceBefore_;
                if (!nativeRevealAccepted) {
                    break;
                }
                accepted = true;
            } while (false);
        } catch (...) {
            accepted = false;
        }
        if (!accepted && activeSpaceCleanupArmed_) {
            restoreActiveSpaceCollectionBehaviorBestEffort();
        }
        return accepted;
    }

    bool revealNativeExactDialog(
        bool preserveBoundIdentity = false) noexcept {
        try {
            QWidget* dialog = dialog_.data();
            if (dialog == nullptr || !before_.privateStateReadable ||
                !isExactMotionStudyDialog(dialog) ||
                !before_.dialogWidget.visible) {
                return false;
            }
            if (preserveBoundIdentity) {
                if (!nativeQtAssociationStable()) {
                    return false;
                }
            } else {
                nativeWindowWidget_ = QPointer<QWidget>(
                    dialog->window());
                if (nativeWindowWidget_ == nullptr) {
                    return false;
                }
                QWindow* qWindow =
                    nativeWindowWidget_->windowHandle();
                nativeQWindow_ = QPointer<QWindow>(qWindow);
                if (nativeQWindow_ == nullptr ||
                    nativeQWindow_->handle() == nullptr) {
                    return false;
                }
            }
            nativeBefore_ = inspectExistingCocoaWindow(dialog_.data());
            if (!nativeBefore_.platformCocoa ||
                !nativeBefore_.nativeViewValid ||
                !nativeBefore_.nativeWindowValid ||
                !nativeBefore_.nativePanelValid ||
                !nativeBefore_.requiredSelectorsPresent ||
                !nativeBefore_.applicationWindowMember ||
                nativeBefore_.nativeWindowIdentity == 0 ||
                !nativeBefore_.qWindowVisible ||
                nativeBefore_.miniaturized ||
                !nativeBefore_.canBecomeKeyWindow) {
                return false;
            }
            if (preserveBoundIdentity) {
                if (!nativeEvidenceMatchesOriginal(nativeBefore_)) {
                    return false;
                }
            } else {
                nativeWindowIdentity_ =
                    nativeBefore_.nativeWindowIdentity;
                nativeViewIdentity_ = nativeBefore_.nativeViewIdentity;
                nativeWindowNumber_ = nativeBefore_.windowNumber;
            }

            nativeQWindow_->raise();
            ++nativeQtRaiseCount_;
            if (!nativeQtAssociationStable()) {
                return false;
            }
            nativeQWindow_->requestActivate();
            ++nativeQtActivateCount_;
            if (!nativeQtAssociationStable()) {
                return false;
            }

            NativeCocoaWindowEvidence fresh =
                inspectExistingCocoaWindow(dialog_.data());
            nativeIdentityStableAfterQtRequest_ =
                nativeEvidenceMatchesOriginal(fresh);
            if (!nativeIdentityStableAfterQtRequest_) {
                return false;
            }
            id nativeWindow = reinterpret_cast<id>(
                fresh.nativeWindowIdentity);
            sendObjc<void>(nativeWindow,
                           sel_registerName("orderFrontRegardless"));
            ++nativeOrderFrontCount_;
            if (!nativeQtAssociationStable()) {
                return false;
            }

            fresh = inspectExistingCocoaWindow(dialog_.data());
            nativeIdentityStableAfterOrderFront_ =
                nativeEvidenceMatchesOriginal(fresh);
            if (!nativeIdentityStableAfterOrderFront_) {
                return false;
            }
            nativeWindow = reinterpret_cast<id>(
                fresh.nativeWindowIdentity);
            sendObjc<void>(nativeWindow,
                           sel_registerName("makeKeyAndOrderFront:"),
                           static_cast<id>(nil));
            ++nativeMakeKeyCount_;
            if (!nativeQtAssociationStable()) {
                return false;
            }

            fresh = inspectExistingCocoaWindow(dialog_.data());
            nativeIdentityStableAfterMakeKey_ =
                nativeEvidenceMatchesOriginal(fresh);
            if (!nativeIdentityStableAfterMakeKey_) {
                return false;
            }
            nativeQWindow_->requestActivate();
            ++nativeQtActivateCount_;
            if (!nativeQtAssociationStable()) {
                return false;
            }
            fresh = inspectExistingCocoaWindow(dialog_.data());
            nativeIdentityStableAfterFinalQtRequest_ =
                nativeEvidenceMatchesOriginal(fresh);
            nativeRevealDispatched_ =
                nativeIdentityStableAfterFinalQtRequest_;
            return nativeRevealDispatched_;
        } catch (...) {
            return false;
        }
    }

    bool revealExactDialog() noexcept {
        try {
            QWidget* dialog = dialog_.data();
            if (dialog == nullptr || !before_.privateStateReadable ||
                !isExactMotionStudyDialog(dialog)) {
                return false;
            }

            std::vector<QWidget*> visited = {dialog};
            QWidget* parent = dialog->parentWidget();
            for (int depth = 0; parent != nullptr && depth < 32;
                 ++depth) {
                if (std::find(visited.begin(), visited.end(), parent) !=
                    visited.end()) {
                    revealHierarchyCycleDetected_ = true;
                    return false;
                }
                visited.push_back(parent);
                revealParentChain_.push_back(QPointer<QWidget>(parent));
                parent = parent->parentWidget();
            }
            revealHierarchyBounded_ = parent == nullptr;
            if (!revealHierarchyBounded_) {
                return false;
            }
            revealWindow_ = QPointer<QWidget>(dialog->window());
            if (revealWindow_ == nullptr) {
                return false;
            }

            std::vector<QPointer<QWidget>> acted;
            const auto revealWidget = [this, &acted](QWidget* widget) {
                QPointer<QWidget> guard(widget);
                if (guard == nullptr) {
                    return false;
                }
                const bool alreadyActed = std::any_of(
                    acted.begin(), acted.end(),
                    [&guard](const QPointer<QWidget>& existing) {
                        return existing.data() == guard.data();
                    });
                if (alreadyActed) {
                    return true;
                }
                acted.push_back(guard);
                if (guard->isMinimized()) {
                    guard->showNormal();
                    ++revealShowCount_;
                    if (guard == nullptr) {
                        return false;
                    }
                } else if (guard->isHidden()) {
                    guard->show();
                    ++revealShowCount_;
                    if (guard == nullptr) {
                        return false;
                    }
                }
                guard->raise();
                ++revealRaiseCount_;
                if (guard == nullptr) {
                    return false;
                }
                guard->activateWindow();
                ++revealActivateCount_;
                return guard != nullptr;
            };

            for (auto it = revealParentChain_.rbegin();
                 it != revealParentChain_.rend(); ++it) {
                QWidget* ancestor = it->data();
                if (ancestor == nullptr) {
                    return false;
                }
                if (ancestor->isWindow() &&
                    !revealWidget(ancestor)) {
                    return false;
                }
            }
            QWidget* containingWindow = revealWindow_.data();
            if (containingWindow != dialog_.data() &&
                !revealWidget(containingWindow)) {
                return false;
            }
            if (!revealWidget(dialog_.data())) {
                return false;
            }
            revealDispatched_ = true;
            return true;
        } catch (...) {
            return false;
        }
    }

    bool revealHierarchyStable() const noexcept {
        try {
            QWidget* dialog = dialog_.data();
            if (dialog == nullptr || dialog->window() !=
                    revealWindow_.data()) {
                return false;
            }
            QWidget* parent = dialog->parentWidget();
            for (const QPointer<QWidget>& expected :
                 revealParentChain_) {
                if (parent == nullptr || parent != expected.data()) {
                    return false;
                }
                parent = parent->parentWidget();
            }
            return parent == nullptr;
        } catch (...) {
            return false;
        }
    }

    std::string makeReport(const char* status) const {
        std::ostringstream output;
        output
            << "{\"schema\":\"cad-agent.motion-study-native-control.v1\""
            << ",\"status\":" << quoted(std::string(status))
            << ",\"qt_version\":" << quoted(std::string(qVersion()))
            << ",\"main_thread\":"
            << jsonBool(QCoreApplication::instance() != nullptr &&
                        QCoreApplication::instance()->thread() ==
                            QThread::currentThread())
            << ",\"mouse_input_used\":false"
            << ",\"keyboard_input_used\":false"
            << ",\"input_synthesis_used\":false"
            << ",\"model_write_requested\":false"
            << ",\"geometry_write_requested\":false"
            << ",\"window_flags_write_requested\":"
            << jsonBool(
                   activeSpaceCollectionBehaviorWriteAttempted_ ||
                   activeSpaceRestorationSetterCalled_)
            << ",\"application_activation_selector_present\":"
            << jsonBool(applicationActivationSelectorPresent_)
            << ",\"application_activation_called\":"
            << jsonBool(applicationActivationCalled_)
            << ",\"application_activation_not_required\":"
            << jsonBool(applicationActivationNotRequired_)
            << ",\"application_activation_observed_immediately\":"
            << jsonBool(
                   applicationActivationObservedImmediately_)
            << ",\"application_reveal_observed\":"
            << jsonBool(applicationRevealObserved_)
            << ",\"reparent_requested\":false"
            << ",\"event_injection_used\":false"
            << ",\"native_ui_left_visible\":"
            << jsonBool(action_ != "cancel" &&
                        dialogSameAfter_ && after_.exact &&
                        after_.dialogWidget.visible)
            << ",\"curve_write_requested\":false"
            << ",\"transient_motion_preview\":"
            << jsonBool(action_ == "play" || action_ == "repeat" ||
                        action_ == "stop" || action_ == "move-start")
            << ",\"requested_action\":" << quoted(action_)
            << ",\"invoked_method\":" << quoted(invokedMethod_)
            << ",\"action_accepted\":" << jsonBool(actionAccepted_)
            << ",\"dialog_cardinality_before\":"
            << dialogCardinality_
            << ",\"dialog_cardinality_after\":"
            << dialogCardinalityAfter_
            << ",\"dialog_same_after\":"
            << jsonBool(dialogSameAfter_)
            << ",\"settle_ms\":" << settleMs_
            << ",\"reveal_dispatched\":"
            << jsonBool(revealDispatched_)
            << ",\"reveal_hierarchy_depth\":"
            << revealParentChain_.size()
            << ",\"reveal_hierarchy_bounded\":"
            << jsonBool(revealHierarchyBounded_)
            << ",\"reveal_hierarchy_cycle_detected\":"
            << jsonBool(revealHierarchyCycleDetected_)
            << ",\"reveal_hierarchy_stable_after\":"
            << jsonBool(revealHierarchyStableAfter_)
            << ",\"reveal_show_count\":" << revealShowCount_
            << ",\"reveal_raise_count\":" << revealRaiseCount_
            << ",\"reveal_activate_count\":"
            << revealActivateCount_
            << ",\"reveal_observed\":"
            << jsonBool(revealObserved_)
            << ",\"native_reveal_dispatched\":"
            << jsonBool(nativeRevealDispatched_)
            << ",\"native_qt_raise_count\":"
            << nativeQtRaiseCount_
            << ",\"native_qt_activate_count\":"
            << nativeQtActivateCount_
            << ",\"native_order_front_count\":"
            << nativeOrderFrontCount_
            << ",\"native_make_key_count\":"
            << nativeMakeKeyCount_
            << ",\"native_identity_stable_after_qt_request\":"
            << jsonBool(nativeIdentityStableAfterQtRequest_)
            << ",\"native_identity_stable_after_order_front\":"
            << jsonBool(nativeIdentityStableAfterOrderFront_)
            << ",\"native_identity_stable_after_make_key\":"
            << jsonBool(nativeIdentityStableAfterMakeKey_)
            << ",\"native_identity_stable_after_final_qt_request\":"
            << jsonBool(nativeIdentityStableAfterFinalQtRequest_)
            << ",\"native_qwindow_same_after\":"
            << jsonBool(nativeQWindowSameAfter_)
            << ",\"native_window_identity_same_after\":"
            << jsonBool(nativeWindowIdentitySameAfter_)
            << ",\"native_view_identity_same_after\":"
            << jsonBool(nativeViewIdentitySameAfter_)
            << ",\"native_window_number_same_after\":"
            << jsonBool(nativeWindowNumberSameAfter_)
            << ",\"native_reveal_observed\":"
            << jsonBool(nativeRevealObserved_)
            << ",\"active_space_move_requested\":"
            << jsonBool(activeSpaceMoveRequested_)
            << ",\"active_space_initially_on_active_space\":"
            << jsonBool(activeSpaceInitiallyOnActiveSpace_)
            << ",\"active_space_move_already_present\":"
            << jsonBool(activeSpaceMoveAlreadyPresent_)
            << ",\"active_space_can_join_all_spaces_conflict\":"
            << jsonBool(activeSpaceCanJoinAllSpacesConflict_)
            << ",\"active_space_transient_present\":"
            << jsonBool(activeSpaceTransientPresent_)
            << ",\"active_space_original_collection_behavior\":"
            << activeSpaceOriginalBehavior_
            << ",\"active_space_desired_collection_behavior\":"
            << activeSpaceDesiredBehavior_
            << ",\"active_space_collection_behavior_write_attempted\":"
            << jsonBool(activeSpaceCollectionBehaviorWriteAttempted_)
            << ",\"active_space_collection_behavior_write_observed\":"
            << jsonBool(activeSpaceCollectionBehaviorWriteObserved_)
            << ",\"active_space_collection_behavior_applied\":"
            << jsonBool(activeSpaceCollectionBehaviorApplied_)
            << ",\"active_space_restoration_required\":"
            << jsonBool(activeSpaceRestorationRequired_)
            << ",\"active_space_restoration_not_required\":"
            << jsonBool(activeSpaceRestorationNotRequired_)
            << ",\"active_space_restoration_attempted\":"
            << jsonBool(activeSpaceRestorationAttempted_)
            << ",\"active_space_restoration_attempt_count\":"
            << activeSpaceRestorationAttemptCount_
            << ",\"active_space_restoration_setter_called\":"
            << jsonBool(activeSpaceRestorationSetterCalled_)
            << ",\"active_space_restoration_concurrent_behavior_mismatch\":"
            << jsonBool(
                   activeSpaceRestorationConcurrentBehaviorMismatch_)
            << ",\"active_space_restoration_masked_cleanup_attempted\":"
            << jsonBool(
                   activeSpaceRestorationMaskedCleanupAttempted_)
            << ",\"active_space_restoration_masked_cleanup_succeeded\":"
            << jsonBool(
                   activeSpaceRestorationMaskedCleanupSucceeded_)
            << ",\"active_space_restoration_succeeded\":"
            << jsonBool(activeSpaceRestorationSucceeded_)
            << ",\"active_space_observed_before_restore\":"
            << jsonBool(activeSpaceObservedBeforeRestore_)
            << ",\"active_space_reveal_observed\":"
            << jsonBool(activeSpaceRevealObserved_)
            << ",\"native_before\":";
        appendNativeCocoaWindowEvidence(output, nativeBefore_);
        output << ",\"native_after\":";
        appendNativeCocoaWindowEvidence(output, nativeAfter_);
        output << ",\"application_reveal_before\":";
        appendNativeCocoaWindowEvidence(output,
                                        applicationRevealBefore_);
        output << ",\"application_reveal_after\":";
        appendNativeCocoaWindowEvidence(output,
                                        applicationRevealAfter_);
        output << ",\"application_reveal_cg_before\":";
        appendNativeCGWindowEvidence(output,
                                     applicationRevealCGBefore_);
        output << ",\"application_reveal_cg_after\":";
        appendNativeCGWindowEvidence(output,
                                     applicationRevealCGAfter_);
        output << ",\"active_space_before\":";
        appendNativeCocoaWindowEvidence(output, activeSpaceBefore_);
        output << ",\"active_space_applied\":";
        appendNativeCocoaWindowEvidence(output, activeSpaceApplied_);
        output << ",\"active_space_after_before_restore\":";
        appendNativeCocoaWindowEvidence(output, activeSpaceAfter_);
        output << ",\"active_space_after_restore\":";
        appendNativeCocoaWindowEvidence(output, activeSpaceAfterRestore_);
        output << ",\"active_space_cg_before\":";
        appendNativeCGWindowEvidence(output, activeSpaceCGBefore_);
        output << ",\"active_space_cg_after_before_restore\":";
        appendNativeCGWindowEvidence(output, activeSpaceCGAfter_);
        output << ",\"active_space_cg_after_restore\":";
        appendNativeCGWindowEvidence(output,
                                     activeSpaceCGAfterRestore_);
        output
            << ",\"before\":";
        appendNativeMotionStudyDialogState(output, before_);
        output << ",\"after\":";
        appendNativeMotionStudyDialogState(output, after_);
        output << "}\n";
        return output.str();
    }

    void finish(const char* status) {
        const auto dialogs = exactMotionStudyDialogs();
        dialogCardinalityAfter_ = dialogs.size();
        if (dialogs.size() == 1) {
            dialogSameAfter_ = dialogs.front() == dialog_.data();
            after_ = inspectNativeMotionStudyDialog(dialogs.front());
        } else {
            after_ = inspectNativeMotionStudyDialog(nullptr);
        }
        if (action_ == "reveal") {
            revealHierarchyStableAfter_ = dialogSameAfter_ &&
                revealHierarchyStable();
            revealObserved_ = revealDispatched_ &&
                dialogCardinalityAfter_ == 1 && dialogSameAfter_ &&
                after_.exact && after_.dialogWidget.visible &&
                after_.dialogWidget.intersectsScreen &&
                (after_.dialogWidget.activeWindow ||
                 after_.containingWindow.activeWindow) &&
                revealHierarchyStableAfter_;
            if (!revealObserved_) {
                status = "native-dialog-reveal-not-observed";
            } else {
                status = "native-dialog-reveal-observed";
            }
        } else if (action_ == "reveal-activate-app") {
            QWidget* dialog = dialog_.data();
            nativeQWindowSameAfter_ = dialogSameAfter_ &&
                nativeQtAssociationStable();
            applicationRevealAfter_ = dialogSameAfter_
                ? inspectExistingCocoaWindow(dialog)
                : NativeCocoaWindowEvidence{};
            applicationRevealCGAfter_ = inspectCGWindow(
                nativeWindowNumber_);
            nativeAfter_ = applicationRevealAfter_;
            nativeWindowIdentitySameAfter_ =
                nativeAfter_.nativeWindowValid &&
                nativeAfter_.nativeWindowIdentity ==
                    nativeWindowIdentity_;
            nativeViewIdentitySameAfter_ =
                nativeAfter_.nativeViewValid &&
                nativeAfter_.nativeViewIdentity ==
                    nativeViewIdentity_;
            nativeWindowNumberSameAfter_ =
                nativeAfter_.windowNumber == nativeWindowNumber_;
            applicationRevealObserved_ = actionAccepted_ &&
                nativeRevealDispatched_ &&
                dialogCardinalityAfter_ == 1 && dialogSameAfter_ &&
                after_.exact && nativeQWindowSameAfter_ &&
                nativeEvidenceMatchesOriginal(nativeAfter_) &&
                nativeAfter_.nativePanelValid &&
                nativeAfter_.applicationWindowMember &&
                nativeAfter_.applicationActive &&
                nativeAfter_.onActiveSpace &&
                nativeAfter_.visible && nativeAfter_.keyWindow &&
                !nativeAfter_.miniaturized &&
                nativeAfter_.qWindowActive &&
                nativeAfter_.qWindowExposed &&
                cgWindowEvidenceAuthoritative(
                    applicationRevealCGAfter_);
            nativeRevealObserved_ = applicationRevealObserved_;
            if (actionAccepted_) {
                status = applicationRevealObserved_
                    ? "application-reveal-observed"
                    : "application-reveal-not-observed";
            }
        } else if (action_ == "reveal-active-space") {
            QWidget* dialog = dialog_.data();
            nativeQWindowSameAfter_ = dialogSameAfter_ &&
                nativeQtAssociationStable();
            activeSpaceAfter_ = dialogSameAfter_
                ? inspectExistingCocoaWindow(dialog)
                : NativeCocoaWindowEvidence{};
            activeSpaceCGAfter_ = inspectCGWindow(
                nativeWindowNumber_);
            const unsigned long long expectedBeforeRestore =
                activeSpaceCollectionBehaviorApplied_
                ? activeSpaceDesiredBehavior_
                : activeSpaceOriginalBehavior_;
            activeSpaceObservedBeforeRestore_ = actionAccepted_ &&
                nativeRevealDispatched_ &&
                dialogCardinalityAfter_ == 1 && dialogSameAfter_ &&
                after_.exact && nativeQWindowSameAfter_ &&
                nativeEvidenceMatchesOriginal(activeSpaceAfter_) &&
                activeSpaceAfter_.nativePanelValid &&
                activeSpaceAfter_.collectionBehavior ==
                    expectedBeforeRestore &&
                activeSpaceAfter_.applicationWindowMember &&
                activeSpaceAfter_.applicationActive &&
                activeSpaceAfter_.onActiveSpace &&
                activeSpaceAfter_.visible &&
                activeSpaceAfter_.keyWindow &&
                !activeSpaceAfter_.miniaturized &&
                activeSpaceAfter_.qWindowActive &&
                activeSpaceAfter_.qWindowExposed &&
                cgWindowEvidenceAuthoritative(activeSpaceCGAfter_);

            if (activeSpaceCleanupArmed_) {
                restoreActiveSpaceCollectionBehaviorBestEffort();
            } else if (!activeSpaceRestorationRequired_) {
                activeSpaceRestorationNotRequired_ = true;
            }
            activeSpaceAfterRestore_ = dialogSameAfter_
                ? inspectExistingCocoaWindow(dialog)
                : NativeCocoaWindowEvidence{};
            activeSpaceCGAfterRestore_ = inspectCGWindow(
                nativeWindowNumber_);
            const bool restorationExact =
                activeSpaceAfterRestore_.collectionBehavior ==
                    activeSpaceOriginalBehavior_ &&
                (activeSpaceRestorationNotRequired_ ||
                 activeSpaceRestorationSucceeded_);
            nativeAfter_ = activeSpaceAfterRestore_;
            nativeWindowIdentitySameAfter_ =
                nativeAfter_.nativeWindowValid &&
                nativeAfter_.nativeWindowIdentity ==
                    nativeWindowIdentity_;
            nativeViewIdentitySameAfter_ =
                nativeAfter_.nativeViewValid &&
                nativeAfter_.nativeViewIdentity ==
                    nativeViewIdentity_;
            nativeWindowNumberSameAfter_ =
                nativeAfter_.windowNumber == nativeWindowNumber_;
            activeSpaceRevealObserved_ =
                activeSpaceObservedBeforeRestore_ &&
                restorationExact &&
                nativeEvidenceMatchesOriginal(nativeAfter_) &&
                nativeAfter_.nativePanelValid &&
                nativeAfter_.applicationWindowMember &&
                nativeAfter_.applicationActive &&
                nativeAfter_.onActiveSpace &&
                nativeAfter_.visible && nativeAfter_.keyWindow &&
                !nativeAfter_.miniaturized &&
                nativeAfter_.qWindowActive &&
                nativeAfter_.qWindowExposed &&
                cgWindowEvidenceAuthoritative(
                    activeSpaceCGAfterRestore_);
            nativeRevealObserved_ = activeSpaceRevealObserved_;
            if (actionAccepted_) {
                status = activeSpaceRevealObserved_
                    ? "active-space-reveal-observed"
                    : "active-space-reveal-not-observed";
            }
        } else if (action_ == "reveal-native") {
            QWidget* dialog = dialog_.data();
            nativeQWindowSameAfter_ = dialogSameAfter_ &&
                nativeQtAssociationStable();
            nativeAfter_ = dialogSameAfter_
                ? inspectExistingCocoaWindow(dialog)
                : NativeCocoaWindowEvidence{};
            nativeWindowIdentitySameAfter_ =
                nativeAfter_.nativeWindowValid &&
                nativeAfter_.nativeWindowIdentity ==
                    nativeWindowIdentity_;
            nativeViewIdentitySameAfter_ =
                nativeAfter_.nativeViewValid &&
                nativeAfter_.nativeViewIdentity ==
                    nativeViewIdentity_;
            nativeWindowNumberSameAfter_ =
                nativeAfter_.windowNumber == nativeWindowNumber_;
            nativeRevealObserved_ = nativeRevealDispatched_ &&
                dialogCardinalityAfter_ == 1 && dialogSameAfter_ &&
                after_.exact && nativeQWindowSameAfter_ &&
                nativeWindowIdentitySameAfter_ &&
                nativeViewIdentitySameAfter_ &&
                nativeWindowNumberSameAfter_ &&
                nativeAfter_.applicationWindowMember &&
                nativeAfter_.visible && nativeAfter_.keyWindow &&
                !nativeAfter_.miniaturized &&
                (nativeAfter_.qWindowExposed ||
                 after_.dialogWidget.intersectsScreen) &&
                (nativeAfter_.qWindowActive ||
                 after_.dialogWidget.activeWindow);
            status = nativeRevealObserved_
                ? "native-window-reveal-observed"
                : "native-window-reveal-not-observed";
        }
        writeTextAtomically(outputPath_, makeReport(status));
        gNativeMotionStudyControlControllerActive = false;
        deleteLater();
    }

    std::string action_;
    std::string outputPath_;
    int settleMs_;
    QPointer<QWidget> dialog_;
    QPointer<QWidget> revealWindow_;
    QPointer<QWidget> nativeWindowWidget_;
    QPointer<QWindow> nativeQWindow_;
    std::vector<QPointer<QWidget>> revealParentChain_;
    NativeMotionStudyDialogState before_;
    NativeMotionStudyDialogState after_;
    NativeCocoaWindowEvidence nativeBefore_;
    NativeCocoaWindowEvidence nativeAfter_;
    NativeCocoaWindowEvidence applicationRevealBefore_;
    NativeCocoaWindowEvidence applicationRevealAfter_;
    NativeCGWindowEvidence applicationRevealCGBefore_;
    NativeCGWindowEvidence applicationRevealCGAfter_;
    NativeCocoaWindowEvidence activeSpaceBefore_;
    NativeCocoaWindowEvidence activeSpaceApplied_;
    NativeCocoaWindowEvidence activeSpaceAfter_;
    NativeCocoaWindowEvidence activeSpaceAfterRestore_;
    NativeCGWindowEvidence activeSpaceCGBefore_;
    NativeCGWindowEvidence activeSpaceCGAfter_;
    NativeCGWindowEvidence activeSpaceCGAfterRestore_;
    std::string invokedMethod_;
    std::size_t dialogCardinality_ = 0;
    std::size_t dialogCardinalityAfter_ = 0;
    std::size_t revealShowCount_ = 0;
    std::size_t revealRaiseCount_ = 0;
    std::size_t revealActivateCount_ = 0;
    std::size_t nativeQtRaiseCount_ = 0;
    std::size_t nativeQtActivateCount_ = 0;
    std::size_t nativeOrderFrontCount_ = 0;
    std::size_t nativeMakeKeyCount_ = 0;
    std::uintptr_t nativeWindowIdentity_ = 0;
    std::uintptr_t nativeViewIdentity_ = 0;
    long long nativeWindowNumber_ = -1;
    unsigned long long activeSpaceOriginalBehavior_ = 0;
    unsigned long long activeSpaceDesiredBehavior_ = 0;
    bool actionAccepted_ = false;
    bool dialogSameAfter_ = false;
    bool revealHierarchyBounded_ = false;
    bool revealHierarchyCycleDetected_ = false;
    bool revealHierarchyStableAfter_ = false;
    bool revealDispatched_ = false;
    bool revealObserved_ = false;
    bool nativeIdentityStableAfterQtRequest_ = false;
    bool nativeIdentityStableAfterOrderFront_ = false;
    bool nativeIdentityStableAfterMakeKey_ = false;
    bool nativeIdentityStableAfterFinalQtRequest_ = false;
    bool nativeRevealDispatched_ = false;
    bool nativeQWindowSameAfter_ = false;
    bool nativeWindowIdentitySameAfter_ = false;
    bool nativeViewIdentitySameAfter_ = false;
    bool nativeWindowNumberSameAfter_ = false;
    bool nativeRevealObserved_ = false;
    bool applicationActivationSelectorPresent_ = false;
    bool applicationActivationCalled_ = false;
    bool applicationActivationNotRequired_ = false;
    bool applicationActivationObservedImmediately_ = false;
    bool applicationRevealObserved_ = false;
    bool activeSpaceInitiallyOnActiveSpace_ = false;
    bool activeSpaceMoveRequested_ = false;
    bool activeSpaceMoveAlreadyPresent_ = false;
    bool activeSpaceCanJoinAllSpacesConflict_ = false;
    bool activeSpaceTransientPresent_ = false;
    bool activeSpaceCollectionBehaviorWriteAttempted_ = false;
    bool activeSpaceCollectionBehaviorWriteObserved_ = false;
    bool activeSpaceCollectionBehaviorApplied_ = false;
    bool activeSpaceRestorationRequired_ = false;
    bool activeSpaceRestorationNotRequired_ = false;
    bool activeSpaceCleanupArmed_ = false;
    bool activeSpaceRestorationAttempted_ = false;
    std::size_t activeSpaceRestorationAttemptCount_ = 0;
    bool activeSpaceRestorationSetterCalled_ = false;
    bool activeSpaceRestorationConcurrentBehaviorMismatch_ = false;
    bool activeSpaceRestorationMaskedCleanupAttempted_ = false;
    bool activeSpaceRestorationMaskedCleanupSucceeded_ = false;
    bool activeSpaceRestorationSucceeded_ = false;
    bool activeSpaceObservedBeforeRestore_ = false;
    bool activeSpaceRevealObserved_ = false;
};

class FileRecoveryCloseController final : public QObject {
public:
    FileRecoveryCloseController(std::string outputPath,
                                int pollIntervalMs,
                                int timeoutMs)
        : outputPath_(std::move(outputPath)),
          pollIntervalMs_(std::max(50, pollIntervalMs)),
          timeoutMs_(std::max(250, timeoutMs)) {}

    void start() {
        elapsedMs_ = 0;
        poll();
    }

private:
    void writeResult(const char* status,
                     const QWidget* dialog,
                     const QAbstractButton* button,
                     bool closeDispatched) {
        std::ofstream file(outputPath_, std::ios::out | std::ios::trunc);
        file << "{"
             << "\"schema\":\"cad-agent.fusion-file-recovery-guard.v1\","
             << "\"status\":\"" << status << "\","
             << "\"qt_version\":\"" << qVersion() << "\","
             << "\"main_thread\":"
             << ((QCoreApplication::instance() != nullptr &&
                  QCoreApplication::instance()->thread() ==
                      QThread::currentThread())
                     ? "true"
                     : "false")
             << ",\"elapsed_ms\":" << elapsedMs_
             << ",\"dialog_found\":" << (dialog != nullptr ? "true" : "false")
             << ",\"dialog_class\":"
             << quoted(dialog == nullptr
                           ? QString()
                           : QString::fromLatin1(
                                 dialog->metaObject()->className()))
             << ",\"dialog_object_name\":"
             << quoted(dialog == nullptr ? QString()
                                         : dialog->objectName())
             << ",\"dialog_visible\":"
             << (dialog != nullptr && dialog->isVisible() ? "true" : "false")
             << ",\"dialog_modal\":"
             << (dialog != nullptr && dialog->isModal() ? "true" : "false")
             << ",\"close_button_found\":"
             << (button != nullptr ? "true" : "false")
             << ",\"close_button_object_name\":"
             << quoted(button == nullptr ? QString()
                                         : button->objectName())
             << ",\"close_button_text\":"
             << quoted(button == nullptr ? QString() : button->text())
             << ",\"close_dispatched\":"
             << (closeDispatched ? "true" : "false")
             << "}\n";
        file.close();
    }

    void poll() {
        const auto widgets = QApplication::topLevelWidgets();
        QWidget* recovery = nullptr;
        QAbstractButton* closeButton = nullptr;
        for (QWidget* widget : widgets) {
            if (!looksLikeFileRecovery(widget)) {
                continue;
            }
            recovery = widget;
            closeButton = fileRecoveryCloseButton(widget);
            if (widget->isVisible() && closeButton != nullptr &&
                closeButton->isEnabled()) {
                const QPointer<QWidget> guardedRecovery(recovery);
                const QPointer<QAbstractButton> guardedButton(closeButton);
                const bool queued = QMetaObject::invokeMethod(
                    closeButton, "click", Qt::QueuedConnection);
                writeResult(queued ? "close-queued"
                                   : "close-queue-failed",
                            recovery,
                            closeButton,
                            queued);
                if (!queued) {
                    deleteLater();
                    return;
                }
                QTimer::singleShot(
                    pollIntervalMs_,
                    this,
                    [this, guardedRecovery, guardedButton]() {
                        writeResult(
                            guardedRecovery == nullptr ||
                                    !guardedRecovery->isVisible()
                                ? "closed"
                                : "close-not-observed",
                            guardedRecovery.data(),
                            guardedButton.data(),
                            true);
                        deleteLater();
                    });
                return;
            }
        }

        if (elapsedMs_ >= timeoutMs_) {
            writeResult("timeout", recovery, closeButton, false);
            deleteLater();
            return;
        }

        elapsedMs_ += pollIntervalMs_;
        QTimer::singleShot(
            pollIntervalMs_, this, [this]() { poll(); });
    }

    std::string outputPath_;
    int pollIntervalMs_;
    int timeoutMs_;
    int elapsedMs_ = 0;
};

std::string gRuntimeReport;

}  // namespace

extern "C" __attribute__((visibility("default")))
const char* cad_agent_motion_study_qt_runtime_report() {
    std::ostringstream output;
    output << "{"
           << "\"schema\":\"cad-agent.motion-study-qt-runtime.v1\","
           << "\"qt_version\":\"" << qVersion() << "\","
           << "\"application_present\":"
           << (QCoreApplication::instance() != nullptr ? "true" : "false")
           << ",\"main_thread\":"
           << ((QCoreApplication::instance() != nullptr &&
                QCoreApplication::instance()->thread() ==
                    QThread::currentThread())
                   ? "true"
                   : "false")
           << "}";
    gRuntimeReport = output.str();
    return gRuntimeReport.c_str();
}

extern "C" __attribute__((visibility("default")))
int cad_agent_schedule_motion_study_qt_probe(const char* outputPath,
                                             int pollIntervalMs,
                                             int timeoutMs,
                                             int cancelAfterDump) {
    if (outputPath == nullptr || outputPath[0] == '\0') {
        return 1;
    }
    if (QCoreApplication::instance() == nullptr) {
        return 2;
    }
    if (QCoreApplication::instance()->thread() != QThread::currentThread()) {
        return 3;
    }

    auto* controller =
        new ProbeController(outputPath,
                            pollIntervalMs,
                            timeoutMs,
                            cancelAfterDump != 0);
    QTimer::singleShot(0, controller, [controller]() { controller->start(); });
    return 0;
}

extern "C" __attribute__((visibility("default")))
int cad_agent_schedule_motion_study_qt_delayed_probe(const char* outputPath,
                                                     int pollIntervalMs,
                                                     int timeoutMs,
                                                     int readyDelayMs,
                                                     int cancelAfterDump) {
    if (outputPath == nullptr || outputPath[0] == '\0') {
        return 1;
    }
    if (QCoreApplication::instance() == nullptr) {
        return 2;
    }
    if (QCoreApplication::instance()->thread() != QThread::currentThread()) {
        return 3;
    }

    auto* controller =
        new ProbeController(outputPath,
                            pollIntervalMs,
                            timeoutMs,
                            cancelAfterDump != 0,
                            readyDelayMs);
    QTimer::singleShot(0, controller, [controller]() { controller->start(); });
    return 0;
}

extern "C" __attribute__((visibility("default")))
int cad_agent_schedule_motion_study_joint_token_probe(
    const char* entityToken,
    const char* outputPath,
    int pollIntervalMs,
    int timeoutMs,
    int settleMs) {
    if (entityToken == nullptr || entityToken[0] == '\0' ||
        outputPath == nullptr || outputPath[0] == '\0') {
        return 1;
    }
    if (QCoreApplication::instance() == nullptr) {
        return 2;
    }
    if (QCoreApplication::instance()->thread() !=
        QThread::currentThread()) {
        return 3;
    }

    auto* controller =
        new JointTokenProbeController(entityToken,
                                      outputPath,
                                      pollIntervalMs,
                                      timeoutMs,
                                      settleMs);
    controller->start();
    return 0;
}

extern "C" __attribute__((visibility("default")))
int cad_agent_schedule_motion_study_joint_keyframe_probe(
    const char* entityToken,
    int step,
    double angleDegrees,
    const char* outputPath,
    int pollIntervalMs,
    int timeoutMs,
    int settleMs) {
    if (entityToken == nullptr || entityToken[0] == '\0' ||
        outputPath == nullptr || outputPath[0] == '\0' ||
        step <= 0 || step >= 100 || !std::isfinite(angleDegrees)) {
        return 1;
    }
    if (QCoreApplication::instance() == nullptr) {
        return 2;
    }
    if (QCoreApplication::instance()->thread() !=
        QThread::currentThread()) {
        return 3;
    }

    auto* controller =
        new JointKeyframeProbeController(entityToken,
                                         step,
                                         angleDegrees,
                                         outputPath,
                                         pollIntervalMs,
                                         timeoutMs,
                                         settleMs);
    controller->start();
    return 0;
}

extern "C" __attribute__((visibility("default")))
int cad_agent_schedule_motion_study_program(
    const char* const* entityTokens,
    const char* const* expectedJointNames,
    const int* pointOffsets,
    int jointCount,
    const int* pointSteps,
    const double* pointAnglesDegrees,
    int pointCount,
    const char* outputPath,
    int pollIntervalMs,
    int timeoutMs,
    int settleMs,
    int commitOnSuccess) {
    if (entityTokens == nullptr || expectedJointNames == nullptr ||
        pointOffsets == nullptr || pointSteps == nullptr ||
        pointAnglesDegrees == nullptr || outputPath == nullptr ||
        outputPath[0] == '\0' || jointCount <= 0 || jointCount > 32 ||
        pointCount <= 0 || pointCount > 256 ||
        (commitOnSuccess != 0 && commitOnSuccess != 1) ||
        pointOffsets[0] != 0 || pointOffsets[jointCount] != pointCount) {
        return 1;
    }
    if (QCoreApplication::instance() == nullptr) {
        return 2;
    }
    if (QCoreApplication::instance()->thread() !=
        QThread::currentThread()) {
        return 3;
    }

    std::vector<MotionJointSpec> specs;
    specs.reserve(static_cast<std::size_t>(jointCount));
    for (int jointIndex = 0; jointIndex < jointCount; ++jointIndex) {
        if (entityTokens[jointIndex] == nullptr ||
            entityTokens[jointIndex][0] == '\0' ||
            expectedJointNames[jointIndex] == nullptr ||
            expectedJointNames[jointIndex][0] == '\0' ||
            pointOffsets[jointIndex] < 0 ||
            pointOffsets[jointIndex] >= pointOffsets[jointIndex + 1] ||
            pointOffsets[jointIndex + 1] > pointCount) {
            return 4;
        }
        MotionJointSpec spec;
        spec.entityToken = entityTokens[jointIndex];
        spec.expectedName = expectedJointNames[jointIndex];
        int previousStep = 0;
        for (int pointIndex = pointOffsets[jointIndex];
             pointIndex < pointOffsets[jointIndex + 1];
             ++pointIndex) {
            const int step = pointSteps[pointIndex];
            const double angle = pointAnglesDegrees[pointIndex];
            if (step <= previousStep || step >= 100 ||
                !std::isfinite(angle)) {
                return 5;
            }
            spec.points.push_back({step, angle});
            previousStep = step;
        }
        specs.push_back(std::move(spec));
    }

    auto* controller =
        new MotionStudyProgramController(std::move(specs),
                                         outputPath,
                                         pollIntervalMs,
                                         timeoutMs,
                                         settleMs,
                                         commitOnSuccess != 0);
    controller->start();
    return 0;
}

extern "C" __attribute__((visibility("default")))
int cad_agent_read_persisted_motion_study(
    const char* const* entityTokens,
    const char* const* expectedJointNames,
    const int* pointOffsets,
    int jointCount,
    const int* pointSteps,
    const double* pointAnglesDegrees,
    int pointCount,
    const char* outputPath,
    int expectedTotalPointCount) {
    if (entityTokens == nullptr || expectedJointNames == nullptr ||
        pointOffsets == nullptr || pointSteps == nullptr ||
        pointAnglesDegrees == nullptr || outputPath == nullptr ||
        outputPath[0] == '\0' || jointCount <= 0 || jointCount > 32 ||
        pointCount <= 0 || pointCount > 256 || pointOffsets[0] != 0 ||
        pointOffsets[jointCount] != pointCount ||
        expectedTotalPointCount != pointCount) {
        return 1;
    }
    if (QCoreApplication::instance() == nullptr) {
        return 2;
    }
    if (QCoreApplication::instance()->thread() !=
        QThread::currentThread()) {
        return 3;
    }

    std::vector<MotionJointSpec> specs;
    specs.reserve(static_cast<std::size_t>(jointCount));
    for (int jointIndex = 0; jointIndex < jointCount; ++jointIndex) {
        if (entityTokens[jointIndex] == nullptr ||
            entityTokens[jointIndex][0] == '\0' ||
            expectedJointNames[jointIndex] == nullptr ||
            expectedJointNames[jointIndex][0] == '\0' ||
            pointOffsets[jointIndex] < 0 ||
            pointOffsets[jointIndex] >= pointOffsets[jointIndex + 1] ||
            pointOffsets[jointIndex + 1] > pointCount) {
            return 4;
        }
        MotionJointSpec spec;
        spec.entityToken = entityTokens[jointIndex];
        spec.expectedName = expectedJointNames[jointIndex];
        int previousStep = 0;
        for (int pointIndex = pointOffsets[jointIndex];
             pointIndex < pointOffsets[jointIndex + 1]; ++pointIndex) {
            const int step = pointSteps[pointIndex];
            const double angle = pointAnglesDegrees[pointIndex];
            if (step <= previousStep || step >= 100 ||
                !std::isfinite(angle)) {
                return 5;
            }
            spec.points.push_back({step, angle});
            previousStep = step;
        }
        specs.push_back(std::move(spec));
    }

    const PersistedMotionStudyReadbackResult result =
        readPersistedMotionStudy(specs);
    std::ostringstream output;
    appendPersistedMotionStudyReadback(output, result);
    output << "\n";
    if (!writeTextAtomically(outputPath, output.str())) {
        return 90;
    }
    return result.code;
}

extern "C" __attribute__((visibility("default")))
int cad_agent_schedule_motion_study_reopen_readback(
    const char* const* expectedJointNames,
    const int* pointOffsets,
    int jointCount,
    const int* pointSteps,
    const double* pointAnglesDegrees,
    int pointCount,
    const char* outputPath,
    int pollIntervalMs,
    int timeoutMs,
    int settleMs) {
    if (expectedJointNames == nullptr || pointOffsets == nullptr ||
        pointSteps == nullptr || pointAnglesDegrees == nullptr ||
        outputPath == nullptr || outputPath[0] == '\0' ||
        jointCount <= 0 || jointCount > 32 || pointCount <= 0 ||
        pointCount > 256 || pointOffsets[0] != 0 ||
        pointOffsets[jointCount] != pointCount) {
        return 1;
    }
    if (QCoreApplication::instance() == nullptr) {
        return 2;
    }
    if (QCoreApplication::instance()->thread() !=
        QThread::currentThread()) {
        return 3;
    }

    std::vector<MotionJointSpec> specs;
    specs.reserve(static_cast<std::size_t>(jointCount));
    for (int jointIndex = 0; jointIndex < jointCount; ++jointIndex) {
        if (expectedJointNames[jointIndex] == nullptr ||
            expectedJointNames[jointIndex][0] == '\0' ||
            pointOffsets[jointIndex] < 0 ||
            pointOffsets[jointIndex] >= pointOffsets[jointIndex + 1] ||
            pointOffsets[jointIndex + 1] > pointCount) {
            return 4;
        }
        MotionJointSpec spec;
        spec.expectedName = expectedJointNames[jointIndex];
        int previousStep = 0;
        for (int pointIndex = pointOffsets[jointIndex];
             pointIndex < pointOffsets[jointIndex + 1];
             ++pointIndex) {
            const int step = pointSteps[pointIndex];
            const double angle = pointAnglesDegrees[pointIndex];
            if (step <= previousStep || step >= 100 ||
                !std::isfinite(angle)) {
                return 5;
            }
            spec.points.push_back({step, angle});
            previousStep = step;
        }
        specs.push_back(std::move(spec));
    }

    auto* controller = new MotionStudyReopenReadbackController(
        std::move(specs),
        outputPath,
        pollIntervalMs,
        timeoutMs,
        settleMs);
    controller->start();
    return 0;
}

extern "C" __attribute__((visibility("default")))
int cad_agent_schedule_motion_study_native_edit(
    const char* expectedStudyName,
    int expectedRowCount,
    const char* outputPath,
    int pollIntervalMs,
    int timeoutMs,
    int selectionSettleMs) {
    if (outputPath == nullptr || outputPath[0] == '\0' ||
        expectedRowCount <= 0 || expectedRowCount > 64 ||
        pollIntervalMs <= 0 || timeoutMs <= 0 ||
        selectionSettleMs <= 0) {
        return 1;
    }
    if (QCoreApplication::instance() == nullptr) {
        return 2;
    }
    if (QCoreApplication::instance()->thread() !=
        QThread::currentThread()) {
        return 3;
    }
    if (gNativeMotionStudyEditControllerActive ||
        gNativeMotionStudyDirectEditControllerActive) {
        return 4;
    }

    const QString expectedName = expectedStudyName == nullptr
        ? QString()
        : QString::fromUtf8(expectedStudyName);
    gNativeMotionStudyEditControllerActive = true;
    auto* controller = new NativeMotionStudyEditController(
        expectedName,
        expectedRowCount,
        outputPath,
        pollIntervalMs,
        timeoutMs,
        selectionSettleMs);
    QTimer::singleShot(0, controller, [controller]() {
        controller->start();
    });
    return 0;
}

extern "C" __attribute__((visibility("default")))
int cad_agent_schedule_motion_study_native_edit_direct(
    const char* outputPath,
    int expectedRowCount,
    int expectedPointCount,
    int pollIntervalMs,
    int timeoutMs) {
    if (outputPath == nullptr || outputPath[0] == '\0' ||
        expectedRowCount <= 0 || expectedRowCount > 64 ||
        expectedPointCount <= 0 || expectedPointCount > 32768 ||
        pollIntervalMs <= 0 || timeoutMs <= 0) {
        return 1;
    }
    if (QCoreApplication::instance() == nullptr) {
        return 2;
    }
    if (QCoreApplication::instance()->thread() !=
        QThread::currentThread()) {
        return 3;
    }
    if (gNativeMotionStudyEditControllerActive ||
        gNativeMotionStudyDirectEditControllerActive) {
        return 4;
    }

    gNativeMotionStudyDirectEditControllerActive = true;
    auto* controller = new NativeMotionStudyDirectEditController(
        outputPath,
        expectedRowCount,
        expectedPointCount,
        pollIntervalMs,
        timeoutMs);
    QTimer::singleShot(0, controller, [controller]() {
        controller->start();
    });
    return 0;
}

extern "C" __attribute__((visibility("default")))
int cad_agent_schedule_motion_study_native_control(
    const char* action,
    const char* outputPath,
    int settleMs) {
    if (action == nullptr || action[0] == '\0' ||
        outputPath == nullptr || outputPath[0] == '\0' ||
        settleMs <= 0) {
        return 1;
    }
    if (QCoreApplication::instance() == nullptr) {
        return 2;
    }
    if (QCoreApplication::instance()->thread() !=
        QThread::currentThread()) {
        return 3;
    }
    if (gNativeMotionStudyControlControllerActive ||
        gNativeMotionStudyEditControllerActive ||
        gNativeMotionStudyDirectEditControllerActive) {
        return 4;
    }

    gNativeMotionStudyControlControllerActive = true;
    auto* controller = new NativeMotionStudyControlController(
        action, outputPath, settleMs);
    QTimer::singleShot(0, controller, [controller]() {
        controller->start();
    });
    return 0;
}

extern "C" __attribute__((visibility("default")))
int cad_agent_schedule_file_recovery_close(const char* outputPath,
                                           int pollIntervalMs,
                                           int timeoutMs) {
    if (outputPath == nullptr || outputPath[0] == '\0') {
        return 1;
    }
    if (QCoreApplication::instance() == nullptr) {
        return 2;
    }
    if (QCoreApplication::instance()->thread() != QThread::currentThread()) {
        return 3;
    }

    auto* controller =
        new FileRecoveryCloseController(outputPath,
                                        pollIntervalMs,
                                        timeoutMs);
    QTimer::singleShot(0, controller, [controller]() { controller->start(); });
    return 0;
}
