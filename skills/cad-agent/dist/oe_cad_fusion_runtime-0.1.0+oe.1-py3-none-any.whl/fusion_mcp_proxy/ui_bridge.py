"""Deterministic Fusion native-UI bridge using Peekaboo plus AXUIElement."""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass
from importlib.resources import files
from pathlib import Path
from typing import Any, Callable, Sequence


FUSION_BUNDLE_ID = "com.autodesk.fusion360"
FUSION_APP_NAME = "Fusion"
CHOOSER_TITLES = ("您想设计什么？", "What do you want to design?")
CONFIRM_CHOOSER_SELECT = "FUSION-UI-CHOOSER-SELECT"
CONFIRM_CREATE_DISPOSABLE = "FUSION-UI-CREATE-DISPOSABLE"
CONFIRM_OPEN_CHOOSER = "FUSION-UI-OPEN-CHOOSER"

LABELS = {
    "part": ("零件设计", "Part Design"),
    "assembly": ("部件设计", "Assembly Design"),
    "hybrid": ("混合设计", "Hybrid Design"),
    "create": ("新建", "New"),
    "cancel": ("取消", "Cancel"),
}
MODE_INDEX = {"part": 1, "assembly": 2, "hybrid": 3}


class BridgeError(RuntimeError):
    """A bounded bridge action failed or violated its contract."""


RunCommand = Callable[..., subprocess.CompletedProcess[str]]


def _default_run(
    command: Sequence[str], *, timeout: float = 20.0
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        list(command),
        text=True,
        capture_output=True,
        check=False,
        timeout=timeout,
    )


def _parse_json_result(
    completed: subprocess.CompletedProcess[str], label: str
) -> dict[str, Any]:
    raw = completed.stdout.strip()
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        detail = completed.stderr.strip() or raw or f"{label} returned no output"
        raise BridgeError(f"{label} returned invalid JSON: {detail}") from exc
    if completed.returncode != 0 or payload.get("success") is False:
        error = payload.get("error")
        if isinstance(error, dict):
            error = error.get("message") or json.dumps(error, ensure_ascii=False)
        raise BridgeError(str(error or completed.stderr.strip() or f"{label} failed"))
    return payload


@dataclass
class PeekabooBackend:
    executable: str = "peekaboo"
    runner: RunCommand = _default_run

    def _run_json(self, arguments: Sequence[str]) -> dict[str, Any]:
        command = [self.executable, *arguments, "--json", "--no-remote"]
        return _parse_json_result(self.runner(command, timeout=30.0), "Peekaboo")

    def version(self) -> str:
        completed = self.runner([self.executable, "--version"], timeout=10.0)
        if completed.returncode != 0:
            raise BridgeError(
                completed.stderr.strip() or "Peekaboo version check failed"
            )
        return completed.stdout.strip()

    def permissions(self) -> dict[str, Any]:
        return self._run_json(["permissions"])

    def applications(self) -> dict[str, Any]:
        return self._run_json(["list", "apps"])

    def windows(self) -> dict[str, Any]:
        return self._run_json(["window", "list", "--app", FUSION_BUNDLE_ID])

    def press_escape(self) -> dict[str, Any]:
        return self._run_json(
            [
                "press",
                "escape",
                "--no-auto-focus",
                "--input-strategy",
                "synthOnly",
            ]
        )

    def click_global(self, x: int, y: int) -> dict[str, Any]:
        return self._run_json(
            [
                "click",
                "--coords",
                f"{x},{y}",
                "--global-coords",
                "--no-auto-focus",
                "--input-strategy",
                "synthOnly",
            ]
        )

    def open_chooser(self) -> dict[str, Any]:
        failures: list[str] = []
        for menu_path in ("文件 > 新建...", "File > New..."):
            try:
                result = self._run_json(
                    [
                        "menu",
                        "click",
                        "--app",
                        FUSION_BUNDLE_ID,
                        "--path",
                        menu_path,
                        "--input-strategy",
                        "actionFirst",
                    ]
                )
                return {"menu_path": menu_path, "peekaboo": result}
            except BridgeError as exc:
                failures.append(f"{menu_path}: {exc}")
        raise BridgeError("Fusion New menu was not activated: " + "; ".join(failures))


@dataclass
class NativeAXBackend:
    runner: RunCommand = _default_run
    helper_path: Path | None = None

    def _source_path(self) -> Path:
        resource = files("fusion_mcp_proxy").joinpath("native/fusion_ax_bridge.swift")
        return Path(str(resource))

    def executable(self) -> Path:
        configured = os.environ.get("FUSION_AX_HELPER")
        if configured:
            path = Path(configured).expanduser().resolve()
            if not path.is_file():
                raise BridgeError(f"FUSION_AX_HELPER is not a file: {path}")
            return path
        if self.helper_path is not None:
            return self.helper_path
        source = self._source_path()
        digest = hashlib.sha256(source.read_bytes()).hexdigest()[:16]
        cache_root = Path(
            os.environ.get(
                "FUSION_AX_HELPER_CACHE",
                str(Path(tempfile.gettempdir()) / "cad-agent-fusion-ui"),
            )
        )
        cache_root.mkdir(parents=True, exist_ok=True)
        target = cache_root / f"fusion-ax-helper-{digest}"
        if target.is_file():
            return target
        swiftc = shutil.which("swiftc")
        if swiftc is None:
            raise BridgeError("swiftc is required to build the native AX helper")
        temporary = target.with_suffix(".building")
        completed = self.runner(
            [swiftc, str(source), "-O", "-o", str(temporary)],
            timeout=120.0,
        )
        if completed.returncode != 0:
            raise BridgeError(
                completed.stderr.strip() or "native AX helper build failed"
            )
        temporary.replace(target)
        return target

    def _invoke(
        self, arguments: Sequence[str], *, timeout: float = 30.0
    ) -> dict[str, Any]:
        command = [str(self.executable()), *arguments, "--bundle-id", FUSION_BUNDLE_ID]
        return _parse_json_result(
            self.runner(command, timeout=timeout), "native AX helper"
        )

    def snapshot(
        self,
        *,
        window_titles: Sequence[str] = (),
        max_elements: int = 500,
    ) -> dict[str, Any]:
        arguments = ["snapshot", "--max-elements", str(max_elements)]
        for title in window_titles:
            arguments.extend(["--window-title", title])
        return self._invoke(arguments)

    def press(
        self,
        *,
        role: str,
        window_titles: Sequence[str],
        index: int = 1,
        labels: Sequence[str] = (),
    ) -> dict[str, Any]:
        arguments = ["press", "--role", role, "--index", str(index)]
        for title in window_titles:
            arguments.extend(["--window-title", title])
        for label in labels:
            arguments.extend(["--label", label])
        return self._invoke(arguments)


class FusionUIBridge:
    """Bounded orchestration over Peekaboo interaction and native AX inspection."""

    def __init__(
        self,
        peekaboo: PeekabooBackend | None = None,
        native_ax: NativeAXBackend | None = None,
        sleeper: Callable[[float], None] = time.sleep,
    ) -> None:
        self.peekaboo = peekaboo or PeekabooBackend()
        self.native_ax = native_ax or NativeAXBackend()
        self._sleep = sleeper

    @staticmethod
    def _backend_record() -> dict[str, str]:
        return {"interaction": "peekaboo", "modal_inspection": "native_axui_element"}

    def _fusion_application(self) -> dict[str, Any] | None:
        applications = self.peekaboo.applications()
        app_rows = applications.get("data", {}).get("applications", [])
        return next(
            (
                row
                for row in app_rows
                if row.get("bundleIdentifier") == FUSION_BUNDLE_ID
            ),
            None,
        )

    def _require_fusion_active(self) -> dict[str, Any]:
        fusion = self._fusion_application()
        if fusion is None:
            raise BridgeError("Fusion is not running")
        if fusion.get("isActive") is not True:
            raise BridgeError(
                "Fusion is not the active application; synthesized input was refused"
            )
        return fusion

    def preflight(self) -> dict[str, Any]:
        permissions = self.peekaboo.permissions()
        fusion = self._fusion_application()
        if fusion is None:
            raise BridgeError("Fusion is not running")
        required_permissions = permissions.get("data", {}).get("permissions", [])
        missing = [
            row.get("name")
            for row in required_permissions
            if row.get("isRequired") and not row.get("isGranted")
        ]
        if missing:
            raise BridgeError(
                "missing Peekaboo permissions: "
                + ", ".join(str(item) for item in missing)
            )
        ax = self.native_ax.snapshot(max_elements=1)
        return {
            "action": "preflight",
            "backends": self._backend_record(),
            "peekaboo_version": self.peekaboo.version(),
            "permissions": required_permissions,
            "fusion": fusion,
            "native_ax": {
                "accessibility_trusted": ax.get("accessibility_trusted"),
                "pid": ax.get("pid"),
            },
        }

    def status(self) -> dict[str, Any]:
        windows = self.peekaboo.windows()
        fusion = self._fusion_application()
        return {
            "action": "status",
            "backends": self._backend_record(),
            "running": fusion is not None,
            "application": fusion,
            "windows": windows.get("data", {}).get("windows", []),
        }

    def escape(self) -> dict[str, Any]:
        if self._chooser_window(required=False) is not None:
            try:
                native = self.native_ax.press(
                    role="AXButton",
                    window_titles=CHOOSER_TITLES,
                    labels=LABELS["cancel"],
                )
                self._sleep(0.4)
                return {
                    "action": "escape",
                    "backends": self._backend_record(),
                    "terminal_action": "cancel",
                    "native_ax": native,
                }
            except BridgeError:
                pass
        self._require_fusion_active()
        return {
            "action": "escape",
            "backends": self._backend_record(),
            "peekaboo": self.peekaboo.press_escape(),
        }

    def _chooser_window(self, *, required: bool = True) -> dict[str, Any] | None:
        snapshot = self.native_ax.snapshot(
            window_titles=CHOOSER_TITLES, max_elements=500
        )
        windows = snapshot.get("windows", [])
        if not windows:
            if required:
                raise BridgeError("Fusion new-design chooser not found")
            return None
        if len(windows) != 1:
            raise BridgeError("Fusion exposed more than one new-design chooser")
        return windows[0]

    @staticmethod
    def _truthy_ax_value(value: Any) -> bool:
        return value is True or value == 1 or str(value).lower() in {"1", "true", "yes"}

    def chooser_snapshot(self) -> dict[str, Any]:
        window = self._chooser_window(required=True)
        assert window is not None
        elements = window.get("elements", [])
        checkboxes = [row for row in elements if row.get("role") == "AXCheckBox"]
        if len(checkboxes) < 3:
            raise BridgeError("Fusion chooser exposes fewer than three mode checkboxes")
        cards = {
            str(index): {
                "value": row.get("value"),
                "position": row.get("position"),
                "size": row.get("size"),
                "identifier": row.get("identifier"),
                "path": row.get("path"),
            }
            for index, row in enumerate(checkboxes[:3], start=1)
        }
        labels = [
            str(row.get("title") or row.get("value") or row.get("description"))
            for row in elements
            if row.get("role") == "AXStaticText"
            and (row.get("title") or row.get("value") or row.get("description"))
        ]
        detail_candidates = []
        for mode, accepted_labels in LABELS.items():
            if (
                mode in MODE_INDEX
                and sum(label in accepted_labels for label in labels) > 1
            ):
                detail_candidates.append(mode)
        selected = [
            index
            for index in range(1, 4)
            if self._truthy_ax_value(cards[str(index)]["value"])
        ]
        if len(detail_candidates) == 1:
            detail_mode = detail_candidates[0]
        elif len(selected) == 1:
            detail_mode = next(
                mode for mode, index in MODE_INDEX.items() if index == selected[0]
            )
        else:
            detail_mode = "unknown"
        return {
            "action": "chooser_snapshot",
            "backends": self._backend_record(),
            "window_title": window.get("title"),
            "cards": cards,
            "labels": labels,
            "detail_mode": detail_mode,
            "element_count": len(elements),
            "truncated": bool(window.get("truncated")),
        }

    def open_chooser(self) -> dict[str, Any]:
        if self._chooser_window(required=False) is not None:
            return {
                "action": "open_chooser",
                "already_open": True,
                "backends": self._backend_record(),
            }
        warning = None
        try:
            interaction = self.peekaboo.open_chooser()
        except BridgeError as exc:
            warning = str(exc)
            interaction = {"reported_failure": warning}
        self._sleep(0.8)
        snapshot = self.chooser_snapshot()
        return {
            "action": "open_chooser",
            "already_open": False,
            "backends": self._backend_record(),
            "interaction": interaction,
            "interaction_warning": warning,
            "snapshot": snapshot,
        }

    def chooser_select(self, mode: str, *, cancel_after: bool = True) -> dict[str, Any]:
        if mode not in MODE_INDEX:
            raise BridgeError(f"unsupported chooser mode: {mode}")
        self.open_chooser()
        initial = self.chooser_snapshot()
        if initial["detail_mode"] != mode:
            target = initial["cards"][str(MODE_INDEX[mode])]
            position = target.get("position")
            size = target.get("size")
            if not isinstance(position, dict) or not isinstance(size, dict):
                self.escape()
                raise BridgeError(
                    "Fusion chooser card has no verified Accessibility geometry"
                )
            x = int(float(position["x"]) + float(size["width"]) / 2)
            y = int(float(position["y"]) + float(size["height"]) / 2)
            self._require_fusion_active()
            self.peekaboo.click_global(x, y)
            self._sleep(0.4)
        selected = self.chooser_snapshot()
        if selected["detail_mode"] != mode:
            self.escape()
            raise BridgeError(
                "Fusion chooser detail panel does not match the requested mode"
            )
        terminal_action = "leave_open"
        if cancel_after:
            try:
                self.native_ax.press(
                    role="AXButton",
                    window_titles=CHOOSER_TITLES,
                    labels=LABELS["cancel"],
                )
            except BridgeError:
                self.escape()
            terminal_action = "cancel"
            self._sleep(0.4)
        return {
            "action": "chooser_select",
            "mode": mode,
            "backends": self._backend_record(),
            "initial": initial,
            "selected": selected,
            "terminal_action": terminal_action,
        }

    def chooser_create(self, mode: str) -> dict[str, Any]:
        selected_result = self.chooser_select(mode, cancel_after=False)
        try:
            terminal = self.native_ax.press(
                role="AXButton",
                window_titles=CHOOSER_TITLES,
                labels=LABELS["create"],
            )
        except BridgeError:
            self.escape()
            raise
        self._sleep(0.5)
        return {
            **selected_result,
            "action": "chooser_create",
            "terminal_action": "create",
            "terminal": terminal,
        }

    def chooser_probe(self, mode: str | None = None) -> dict[str, Any]:
        if mode is None:
            self.open_chooser()
            snapshot = self.chooser_snapshot()
            try:
                self.native_ax.press(
                    role="AXButton",
                    window_titles=CHOOSER_TITLES,
                    labels=LABELS["cancel"],
                )
            except BridgeError:
                self.escape()
            return {
                "action": "chooser_probe",
                "snapshot": snapshot,
                "terminal_action": "cancel",
                "backends": self._backend_record(),
            }
        return self.chooser_select(mode, cancel_after=True)

    def dialog_inspect(self, max_elements: int = 120) -> dict[str, Any]:
        if not 1 <= max_elements <= 500:
            raise BridgeError("max_elements must be between 1 and 500")
        snapshot = self.native_ax.snapshot(max_elements=max_elements)
        windows = snapshot.get("windows", [])
        if not windows:
            raise BridgeError("Fusion has no Accessibility windows")
        chosen = next(
            (row for row in windows if row.get("title") in CHOOSER_TITLES), None
        )
        if chosen is None:
            chosen = next((row for row in windows if row.get("title")), windows[0])
        return {
            "action": "dialog_inspect",
            "backends": self._backend_record(),
            "window": chosen,
            "available_window_titles": [row.get("title") for row in windows],
        }
