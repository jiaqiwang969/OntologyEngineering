"""Fusion MCP proxy with bounded macOS UI automation."""

from .server import create_server

__all__ = ["create_server"]
