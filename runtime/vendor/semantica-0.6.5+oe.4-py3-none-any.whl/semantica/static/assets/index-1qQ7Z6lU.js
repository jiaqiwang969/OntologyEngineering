const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/DecisionWorkspace-BKQFtyNr.js","assets/query-vendor-CCrh9h3E.js","assets/info-dJPV3cr-.js","assets/DiffMergeWorkspace-DfaDgl2T.js","assets/registryStore-Dht1Q3ou.js","assets/circle-check-CPs8YpeG.js","assets/loader-circle-CAZLCtQN.js","assets/GraphWorkspace-CeTkK6Qg.js","assets/graph-vendor-C_DST6AN.js","assets/refresh-cw-5nONYge_.js","assets/layers-BNwmhVK0.js","assets/git-branch-CGVAeB2F.js","assets/play-iDE8EwDZ.js","assets/x-aaLk_uas.js","assets/ImportExportWorkspace-CHzYUTOl.js","assets/index-DvoGHVaC.js","assets/file-text-BPsto7n-.js","assets/download-BwpCNIOS.js","assets/LineageDiagram-Dq-BhLNV.js","assets/style-B7ALFMc_.js","assets/index-CVqD6U61.js","assets/style-BZV40eAE.css","assets/ReasoningWorkspace-BVlShoff.js","assets/SparqlWorkspace-CT9WWG1I.js","assets/index-CTgLUBnY.js","assets/VocabularyWorkspace-BTccYbUX.js","assets/queries-DBXYfeHe.js","assets/chevron-right-CHH7KMxi.js","assets/RegistryTab-DjoaSS2H.js","assets/trash-2-DGYXFPWc.js","assets/EntityResolutionTab-DQWfDZY8.js","assets/KGOverviewTab-BIX4S7IL.js","assets/OntologySummaryTab-DQBwkrv6.js","assets/external-link-NDD8EOeI.js","assets/index-_mMYPpGW.js"])))=>i.map(i=>d[i]);
import{r as Bf,a as K,j as o,Q as sm,b as rm}from"./query-vendor-CCrh9h3E.js";(function(){const c=document.createElement("link").relList;if(c&&c.supports&&c.supports("modulepreload"))return;for(const j of document.querySelectorAll('link[rel="modulepreload"]'))g(j);new MutationObserver(j=>{for(const H of j)if(H.type==="childList")for(const V of H.addedNodes)V.tagName==="LINK"&&V.rel==="modulepreload"&&g(V)}).observe(document,{childList:!0,subtree:!0});function O(j){const H={};return j.integrity&&(H.integrity=j.integrity),j.referrerPolicy&&(H.referrerPolicy=j.referrerPolicy),j.crossOrigin==="use-credentials"?H.credentials="include":j.crossOrigin==="anonymous"?H.credentials="omit":H.credentials="same-origin",H}function g(j){if(j.ep)return;j.ep=!0;const H=O(j);fetch(j.href,H)}})();var Of={exports:{}},ai={},Nf={exports:{}},Df={};/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var wd;function om(){return wd||(wd=1,(function(d){function c(S,A){var w=S.length;S.push(A);l:for(;0<w;){var al=w-1>>>1,$=S[al];if(0<j($,A))S[al]=A,S[w]=$,w=al;else break l}}function O(S){return S.length===0?null:S[0]}function g(S){if(S.length===0)return null;var A=S[0],w=S.pop();if(w!==A){S[0]=w;l:for(var al=0,$=S.length,zl=$>>>1;al<zl;){var il=2*(al+1)-1,Z=S[il],pl=il+1,Zl=S[pl];if(0>j(Z,w))pl<$&&0>j(Zl,Z)?(S[al]=Zl,S[pl]=w,al=pl):(S[al]=Z,S[il]=w,al=il);else if(pl<$&&0>j(Zl,w))S[al]=Zl,S[pl]=w,al=pl;else break l}}return A}function j(S,A){var w=S.sortIndex-A.sortIndex;return w!==0?w:S.id-A.id}if(d.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var H=performance;d.unstable_now=function(){return H.now()}}else{var V=Date,R=V.now();d.unstable_now=function(){return V.now()-R}}var T=[],v=[],C=1,E=null,B=3,ll=!1,J=!1,W=!1,sl=!1,rl=typeof setTimeout=="function"?setTimeout:null,gl=typeof clearTimeout=="function"?clearTimeout:null,nl=typeof setImmediate<"u"?setImmediate:null;function Bl(S){for(var A=O(v);A!==null;){if(A.callback===null)g(v);else if(A.startTime<=S)g(v),A.sortIndex=A.expirationTime,c(T,A);else break;A=O(v)}}function jl(S){if(W=!1,Bl(S),!J)if(O(T)!==null)J=!0,Ol||(Ol=!0,Nl());else{var A=O(v);A!==null&&Kl(jl,A.startTime-S)}}var Ol=!1,kl=-1,Sl=5,Vl=-1;function Ma(){return sl?!0:!(d.unstable_now()-Vl<Sl)}function ta(){if(sl=!1,Ol){var S=d.unstable_now();Vl=S;var A=!0;try{l:{J=!1,W&&(W=!1,gl(kl),kl=-1),ll=!0;var w=B;try{a:{for(Bl(S),E=O(T);E!==null&&!(E.expirationTime>S&&Ma());){var al=E.callback;if(typeof al=="function"){E.callback=null,B=E.priorityLevel;var $=al(E.expirationTime<=S);if(S=d.unstable_now(),typeof $=="function"){E.callback=$,Bl(S),A=!0;break a}E===O(T)&&g(T),Bl(S)}else g(T);E=O(T)}if(E!==null)A=!0;else{var zl=O(v);zl!==null&&Kl(jl,zl.startTime-S),A=!1}}break l}finally{E=null,B=w,ll=!1}A=void 0}}finally{A?Nl():Ol=!1}}}var Nl;if(typeof nl=="function")Nl=function(){nl(ta)};else if(typeof MessageChannel<"u"){var ka=new MessageChannel,Va=ka.port2;ka.port1.onmessage=ta,Nl=function(){Va.postMessage(null)}}else Nl=function(){rl(ta,0)};function Kl(S,A){kl=rl(function(){S(d.unstable_now())},A)}d.unstable_IdlePriority=5,d.unstable_ImmediatePriority=1,d.unstable_LowPriority=4,d.unstable_NormalPriority=3,d.unstable_Profiling=null,d.unstable_UserBlockingPriority=2,d.unstable_cancelCallback=function(S){S.callback=null},d.unstable_forceFrameRate=function(S){0>S||125<S?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):Sl=0<S?Math.floor(1e3/S):5},d.unstable_getCurrentPriorityLevel=function(){return B},d.unstable_next=function(S){switch(B){case 1:case 2:case 3:var A=3;break;default:A=B}var w=B;B=A;try{return S()}finally{B=w}},d.unstable_requestPaint=function(){sl=!0},d.unstable_runWithPriority=function(S,A){switch(S){case 1:case 2:case 3:case 4:case 5:break;default:S=3}var w=B;B=S;try{return A()}finally{B=w}},d.unstable_scheduleCallback=function(S,A,w){var al=d.unstable_now();switch(typeof w=="object"&&w!==null?(w=w.delay,w=typeof w=="number"&&0<w?al+w:al):w=al,S){case 1:var $=-1;break;case 2:$=250;break;case 5:$=1073741823;break;case 4:$=1e4;break;default:$=5e3}return $=w+$,S={id:C++,callback:A,priorityLevel:S,startTime:w,expirationTime:$,sortIndex:-1},w>al?(S.sortIndex=w,c(v,S),O(T)===null&&S===O(v)&&(W?(gl(kl),kl=-1):W=!0,Kl(jl,w-al))):(S.sortIndex=$,c(T,S),J||ll||(J=!0,Ol||(Ol=!0,Nl()))),S},d.unstable_shouldYield=Ma,d.unstable_wrapCallback=function(S){var A=B;return function(){var w=B;B=A;try{return S.apply(this,arguments)}finally{B=w}}}})(Df)),Df}var Ud;function dm(){return Ud||(Ud=1,Nf.exports=om()),Nf.exports}var jf={exports:{}},Xl={};/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Cd;function mm(){if(Cd)return Xl;Cd=1;var d=Bf();function c(T){var v="https://react.dev/errors/"+T;if(1<arguments.length){v+="?args[]="+encodeURIComponent(arguments[1]);for(var C=2;C<arguments.length;C++)v+="&args[]="+encodeURIComponent(arguments[C])}return"Minified React error #"+T+"; visit "+v+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function O(){}var g={d:{f:O,r:function(){throw Error(c(522))},D:O,C:O,L:O,m:O,X:O,S:O,M:O},p:0,findDOMNode:null},j=Symbol.for("react.portal");function H(T,v,C){var E=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:j,key:E==null?null:""+E,children:T,containerInfo:v,implementation:C}}var V=d.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function R(T,v){if(T==="font")return"";if(typeof v=="string")return v==="use-credentials"?v:""}return Xl.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=g,Xl.createPortal=function(T,v){var C=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!v||v.nodeType!==1&&v.nodeType!==9&&v.nodeType!==11)throw Error(c(299));return H(T,v,null,C)},Xl.flushSync=function(T){var v=V.T,C=g.p;try{if(V.T=null,g.p=2,T)return T()}finally{V.T=v,g.p=C,g.d.f()}},Xl.preconnect=function(T,v){typeof T=="string"&&(v?(v=v.crossOrigin,v=typeof v=="string"?v==="use-credentials"?v:"":void 0):v=null,g.d.C(T,v))},Xl.prefetchDNS=function(T){typeof T=="string"&&g.d.D(T)},Xl.preinit=function(T,v){if(typeof T=="string"&&v&&typeof v.as=="string"){var C=v.as,E=R(C,v.crossOrigin),B=typeof v.integrity=="string"?v.integrity:void 0,ll=typeof v.fetchPriority=="string"?v.fetchPriority:void 0;C==="style"?g.d.S(T,typeof v.precedence=="string"?v.precedence:void 0,{crossOrigin:E,integrity:B,fetchPriority:ll}):C==="script"&&g.d.X(T,{crossOrigin:E,integrity:B,fetchPriority:ll,nonce:typeof v.nonce=="string"?v.nonce:void 0})}},Xl.preinitModule=function(T,v){if(typeof T=="string")if(typeof v=="object"&&v!==null){if(v.as==null||v.as==="script"){var C=R(v.as,v.crossOrigin);g.d.M(T,{crossOrigin:C,integrity:typeof v.integrity=="string"?v.integrity:void 0,nonce:typeof v.nonce=="string"?v.nonce:void 0})}}else v==null&&g.d.M(T)},Xl.preload=function(T,v){if(typeof T=="string"&&typeof v=="object"&&v!==null&&typeof v.as=="string"){var C=v.as,E=R(C,v.crossOrigin);g.d.L(T,C,{crossOrigin:E,integrity:typeof v.integrity=="string"?v.integrity:void 0,nonce:typeof v.nonce=="string"?v.nonce:void 0,type:typeof v.type=="string"?v.type:void 0,fetchPriority:typeof v.fetchPriority=="string"?v.fetchPriority:void 0,referrerPolicy:typeof v.referrerPolicy=="string"?v.referrerPolicy:void 0,imageSrcSet:typeof v.imageSrcSet=="string"?v.imageSrcSet:void 0,imageSizes:typeof v.imageSizes=="string"?v.imageSizes:void 0,media:typeof v.media=="string"?v.media:void 0})}},Xl.preloadModule=function(T,v){if(typeof T=="string")if(v){var C=R(v.as,v.crossOrigin);g.d.m(T,{as:typeof v.as=="string"&&v.as!=="script"?v.as:void 0,crossOrigin:C,integrity:typeof v.integrity=="string"?v.integrity:void 0})}else g.d.m(T)},Xl.requestFormReset=function(T){g.d.r(T)},Xl.unstable_batchedUpdates=function(T,v){return T(v)},Xl.useFormState=function(T,v,C){return V.H.useFormState(T,v,C)},Xl.useFormStatus=function(){return V.H.useHostTransitionStatus()},Xl.version="19.2.5",Xl}var Hd;function gm(){if(Hd)return jf.exports;Hd=1;function d(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(d)}catch(c){console.error(c)}}return d(),jf.exports=mm(),jf.exports}/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Bd;function hm(){if(Bd)return ai;Bd=1;var d=dm(),c=Bf(),O=gm();function g(l){var a="https://react.dev/errors/"+l;if(1<arguments.length){a+="?args[]="+encodeURIComponent(arguments[1]);for(var t=2;t<arguments.length;t++)a+="&args[]="+encodeURIComponent(arguments[t])}return"Minified React error #"+l+"; visit "+a+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function j(l){return!(!l||l.nodeType!==1&&l.nodeType!==9&&l.nodeType!==11)}function H(l){var a=l,t=l;if(l.alternate)for(;a.return;)a=a.return;else{l=a;do a=l,(a.flags&4098)!==0&&(t=a.return),l=a.return;while(l)}return a.tag===3?t:null}function V(l){if(l.tag===13){var a=l.memoizedState;if(a===null&&(l=l.alternate,l!==null&&(a=l.memoizedState)),a!==null)return a.dehydrated}return null}function R(l){if(l.tag===31){var a=l.memoizedState;if(a===null&&(l=l.alternate,l!==null&&(a=l.memoizedState)),a!==null)return a.dehydrated}return null}function T(l){if(H(l)!==l)throw Error(g(188))}function v(l){var a=l.alternate;if(!a){if(a=H(l),a===null)throw Error(g(188));return a!==l?null:l}for(var t=l,e=a;;){var n=t.return;if(n===null)break;var i=n.alternate;if(i===null){if(e=n.return,e!==null){t=e;continue}break}if(n.child===i.child){for(i=n.child;i;){if(i===t)return T(n),l;if(i===e)return T(n),a;i=i.sibling}throw Error(g(188))}if(t.return!==e.return)t=n,e=i;else{for(var u=!1,f=n.child;f;){if(f===t){u=!0,t=n,e=i;break}if(f===e){u=!0,e=n,t=i;break}f=f.sibling}if(!u){for(f=i.child;f;){if(f===t){u=!0,t=i,e=n;break}if(f===e){u=!0,e=i,t=n;break}f=f.sibling}if(!u)throw Error(g(189))}}if(t.alternate!==e)throw Error(g(190))}if(t.tag!==3)throw Error(g(188));return t.stateNode.current===t?l:a}function C(l){var a=l.tag;if(a===5||a===26||a===27||a===6)return l;for(l=l.child;l!==null;){if(a=C(l),a!==null)return a;l=l.sibling}return null}var E=Object.assign,B=Symbol.for("react.element"),ll=Symbol.for("react.transitional.element"),J=Symbol.for("react.portal"),W=Symbol.for("react.fragment"),sl=Symbol.for("react.strict_mode"),rl=Symbol.for("react.profiler"),gl=Symbol.for("react.consumer"),nl=Symbol.for("react.context"),Bl=Symbol.for("react.forward_ref"),jl=Symbol.for("react.suspense"),Ol=Symbol.for("react.suspense_list"),kl=Symbol.for("react.memo"),Sl=Symbol.for("react.lazy"),Vl=Symbol.for("react.activity"),Ma=Symbol.for("react.memo_cache_sentinel"),ta=Symbol.iterator;function Nl(l){return l===null||typeof l!="object"?null:(l=ta&&l[ta]||l["@@iterator"],typeof l=="function"?l:null)}var ka=Symbol.for("react.client.reference");function Va(l){if(l==null)return null;if(typeof l=="function")return l.$$typeof===ka?null:l.displayName||l.name||null;if(typeof l=="string")return l;switch(l){case W:return"Fragment";case rl:return"Profiler";case sl:return"StrictMode";case jl:return"Suspense";case Ol:return"SuspenseList";case Vl:return"Activity"}if(typeof l=="object")switch(l.$$typeof){case J:return"Portal";case nl:return l.displayName||"Context";case gl:return(l._context.displayName||"Context")+".Consumer";case Bl:var a=l.render;return l=l.displayName,l||(l=a.displayName||a.name||"",l=l!==""?"ForwardRef("+l+")":"ForwardRef"),l;case kl:return a=l.displayName||null,a!==null?a:Va(l.type)||"Memo";case Sl:a=l._payload,l=l._init;try{return Va(l(a))}catch{}}return null}var Kl=Array.isArray,S=c.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,A=O.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,w={pending:!1,data:null,method:null,action:null},al=[],$=-1;function zl(l){return{current:l}}function il(l){0>$||(l.current=al[$],al[$]=null,$--)}function Z(l,a){$++,al[$]=l.current,l.current=a}var pl=zl(null),Zl=zl(null),ea=zl(null),Oa=zl(null);function Za(l,a){switch(Z(ea,a),Z(Zl,l),Z(pl,null),a.nodeType){case 9:case 11:l=(l=a.documentElement)&&(l=l.namespaceURI)?ad(l):0;break;default:if(l=a.tagName,a=a.namespaceURI)a=ad(a),l=td(a,l);else switch(l){case"svg":l=1;break;case"math":l=2;break;default:l=0}}il(pl),Z(pl,l)}function na(){il(pl),il(Zl),il(ea)}function Ba(l){l.memoizedState!==null&&Z(Oa,l);var a=pl.current,t=td(a,l.type);a!==t&&(Z(Zl,l),Z(pl,t))}function Na(l){Zl.current===l&&(il(pl),il(Zl)),Oa.current===l&&(il(Oa),Fn._currentValue=w)}var mt,Vt;function ga(l){if(mt===void 0)try{throw Error()}catch(t){var a=t.stack.trim().match(/\n( *(at )?)/);mt=a&&a[1]||"",Vt=-1<t.stack.indexOf(`
    at`)?" (<anonymous>)":-1<t.stack.indexOf("@")?"@unknown:0:0":""}return`
`+mt+l+Vt}var gt=!1;function ht(l,a){if(!l||gt)return"";gt=!0;var t=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var e={DetermineComponentFrameRoot:function(){try{if(a){var _=function(){throw Error()};if(Object.defineProperty(_.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(_,[])}catch(b){var y=b}Reflect.construct(l,[],_)}else{try{_.call()}catch(b){y=b}l.call(_.prototype)}}else{try{throw Error()}catch(b){y=b}(_=l())&&typeof _.catch=="function"&&_.catch(function(){})}}catch(b){if(b&&y&&typeof b.stack=="string")return[b.stack,y.stack]}return[null,null]}};e.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var n=Object.getOwnPropertyDescriptor(e.DetermineComponentFrameRoot,"name");n&&n.configurable&&Object.defineProperty(e.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var i=e.DetermineComponentFrameRoot(),u=i[0],f=i[1];if(u&&f){var s=u.split(`
`),p=f.split(`
`);for(n=e=0;e<s.length&&!s[e].includes("DetermineComponentFrameRoot");)e++;for(;n<p.length&&!p[n].includes("DetermineComponentFrameRoot");)n++;if(e===s.length||n===p.length)for(e=s.length-1,n=p.length-1;1<=e&&0<=n&&s[e]!==p[n];)n--;for(;1<=e&&0<=n;e--,n--)if(s[e]!==p[n]){if(e!==1||n!==1)do if(e--,n--,0>n||s[e]!==p[n]){var x=`
`+s[e].replace(" at new "," at ");return l.displayName&&x.includes("<anonymous>")&&(x=x.replace("<anonymous>",l.displayName)),x}while(1<=e&&0<=n);break}}}finally{gt=!1,Error.prepareStackTrace=t}return(t=l?l.displayName||l.name:"")?ga(t):""}function me(l,a){switch(l.tag){case 26:case 27:case 5:return ga(l.type);case 16:return ga("Lazy");case 13:return l.child!==a&&a!==null?ga("Suspense Fallback"):ga("Suspense");case 19:return ga("SuspenseList");case 0:case 15:return ht(l.type,!1);case 11:return ht(l.type.render,!1);case 1:return ht(l.type,!0);case 31:return ga("Activity");default:return""}}function Zt(l){try{var a="",t=null;do a+=me(l,t),t=l,l=l.return;while(l);return a}catch(e){return`
Error generating stack: `+e.message+`
`+e.stack}}var pt=Object.prototype.hasOwnProperty,yt=d.unstable_scheduleCallback,bt=d.unstable_cancelCallback,ge=d.unstable_shouldYield,he=d.unstable_requestPaint,wl=d.unstable_now,pe=d.unstable_getCurrentPriorityLevel,Lt=d.unstable_ImmediatePriority,Kt=d.unstable_UserBlockingPriority,La=d.unstable_NormalPriority,ye=d.unstable_LowPriority,Jt=d.unstable_IdlePriority,be=d.log,ve=d.unstable_setDisableYieldValue,ha=null,_l=null;function ia(l){if(typeof be=="function"&&ve(l),_l&&typeof _l.setStrictMode=="function")try{_l.setStrictMode(ha,l)}catch{}}var Ul=Math.clz32?Math.clz32:ze,xe=Math.log,Se=Math.LN2;function ze(l){return l>>>=0,l===0?32:31-(xe(l)/Se|0)|0}var Da=256,ja=262144,wa=4194304;function pa(l){var a=l&42;if(a!==0)return a;switch(l&-l){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return l&261888;case 262144:case 524288:case 1048576:case 2097152:return l&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return l&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return l}}function Ka(l,a,t){var e=l.pendingLanes;if(e===0)return 0;var n=0,i=l.suspendedLanes,u=l.pingedLanes;l=l.warmLanes;var f=e&134217727;return f!==0?(e=f&~i,e!==0?n=pa(e):(u&=f,u!==0?n=pa(u):t||(t=f&~l,t!==0&&(n=pa(t))))):(f=e&~i,f!==0?n=pa(f):u!==0?n=pa(u):t||(t=e&~l,t!==0&&(n=pa(t)))),n===0?0:a!==0&&a!==n&&(a&i)===0&&(i=n&-n,t=a&-a,i>=t||i===32&&(t&4194048)!==0)?a:n}function qa(l,a){return(l.pendingLanes&~(l.suspendedLanes&~l.pingedLanes)&a)===0}function _e(l,a){switch(l){case 1:case 2:case 4:case 8:case 64:return a+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return a+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Wt(){var l=wa;return wa<<=1,(wa&62914560)===0&&(wa=4194304),l}function vt(l){for(var a=[],t=0;31>t;t++)a.push(l);return a}function Ra(l,a){l.pendingLanes|=a,a!==268435456&&(l.suspendedLanes=0,l.pingedLanes=0,l.warmLanes=0)}function ti(l,a,t,e,n,i){var u=l.pendingLanes;l.pendingLanes=t,l.suspendedLanes=0,l.pingedLanes=0,l.warmLanes=0,l.expiredLanes&=t,l.entangledLanes&=t,l.errorRecoveryDisabledLanes&=t,l.shellSuspendCounter=0;var f=l.entanglements,s=l.expirationTimes,p=l.hiddenUpdates;for(t=u&~t;0<t;){var x=31-Ul(t),_=1<<x;f[x]=0,s[x]=-1;var y=p[x];if(y!==null)for(p[x]=null,x=0;x<y.length;x++){var b=y[x];b!==null&&(b.lane&=-536870913)}t&=~_}e!==0&&Ja(l,e,0),i!==0&&n===0&&l.tag!==0&&(l.suspendedLanes|=i&~(u&~a))}function Ja(l,a,t){l.pendingLanes|=a,l.suspendedLanes&=~a;var e=31-Ul(a);l.entangledLanes|=a,l.entanglements[e]=l.entanglements[e]|1073741824|t&261930}function qf(l,a){var t=l.entangledLanes|=a;for(l=l.entanglements;t;){var e=31-Ul(t),n=1<<e;n&a|l[e]&a&&(l[e]|=a),t&=~n}}function Rf(l,a){var t=a&-a;return t=(t&42)!==0?1:pu(t),(t&(l.suspendedLanes|a))!==0?0:t}function pu(l){switch(l){case 2:l=1;break;case 8:l=4;break;case 32:l=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:l=128;break;case 268435456:l=134217728;break;default:l=0}return l}function yu(l){return l&=-l,2<l?8<l?(l&134217727)!==0?32:268435456:8:2}function Yf(){var l=A.p;return l!==0?l:(l=window.event,l===void 0?32:Ed(l.type))}function Gf(l,a){var t=A.p;try{return A.p=l,a()}finally{A.p=t}}var xt=Math.random().toString(36).slice(2),ql="__reactFiber$"+xt,Jl="__reactProps$"+xt,Ae="__reactContainer$"+xt,bu="__reactEvents$"+xt,Id="__reactListeners$"+xt,Pd="__reactHandles$"+xt,Qf="__reactResources$"+xt,dn="__reactMarker$"+xt;function vu(l){delete l[ql],delete l[Jl],delete l[bu],delete l[Id],delete l[Pd]}function Ee(l){var a=l[ql];if(a)return a;for(var t=l.parentNode;t;){if(a=t[Ae]||t[ql]){if(t=a.alternate,a.child!==null||t!==null&&t.child!==null)for(l=sd(l);l!==null;){if(t=l[ql])return t;l=sd(l)}return a}l=t,t=l.parentNode}return null}function Te(l){if(l=l[ql]||l[Ae]){var a=l.tag;if(a===5||a===6||a===13||a===31||a===26||a===27||a===3)return l}return null}function mn(l){var a=l.tag;if(a===5||a===26||a===27||a===6)return l.stateNode;throw Error(g(33))}function Me(l){var a=l[Qf];return a||(a=l[Qf]={hoistableStyles:new Map,hoistableScripts:new Map}),a}function Cl(l){l[dn]=!0}var Xf=new Set,kf={};function $t(l,a){Oe(l,a),Oe(l+"Capture",a)}function Oe(l,a){for(kf[l]=a,l=0;l<a.length;l++)Xf.add(a[l])}var l0=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),Vf={},Zf={};function a0(l){return pt.call(Zf,l)?!0:pt.call(Vf,l)?!1:l0.test(l)?Zf[l]=!0:(Vf[l]=!0,!1)}function ei(l,a,t){if(a0(a))if(t===null)l.removeAttribute(a);else{switch(typeof t){case"undefined":case"function":case"symbol":l.removeAttribute(a);return;case"boolean":var e=a.toLowerCase().slice(0,5);if(e!=="data-"&&e!=="aria-"){l.removeAttribute(a);return}}l.setAttribute(a,""+t)}}function ni(l,a,t){if(t===null)l.removeAttribute(a);else{switch(typeof t){case"undefined":case"function":case"symbol":case"boolean":l.removeAttribute(a);return}l.setAttribute(a,""+t)}}function Wa(l,a,t,e){if(e===null)l.removeAttribute(t);else{switch(typeof e){case"undefined":case"function":case"symbol":case"boolean":l.removeAttribute(t);return}l.setAttributeNS(a,t,""+e)}}function ya(l){switch(typeof l){case"bigint":case"boolean":case"number":case"string":case"undefined":return l;case"object":return l;default:return""}}function Lf(l){var a=l.type;return(l=l.nodeName)&&l.toLowerCase()==="input"&&(a==="checkbox"||a==="radio")}function t0(l,a,t){var e=Object.getOwnPropertyDescriptor(l.constructor.prototype,a);if(!l.hasOwnProperty(a)&&typeof e<"u"&&typeof e.get=="function"&&typeof e.set=="function"){var n=e.get,i=e.set;return Object.defineProperty(l,a,{configurable:!0,get:function(){return n.call(this)},set:function(u){t=""+u,i.call(this,u)}}),Object.defineProperty(l,a,{enumerable:e.enumerable}),{getValue:function(){return t},setValue:function(u){t=""+u},stopTracking:function(){l._valueTracker=null,delete l[a]}}}}function xu(l){if(!l._valueTracker){var a=Lf(l)?"checked":"value";l._valueTracker=t0(l,a,""+l[a])}}function Kf(l){if(!l)return!1;var a=l._valueTracker;if(!a)return!0;var t=a.getValue(),e="";return l&&(e=Lf(l)?l.checked?"true":"false":l.value),l=e,l!==t?(a.setValue(l),!0):!1}function ii(l){if(l=l||(typeof document<"u"?document:void 0),typeof l>"u")return null;try{return l.activeElement||l.body}catch{return l.body}}var e0=/[\n"\\]/g;function ba(l){return l.replace(e0,function(a){return"\\"+a.charCodeAt(0).toString(16)+" "})}function Su(l,a,t,e,n,i,u,f){l.name="",u!=null&&typeof u!="function"&&typeof u!="symbol"&&typeof u!="boolean"?l.type=u:l.removeAttribute("type"),a!=null?u==="number"?(a===0&&l.value===""||l.value!=a)&&(l.value=""+ya(a)):l.value!==""+ya(a)&&(l.value=""+ya(a)):u!=="submit"&&u!=="reset"||l.removeAttribute("value"),a!=null?zu(l,u,ya(a)):t!=null?zu(l,u,ya(t)):e!=null&&l.removeAttribute("value"),n==null&&i!=null&&(l.defaultChecked=!!i),n!=null&&(l.checked=n&&typeof n!="function"&&typeof n!="symbol"),f!=null&&typeof f!="function"&&typeof f!="symbol"&&typeof f!="boolean"?l.name=""+ya(f):l.removeAttribute("name")}function Jf(l,a,t,e,n,i,u,f){if(i!=null&&typeof i!="function"&&typeof i!="symbol"&&typeof i!="boolean"&&(l.type=i),a!=null||t!=null){if(!(i!=="submit"&&i!=="reset"||a!=null)){xu(l);return}t=t!=null?""+ya(t):"",a=a!=null?""+ya(a):t,f||a===l.value||(l.value=a),l.defaultValue=a}e=e??n,e=typeof e!="function"&&typeof e!="symbol"&&!!e,l.checked=f?l.checked:!!e,l.defaultChecked=!!e,u!=null&&typeof u!="function"&&typeof u!="symbol"&&typeof u!="boolean"&&(l.name=u),xu(l)}function zu(l,a,t){a==="number"&&ii(l.ownerDocument)===l||l.defaultValue===""+t||(l.defaultValue=""+t)}function Ne(l,a,t,e){if(l=l.options,a){a={};for(var n=0;n<t.length;n++)a["$"+t[n]]=!0;for(t=0;t<l.length;t++)n=a.hasOwnProperty("$"+l[t].value),l[t].selected!==n&&(l[t].selected=n),n&&e&&(l[t].defaultSelected=!0)}else{for(t=""+ya(t),a=null,n=0;n<l.length;n++){if(l[n].value===t){l[n].selected=!0,e&&(l[n].defaultSelected=!0);return}a!==null||l[n].disabled||(a=l[n])}a!==null&&(a.selected=!0)}}function Wf(l,a,t){if(a!=null&&(a=""+ya(a),a!==l.value&&(l.value=a),t==null)){l.defaultValue!==a&&(l.defaultValue=a);return}l.defaultValue=t!=null?""+ya(t):""}function $f(l,a,t,e){if(a==null){if(e!=null){if(t!=null)throw Error(g(92));if(Kl(e)){if(1<e.length)throw Error(g(93));e=e[0]}t=e}t==null&&(t=""),a=t}t=ya(a),l.defaultValue=t,e=l.textContent,e===t&&e!==""&&e!==null&&(l.value=e),xu(l)}function De(l,a){if(a){var t=l.firstChild;if(t&&t===l.lastChild&&t.nodeType===3){t.nodeValue=a;return}}l.textContent=a}var n0=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function Ff(l,a,t){var e=a.indexOf("--")===0;t==null||typeof t=="boolean"||t===""?e?l.setProperty(a,""):a==="float"?l.cssFloat="":l[a]="":e?l.setProperty(a,t):typeof t!="number"||t===0||n0.has(a)?a==="float"?l.cssFloat=t:l[a]=(""+t).trim():l[a]=t+"px"}function If(l,a,t){if(a!=null&&typeof a!="object")throw Error(g(62));if(l=l.style,t!=null){for(var e in t)!t.hasOwnProperty(e)||a!=null&&a.hasOwnProperty(e)||(e.indexOf("--")===0?l.setProperty(e,""):e==="float"?l.cssFloat="":l[e]="");for(var n in a)e=a[n],a.hasOwnProperty(n)&&t[n]!==e&&Ff(l,n,e)}else for(var i in a)a.hasOwnProperty(i)&&Ff(l,i,a[i])}function _u(l){if(l.indexOf("-")===-1)return!1;switch(l){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var i0=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),u0=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function ui(l){return u0.test(""+l)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":l}function $a(){}var Au=null;function Eu(l){return l=l.target||l.srcElement||window,l.correspondingUseElement&&(l=l.correspondingUseElement),l.nodeType===3?l.parentNode:l}var je=null,we=null;function Pf(l){var a=Te(l);if(a&&(l=a.stateNode)){var t=l[Jl]||null;l:switch(l=a.stateNode,a.type){case"input":if(Su(l,t.value,t.defaultValue,t.defaultValue,t.checked,t.defaultChecked,t.type,t.name),a=t.name,t.type==="radio"&&a!=null){for(t=l;t.parentNode;)t=t.parentNode;for(t=t.querySelectorAll('input[name="'+ba(""+a)+'"][type="radio"]'),a=0;a<t.length;a++){var e=t[a];if(e!==l&&e.form===l.form){var n=e[Jl]||null;if(!n)throw Error(g(90));Su(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name)}}for(a=0;a<t.length;a++)e=t[a],e.form===l.form&&Kf(e)}break l;case"textarea":Wf(l,t.value,t.defaultValue);break l;case"select":a=t.value,a!=null&&Ne(l,!!t.multiple,a,!1)}}}var Tu=!1;function ls(l,a,t){if(Tu)return l(a,t);Tu=!0;try{var e=l(a);return e}finally{if(Tu=!1,(je!==null||we!==null)&&(Ki(),je&&(a=je,l=we,we=je=null,Pf(a),l)))for(a=0;a<l.length;a++)Pf(l[a])}}function gn(l,a){var t=l.stateNode;if(t===null)return null;var e=t[Jl]||null;if(e===null)return null;t=e[a];l:switch(a){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(e=!e.disabled)||(l=l.type,e=!(l==="button"||l==="input"||l==="select"||l==="textarea")),l=!e;break l;default:l=!1}if(l)return null;if(t&&typeof t!="function")throw Error(g(231,a,typeof t));return t}var Fa=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Mu=!1;if(Fa)try{var hn={};Object.defineProperty(hn,"passive",{get:function(){Mu=!0}}),window.addEventListener("test",hn,hn),window.removeEventListener("test",hn,hn)}catch{Mu=!1}var St=null,Ou=null,ci=null;function as(){if(ci)return ci;var l,a=Ou,t=a.length,e,n="value"in St?St.value:St.textContent,i=n.length;for(l=0;l<t&&a[l]===n[l];l++);var u=t-l;for(e=1;e<=u&&a[t-e]===n[i-e];e++);return ci=n.slice(l,1<e?1-e:void 0)}function fi(l){var a=l.keyCode;return"charCode"in l?(l=l.charCode,l===0&&a===13&&(l=13)):l=a,l===10&&(l=13),32<=l||l===13?l:0}function si(){return!0}function ts(){return!1}function Wl(l){function a(t,e,n,i,u){this._reactName=t,this._targetInst=n,this.type=e,this.nativeEvent=i,this.target=u,this.currentTarget=null;for(var f in l)l.hasOwnProperty(f)&&(t=l[f],this[f]=t?t(i):i[f]);return this.isDefaultPrevented=(i.defaultPrevented!=null?i.defaultPrevented:i.returnValue===!1)?si:ts,this.isPropagationStopped=ts,this}return E(a.prototype,{preventDefault:function(){this.defaultPrevented=!0;var t=this.nativeEvent;t&&(t.preventDefault?t.preventDefault():typeof t.returnValue!="unknown"&&(t.returnValue=!1),this.isDefaultPrevented=si)},stopPropagation:function(){var t=this.nativeEvent;t&&(t.stopPropagation?t.stopPropagation():typeof t.cancelBubble!="unknown"&&(t.cancelBubble=!0),this.isPropagationStopped=si)},persist:function(){},isPersistent:si}),a}var Ft={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(l){return l.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},ri=Wl(Ft),pn=E({},Ft,{view:0,detail:0}),c0=Wl(pn),Nu,Du,yn,oi=E({},pn,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:wu,button:0,buttons:0,relatedTarget:function(l){return l.relatedTarget===void 0?l.fromElement===l.srcElement?l.toElement:l.fromElement:l.relatedTarget},movementX:function(l){return"movementX"in l?l.movementX:(l!==yn&&(yn&&l.type==="mousemove"?(Nu=l.screenX-yn.screenX,Du=l.screenY-yn.screenY):Du=Nu=0,yn=l),Nu)},movementY:function(l){return"movementY"in l?l.movementY:Du}}),es=Wl(oi),f0=E({},oi,{dataTransfer:0}),s0=Wl(f0),r0=E({},pn,{relatedTarget:0}),ju=Wl(r0),o0=E({},Ft,{animationName:0,elapsedTime:0,pseudoElement:0}),d0=Wl(o0),m0=E({},Ft,{clipboardData:function(l){return"clipboardData"in l?l.clipboardData:window.clipboardData}}),g0=Wl(m0),h0=E({},Ft,{data:0}),ns=Wl(h0),p0={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},y0={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},b0={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function v0(l){var a=this.nativeEvent;return a.getModifierState?a.getModifierState(l):(l=b0[l])?!!a[l]:!1}function wu(){return v0}var x0=E({},pn,{key:function(l){if(l.key){var a=p0[l.key]||l.key;if(a!=="Unidentified")return a}return l.type==="keypress"?(l=fi(l),l===13?"Enter":String.fromCharCode(l)):l.type==="keydown"||l.type==="keyup"?y0[l.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:wu,charCode:function(l){return l.type==="keypress"?fi(l):0},keyCode:function(l){return l.type==="keydown"||l.type==="keyup"?l.keyCode:0},which:function(l){return l.type==="keypress"?fi(l):l.type==="keydown"||l.type==="keyup"?l.keyCode:0}}),S0=Wl(x0),z0=E({},oi,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),is=Wl(z0),_0=E({},pn,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:wu}),A0=Wl(_0),E0=E({},Ft,{propertyName:0,elapsedTime:0,pseudoElement:0}),T0=Wl(E0),M0=E({},oi,{deltaX:function(l){return"deltaX"in l?l.deltaX:"wheelDeltaX"in l?-l.wheelDeltaX:0},deltaY:function(l){return"deltaY"in l?l.deltaY:"wheelDeltaY"in l?-l.wheelDeltaY:"wheelDelta"in l?-l.wheelDelta:0},deltaZ:0,deltaMode:0}),O0=Wl(M0),N0=E({},Ft,{newState:0,oldState:0}),D0=Wl(N0),j0=[9,13,27,32],Uu=Fa&&"CompositionEvent"in window,bn=null;Fa&&"documentMode"in document&&(bn=document.documentMode);var w0=Fa&&"TextEvent"in window&&!bn,us=Fa&&(!Uu||bn&&8<bn&&11>=bn),cs=" ",fs=!1;function ss(l,a){switch(l){case"keyup":return j0.indexOf(a.keyCode)!==-1;case"keydown":return a.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function rs(l){return l=l.detail,typeof l=="object"&&"data"in l?l.data:null}var Ue=!1;function U0(l,a){switch(l){case"compositionend":return rs(a);case"keypress":return a.which!==32?null:(fs=!0,cs);case"textInput":return l=a.data,l===cs&&fs?null:l;default:return null}}function C0(l,a){if(Ue)return l==="compositionend"||!Uu&&ss(l,a)?(l=as(),ci=Ou=St=null,Ue=!1,l):null;switch(l){case"paste":return null;case"keypress":if(!(a.ctrlKey||a.altKey||a.metaKey)||a.ctrlKey&&a.altKey){if(a.char&&1<a.char.length)return a.char;if(a.which)return String.fromCharCode(a.which)}return null;case"compositionend":return us&&a.locale!=="ko"?null:a.data;default:return null}}var H0={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function os(l){var a=l&&l.nodeName&&l.nodeName.toLowerCase();return a==="input"?!!H0[l.type]:a==="textarea"}function ds(l,a,t,e){je?we?we.push(e):we=[e]:je=e,a=lu(a,"onChange"),0<a.length&&(t=new ri("onChange","change",null,t,e),l.push({event:t,listeners:a}))}var vn=null,xn=null;function B0(l){Wo(l,0)}function di(l){var a=mn(l);if(Kf(a))return l}function ms(l,a){if(l==="change")return a}var gs=!1;if(Fa){var Cu;if(Fa){var Hu="oninput"in document;if(!Hu){var hs=document.createElement("div");hs.setAttribute("oninput","return;"),Hu=typeof hs.oninput=="function"}Cu=Hu}else Cu=!1;gs=Cu&&(!document.documentMode||9<document.documentMode)}function ps(){vn&&(vn.detachEvent("onpropertychange",ys),xn=vn=null)}function ys(l){if(l.propertyName==="value"&&di(xn)){var a=[];ds(a,xn,l,Eu(l)),ls(B0,a)}}function q0(l,a,t){l==="focusin"?(ps(),vn=a,xn=t,vn.attachEvent("onpropertychange",ys)):l==="focusout"&&ps()}function R0(l){if(l==="selectionchange"||l==="keyup"||l==="keydown")return di(xn)}function Y0(l,a){if(l==="click")return di(a)}function G0(l,a){if(l==="input"||l==="change")return di(a)}function Q0(l,a){return l===a&&(l!==0||1/l===1/a)||l!==l&&a!==a}var ua=typeof Object.is=="function"?Object.is:Q0;function Sn(l,a){if(ua(l,a))return!0;if(typeof l!="object"||l===null||typeof a!="object"||a===null)return!1;var t=Object.keys(l),e=Object.keys(a);if(t.length!==e.length)return!1;for(e=0;e<t.length;e++){var n=t[e];if(!pt.call(a,n)||!ua(l[n],a[n]))return!1}return!0}function bs(l){for(;l&&l.firstChild;)l=l.firstChild;return l}function vs(l,a){var t=bs(l);l=0;for(var e;t;){if(t.nodeType===3){if(e=l+t.textContent.length,l<=a&&e>=a)return{node:t,offset:a-l};l=e}l:{for(;t;){if(t.nextSibling){t=t.nextSibling;break l}t=t.parentNode}t=void 0}t=bs(t)}}function xs(l,a){return l&&a?l===a?!0:l&&l.nodeType===3?!1:a&&a.nodeType===3?xs(l,a.parentNode):"contains"in l?l.contains(a):l.compareDocumentPosition?!!(l.compareDocumentPosition(a)&16):!1:!1}function Ss(l){l=l!=null&&l.ownerDocument!=null&&l.ownerDocument.defaultView!=null?l.ownerDocument.defaultView:window;for(var a=ii(l.document);a instanceof l.HTMLIFrameElement;){try{var t=typeof a.contentWindow.location.href=="string"}catch{t=!1}if(t)l=a.contentWindow;else break;a=ii(l.document)}return a}function Bu(l){var a=l&&l.nodeName&&l.nodeName.toLowerCase();return a&&(a==="input"&&(l.type==="text"||l.type==="search"||l.type==="tel"||l.type==="url"||l.type==="password")||a==="textarea"||l.contentEditable==="true")}var X0=Fa&&"documentMode"in document&&11>=document.documentMode,Ce=null,qu=null,zn=null,Ru=!1;function zs(l,a,t){var e=t.window===t?t.document:t.nodeType===9?t:t.ownerDocument;Ru||Ce==null||Ce!==ii(e)||(e=Ce,"selectionStart"in e&&Bu(e)?e={start:e.selectionStart,end:e.selectionEnd}:(e=(e.ownerDocument&&e.ownerDocument.defaultView||window).getSelection(),e={anchorNode:e.anchorNode,anchorOffset:e.anchorOffset,focusNode:e.focusNode,focusOffset:e.focusOffset}),zn&&Sn(zn,e)||(zn=e,e=lu(qu,"onSelect"),0<e.length&&(a=new ri("onSelect","select",null,a,t),l.push({event:a,listeners:e}),a.target=Ce)))}function It(l,a){var t={};return t[l.toLowerCase()]=a.toLowerCase(),t["Webkit"+l]="webkit"+a,t["Moz"+l]="moz"+a,t}var He={animationend:It("Animation","AnimationEnd"),animationiteration:It("Animation","AnimationIteration"),animationstart:It("Animation","AnimationStart"),transitionrun:It("Transition","TransitionRun"),transitionstart:It("Transition","TransitionStart"),transitioncancel:It("Transition","TransitionCancel"),transitionend:It("Transition","TransitionEnd")},Yu={},_s={};Fa&&(_s=document.createElement("div").style,"AnimationEvent"in window||(delete He.animationend.animation,delete He.animationiteration.animation,delete He.animationstart.animation),"TransitionEvent"in window||delete He.transitionend.transition);function Pt(l){if(Yu[l])return Yu[l];if(!He[l])return l;var a=He[l],t;for(t in a)if(a.hasOwnProperty(t)&&t in _s)return Yu[l]=a[t];return l}var As=Pt("animationend"),Es=Pt("animationiteration"),Ts=Pt("animationstart"),k0=Pt("transitionrun"),V0=Pt("transitionstart"),Z0=Pt("transitioncancel"),Ms=Pt("transitionend"),Os=new Map,Gu="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");Gu.push("scrollEnd");function Ua(l,a){Os.set(l,a),$t(a,[l])}var mi=typeof reportError=="function"?reportError:function(l){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var a=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof l=="object"&&l!==null&&typeof l.message=="string"?String(l.message):String(l),error:l});if(!window.dispatchEvent(a))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",l);return}console.error(l)},va=[],Be=0,Qu=0;function gi(){for(var l=Be,a=Qu=Be=0;a<l;){var t=va[a];va[a++]=null;var e=va[a];va[a++]=null;var n=va[a];va[a++]=null;var i=va[a];if(va[a++]=null,e!==null&&n!==null){var u=e.pending;u===null?n.next=n:(n.next=u.next,u.next=n),e.pending=n}i!==0&&Ns(t,n,i)}}function hi(l,a,t,e){va[Be++]=l,va[Be++]=a,va[Be++]=t,va[Be++]=e,Qu|=e,l.lanes|=e,l=l.alternate,l!==null&&(l.lanes|=e)}function Xu(l,a,t,e){return hi(l,a,t,e),pi(l)}function le(l,a){return hi(l,null,null,a),pi(l)}function Ns(l,a,t){l.lanes|=t;var e=l.alternate;e!==null&&(e.lanes|=t);for(var n=!1,i=l.return;i!==null;)i.childLanes|=t,e=i.alternate,e!==null&&(e.childLanes|=t),i.tag===22&&(l=i.stateNode,l===null||l._visibility&1||(n=!0)),l=i,i=i.return;return l.tag===3?(i=l.stateNode,n&&a!==null&&(n=31-Ul(t),l=i.hiddenUpdates,e=l[n],e===null?l[n]=[a]:e.push(a),a.lane=t|536870912),i):null}function pi(l){if(50<Vn)throw Vn=0,Fc=null,Error(g(185));for(var a=l.return;a!==null;)l=a,a=l.return;return l.tag===3?l.stateNode:null}var qe={};function L0(l,a,t,e){this.tag=l,this.key=t,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=a,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=e,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function ca(l,a,t,e){return new L0(l,a,t,e)}function ku(l){return l=l.prototype,!(!l||!l.isReactComponent)}function Ia(l,a){var t=l.alternate;return t===null?(t=ca(l.tag,a,l.key,l.mode),t.elementType=l.elementType,t.type=l.type,t.stateNode=l.stateNode,t.alternate=l,l.alternate=t):(t.pendingProps=a,t.type=l.type,t.flags=0,t.subtreeFlags=0,t.deletions=null),t.flags=l.flags&65011712,t.childLanes=l.childLanes,t.lanes=l.lanes,t.child=l.child,t.memoizedProps=l.memoizedProps,t.memoizedState=l.memoizedState,t.updateQueue=l.updateQueue,a=l.dependencies,t.dependencies=a===null?null:{lanes:a.lanes,firstContext:a.firstContext},t.sibling=l.sibling,t.index=l.index,t.ref=l.ref,t.refCleanup=l.refCleanup,t}function Ds(l,a){l.flags&=65011714;var t=l.alternate;return t===null?(l.childLanes=0,l.lanes=a,l.child=null,l.subtreeFlags=0,l.memoizedProps=null,l.memoizedState=null,l.updateQueue=null,l.dependencies=null,l.stateNode=null):(l.childLanes=t.childLanes,l.lanes=t.lanes,l.child=t.child,l.subtreeFlags=0,l.deletions=null,l.memoizedProps=t.memoizedProps,l.memoizedState=t.memoizedState,l.updateQueue=t.updateQueue,l.type=t.type,a=t.dependencies,l.dependencies=a===null?null:{lanes:a.lanes,firstContext:a.firstContext}),l}function yi(l,a,t,e,n,i){var u=0;if(e=l,typeof l=="function")ku(l)&&(u=1);else if(typeof l=="string")u=F1(l,t,pl.current)?26:l==="html"||l==="head"||l==="body"?27:5;else l:switch(l){case Vl:return l=ca(31,t,a,n),l.elementType=Vl,l.lanes=i,l;case W:return ae(t.children,n,i,a);case sl:u=8,n|=24;break;case rl:return l=ca(12,t,a,n|2),l.elementType=rl,l.lanes=i,l;case jl:return l=ca(13,t,a,n),l.elementType=jl,l.lanes=i,l;case Ol:return l=ca(19,t,a,n),l.elementType=Ol,l.lanes=i,l;default:if(typeof l=="object"&&l!==null)switch(l.$$typeof){case nl:u=10;break l;case gl:u=9;break l;case Bl:u=11;break l;case kl:u=14;break l;case Sl:u=16,e=null;break l}u=29,t=Error(g(130,l===null?"null":typeof l,"")),e=null}return a=ca(u,t,a,n),a.elementType=l,a.type=e,a.lanes=i,a}function ae(l,a,t,e){return l=ca(7,l,e,a),l.lanes=t,l}function Vu(l,a,t){return l=ca(6,l,null,a),l.lanes=t,l}function js(l){var a=ca(18,null,null,0);return a.stateNode=l,a}function Zu(l,a,t){return a=ca(4,l.children!==null?l.children:[],l.key,a),a.lanes=t,a.stateNode={containerInfo:l.containerInfo,pendingChildren:null,implementation:l.implementation},a}var ws=new WeakMap;function xa(l,a){if(typeof l=="object"&&l!==null){var t=ws.get(l);return t!==void 0?t:(a={value:l,source:a,stack:Zt(a)},ws.set(l,a),a)}return{value:l,source:a,stack:Zt(a)}}var Re=[],Ye=0,bi=null,_n=0,Sa=[],za=0,zt=null,Ya=1,Ga="";function Pa(l,a){Re[Ye++]=_n,Re[Ye++]=bi,bi=l,_n=a}function Us(l,a,t){Sa[za++]=Ya,Sa[za++]=Ga,Sa[za++]=zt,zt=l;var e=Ya;l=Ga;var n=32-Ul(e)-1;e&=~(1<<n),t+=1;var i=32-Ul(a)+n;if(30<i){var u=n-n%5;i=(e&(1<<u)-1).toString(32),e>>=u,n-=u,Ya=1<<32-Ul(a)+n|t<<n|e,Ga=i+l}else Ya=1<<i|t<<n|e,Ga=l}function Lu(l){l.return!==null&&(Pa(l,1),Us(l,1,0))}function Ku(l){for(;l===bi;)bi=Re[--Ye],Re[Ye]=null,_n=Re[--Ye],Re[Ye]=null;for(;l===zt;)zt=Sa[--za],Sa[za]=null,Ga=Sa[--za],Sa[za]=null,Ya=Sa[--za],Sa[za]=null}function Cs(l,a){Sa[za++]=Ya,Sa[za++]=Ga,Sa[za++]=zt,Ya=a.id,Ga=a.overflow,zt=l}var Rl=null,dl=null,L=!1,_t=null,_a=!1,Ju=Error(g(519));function At(l){var a=Error(g(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw An(xa(a,l)),Ju}function Hs(l){var a=l.stateNode,t=l.type,e=l.memoizedProps;switch(a[ql]=l,a[Jl]=e,t){case"dialog":Q("cancel",a),Q("close",a);break;case"iframe":case"object":case"embed":Q("load",a);break;case"video":case"audio":for(t=0;t<Ln.length;t++)Q(Ln[t],a);break;case"source":Q("error",a);break;case"img":case"image":case"link":Q("error",a),Q("load",a);break;case"details":Q("toggle",a);break;case"input":Q("invalid",a),Jf(a,e.value,e.defaultValue,e.checked,e.defaultChecked,e.type,e.name,!0);break;case"select":Q("invalid",a);break;case"textarea":Q("invalid",a),$f(a,e.value,e.defaultValue,e.children)}t=e.children,typeof t!="string"&&typeof t!="number"&&typeof t!="bigint"||a.textContent===""+t||e.suppressHydrationWarning===!0||Po(a.textContent,t)?(e.popover!=null&&(Q("beforetoggle",a),Q("toggle",a)),e.onScroll!=null&&Q("scroll",a),e.onScrollEnd!=null&&Q("scrollend",a),e.onClick!=null&&(a.onclick=$a),a=!0):a=!1,a||At(l,!0)}function Bs(l){for(Rl=l.return;Rl;)switch(Rl.tag){case 5:case 31:case 13:_a=!1;return;case 27:case 3:_a=!0;return;default:Rl=Rl.return}}function Ge(l){if(l!==Rl)return!1;if(!L)return Bs(l),L=!0,!1;var a=l.tag,t;if((t=a!==3&&a!==27)&&((t=a===5)&&(t=l.type,t=!(t!=="form"&&t!=="button")||mf(l.type,l.memoizedProps)),t=!t),t&&dl&&At(l),Bs(l),a===13){if(l=l.memoizedState,l=l!==null?l.dehydrated:null,!l)throw Error(g(317));dl=fd(l)}else if(a===31){if(l=l.memoizedState,l=l!==null?l.dehydrated:null,!l)throw Error(g(317));dl=fd(l)}else a===27?(a=dl,Rt(l.type)?(l=bf,bf=null,dl=l):dl=a):dl=Rl?Ea(l.stateNode.nextSibling):null;return!0}function te(){dl=Rl=null,L=!1}function Wu(){var l=_t;return l!==null&&(Pl===null?Pl=l:Pl.push.apply(Pl,l),_t=null),l}function An(l){_t===null?_t=[l]:_t.push(l)}var $u=zl(null),ee=null,lt=null;function Et(l,a,t){Z($u,a._currentValue),a._currentValue=t}function at(l){l._currentValue=$u.current,il($u)}function Fu(l,a,t){for(;l!==null;){var e=l.alternate;if((l.childLanes&a)!==a?(l.childLanes|=a,e!==null&&(e.childLanes|=a)):e!==null&&(e.childLanes&a)!==a&&(e.childLanes|=a),l===t)break;l=l.return}}function Iu(l,a,t,e){var n=l.child;for(n!==null&&(n.return=l);n!==null;){var i=n.dependencies;if(i!==null){var u=n.child;i=i.firstContext;l:for(;i!==null;){var f=i;i=n;for(var s=0;s<a.length;s++)if(f.context===a[s]){i.lanes|=t,f=i.alternate,f!==null&&(f.lanes|=t),Fu(i.return,t,l),e||(u=null);break l}i=f.next}}else if(n.tag===18){if(u=n.return,u===null)throw Error(g(341));u.lanes|=t,i=u.alternate,i!==null&&(i.lanes|=t),Fu(u,t,l),u=null}else u=n.child;if(u!==null)u.return=n;else for(u=n;u!==null;){if(u===l){u=null;break}if(n=u.sibling,n!==null){n.return=u.return,u=n;break}u=u.return}n=u}}function Qe(l,a,t,e){l=null;for(var n=a,i=!1;n!==null;){if(!i){if((n.flags&524288)!==0)i=!0;else if((n.flags&262144)!==0)break}if(n.tag===10){var u=n.alternate;if(u===null)throw Error(g(387));if(u=u.memoizedProps,u!==null){var f=n.type;ua(n.pendingProps.value,u.value)||(l!==null?l.push(f):l=[f])}}else if(n===Oa.current){if(u=n.alternate,u===null)throw Error(g(387));u.memoizedState.memoizedState!==n.memoizedState.memoizedState&&(l!==null?l.push(Fn):l=[Fn])}n=n.return}l!==null&&Iu(a,l,t,e),a.flags|=262144}function vi(l){for(l=l.firstContext;l!==null;){if(!ua(l.context._currentValue,l.memoizedValue))return!0;l=l.next}return!1}function ne(l){ee=l,lt=null,l=l.dependencies,l!==null&&(l.firstContext=null)}function Yl(l){return qs(ee,l)}function xi(l,a){return ee===null&&ne(l),qs(l,a)}function qs(l,a){var t=a._currentValue;if(a={context:a,memoizedValue:t,next:null},lt===null){if(l===null)throw Error(g(308));lt=a,l.dependencies={lanes:0,firstContext:a},l.flags|=524288}else lt=lt.next=a;return t}var K0=typeof AbortController<"u"?AbortController:function(){var l=[],a=this.signal={aborted:!1,addEventListener:function(t,e){l.push(e)}};this.abort=function(){a.aborted=!0,l.forEach(function(t){return t()})}},J0=d.unstable_scheduleCallback,W0=d.unstable_NormalPriority,Al={$$typeof:nl,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Pu(){return{controller:new K0,data:new Map,refCount:0}}function En(l){l.refCount--,l.refCount===0&&J0(W0,function(){l.controller.abort()})}var Tn=null,lc=0,Xe=0,ke=null;function $0(l,a){if(Tn===null){var t=Tn=[];lc=0,Xe=ef(),ke={status:"pending",value:void 0,then:function(e){t.push(e)}}}return lc++,a.then(Rs,Rs),a}function Rs(){if(--lc===0&&Tn!==null){ke!==null&&(ke.status="fulfilled");var l=Tn;Tn=null,Xe=0,ke=null;for(var a=0;a<l.length;a++)(0,l[a])()}}function F0(l,a){var t=[],e={status:"pending",value:null,reason:null,then:function(n){t.push(n)}};return l.then(function(){e.status="fulfilled",e.value=a;for(var n=0;n<t.length;n++)(0,t[n])(a)},function(n){for(e.status="rejected",e.reason=n,n=0;n<t.length;n++)(0,t[n])(void 0)}),e}var Ys=S.S;S.S=function(l,a){_o=wl(),typeof a=="object"&&a!==null&&typeof a.then=="function"&&$0(l,a),Ys!==null&&Ys(l,a)};var ie=zl(null);function ac(){var l=ie.current;return l!==null?l:ol.pooledCache}function Si(l,a){a===null?Z(ie,ie.current):Z(ie,a.pool)}function Gs(){var l=ac();return l===null?null:{parent:Al._currentValue,pool:l}}var Ve=Error(g(460)),tc=Error(g(474)),zi=Error(g(542)),_i={then:function(){}};function Qs(l){return l=l.status,l==="fulfilled"||l==="rejected"}function Xs(l,a,t){switch(t=l[t],t===void 0?l.push(a):t!==a&&(a.then($a,$a),a=t),a.status){case"fulfilled":return a.value;case"rejected":throw l=a.reason,Vs(l),l;default:if(typeof a.status=="string")a.then($a,$a);else{if(l=ol,l!==null&&100<l.shellSuspendCounter)throw Error(g(482));l=a,l.status="pending",l.then(function(e){if(a.status==="pending"){var n=a;n.status="fulfilled",n.value=e}},function(e){if(a.status==="pending"){var n=a;n.status="rejected",n.reason=e}})}switch(a.status){case"fulfilled":return a.value;case"rejected":throw l=a.reason,Vs(l),l}throw ce=a,Ve}}function ue(l){try{var a=l._init;return a(l._payload)}catch(t){throw t!==null&&typeof t=="object"&&typeof t.then=="function"?(ce=t,Ve):t}}var ce=null;function ks(){if(ce===null)throw Error(g(459));var l=ce;return ce=null,l}function Vs(l){if(l===Ve||l===zi)throw Error(g(483))}var Ze=null,Mn=0;function Ai(l){var a=Mn;return Mn+=1,Ze===null&&(Ze=[]),Xs(Ze,l,a)}function On(l,a){a=a.props.ref,l.ref=a!==void 0?a:null}function Ei(l,a){throw a.$$typeof===B?Error(g(525)):(l=Object.prototype.toString.call(a),Error(g(31,l==="[object Object]"?"object with keys {"+Object.keys(a).join(", ")+"}":l)))}function Zs(l){function a(m,r){if(l){var h=m.deletions;h===null?(m.deletions=[r],m.flags|=16):h.push(r)}}function t(m,r){if(!l)return null;for(;r!==null;)a(m,r),r=r.sibling;return null}function e(m){for(var r=new Map;m!==null;)m.key!==null?r.set(m.key,m):r.set(m.index,m),m=m.sibling;return r}function n(m,r){return m=Ia(m,r),m.index=0,m.sibling=null,m}function i(m,r,h){return m.index=h,l?(h=m.alternate,h!==null?(h=h.index,h<r?(m.flags|=67108866,r):h):(m.flags|=67108866,r)):(m.flags|=1048576,r)}function u(m){return l&&m.alternate===null&&(m.flags|=67108866),m}function f(m,r,h,z){return r===null||r.tag!==6?(r=Vu(h,m.mode,z),r.return=m,r):(r=n(r,h),r.return=m,r)}function s(m,r,h,z){var D=h.type;return D===W?x(m,r,h.props.children,z,h.key):r!==null&&(r.elementType===D||typeof D=="object"&&D!==null&&D.$$typeof===Sl&&ue(D)===r.type)?(r=n(r,h.props),On(r,h),r.return=m,r):(r=yi(h.type,h.key,h.props,null,m.mode,z),On(r,h),r.return=m,r)}function p(m,r,h,z){return r===null||r.tag!==4||r.stateNode.containerInfo!==h.containerInfo||r.stateNode.implementation!==h.implementation?(r=Zu(h,m.mode,z),r.return=m,r):(r=n(r,h.children||[]),r.return=m,r)}function x(m,r,h,z,D){return r===null||r.tag!==7?(r=ae(h,m.mode,z,D),r.return=m,r):(r=n(r,h),r.return=m,r)}function _(m,r,h){if(typeof r=="string"&&r!==""||typeof r=="number"||typeof r=="bigint")return r=Vu(""+r,m.mode,h),r.return=m,r;if(typeof r=="object"&&r!==null){switch(r.$$typeof){case ll:return h=yi(r.type,r.key,r.props,null,m.mode,h),On(h,r),h.return=m,h;case J:return r=Zu(r,m.mode,h),r.return=m,r;case Sl:return r=ue(r),_(m,r,h)}if(Kl(r)||Nl(r))return r=ae(r,m.mode,h,null),r.return=m,r;if(typeof r.then=="function")return _(m,Ai(r),h);if(r.$$typeof===nl)return _(m,xi(m,r),h);Ei(m,r)}return null}function y(m,r,h,z){var D=r!==null?r.key:null;if(typeof h=="string"&&h!==""||typeof h=="number"||typeof h=="bigint")return D!==null?null:f(m,r,""+h,z);if(typeof h=="object"&&h!==null){switch(h.$$typeof){case ll:return h.key===D?s(m,r,h,z):null;case J:return h.key===D?p(m,r,h,z):null;case Sl:return h=ue(h),y(m,r,h,z)}if(Kl(h)||Nl(h))return D!==null?null:x(m,r,h,z,null);if(typeof h.then=="function")return y(m,r,Ai(h),z);if(h.$$typeof===nl)return y(m,r,xi(m,h),z);Ei(m,h)}return null}function b(m,r,h,z,D){if(typeof z=="string"&&z!==""||typeof z=="number"||typeof z=="bigint")return m=m.get(h)||null,f(r,m,""+z,D);if(typeof z=="object"&&z!==null){switch(z.$$typeof){case ll:return m=m.get(z.key===null?h:z.key)||null,s(r,m,z,D);case J:return m=m.get(z.key===null?h:z.key)||null,p(r,m,z,D);case Sl:return z=ue(z),b(m,r,h,z,D)}if(Kl(z)||Nl(z))return m=m.get(h)||null,x(r,m,z,D,null);if(typeof z.then=="function")return b(m,r,h,Ai(z),D);if(z.$$typeof===nl)return b(m,r,h,xi(r,z),D);Ei(r,z)}return null}function M(m,r,h,z){for(var D=null,F=null,N=r,Y=r=0,k=null;N!==null&&Y<h.length;Y++){N.index>Y?(k=N,N=null):k=N.sibling;var I=y(m,N,h[Y],z);if(I===null){N===null&&(N=k);break}l&&N&&I.alternate===null&&a(m,N),r=i(I,r,Y),F===null?D=I:F.sibling=I,F=I,N=k}if(Y===h.length)return t(m,N),L&&Pa(m,Y),D;if(N===null){for(;Y<h.length;Y++)N=_(m,h[Y],z),N!==null&&(r=i(N,r,Y),F===null?D=N:F.sibling=N,F=N);return L&&Pa(m,Y),D}for(N=e(N);Y<h.length;Y++)k=b(N,m,Y,h[Y],z),k!==null&&(l&&k.alternate!==null&&N.delete(k.key===null?Y:k.key),r=i(k,r,Y),F===null?D=k:F.sibling=k,F=k);return l&&N.forEach(function(kt){return a(m,kt)}),L&&Pa(m,Y),D}function U(m,r,h,z){if(h==null)throw Error(g(151));for(var D=null,F=null,N=r,Y=r=0,k=null,I=h.next();N!==null&&!I.done;Y++,I=h.next()){N.index>Y?(k=N,N=null):k=N.sibling;var kt=y(m,N,I.value,z);if(kt===null){N===null&&(N=k);break}l&&N&&kt.alternate===null&&a(m,N),r=i(kt,r,Y),F===null?D=kt:F.sibling=kt,F=kt,N=k}if(I.done)return t(m,N),L&&Pa(m,Y),D;if(N===null){for(;!I.done;Y++,I=h.next())I=_(m,I.value,z),I!==null&&(r=i(I,r,Y),F===null?D=I:F.sibling=I,F=I);return L&&Pa(m,Y),D}for(N=e(N);!I.done;Y++,I=h.next())I=b(N,m,Y,I.value,z),I!==null&&(l&&I.alternate!==null&&N.delete(I.key===null?Y:I.key),r=i(I,r,Y),F===null?D=I:F.sibling=I,F=I);return l&&N.forEach(function(fm){return a(m,fm)}),L&&Pa(m,Y),D}function fl(m,r,h,z){if(typeof h=="object"&&h!==null&&h.type===W&&h.key===null&&(h=h.props.children),typeof h=="object"&&h!==null){switch(h.$$typeof){case ll:l:{for(var D=h.key;r!==null;){if(r.key===D){if(D=h.type,D===W){if(r.tag===7){t(m,r.sibling),z=n(r,h.props.children),z.return=m,m=z;break l}}else if(r.elementType===D||typeof D=="object"&&D!==null&&D.$$typeof===Sl&&ue(D)===r.type){t(m,r.sibling),z=n(r,h.props),On(z,h),z.return=m,m=z;break l}t(m,r);break}else a(m,r);r=r.sibling}h.type===W?(z=ae(h.props.children,m.mode,z,h.key),z.return=m,m=z):(z=yi(h.type,h.key,h.props,null,m.mode,z),On(z,h),z.return=m,m=z)}return u(m);case J:l:{for(D=h.key;r!==null;){if(r.key===D)if(r.tag===4&&r.stateNode.containerInfo===h.containerInfo&&r.stateNode.implementation===h.implementation){t(m,r.sibling),z=n(r,h.children||[]),z.return=m,m=z;break l}else{t(m,r);break}else a(m,r);r=r.sibling}z=Zu(h,m.mode,z),z.return=m,m=z}return u(m);case Sl:return h=ue(h),fl(m,r,h,z)}if(Kl(h))return M(m,r,h,z);if(Nl(h)){if(D=Nl(h),typeof D!="function")throw Error(g(150));return h=D.call(h),U(m,r,h,z)}if(typeof h.then=="function")return fl(m,r,Ai(h),z);if(h.$$typeof===nl)return fl(m,r,xi(m,h),z);Ei(m,h)}return typeof h=="string"&&h!==""||typeof h=="number"||typeof h=="bigint"?(h=""+h,r!==null&&r.tag===6?(t(m,r.sibling),z=n(r,h),z.return=m,m=z):(t(m,r),z=Vu(h,m.mode,z),z.return=m,m=z),u(m)):t(m,r)}return function(m,r,h,z){try{Mn=0;var D=fl(m,r,h,z);return Ze=null,D}catch(N){if(N===Ve||N===zi)throw N;var F=ca(29,N,null,m.mode);return F.lanes=z,F.return=m,F}}}var fe=Zs(!0),Ls=Zs(!1),Tt=!1;function ec(l){l.updateQueue={baseState:l.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function nc(l,a){l=l.updateQueue,a.updateQueue===l&&(a.updateQueue={baseState:l.baseState,firstBaseUpdate:l.firstBaseUpdate,lastBaseUpdate:l.lastBaseUpdate,shared:l.shared,callbacks:null})}function Mt(l){return{lane:l,tag:0,payload:null,callback:null,next:null}}function Ot(l,a,t){var e=l.updateQueue;if(e===null)return null;if(e=e.shared,(P&2)!==0){var n=e.pending;return n===null?a.next=a:(a.next=n.next,n.next=a),e.pending=a,a=pi(l),Ns(l,null,t),a}return hi(l,e,a,t),pi(l)}function Nn(l,a,t){if(a=a.updateQueue,a!==null&&(a=a.shared,(t&4194048)!==0)){var e=a.lanes;e&=l.pendingLanes,t|=e,a.lanes=t,qf(l,t)}}function ic(l,a){var t=l.updateQueue,e=l.alternate;if(e!==null&&(e=e.updateQueue,t===e)){var n=null,i=null;if(t=t.firstBaseUpdate,t!==null){do{var u={lane:t.lane,tag:t.tag,payload:t.payload,callback:null,next:null};i===null?n=i=u:i=i.next=u,t=t.next}while(t!==null);i===null?n=i=a:i=i.next=a}else n=i=a;t={baseState:e.baseState,firstBaseUpdate:n,lastBaseUpdate:i,shared:e.shared,callbacks:e.callbacks},l.updateQueue=t;return}l=t.lastBaseUpdate,l===null?t.firstBaseUpdate=a:l.next=a,t.lastBaseUpdate=a}var uc=!1;function Dn(){if(uc){var l=ke;if(l!==null)throw l}}function jn(l,a,t,e){uc=!1;var n=l.updateQueue;Tt=!1;var i=n.firstBaseUpdate,u=n.lastBaseUpdate,f=n.shared.pending;if(f!==null){n.shared.pending=null;var s=f,p=s.next;s.next=null,u===null?i=p:u.next=p,u=s;var x=l.alternate;x!==null&&(x=x.updateQueue,f=x.lastBaseUpdate,f!==u&&(f===null?x.firstBaseUpdate=p:f.next=p,x.lastBaseUpdate=s))}if(i!==null){var _=n.baseState;u=0,x=p=s=null,f=i;do{var y=f.lane&-536870913,b=y!==f.lane;if(b?(X&y)===y:(e&y)===y){y!==0&&y===Xe&&(uc=!0),x!==null&&(x=x.next={lane:0,tag:f.tag,payload:f.payload,callback:null,next:null});l:{var M=l,U=f;y=a;var fl=t;switch(U.tag){case 1:if(M=U.payload,typeof M=="function"){_=M.call(fl,_,y);break l}_=M;break l;case 3:M.flags=M.flags&-65537|128;case 0:if(M=U.payload,y=typeof M=="function"?M.call(fl,_,y):M,y==null)break l;_=E({},_,y);break l;case 2:Tt=!0}}y=f.callback,y!==null&&(l.flags|=64,b&&(l.flags|=8192),b=n.callbacks,b===null?n.callbacks=[y]:b.push(y))}else b={lane:y,tag:f.tag,payload:f.payload,callback:f.callback,next:null},x===null?(p=x=b,s=_):x=x.next=b,u|=y;if(f=f.next,f===null){if(f=n.shared.pending,f===null)break;b=f,f=b.next,b.next=null,n.lastBaseUpdate=b,n.shared.pending=null}}while(!0);x===null&&(s=_),n.baseState=s,n.firstBaseUpdate=p,n.lastBaseUpdate=x,i===null&&(n.shared.lanes=0),Ut|=u,l.lanes=u,l.memoizedState=_}}function Ks(l,a){if(typeof l!="function")throw Error(g(191,l));l.call(a)}function Js(l,a){var t=l.callbacks;if(t!==null)for(l.callbacks=null,l=0;l<t.length;l++)Ks(t[l],a)}var Le=zl(null),Ti=zl(0);function Ws(l,a){l=rt,Z(Ti,l),Z(Le,a),rt=l|a.baseLanes}function cc(){Z(Ti,rt),Z(Le,Le.current)}function fc(){rt=Ti.current,il(Le),il(Ti)}var fa=zl(null),Aa=null;function Nt(l){var a=l.alternate;Z(vl,vl.current&1),Z(fa,l),Aa===null&&(a===null||Le.current!==null||a.memoizedState!==null)&&(Aa=l)}function sc(l){Z(vl,vl.current),Z(fa,l),Aa===null&&(Aa=l)}function $s(l){l.tag===22?(Z(vl,vl.current),Z(fa,l),Aa===null&&(Aa=l)):Dt()}function Dt(){Z(vl,vl.current),Z(fa,fa.current)}function sa(l){il(fa),Aa===l&&(Aa=null),il(vl)}var vl=zl(0);function Mi(l){for(var a=l;a!==null;){if(a.tag===13){var t=a.memoizedState;if(t!==null&&(t=t.dehydrated,t===null||pf(t)||yf(t)))return a}else if(a.tag===19&&(a.memoizedProps.revealOrder==="forwards"||a.memoizedProps.revealOrder==="backwards"||a.memoizedProps.revealOrder==="unstable_legacy-backwards"||a.memoizedProps.revealOrder==="together")){if((a.flags&128)!==0)return a}else if(a.child!==null){a.child.return=a,a=a.child;continue}if(a===l)break;for(;a.sibling===null;){if(a.return===null||a.return===l)return null;a=a.return}a.sibling.return=a.return,a=a.sibling}return null}var tt=0,q=null,ul=null,El=null,Oi=!1,Ke=!1,se=!1,Ni=0,wn=0,Je=null,I0=0;function yl(){throw Error(g(321))}function rc(l,a){if(a===null)return!1;for(var t=0;t<a.length&&t<l.length;t++)if(!ua(l[t],a[t]))return!1;return!0}function oc(l,a,t,e,n,i){return tt=i,q=a,a.memoizedState=null,a.updateQueue=null,a.lanes=0,S.H=l===null||l.memoizedState===null?Ur:Tc,se=!1,i=t(e,n),se=!1,Ke&&(i=Is(a,t,e,n)),Fs(l),i}function Fs(l){S.H=Hn;var a=ul!==null&&ul.next!==null;if(tt=0,El=ul=q=null,Oi=!1,wn=0,Je=null,a)throw Error(g(300));l===null||Tl||(l=l.dependencies,l!==null&&vi(l)&&(Tl=!0))}function Is(l,a,t,e){q=l;var n=0;do{if(Ke&&(Je=null),wn=0,Ke=!1,25<=n)throw Error(g(301));if(n+=1,El=ul=null,l.updateQueue!=null){var i=l.updateQueue;i.lastEffect=null,i.events=null,i.stores=null,i.memoCache!=null&&(i.memoCache.index=0)}S.H=Cr,i=a(t,e)}while(Ke);return i}function P0(){var l=S.H,a=l.useState()[0];return a=typeof a.then=="function"?Un(a):a,l=l.useState()[0],(ul!==null?ul.memoizedState:null)!==l&&(q.flags|=1024),a}function dc(){var l=Ni!==0;return Ni=0,l}function mc(l,a,t){a.updateQueue=l.updateQueue,a.flags&=-2053,l.lanes&=~t}function gc(l){if(Oi){for(l=l.memoizedState;l!==null;){var a=l.queue;a!==null&&(a.pending=null),l=l.next}Oi=!1}tt=0,El=ul=q=null,Ke=!1,wn=Ni=0,Je=null}function Ll(){var l={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return El===null?q.memoizedState=El=l:El=El.next=l,El}function xl(){if(ul===null){var l=q.alternate;l=l!==null?l.memoizedState:null}else l=ul.next;var a=El===null?q.memoizedState:El.next;if(a!==null)El=a,ul=l;else{if(l===null)throw q.alternate===null?Error(g(467)):Error(g(310));ul=l,l={memoizedState:ul.memoizedState,baseState:ul.baseState,baseQueue:ul.baseQueue,queue:ul.queue,next:null},El===null?q.memoizedState=El=l:El=El.next=l}return El}function Di(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Un(l){var a=wn;return wn+=1,Je===null&&(Je=[]),l=Xs(Je,l,a),a=q,(El===null?a.memoizedState:El.next)===null&&(a=a.alternate,S.H=a===null||a.memoizedState===null?Ur:Tc),l}function ji(l){if(l!==null&&typeof l=="object"){if(typeof l.then=="function")return Un(l);if(l.$$typeof===nl)return Yl(l)}throw Error(g(438,String(l)))}function hc(l){var a=null,t=q.updateQueue;if(t!==null&&(a=t.memoCache),a==null){var e=q.alternate;e!==null&&(e=e.updateQueue,e!==null&&(e=e.memoCache,e!=null&&(a={data:e.data.map(function(n){return n.slice()}),index:0})))}if(a==null&&(a={data:[],index:0}),t===null&&(t=Di(),q.updateQueue=t),t.memoCache=a,t=a.data[a.index],t===void 0)for(t=a.data[a.index]=Array(l),e=0;e<l;e++)t[e]=Ma;return a.index++,t}function et(l,a){return typeof a=="function"?a(l):a}function wi(l){var a=xl();return pc(a,ul,l)}function pc(l,a,t){var e=l.queue;if(e===null)throw Error(g(311));e.lastRenderedReducer=t;var n=l.baseQueue,i=e.pending;if(i!==null){if(n!==null){var u=n.next;n.next=i.next,i.next=u}a.baseQueue=n=i,e.pending=null}if(i=l.baseState,n===null)l.memoizedState=i;else{a=n.next;var f=u=null,s=null,p=a,x=!1;do{var _=p.lane&-536870913;if(_!==p.lane?(X&_)===_:(tt&_)===_){var y=p.revertLane;if(y===0)s!==null&&(s=s.next={lane:0,revertLane:0,gesture:null,action:p.action,hasEagerState:p.hasEagerState,eagerState:p.eagerState,next:null}),_===Xe&&(x=!0);else if((tt&y)===y){p=p.next,y===Xe&&(x=!0);continue}else _={lane:0,revertLane:p.revertLane,gesture:null,action:p.action,hasEagerState:p.hasEagerState,eagerState:p.eagerState,next:null},s===null?(f=s=_,u=i):s=s.next=_,q.lanes|=y,Ut|=y;_=p.action,se&&t(i,_),i=p.hasEagerState?p.eagerState:t(i,_)}else y={lane:_,revertLane:p.revertLane,gesture:p.gesture,action:p.action,hasEagerState:p.hasEagerState,eagerState:p.eagerState,next:null},s===null?(f=s=y,u=i):s=s.next=y,q.lanes|=_,Ut|=_;p=p.next}while(p!==null&&p!==a);if(s===null?u=i:s.next=f,!ua(i,l.memoizedState)&&(Tl=!0,x&&(t=ke,t!==null)))throw t;l.memoizedState=i,l.baseState=u,l.baseQueue=s,e.lastRenderedState=i}return n===null&&(e.lanes=0),[l.memoizedState,e.dispatch]}function yc(l){var a=xl(),t=a.queue;if(t===null)throw Error(g(311));t.lastRenderedReducer=l;var e=t.dispatch,n=t.pending,i=a.memoizedState;if(n!==null){t.pending=null;var u=n=n.next;do i=l(i,u.action),u=u.next;while(u!==n);ua(i,a.memoizedState)||(Tl=!0),a.memoizedState=i,a.baseQueue===null&&(a.baseState=i),t.lastRenderedState=i}return[i,e]}function Ps(l,a,t){var e=q,n=xl(),i=L;if(i){if(t===void 0)throw Error(g(407));t=t()}else t=a();var u=!ua((ul||n).memoizedState,t);if(u&&(n.memoizedState=t,Tl=!0),n=n.queue,xc(tr.bind(null,e,n,l),[l]),n.getSnapshot!==a||u||El!==null&&El.memoizedState.tag&1){if(e.flags|=2048,We(9,{destroy:void 0},ar.bind(null,e,n,t,a),null),ol===null)throw Error(g(349));i||(tt&127)!==0||lr(e,a,t)}return t}function lr(l,a,t){l.flags|=16384,l={getSnapshot:a,value:t},a=q.updateQueue,a===null?(a=Di(),q.updateQueue=a,a.stores=[l]):(t=a.stores,t===null?a.stores=[l]:t.push(l))}function ar(l,a,t,e){a.value=t,a.getSnapshot=e,er(a)&&nr(l)}function tr(l,a,t){return t(function(){er(a)&&nr(l)})}function er(l){var a=l.getSnapshot;l=l.value;try{var t=a();return!ua(l,t)}catch{return!0}}function nr(l){var a=le(l,2);a!==null&&la(a,l,2)}function bc(l){var a=Ll();if(typeof l=="function"){var t=l;if(l=t(),se){ia(!0);try{t()}finally{ia(!1)}}}return a.memoizedState=a.baseState=l,a.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:et,lastRenderedState:l},a}function ir(l,a,t,e){return l.baseState=t,pc(l,ul,typeof e=="function"?e:et)}function l1(l,a,t,e,n){if(Hi(l))throw Error(g(485));if(l=a.action,l!==null){var i={payload:n,action:l,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(u){i.listeners.push(u)}};S.T!==null?t(!0):i.isTransition=!1,e(i),t=a.pending,t===null?(i.next=a.pending=i,ur(a,i)):(i.next=t.next,a.pending=t.next=i)}}function ur(l,a){var t=a.action,e=a.payload,n=l.state;if(a.isTransition){var i=S.T,u={};S.T=u;try{var f=t(n,e),s=S.S;s!==null&&s(u,f),cr(l,a,f)}catch(p){vc(l,a,p)}finally{i!==null&&u.types!==null&&(i.types=u.types),S.T=i}}else try{i=t(n,e),cr(l,a,i)}catch(p){vc(l,a,p)}}function cr(l,a,t){t!==null&&typeof t=="object"&&typeof t.then=="function"?t.then(function(e){fr(l,a,e)},function(e){return vc(l,a,e)}):fr(l,a,t)}function fr(l,a,t){a.status="fulfilled",a.value=t,sr(a),l.state=t,a=l.pending,a!==null&&(t=a.next,t===a?l.pending=null:(t=t.next,a.next=t,ur(l,t)))}function vc(l,a,t){var e=l.pending;if(l.pending=null,e!==null){e=e.next;do a.status="rejected",a.reason=t,sr(a),a=a.next;while(a!==e)}l.action=null}function sr(l){l=l.listeners;for(var a=0;a<l.length;a++)(0,l[a])()}function rr(l,a){return a}function or(l,a){if(L){var t=ol.formState;if(t!==null){l:{var e=q;if(L){if(dl){a:{for(var n=dl,i=_a;n.nodeType!==8;){if(!i){n=null;break a}if(n=Ea(n.nextSibling),n===null){n=null;break a}}i=n.data,n=i==="F!"||i==="F"?n:null}if(n){dl=Ea(n.nextSibling),e=n.data==="F!";break l}}At(e)}e=!1}e&&(a=t[0])}}return t=Ll(),t.memoizedState=t.baseState=a,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:rr,lastRenderedState:a},t.queue=e,t=Dr.bind(null,q,e),e.dispatch=t,e=bc(!1),i=Ec.bind(null,q,!1,e.queue),e=Ll(),n={state:a,dispatch:null,action:l,pending:null},e.queue=n,t=l1.bind(null,q,n,i,t),n.dispatch=t,e.memoizedState=l,[a,t,!1]}function dr(l){var a=xl();return mr(a,ul,l)}function mr(l,a,t){if(a=pc(l,a,rr)[0],l=wi(et)[0],typeof a=="object"&&a!==null&&typeof a.then=="function")try{var e=Un(a)}catch(u){throw u===Ve?zi:u}else e=a;a=xl();var n=a.queue,i=n.dispatch;return t!==a.memoizedState&&(q.flags|=2048,We(9,{destroy:void 0},a1.bind(null,n,t),null)),[e,i,l]}function a1(l,a){l.action=a}function gr(l){var a=xl(),t=ul;if(t!==null)return mr(a,t,l);xl(),a=a.memoizedState,t=xl();var e=t.queue.dispatch;return t.memoizedState=l,[a,e,!1]}function We(l,a,t,e){return l={tag:l,create:t,deps:e,inst:a,next:null},a=q.updateQueue,a===null&&(a=Di(),q.updateQueue=a),t=a.lastEffect,t===null?a.lastEffect=l.next=l:(e=t.next,t.next=l,l.next=e,a.lastEffect=l),l}function hr(){return xl().memoizedState}function Ui(l,a,t,e){var n=Ll();q.flags|=l,n.memoizedState=We(1|a,{destroy:void 0},t,e===void 0?null:e)}function Ci(l,a,t,e){var n=xl();e=e===void 0?null:e;var i=n.memoizedState.inst;ul!==null&&e!==null&&rc(e,ul.memoizedState.deps)?n.memoizedState=We(a,i,t,e):(q.flags|=l,n.memoizedState=We(1|a,i,t,e))}function pr(l,a){Ui(8390656,8,l,a)}function xc(l,a){Ci(2048,8,l,a)}function t1(l){q.flags|=4;var a=q.updateQueue;if(a===null)a=Di(),q.updateQueue=a,a.events=[l];else{var t=a.events;t===null?a.events=[l]:t.push(l)}}function yr(l){var a=xl().memoizedState;return t1({ref:a,nextImpl:l}),function(){if((P&2)!==0)throw Error(g(440));return a.impl.apply(void 0,arguments)}}function br(l,a){return Ci(4,2,l,a)}function vr(l,a){return Ci(4,4,l,a)}function xr(l,a){if(typeof a=="function"){l=l();var t=a(l);return function(){typeof t=="function"?t():a(null)}}if(a!=null)return l=l(),a.current=l,function(){a.current=null}}function Sr(l,a,t){t=t!=null?t.concat([l]):null,Ci(4,4,xr.bind(null,a,l),t)}function Sc(){}function zr(l,a){var t=xl();a=a===void 0?null:a;var e=t.memoizedState;return a!==null&&rc(a,e[1])?e[0]:(t.memoizedState=[l,a],l)}function _r(l,a){var t=xl();a=a===void 0?null:a;var e=t.memoizedState;if(a!==null&&rc(a,e[1]))return e[0];if(e=l(),se){ia(!0);try{l()}finally{ia(!1)}}return t.memoizedState=[e,a],e}function zc(l,a,t){return t===void 0||(tt&1073741824)!==0&&(X&261930)===0?l.memoizedState=a:(l.memoizedState=t,l=Eo(),q.lanes|=l,Ut|=l,t)}function Ar(l,a,t,e){return ua(t,a)?t:Le.current!==null?(l=zc(l,t,e),ua(l,a)||(Tl=!0),l):(tt&42)===0||(tt&1073741824)!==0&&(X&261930)===0?(Tl=!0,l.memoizedState=t):(l=Eo(),q.lanes|=l,Ut|=l,a)}function Er(l,a,t,e,n){var i=A.p;A.p=i!==0&&8>i?i:8;var u=S.T,f={};S.T=f,Ec(l,!1,a,t);try{var s=n(),p=S.S;if(p!==null&&p(f,s),s!==null&&typeof s=="object"&&typeof s.then=="function"){var x=F0(s,e);Cn(l,a,x,da(l))}else Cn(l,a,e,da(l))}catch(_){Cn(l,a,{then:function(){},status:"rejected",reason:_},da())}finally{A.p=i,u!==null&&f.types!==null&&(u.types=f.types),S.T=u}}function e1(){}function _c(l,a,t,e){if(l.tag!==5)throw Error(g(476));var n=Tr(l).queue;Er(l,n,a,w,t===null?e1:function(){return Mr(l),t(e)})}function Tr(l){var a=l.memoizedState;if(a!==null)return a;a={memoizedState:w,baseState:w,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:et,lastRenderedState:w},next:null};var t={};return a.next={memoizedState:t,baseState:t,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:et,lastRenderedState:t},next:null},l.memoizedState=a,l=l.alternate,l!==null&&(l.memoizedState=a),a}function Mr(l){var a=Tr(l);a.next===null&&(a=l.alternate.memoizedState),Cn(l,a.next.queue,{},da())}function Ac(){return Yl(Fn)}function Or(){return xl().memoizedState}function Nr(){return xl().memoizedState}function n1(l){for(var a=l.return;a!==null;){switch(a.tag){case 24:case 3:var t=da();l=Mt(t);var e=Ot(a,l,t);e!==null&&(la(e,a,t),Nn(e,a,t)),a={cache:Pu()},l.payload=a;return}a=a.return}}function i1(l,a,t){var e=da();t={lane:e,revertLane:0,gesture:null,action:t,hasEagerState:!1,eagerState:null,next:null},Hi(l)?jr(a,t):(t=Xu(l,a,t,e),t!==null&&(la(t,l,e),wr(t,a,e)))}function Dr(l,a,t){var e=da();Cn(l,a,t,e)}function Cn(l,a,t,e){var n={lane:e,revertLane:0,gesture:null,action:t,hasEagerState:!1,eagerState:null,next:null};if(Hi(l))jr(a,n);else{var i=l.alternate;if(l.lanes===0&&(i===null||i.lanes===0)&&(i=a.lastRenderedReducer,i!==null))try{var u=a.lastRenderedState,f=i(u,t);if(n.hasEagerState=!0,n.eagerState=f,ua(f,u))return hi(l,a,n,0),ol===null&&gi(),!1}catch{}if(t=Xu(l,a,n,e),t!==null)return la(t,l,e),wr(t,a,e),!0}return!1}function Ec(l,a,t,e){if(e={lane:2,revertLane:ef(),gesture:null,action:e,hasEagerState:!1,eagerState:null,next:null},Hi(l)){if(a)throw Error(g(479))}else a=Xu(l,t,e,2),a!==null&&la(a,l,2)}function Hi(l){var a=l.alternate;return l===q||a!==null&&a===q}function jr(l,a){Ke=Oi=!0;var t=l.pending;t===null?a.next=a:(a.next=t.next,t.next=a),l.pending=a}function wr(l,a,t){if((t&4194048)!==0){var e=a.lanes;e&=l.pendingLanes,t|=e,a.lanes=t,qf(l,t)}}var Hn={readContext:Yl,use:ji,useCallback:yl,useContext:yl,useEffect:yl,useImperativeHandle:yl,useLayoutEffect:yl,useInsertionEffect:yl,useMemo:yl,useReducer:yl,useRef:yl,useState:yl,useDebugValue:yl,useDeferredValue:yl,useTransition:yl,useSyncExternalStore:yl,useId:yl,useHostTransitionStatus:yl,useFormState:yl,useActionState:yl,useOptimistic:yl,useMemoCache:yl,useCacheRefresh:yl};Hn.useEffectEvent=yl;var Ur={readContext:Yl,use:ji,useCallback:function(l,a){return Ll().memoizedState=[l,a===void 0?null:a],l},useContext:Yl,useEffect:pr,useImperativeHandle:function(l,a,t){t=t!=null?t.concat([l]):null,Ui(4194308,4,xr.bind(null,a,l),t)},useLayoutEffect:function(l,a){return Ui(4194308,4,l,a)},useInsertionEffect:function(l,a){Ui(4,2,l,a)},useMemo:function(l,a){var t=Ll();a=a===void 0?null:a;var e=l();if(se){ia(!0);try{l()}finally{ia(!1)}}return t.memoizedState=[e,a],e},useReducer:function(l,a,t){var e=Ll();if(t!==void 0){var n=t(a);if(se){ia(!0);try{t(a)}finally{ia(!1)}}}else n=a;return e.memoizedState=e.baseState=n,l={pending:null,lanes:0,dispatch:null,lastRenderedReducer:l,lastRenderedState:n},e.queue=l,l=l.dispatch=i1.bind(null,q,l),[e.memoizedState,l]},useRef:function(l){var a=Ll();return l={current:l},a.memoizedState=l},useState:function(l){l=bc(l);var a=l.queue,t=Dr.bind(null,q,a);return a.dispatch=t,[l.memoizedState,t]},useDebugValue:Sc,useDeferredValue:function(l,a){var t=Ll();return zc(t,l,a)},useTransition:function(){var l=bc(!1);return l=Er.bind(null,q,l.queue,!0,!1),Ll().memoizedState=l,[!1,l]},useSyncExternalStore:function(l,a,t){var e=q,n=Ll();if(L){if(t===void 0)throw Error(g(407));t=t()}else{if(t=a(),ol===null)throw Error(g(349));(X&127)!==0||lr(e,a,t)}n.memoizedState=t;var i={value:t,getSnapshot:a};return n.queue=i,pr(tr.bind(null,e,i,l),[l]),e.flags|=2048,We(9,{destroy:void 0},ar.bind(null,e,i,t,a),null),t},useId:function(){var l=Ll(),a=ol.identifierPrefix;if(L){var t=Ga,e=Ya;t=(e&~(1<<32-Ul(e)-1)).toString(32)+t,a="_"+a+"R_"+t,t=Ni++,0<t&&(a+="H"+t.toString(32)),a+="_"}else t=I0++,a="_"+a+"r_"+t.toString(32)+"_";return l.memoizedState=a},useHostTransitionStatus:Ac,useFormState:or,useActionState:or,useOptimistic:function(l){var a=Ll();a.memoizedState=a.baseState=l;var t={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return a.queue=t,a=Ec.bind(null,q,!0,t),t.dispatch=a,[l,a]},useMemoCache:hc,useCacheRefresh:function(){return Ll().memoizedState=n1.bind(null,q)},useEffectEvent:function(l){var a=Ll(),t={impl:l};return a.memoizedState=t,function(){if((P&2)!==0)throw Error(g(440));return t.impl.apply(void 0,arguments)}}},Tc={readContext:Yl,use:ji,useCallback:zr,useContext:Yl,useEffect:xc,useImperativeHandle:Sr,useInsertionEffect:br,useLayoutEffect:vr,useMemo:_r,useReducer:wi,useRef:hr,useState:function(){return wi(et)},useDebugValue:Sc,useDeferredValue:function(l,a){var t=xl();return Ar(t,ul.memoizedState,l,a)},useTransition:function(){var l=wi(et)[0],a=xl().memoizedState;return[typeof l=="boolean"?l:Un(l),a]},useSyncExternalStore:Ps,useId:Or,useHostTransitionStatus:Ac,useFormState:dr,useActionState:dr,useOptimistic:function(l,a){var t=xl();return ir(t,ul,l,a)},useMemoCache:hc,useCacheRefresh:Nr};Tc.useEffectEvent=yr;var Cr={readContext:Yl,use:ji,useCallback:zr,useContext:Yl,useEffect:xc,useImperativeHandle:Sr,useInsertionEffect:br,useLayoutEffect:vr,useMemo:_r,useReducer:yc,useRef:hr,useState:function(){return yc(et)},useDebugValue:Sc,useDeferredValue:function(l,a){var t=xl();return ul===null?zc(t,l,a):Ar(t,ul.memoizedState,l,a)},useTransition:function(){var l=yc(et)[0],a=xl().memoizedState;return[typeof l=="boolean"?l:Un(l),a]},useSyncExternalStore:Ps,useId:Or,useHostTransitionStatus:Ac,useFormState:gr,useActionState:gr,useOptimistic:function(l,a){var t=xl();return ul!==null?ir(t,ul,l,a):(t.baseState=l,[l,t.queue.dispatch])},useMemoCache:hc,useCacheRefresh:Nr};Cr.useEffectEvent=yr;function Mc(l,a,t,e){a=l.memoizedState,t=t(e,a),t=t==null?a:E({},a,t),l.memoizedState=t,l.lanes===0&&(l.updateQueue.baseState=t)}var Oc={enqueueSetState:function(l,a,t){l=l._reactInternals;var e=da(),n=Mt(e);n.payload=a,t!=null&&(n.callback=t),a=Ot(l,n,e),a!==null&&(la(a,l,e),Nn(a,l,e))},enqueueReplaceState:function(l,a,t){l=l._reactInternals;var e=da(),n=Mt(e);n.tag=1,n.payload=a,t!=null&&(n.callback=t),a=Ot(l,n,e),a!==null&&(la(a,l,e),Nn(a,l,e))},enqueueForceUpdate:function(l,a){l=l._reactInternals;var t=da(),e=Mt(t);e.tag=2,a!=null&&(e.callback=a),a=Ot(l,e,t),a!==null&&(la(a,l,t),Nn(a,l,t))}};function Hr(l,a,t,e,n,i,u){return l=l.stateNode,typeof l.shouldComponentUpdate=="function"?l.shouldComponentUpdate(e,i,u):a.prototype&&a.prototype.isPureReactComponent?!Sn(t,e)||!Sn(n,i):!0}function Br(l,a,t,e){l=a.state,typeof a.componentWillReceiveProps=="function"&&a.componentWillReceiveProps(t,e),typeof a.UNSAFE_componentWillReceiveProps=="function"&&a.UNSAFE_componentWillReceiveProps(t,e),a.state!==l&&Oc.enqueueReplaceState(a,a.state,null)}function re(l,a){var t=a;if("ref"in a){t={};for(var e in a)e!=="ref"&&(t[e]=a[e])}if(l=l.defaultProps){t===a&&(t=E({},t));for(var n in l)t[n]===void 0&&(t[n]=l[n])}return t}function qr(l){mi(l)}function Rr(l){console.error(l)}function Yr(l){mi(l)}function Bi(l,a){try{var t=l.onUncaughtError;t(a.value,{componentStack:a.stack})}catch(e){setTimeout(function(){throw e})}}function Gr(l,a,t){try{var e=l.onCaughtError;e(t.value,{componentStack:t.stack,errorBoundary:a.tag===1?a.stateNode:null})}catch(n){setTimeout(function(){throw n})}}function Nc(l,a,t){return t=Mt(t),t.tag=3,t.payload={element:null},t.callback=function(){Bi(l,a)},t}function Qr(l){return l=Mt(l),l.tag=3,l}function Xr(l,a,t,e){var n=t.type.getDerivedStateFromError;if(typeof n=="function"){var i=e.value;l.payload=function(){return n(i)},l.callback=function(){Gr(a,t,e)}}var u=t.stateNode;u!==null&&typeof u.componentDidCatch=="function"&&(l.callback=function(){Gr(a,t,e),typeof n!="function"&&(Ct===null?Ct=new Set([this]):Ct.add(this));var f=e.stack;this.componentDidCatch(e.value,{componentStack:f!==null?f:""})})}function u1(l,a,t,e,n){if(t.flags|=32768,e!==null&&typeof e=="object"&&typeof e.then=="function"){if(a=t.alternate,a!==null&&Qe(a,t,n,!0),t=fa.current,t!==null){switch(t.tag){case 31:case 13:return Aa===null?Ji():t.alternate===null&&bl===0&&(bl=3),t.flags&=-257,t.flags|=65536,t.lanes=n,e===_i?t.flags|=16384:(a=t.updateQueue,a===null?t.updateQueue=new Set([e]):a.add(e),lf(l,e,n)),!1;case 22:return t.flags|=65536,e===_i?t.flags|=16384:(a=t.updateQueue,a===null?(a={transitions:null,markerInstances:null,retryQueue:new Set([e])},t.updateQueue=a):(t=a.retryQueue,t===null?a.retryQueue=new Set([e]):t.add(e)),lf(l,e,n)),!1}throw Error(g(435,t.tag))}return lf(l,e,n),Ji(),!1}if(L)return a=fa.current,a!==null?((a.flags&65536)===0&&(a.flags|=256),a.flags|=65536,a.lanes=n,e!==Ju&&(l=Error(g(422),{cause:e}),An(xa(l,t)))):(e!==Ju&&(a=Error(g(423),{cause:e}),An(xa(a,t))),l=l.current.alternate,l.flags|=65536,n&=-n,l.lanes|=n,e=xa(e,t),n=Nc(l.stateNode,e,n),ic(l,n),bl!==4&&(bl=2)),!1;var i=Error(g(520),{cause:e});if(i=xa(i,t),kn===null?kn=[i]:kn.push(i),bl!==4&&(bl=2),a===null)return!0;e=xa(e,t),t=a;do{switch(t.tag){case 3:return t.flags|=65536,l=n&-n,t.lanes|=l,l=Nc(t.stateNode,e,l),ic(t,l),!1;case 1:if(a=t.type,i=t.stateNode,(t.flags&128)===0&&(typeof a.getDerivedStateFromError=="function"||i!==null&&typeof i.componentDidCatch=="function"&&(Ct===null||!Ct.has(i))))return t.flags|=65536,n&=-n,t.lanes|=n,n=Qr(n),Xr(n,l,t,e),ic(t,n),!1}t=t.return}while(t!==null);return!1}var Dc=Error(g(461)),Tl=!1;function Gl(l,a,t,e){a.child=l===null?Ls(a,null,t,e):fe(a,l.child,t,e)}function kr(l,a,t,e,n){t=t.render;var i=a.ref;if("ref"in e){var u={};for(var f in e)f!=="ref"&&(u[f]=e[f])}else u=e;return ne(a),e=oc(l,a,t,u,i,n),f=dc(),l!==null&&!Tl?(mc(l,a,n),nt(l,a,n)):(L&&f&&Lu(a),a.flags|=1,Gl(l,a,e,n),a.child)}function Vr(l,a,t,e,n){if(l===null){var i=t.type;return typeof i=="function"&&!ku(i)&&i.defaultProps===void 0&&t.compare===null?(a.tag=15,a.type=i,Zr(l,a,i,e,n)):(l=yi(t.type,null,e,a,a.mode,n),l.ref=a.ref,l.return=a,a.child=l)}if(i=l.child,!Rc(l,n)){var u=i.memoizedProps;if(t=t.compare,t=t!==null?t:Sn,t(u,e)&&l.ref===a.ref)return nt(l,a,n)}return a.flags|=1,l=Ia(i,e),l.ref=a.ref,l.return=a,a.child=l}function Zr(l,a,t,e,n){if(l!==null){var i=l.memoizedProps;if(Sn(i,e)&&l.ref===a.ref)if(Tl=!1,a.pendingProps=e=i,Rc(l,n))(l.flags&131072)!==0&&(Tl=!0);else return a.lanes=l.lanes,nt(l,a,n)}return jc(l,a,t,e,n)}function Lr(l,a,t,e){var n=e.children,i=l!==null?l.memoizedState:null;if(l===null&&a.stateNode===null&&(a.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),e.mode==="hidden"){if((a.flags&128)!==0){if(i=i!==null?i.baseLanes|t:t,l!==null){for(e=a.child=l.child,n=0;e!==null;)n=n|e.lanes|e.childLanes,e=e.sibling;e=n&~i}else e=0,a.child=null;return Kr(l,a,i,t,e)}if((t&536870912)!==0)a.memoizedState={baseLanes:0,cachePool:null},l!==null&&Si(a,i!==null?i.cachePool:null),i!==null?Ws(a,i):cc(),$s(a);else return e=a.lanes=536870912,Kr(l,a,i!==null?i.baseLanes|t:t,t,e)}else i!==null?(Si(a,i.cachePool),Ws(a,i),Dt(),a.memoizedState=null):(l!==null&&Si(a,null),cc(),Dt());return Gl(l,a,n,t),a.child}function Bn(l,a){return l!==null&&l.tag===22||a.stateNode!==null||(a.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),a.sibling}function Kr(l,a,t,e,n){var i=ac();return i=i===null?null:{parent:Al._currentValue,pool:i},a.memoizedState={baseLanes:t,cachePool:i},l!==null&&Si(a,null),cc(),$s(a),l!==null&&Qe(l,a,e,!0),a.childLanes=n,null}function qi(l,a){return a=Yi({mode:a.mode,children:a.children},l.mode),a.ref=l.ref,l.child=a,a.return=l,a}function Jr(l,a,t){return fe(a,l.child,null,t),l=qi(a,a.pendingProps),l.flags|=2,sa(a),a.memoizedState=null,l}function c1(l,a,t){var e=a.pendingProps,n=(a.flags&128)!==0;if(a.flags&=-129,l===null){if(L){if(e.mode==="hidden")return l=qi(a,e),a.lanes=536870912,Bn(null,l);if(sc(a),(l=dl)?(l=cd(l,_a),l=l!==null&&l.data==="&"?l:null,l!==null&&(a.memoizedState={dehydrated:l,treeContext:zt!==null?{id:Ya,overflow:Ga}:null,retryLane:536870912,hydrationErrors:null},t=js(l),t.return=a,a.child=t,Rl=a,dl=null)):l=null,l===null)throw At(a);return a.lanes=536870912,null}return qi(a,e)}var i=l.memoizedState;if(i!==null){var u=i.dehydrated;if(sc(a),n)if(a.flags&256)a.flags&=-257,a=Jr(l,a,t);else if(a.memoizedState!==null)a.child=l.child,a.flags|=128,a=null;else throw Error(g(558));else if(Tl||Qe(l,a,t,!1),n=(t&l.childLanes)!==0,Tl||n){if(e=ol,e!==null&&(u=Rf(e,t),u!==0&&u!==i.retryLane))throw i.retryLane=u,le(l,u),la(e,l,u),Dc;Ji(),a=Jr(l,a,t)}else l=i.treeContext,dl=Ea(u.nextSibling),Rl=a,L=!0,_t=null,_a=!1,l!==null&&Cs(a,l),a=qi(a,e),a.flags|=4096;return a}return l=Ia(l.child,{mode:e.mode,children:e.children}),l.ref=a.ref,a.child=l,l.return=a,l}function Ri(l,a){var t=a.ref;if(t===null)l!==null&&l.ref!==null&&(a.flags|=4194816);else{if(typeof t!="function"&&typeof t!="object")throw Error(g(284));(l===null||l.ref!==t)&&(a.flags|=4194816)}}function jc(l,a,t,e,n){return ne(a),t=oc(l,a,t,e,void 0,n),e=dc(),l!==null&&!Tl?(mc(l,a,n),nt(l,a,n)):(L&&e&&Lu(a),a.flags|=1,Gl(l,a,t,n),a.child)}function Wr(l,a,t,e,n,i){return ne(a),a.updateQueue=null,t=Is(a,e,t,n),Fs(l),e=dc(),l!==null&&!Tl?(mc(l,a,i),nt(l,a,i)):(L&&e&&Lu(a),a.flags|=1,Gl(l,a,t,i),a.child)}function $r(l,a,t,e,n){if(ne(a),a.stateNode===null){var i=qe,u=t.contextType;typeof u=="object"&&u!==null&&(i=Yl(u)),i=new t(e,i),a.memoizedState=i.state!==null&&i.state!==void 0?i.state:null,i.updater=Oc,a.stateNode=i,i._reactInternals=a,i=a.stateNode,i.props=e,i.state=a.memoizedState,i.refs={},ec(a),u=t.contextType,i.context=typeof u=="object"&&u!==null?Yl(u):qe,i.state=a.memoizedState,u=t.getDerivedStateFromProps,typeof u=="function"&&(Mc(a,t,u,e),i.state=a.memoizedState),typeof t.getDerivedStateFromProps=="function"||typeof i.getSnapshotBeforeUpdate=="function"||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(u=i.state,typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount(),u!==i.state&&Oc.enqueueReplaceState(i,i.state,null),jn(a,e,i,n),Dn(),i.state=a.memoizedState),typeof i.componentDidMount=="function"&&(a.flags|=4194308),e=!0}else if(l===null){i=a.stateNode;var f=a.memoizedProps,s=re(t,f);i.props=s;var p=i.context,x=t.contextType;u=qe,typeof x=="object"&&x!==null&&(u=Yl(x));var _=t.getDerivedStateFromProps;x=typeof _=="function"||typeof i.getSnapshotBeforeUpdate=="function",f=a.pendingProps!==f,x||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(f||p!==u)&&Br(a,i,e,u),Tt=!1;var y=a.memoizedState;i.state=y,jn(a,e,i,n),Dn(),p=a.memoizedState,f||y!==p||Tt?(typeof _=="function"&&(Mc(a,t,_,e),p=a.memoizedState),(s=Tt||Hr(a,t,s,e,y,p,u))?(x||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount()),typeof i.componentDidMount=="function"&&(a.flags|=4194308)):(typeof i.componentDidMount=="function"&&(a.flags|=4194308),a.memoizedProps=e,a.memoizedState=p),i.props=e,i.state=p,i.context=u,e=s):(typeof i.componentDidMount=="function"&&(a.flags|=4194308),e=!1)}else{i=a.stateNode,nc(l,a),u=a.memoizedProps,x=re(t,u),i.props=x,_=a.pendingProps,y=i.context,p=t.contextType,s=qe,typeof p=="object"&&p!==null&&(s=Yl(p)),f=t.getDerivedStateFromProps,(p=typeof f=="function"||typeof i.getSnapshotBeforeUpdate=="function")||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(u!==_||y!==s)&&Br(a,i,e,s),Tt=!1,y=a.memoizedState,i.state=y,jn(a,e,i,n),Dn();var b=a.memoizedState;u!==_||y!==b||Tt||l!==null&&l.dependencies!==null&&vi(l.dependencies)?(typeof f=="function"&&(Mc(a,t,f,e),b=a.memoizedState),(x=Tt||Hr(a,t,x,e,y,b,s)||l!==null&&l.dependencies!==null&&vi(l.dependencies))?(p||typeof i.UNSAFE_componentWillUpdate!="function"&&typeof i.componentWillUpdate!="function"||(typeof i.componentWillUpdate=="function"&&i.componentWillUpdate(e,b,s),typeof i.UNSAFE_componentWillUpdate=="function"&&i.UNSAFE_componentWillUpdate(e,b,s)),typeof i.componentDidUpdate=="function"&&(a.flags|=4),typeof i.getSnapshotBeforeUpdate=="function"&&(a.flags|=1024)):(typeof i.componentDidUpdate!="function"||u===l.memoizedProps&&y===l.memoizedState||(a.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||u===l.memoizedProps&&y===l.memoizedState||(a.flags|=1024),a.memoizedProps=e,a.memoizedState=b),i.props=e,i.state=b,i.context=s,e=x):(typeof i.componentDidUpdate!="function"||u===l.memoizedProps&&y===l.memoizedState||(a.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||u===l.memoizedProps&&y===l.memoizedState||(a.flags|=1024),e=!1)}return i=e,Ri(l,a),e=(a.flags&128)!==0,i||e?(i=a.stateNode,t=e&&typeof t.getDerivedStateFromError!="function"?null:i.render(),a.flags|=1,l!==null&&e?(a.child=fe(a,l.child,null,n),a.child=fe(a,null,t,n)):Gl(l,a,t,n),a.memoizedState=i.state,l=a.child):l=nt(l,a,n),l}function Fr(l,a,t,e){return te(),a.flags|=256,Gl(l,a,t,e),a.child}var wc={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Uc(l){return{baseLanes:l,cachePool:Gs()}}function Cc(l,a,t){return l=l!==null?l.childLanes&~t:0,a&&(l|=oa),l}function Ir(l,a,t){var e=a.pendingProps,n=!1,i=(a.flags&128)!==0,u;if((u=i)||(u=l!==null&&l.memoizedState===null?!1:(vl.current&2)!==0),u&&(n=!0,a.flags&=-129),u=(a.flags&32)!==0,a.flags&=-33,l===null){if(L){if(n?Nt(a):Dt(),(l=dl)?(l=cd(l,_a),l=l!==null&&l.data!=="&"?l:null,l!==null&&(a.memoizedState={dehydrated:l,treeContext:zt!==null?{id:Ya,overflow:Ga}:null,retryLane:536870912,hydrationErrors:null},t=js(l),t.return=a,a.child=t,Rl=a,dl=null)):l=null,l===null)throw At(a);return yf(l)?a.lanes=32:a.lanes=536870912,null}var f=e.children;return e=e.fallback,n?(Dt(),n=a.mode,f=Yi({mode:"hidden",children:f},n),e=ae(e,n,t,null),f.return=a,e.return=a,f.sibling=e,a.child=f,e=a.child,e.memoizedState=Uc(t),e.childLanes=Cc(l,u,t),a.memoizedState=wc,Bn(null,e)):(Nt(a),Hc(a,f))}var s=l.memoizedState;if(s!==null&&(f=s.dehydrated,f!==null)){if(i)a.flags&256?(Nt(a),a.flags&=-257,a=Bc(l,a,t)):a.memoizedState!==null?(Dt(),a.child=l.child,a.flags|=128,a=null):(Dt(),f=e.fallback,n=a.mode,e=Yi({mode:"visible",children:e.children},n),f=ae(f,n,t,null),f.flags|=2,e.return=a,f.return=a,e.sibling=f,a.child=e,fe(a,l.child,null,t),e=a.child,e.memoizedState=Uc(t),e.childLanes=Cc(l,u,t),a.memoizedState=wc,a=Bn(null,e));else if(Nt(a),yf(f)){if(u=f.nextSibling&&f.nextSibling.dataset,u)var p=u.dgst;u=p,e=Error(g(419)),e.stack="",e.digest=u,An({value:e,source:null,stack:null}),a=Bc(l,a,t)}else if(Tl||Qe(l,a,t,!1),u=(t&l.childLanes)!==0,Tl||u){if(u=ol,u!==null&&(e=Rf(u,t),e!==0&&e!==s.retryLane))throw s.retryLane=e,le(l,e),la(u,l,e),Dc;pf(f)||Ji(),a=Bc(l,a,t)}else pf(f)?(a.flags|=192,a.child=l.child,a=null):(l=s.treeContext,dl=Ea(f.nextSibling),Rl=a,L=!0,_t=null,_a=!1,l!==null&&Cs(a,l),a=Hc(a,e.children),a.flags|=4096);return a}return n?(Dt(),f=e.fallback,n=a.mode,s=l.child,p=s.sibling,e=Ia(s,{mode:"hidden",children:e.children}),e.subtreeFlags=s.subtreeFlags&65011712,p!==null?f=Ia(p,f):(f=ae(f,n,t,null),f.flags|=2),f.return=a,e.return=a,e.sibling=f,a.child=e,Bn(null,e),e=a.child,f=l.child.memoizedState,f===null?f=Uc(t):(n=f.cachePool,n!==null?(s=Al._currentValue,n=n.parent!==s?{parent:s,pool:s}:n):n=Gs(),f={baseLanes:f.baseLanes|t,cachePool:n}),e.memoizedState=f,e.childLanes=Cc(l,u,t),a.memoizedState=wc,Bn(l.child,e)):(Nt(a),t=l.child,l=t.sibling,t=Ia(t,{mode:"visible",children:e.children}),t.return=a,t.sibling=null,l!==null&&(u=a.deletions,u===null?(a.deletions=[l],a.flags|=16):u.push(l)),a.child=t,a.memoizedState=null,t)}function Hc(l,a){return a=Yi({mode:"visible",children:a},l.mode),a.return=l,l.child=a}function Yi(l,a){return l=ca(22,l,null,a),l.lanes=0,l}function Bc(l,a,t){return fe(a,l.child,null,t),l=Hc(a,a.pendingProps.children),l.flags|=2,a.memoizedState=null,l}function Pr(l,a,t){l.lanes|=a;var e=l.alternate;e!==null&&(e.lanes|=a),Fu(l.return,a,t)}function qc(l,a,t,e,n,i){var u=l.memoizedState;u===null?l.memoizedState={isBackwards:a,rendering:null,renderingStartTime:0,last:e,tail:t,tailMode:n,treeForkCount:i}:(u.isBackwards=a,u.rendering=null,u.renderingStartTime=0,u.last=e,u.tail=t,u.tailMode=n,u.treeForkCount=i)}function lo(l,a,t){var e=a.pendingProps,n=e.revealOrder,i=e.tail;e=e.children;var u=vl.current,f=(u&2)!==0;if(f?(u=u&1|2,a.flags|=128):u&=1,Z(vl,u),Gl(l,a,e,t),e=L?_n:0,!f&&l!==null&&(l.flags&128)!==0)l:for(l=a.child;l!==null;){if(l.tag===13)l.memoizedState!==null&&Pr(l,t,a);else if(l.tag===19)Pr(l,t,a);else if(l.child!==null){l.child.return=l,l=l.child;continue}if(l===a)break l;for(;l.sibling===null;){if(l.return===null||l.return===a)break l;l=l.return}l.sibling.return=l.return,l=l.sibling}switch(n){case"forwards":for(t=a.child,n=null;t!==null;)l=t.alternate,l!==null&&Mi(l)===null&&(n=t),t=t.sibling;t=n,t===null?(n=a.child,a.child=null):(n=t.sibling,t.sibling=null),qc(a,!1,n,t,i,e);break;case"backwards":case"unstable_legacy-backwards":for(t=null,n=a.child,a.child=null;n!==null;){if(l=n.alternate,l!==null&&Mi(l)===null){a.child=n;break}l=n.sibling,n.sibling=t,t=n,n=l}qc(a,!0,t,null,i,e);break;case"together":qc(a,!1,null,null,void 0,e);break;default:a.memoizedState=null}return a.child}function nt(l,a,t){if(l!==null&&(a.dependencies=l.dependencies),Ut|=a.lanes,(t&a.childLanes)===0)if(l!==null){if(Qe(l,a,t,!1),(t&a.childLanes)===0)return null}else return null;if(l!==null&&a.child!==l.child)throw Error(g(153));if(a.child!==null){for(l=a.child,t=Ia(l,l.pendingProps),a.child=t,t.return=a;l.sibling!==null;)l=l.sibling,t=t.sibling=Ia(l,l.pendingProps),t.return=a;t.sibling=null}return a.child}function Rc(l,a){return(l.lanes&a)!==0?!0:(l=l.dependencies,!!(l!==null&&vi(l)))}function f1(l,a,t){switch(a.tag){case 3:Za(a,a.stateNode.containerInfo),Et(a,Al,l.memoizedState.cache),te();break;case 27:case 5:Ba(a);break;case 4:Za(a,a.stateNode.containerInfo);break;case 10:Et(a,a.type,a.memoizedProps.value);break;case 31:if(a.memoizedState!==null)return a.flags|=128,sc(a),null;break;case 13:var e=a.memoizedState;if(e!==null)return e.dehydrated!==null?(Nt(a),a.flags|=128,null):(t&a.child.childLanes)!==0?Ir(l,a,t):(Nt(a),l=nt(l,a,t),l!==null?l.sibling:null);Nt(a);break;case 19:var n=(l.flags&128)!==0;if(e=(t&a.childLanes)!==0,e||(Qe(l,a,t,!1),e=(t&a.childLanes)!==0),n){if(e)return lo(l,a,t);a.flags|=128}if(n=a.memoizedState,n!==null&&(n.rendering=null,n.tail=null,n.lastEffect=null),Z(vl,vl.current),e)break;return null;case 22:return a.lanes=0,Lr(l,a,t,a.pendingProps);case 24:Et(a,Al,l.memoizedState.cache)}return nt(l,a,t)}function ao(l,a,t){if(l!==null)if(l.memoizedProps!==a.pendingProps)Tl=!0;else{if(!Rc(l,t)&&(a.flags&128)===0)return Tl=!1,f1(l,a,t);Tl=(l.flags&131072)!==0}else Tl=!1,L&&(a.flags&1048576)!==0&&Us(a,_n,a.index);switch(a.lanes=0,a.tag){case 16:l:{var e=a.pendingProps;if(l=ue(a.elementType),a.type=l,typeof l=="function")ku(l)?(e=re(l,e),a.tag=1,a=$r(null,a,l,e,t)):(a.tag=0,a=jc(null,a,l,e,t));else{if(l!=null){var n=l.$$typeof;if(n===Bl){a.tag=11,a=kr(null,a,l,e,t);break l}else if(n===kl){a.tag=14,a=Vr(null,a,l,e,t);break l}}throw a=Va(l)||l,Error(g(306,a,""))}}return a;case 0:return jc(l,a,a.type,a.pendingProps,t);case 1:return e=a.type,n=re(e,a.pendingProps),$r(l,a,e,n,t);case 3:l:{if(Za(a,a.stateNode.containerInfo),l===null)throw Error(g(387));e=a.pendingProps;var i=a.memoizedState;n=i.element,nc(l,a),jn(a,e,null,t);var u=a.memoizedState;if(e=u.cache,Et(a,Al,e),e!==i.cache&&Iu(a,[Al],t,!0),Dn(),e=u.element,i.isDehydrated)if(i={element:e,isDehydrated:!1,cache:u.cache},a.updateQueue.baseState=i,a.memoizedState=i,a.flags&256){a=Fr(l,a,e,t);break l}else if(e!==n){n=xa(Error(g(424)),a),An(n),a=Fr(l,a,e,t);break l}else for(l=a.stateNode.containerInfo,l.nodeType===9?l=l.body:l=l.nodeName==="HTML"?l.ownerDocument.body:l,dl=Ea(l.firstChild),Rl=a,L=!0,_t=null,_a=!0,t=Ls(a,null,e,t),a.child=t;t;)t.flags=t.flags&-3|4096,t=t.sibling;else{if(te(),e===n){a=nt(l,a,t);break l}Gl(l,a,e,t)}a=a.child}return a;case 26:return Ri(l,a),l===null?(t=md(a.type,null,a.pendingProps,null))?a.memoizedState=t:L||(t=a.type,l=a.pendingProps,e=au(ea.current).createElement(t),e[ql]=a,e[Jl]=l,Ql(e,t,l),Cl(e),a.stateNode=e):a.memoizedState=md(a.type,l.memoizedProps,a.pendingProps,l.memoizedState),null;case 27:return Ba(a),l===null&&L&&(e=a.stateNode=rd(a.type,a.pendingProps,ea.current),Rl=a,_a=!0,n=dl,Rt(a.type)?(bf=n,dl=Ea(e.firstChild)):dl=n),Gl(l,a,a.pendingProps.children,t),Ri(l,a),l===null&&(a.flags|=4194304),a.child;case 5:return l===null&&L&&((n=e=dl)&&(e=R1(e,a.type,a.pendingProps,_a),e!==null?(a.stateNode=e,Rl=a,dl=Ea(e.firstChild),_a=!1,n=!0):n=!1),n||At(a)),Ba(a),n=a.type,i=a.pendingProps,u=l!==null?l.memoizedProps:null,e=i.children,mf(n,i)?e=null:u!==null&&mf(n,u)&&(a.flags|=32),a.memoizedState!==null&&(n=oc(l,a,P0,null,null,t),Fn._currentValue=n),Ri(l,a),Gl(l,a,e,t),a.child;case 6:return l===null&&L&&((l=t=dl)&&(t=Y1(t,a.pendingProps,_a),t!==null?(a.stateNode=t,Rl=a,dl=null,l=!0):l=!1),l||At(a)),null;case 13:return Ir(l,a,t);case 4:return Za(a,a.stateNode.containerInfo),e=a.pendingProps,l===null?a.child=fe(a,null,e,t):Gl(l,a,e,t),a.child;case 11:return kr(l,a,a.type,a.pendingProps,t);case 7:return Gl(l,a,a.pendingProps,t),a.child;case 8:return Gl(l,a,a.pendingProps.children,t),a.child;case 12:return Gl(l,a,a.pendingProps.children,t),a.child;case 10:return e=a.pendingProps,Et(a,a.type,e.value),Gl(l,a,e.children,t),a.child;case 9:return n=a.type._context,e=a.pendingProps.children,ne(a),n=Yl(n),e=e(n),a.flags|=1,Gl(l,a,e,t),a.child;case 14:return Vr(l,a,a.type,a.pendingProps,t);case 15:return Zr(l,a,a.type,a.pendingProps,t);case 19:return lo(l,a,t);case 31:return c1(l,a,t);case 22:return Lr(l,a,t,a.pendingProps);case 24:return ne(a),e=Yl(Al),l===null?(n=ac(),n===null&&(n=ol,i=Pu(),n.pooledCache=i,i.refCount++,i!==null&&(n.pooledCacheLanes|=t),n=i),a.memoizedState={parent:e,cache:n},ec(a),Et(a,Al,n)):((l.lanes&t)!==0&&(nc(l,a),jn(a,null,null,t),Dn()),n=l.memoizedState,i=a.memoizedState,n.parent!==e?(n={parent:e,cache:e},a.memoizedState=n,a.lanes===0&&(a.memoizedState=a.updateQueue.baseState=n),Et(a,Al,e)):(e=i.cache,Et(a,Al,e),e!==n.cache&&Iu(a,[Al],t,!0))),Gl(l,a,a.pendingProps.children,t),a.child;case 29:throw a.pendingProps}throw Error(g(156,a.tag))}function it(l){l.flags|=4}function Yc(l,a,t,e,n){if((a=(l.mode&32)!==0)&&(a=!1),a){if(l.flags|=16777216,(n&335544128)===n)if(l.stateNode.complete)l.flags|=8192;else if(No())l.flags|=8192;else throw ce=_i,tc}else l.flags&=-16777217}function to(l,a){if(a.type!=="stylesheet"||(a.state.loading&4)!==0)l.flags&=-16777217;else if(l.flags|=16777216,!bd(a))if(No())l.flags|=8192;else throw ce=_i,tc}function Gi(l,a){a!==null&&(l.flags|=4),l.flags&16384&&(a=l.tag!==22?Wt():536870912,l.lanes|=a,Pe|=a)}function qn(l,a){if(!L)switch(l.tailMode){case"hidden":a=l.tail;for(var t=null;a!==null;)a.alternate!==null&&(t=a),a=a.sibling;t===null?l.tail=null:t.sibling=null;break;case"collapsed":t=l.tail;for(var e=null;t!==null;)t.alternate!==null&&(e=t),t=t.sibling;e===null?a||l.tail===null?l.tail=null:l.tail.sibling=null:e.sibling=null}}function ml(l){var a=l.alternate!==null&&l.alternate.child===l.child,t=0,e=0;if(a)for(var n=l.child;n!==null;)t|=n.lanes|n.childLanes,e|=n.subtreeFlags&65011712,e|=n.flags&65011712,n.return=l,n=n.sibling;else for(n=l.child;n!==null;)t|=n.lanes|n.childLanes,e|=n.subtreeFlags,e|=n.flags,n.return=l,n=n.sibling;return l.subtreeFlags|=e,l.childLanes=t,a}function s1(l,a,t){var e=a.pendingProps;switch(Ku(a),a.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return ml(a),null;case 1:return ml(a),null;case 3:return t=a.stateNode,e=null,l!==null&&(e=l.memoizedState.cache),a.memoizedState.cache!==e&&(a.flags|=2048),at(Al),na(),t.pendingContext&&(t.context=t.pendingContext,t.pendingContext=null),(l===null||l.child===null)&&(Ge(a)?it(a):l===null||l.memoizedState.isDehydrated&&(a.flags&256)===0||(a.flags|=1024,Wu())),ml(a),null;case 26:var n=a.type,i=a.memoizedState;return l===null?(it(a),i!==null?(ml(a),to(a,i)):(ml(a),Yc(a,n,null,e,t))):i?i!==l.memoizedState?(it(a),ml(a),to(a,i)):(ml(a),a.flags&=-16777217):(l=l.memoizedProps,l!==e&&it(a),ml(a),Yc(a,n,l,e,t)),null;case 27:if(Na(a),t=ea.current,n=a.type,l!==null&&a.stateNode!=null)l.memoizedProps!==e&&it(a);else{if(!e){if(a.stateNode===null)throw Error(g(166));return ml(a),null}l=pl.current,Ge(a)?Hs(a):(l=rd(n,e,t),a.stateNode=l,it(a))}return ml(a),null;case 5:if(Na(a),n=a.type,l!==null&&a.stateNode!=null)l.memoizedProps!==e&&it(a);else{if(!e){if(a.stateNode===null)throw Error(g(166));return ml(a),null}if(i=pl.current,Ge(a))Hs(a);else{var u=au(ea.current);switch(i){case 1:i=u.createElementNS("http://www.w3.org/2000/svg",n);break;case 2:i=u.createElementNS("http://www.w3.org/1998/Math/MathML",n);break;default:switch(n){case"svg":i=u.createElementNS("http://www.w3.org/2000/svg",n);break;case"math":i=u.createElementNS("http://www.w3.org/1998/Math/MathML",n);break;case"script":i=u.createElement("div"),i.innerHTML="<script><\/script>",i=i.removeChild(i.firstChild);break;case"select":i=typeof e.is=="string"?u.createElement("select",{is:e.is}):u.createElement("select"),e.multiple?i.multiple=!0:e.size&&(i.size=e.size);break;default:i=typeof e.is=="string"?u.createElement(n,{is:e.is}):u.createElement(n)}}i[ql]=a,i[Jl]=e;l:for(u=a.child;u!==null;){if(u.tag===5||u.tag===6)i.appendChild(u.stateNode);else if(u.tag!==4&&u.tag!==27&&u.child!==null){u.child.return=u,u=u.child;continue}if(u===a)break l;for(;u.sibling===null;){if(u.return===null||u.return===a)break l;u=u.return}u.sibling.return=u.return,u=u.sibling}a.stateNode=i;l:switch(Ql(i,n,e),n){case"button":case"input":case"select":case"textarea":e=!!e.autoFocus;break l;case"img":e=!0;break l;default:e=!1}e&&it(a)}}return ml(a),Yc(a,a.type,l===null?null:l.memoizedProps,a.pendingProps,t),null;case 6:if(l&&a.stateNode!=null)l.memoizedProps!==e&&it(a);else{if(typeof e!="string"&&a.stateNode===null)throw Error(g(166));if(l=ea.current,Ge(a)){if(l=a.stateNode,t=a.memoizedProps,e=null,n=Rl,n!==null)switch(n.tag){case 27:case 5:e=n.memoizedProps}l[ql]=a,l=!!(l.nodeValue===t||e!==null&&e.suppressHydrationWarning===!0||Po(l.nodeValue,t)),l||At(a,!0)}else l=au(l).createTextNode(e),l[ql]=a,a.stateNode=l}return ml(a),null;case 31:if(t=a.memoizedState,l===null||l.memoizedState!==null){if(e=Ge(a),t!==null){if(l===null){if(!e)throw Error(g(318));if(l=a.memoizedState,l=l!==null?l.dehydrated:null,!l)throw Error(g(557));l[ql]=a}else te(),(a.flags&128)===0&&(a.memoizedState=null),a.flags|=4;ml(a),l=!1}else t=Wu(),l!==null&&l.memoizedState!==null&&(l.memoizedState.hydrationErrors=t),l=!0;if(!l)return a.flags&256?(sa(a),a):(sa(a),null);if((a.flags&128)!==0)throw Error(g(558))}return ml(a),null;case 13:if(e=a.memoizedState,l===null||l.memoizedState!==null&&l.memoizedState.dehydrated!==null){if(n=Ge(a),e!==null&&e.dehydrated!==null){if(l===null){if(!n)throw Error(g(318));if(n=a.memoizedState,n=n!==null?n.dehydrated:null,!n)throw Error(g(317));n[ql]=a}else te(),(a.flags&128)===0&&(a.memoizedState=null),a.flags|=4;ml(a),n=!1}else n=Wu(),l!==null&&l.memoizedState!==null&&(l.memoizedState.hydrationErrors=n),n=!0;if(!n)return a.flags&256?(sa(a),a):(sa(a),null)}return sa(a),(a.flags&128)!==0?(a.lanes=t,a):(t=e!==null,l=l!==null&&l.memoizedState!==null,t&&(e=a.child,n=null,e.alternate!==null&&e.alternate.memoizedState!==null&&e.alternate.memoizedState.cachePool!==null&&(n=e.alternate.memoizedState.cachePool.pool),i=null,e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(i=e.memoizedState.cachePool.pool),i!==n&&(e.flags|=2048)),t!==l&&t&&(a.child.flags|=8192),Gi(a,a.updateQueue),ml(a),null);case 4:return na(),l===null&&ff(a.stateNode.containerInfo),ml(a),null;case 10:return at(a.type),ml(a),null;case 19:if(il(vl),e=a.memoizedState,e===null)return ml(a),null;if(n=(a.flags&128)!==0,i=e.rendering,i===null)if(n)qn(e,!1);else{if(bl!==0||l!==null&&(l.flags&128)!==0)for(l=a.child;l!==null;){if(i=Mi(l),i!==null){for(a.flags|=128,qn(e,!1),l=i.updateQueue,a.updateQueue=l,Gi(a,l),a.subtreeFlags=0,l=t,t=a.child;t!==null;)Ds(t,l),t=t.sibling;return Z(vl,vl.current&1|2),L&&Pa(a,e.treeForkCount),a.child}l=l.sibling}e.tail!==null&&wl()>Zi&&(a.flags|=128,n=!0,qn(e,!1),a.lanes=4194304)}else{if(!n)if(l=Mi(i),l!==null){if(a.flags|=128,n=!0,l=l.updateQueue,a.updateQueue=l,Gi(a,l),qn(e,!0),e.tail===null&&e.tailMode==="hidden"&&!i.alternate&&!L)return ml(a),null}else 2*wl()-e.renderingStartTime>Zi&&t!==536870912&&(a.flags|=128,n=!0,qn(e,!1),a.lanes=4194304);e.isBackwards?(i.sibling=a.child,a.child=i):(l=e.last,l!==null?l.sibling=i:a.child=i,e.last=i)}return e.tail!==null?(l=e.tail,e.rendering=l,e.tail=l.sibling,e.renderingStartTime=wl(),l.sibling=null,t=vl.current,Z(vl,n?t&1|2:t&1),L&&Pa(a,e.treeForkCount),l):(ml(a),null);case 22:case 23:return sa(a),fc(),e=a.memoizedState!==null,l!==null?l.memoizedState!==null!==e&&(a.flags|=8192):e&&(a.flags|=8192),e?(t&536870912)!==0&&(a.flags&128)===0&&(ml(a),a.subtreeFlags&6&&(a.flags|=8192)):ml(a),t=a.updateQueue,t!==null&&Gi(a,t.retryQueue),t=null,l!==null&&l.memoizedState!==null&&l.memoizedState.cachePool!==null&&(t=l.memoizedState.cachePool.pool),e=null,a.memoizedState!==null&&a.memoizedState.cachePool!==null&&(e=a.memoizedState.cachePool.pool),e!==t&&(a.flags|=2048),l!==null&&il(ie),null;case 24:return t=null,l!==null&&(t=l.memoizedState.cache),a.memoizedState.cache!==t&&(a.flags|=2048),at(Al),ml(a),null;case 25:return null;case 30:return null}throw Error(g(156,a.tag))}function r1(l,a){switch(Ku(a),a.tag){case 1:return l=a.flags,l&65536?(a.flags=l&-65537|128,a):null;case 3:return at(Al),na(),l=a.flags,(l&65536)!==0&&(l&128)===0?(a.flags=l&-65537|128,a):null;case 26:case 27:case 5:return Na(a),null;case 31:if(a.memoizedState!==null){if(sa(a),a.alternate===null)throw Error(g(340));te()}return l=a.flags,l&65536?(a.flags=l&-65537|128,a):null;case 13:if(sa(a),l=a.memoizedState,l!==null&&l.dehydrated!==null){if(a.alternate===null)throw Error(g(340));te()}return l=a.flags,l&65536?(a.flags=l&-65537|128,a):null;case 19:return il(vl),null;case 4:return na(),null;case 10:return at(a.type),null;case 22:case 23:return sa(a),fc(),l!==null&&il(ie),l=a.flags,l&65536?(a.flags=l&-65537|128,a):null;case 24:return at(Al),null;case 25:return null;default:return null}}function eo(l,a){switch(Ku(a),a.tag){case 3:at(Al),na();break;case 26:case 27:case 5:Na(a);break;case 4:na();break;case 31:a.memoizedState!==null&&sa(a);break;case 13:sa(a);break;case 19:il(vl);break;case 10:at(a.type);break;case 22:case 23:sa(a),fc(),l!==null&&il(ie);break;case 24:at(Al)}}function Rn(l,a){try{var t=a.updateQueue,e=t!==null?t.lastEffect:null;if(e!==null){var n=e.next;t=n;do{if((t.tag&l)===l){e=void 0;var i=t.create,u=t.inst;e=i(),u.destroy=e}t=t.next}while(t!==n)}}catch(f){el(a,a.return,f)}}function jt(l,a,t){try{var e=a.updateQueue,n=e!==null?e.lastEffect:null;if(n!==null){var i=n.next;e=i;do{if((e.tag&l)===l){var u=e.inst,f=u.destroy;if(f!==void 0){u.destroy=void 0,n=a;var s=t,p=f;try{p()}catch(x){el(n,s,x)}}}e=e.next}while(e!==i)}}catch(x){el(a,a.return,x)}}function no(l){var a=l.updateQueue;if(a!==null){var t=l.stateNode;try{Js(a,t)}catch(e){el(l,l.return,e)}}}function io(l,a,t){t.props=re(l.type,l.memoizedProps),t.state=l.memoizedState;try{t.componentWillUnmount()}catch(e){el(l,a,e)}}function Yn(l,a){try{var t=l.ref;if(t!==null){switch(l.tag){case 26:case 27:case 5:var e=l.stateNode;break;case 30:e=l.stateNode;break;default:e=l.stateNode}typeof t=="function"?l.refCleanup=t(e):t.current=e}}catch(n){el(l,a,n)}}function Qa(l,a){var t=l.ref,e=l.refCleanup;if(t!==null)if(typeof e=="function")try{e()}catch(n){el(l,a,n)}finally{l.refCleanup=null,l=l.alternate,l!=null&&(l.refCleanup=null)}else if(typeof t=="function")try{t(null)}catch(n){el(l,a,n)}else t.current=null}function uo(l){var a=l.type,t=l.memoizedProps,e=l.stateNode;try{l:switch(a){case"button":case"input":case"select":case"textarea":t.autoFocus&&e.focus();break l;case"img":t.src?e.src=t.src:t.srcSet&&(e.srcset=t.srcSet)}}catch(n){el(l,l.return,n)}}function Gc(l,a,t){try{var e=l.stateNode;w1(e,l.type,t,a),e[Jl]=a}catch(n){el(l,l.return,n)}}function co(l){return l.tag===5||l.tag===3||l.tag===26||l.tag===27&&Rt(l.type)||l.tag===4}function Qc(l){l:for(;;){for(;l.sibling===null;){if(l.return===null||co(l.return))return null;l=l.return}for(l.sibling.return=l.return,l=l.sibling;l.tag!==5&&l.tag!==6&&l.tag!==18;){if(l.tag===27&&Rt(l.type)||l.flags&2||l.child===null||l.tag===4)continue l;l.child.return=l,l=l.child}if(!(l.flags&2))return l.stateNode}}function Xc(l,a,t){var e=l.tag;if(e===5||e===6)l=l.stateNode,a?(t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t).insertBefore(l,a):(a=t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t,a.appendChild(l),t=t._reactRootContainer,t!=null||a.onclick!==null||(a.onclick=$a));else if(e!==4&&(e===27&&Rt(l.type)&&(t=l.stateNode,a=null),l=l.child,l!==null))for(Xc(l,a,t),l=l.sibling;l!==null;)Xc(l,a,t),l=l.sibling}function Qi(l,a,t){var e=l.tag;if(e===5||e===6)l=l.stateNode,a?t.insertBefore(l,a):t.appendChild(l);else if(e!==4&&(e===27&&Rt(l.type)&&(t=l.stateNode),l=l.child,l!==null))for(Qi(l,a,t),l=l.sibling;l!==null;)Qi(l,a,t),l=l.sibling}function fo(l){var a=l.stateNode,t=l.memoizedProps;try{for(var e=l.type,n=a.attributes;n.length;)a.removeAttributeNode(n[0]);Ql(a,e,t),a[ql]=l,a[Jl]=t}catch(i){el(l,l.return,i)}}var ut=!1,Ml=!1,kc=!1,so=typeof WeakSet=="function"?WeakSet:Set,Hl=null;function o1(l,a){if(l=l.containerInfo,of=fu,l=Ss(l),Bu(l)){if("selectionStart"in l)var t={start:l.selectionStart,end:l.selectionEnd};else l:{t=(t=l.ownerDocument)&&t.defaultView||window;var e=t.getSelection&&t.getSelection();if(e&&e.rangeCount!==0){t=e.anchorNode;var n=e.anchorOffset,i=e.focusNode;e=e.focusOffset;try{t.nodeType,i.nodeType}catch{t=null;break l}var u=0,f=-1,s=-1,p=0,x=0,_=l,y=null;a:for(;;){for(var b;_!==t||n!==0&&_.nodeType!==3||(f=u+n),_!==i||e!==0&&_.nodeType!==3||(s=u+e),_.nodeType===3&&(u+=_.nodeValue.length),(b=_.firstChild)!==null;)y=_,_=b;for(;;){if(_===l)break a;if(y===t&&++p===n&&(f=u),y===i&&++x===e&&(s=u),(b=_.nextSibling)!==null)break;_=y,y=_.parentNode}_=b}t=f===-1||s===-1?null:{start:f,end:s}}else t=null}t=t||{start:0,end:0}}else t=null;for(df={focusedElem:l,selectionRange:t},fu=!1,Hl=a;Hl!==null;)if(a=Hl,l=a.child,(a.subtreeFlags&1028)!==0&&l!==null)l.return=a,Hl=l;else for(;Hl!==null;){switch(a=Hl,i=a.alternate,l=a.flags,a.tag){case 0:if((l&4)!==0&&(l=a.updateQueue,l=l!==null?l.events:null,l!==null))for(t=0;t<l.length;t++)n=l[t],n.ref.impl=n.nextImpl;break;case 11:case 15:break;case 1:if((l&1024)!==0&&i!==null){l=void 0,t=a,n=i.memoizedProps,i=i.memoizedState,e=t.stateNode;try{var M=re(t.type,n);l=e.getSnapshotBeforeUpdate(M,i),e.__reactInternalSnapshotBeforeUpdate=l}catch(U){el(t,t.return,U)}}break;case 3:if((l&1024)!==0){if(l=a.stateNode.containerInfo,t=l.nodeType,t===9)hf(l);else if(t===1)switch(l.nodeName){case"HEAD":case"HTML":case"BODY":hf(l);break;default:l.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((l&1024)!==0)throw Error(g(163))}if(l=a.sibling,l!==null){l.return=a.return,Hl=l;break}Hl=a.return}}function ro(l,a,t){var e=t.flags;switch(t.tag){case 0:case 11:case 15:ft(l,t),e&4&&Rn(5,t);break;case 1:if(ft(l,t),e&4)if(l=t.stateNode,a===null)try{l.componentDidMount()}catch(u){el(t,t.return,u)}else{var n=re(t.type,a.memoizedProps);a=a.memoizedState;try{l.componentDidUpdate(n,a,l.__reactInternalSnapshotBeforeUpdate)}catch(u){el(t,t.return,u)}}e&64&&no(t),e&512&&Yn(t,t.return);break;case 3:if(ft(l,t),e&64&&(l=t.updateQueue,l!==null)){if(a=null,t.child!==null)switch(t.child.tag){case 27:case 5:a=t.child.stateNode;break;case 1:a=t.child.stateNode}try{Js(l,a)}catch(u){el(t,t.return,u)}}break;case 27:a===null&&e&4&&fo(t);case 26:case 5:ft(l,t),a===null&&e&4&&uo(t),e&512&&Yn(t,t.return);break;case 12:ft(l,t);break;case 31:ft(l,t),e&4&&go(l,t);break;case 13:ft(l,t),e&4&&ho(l,t),e&64&&(l=t.memoizedState,l!==null&&(l=l.dehydrated,l!==null&&(t=x1.bind(null,t),G1(l,t))));break;case 22:if(e=t.memoizedState!==null||ut,!e){a=a!==null&&a.memoizedState!==null||Ml,n=ut;var i=Ml;ut=e,(Ml=a)&&!i?st(l,t,(t.subtreeFlags&8772)!==0):ft(l,t),ut=n,Ml=i}break;case 30:break;default:ft(l,t)}}function oo(l){var a=l.alternate;a!==null&&(l.alternate=null,oo(a)),l.child=null,l.deletions=null,l.sibling=null,l.tag===5&&(a=l.stateNode,a!==null&&vu(a)),l.stateNode=null,l.return=null,l.dependencies=null,l.memoizedProps=null,l.memoizedState=null,l.pendingProps=null,l.stateNode=null,l.updateQueue=null}var hl=null,$l=!1;function ct(l,a,t){for(t=t.child;t!==null;)mo(l,a,t),t=t.sibling}function mo(l,a,t){if(_l&&typeof _l.onCommitFiberUnmount=="function")try{_l.onCommitFiberUnmount(ha,t)}catch{}switch(t.tag){case 26:Ml||Qa(t,a),ct(l,a,t),t.memoizedState?t.memoizedState.count--:t.stateNode&&(t=t.stateNode,t.parentNode.removeChild(t));break;case 27:Ml||Qa(t,a);var e=hl,n=$l;Rt(t.type)&&(hl=t.stateNode,$l=!1),ct(l,a,t),Jn(t.stateNode),hl=e,$l=n;break;case 5:Ml||Qa(t,a);case 6:if(e=hl,n=$l,hl=null,ct(l,a,t),hl=e,$l=n,hl!==null)if($l)try{(hl.nodeType===9?hl.body:hl.nodeName==="HTML"?hl.ownerDocument.body:hl).removeChild(t.stateNode)}catch(i){el(t,a,i)}else try{hl.removeChild(t.stateNode)}catch(i){el(t,a,i)}break;case 18:hl!==null&&($l?(l=hl,id(l.nodeType===9?l.body:l.nodeName==="HTML"?l.ownerDocument.body:l,t.stateNode),fn(l)):id(hl,t.stateNode));break;case 4:e=hl,n=$l,hl=t.stateNode.containerInfo,$l=!0,ct(l,a,t),hl=e,$l=n;break;case 0:case 11:case 14:case 15:jt(2,t,a),Ml||jt(4,t,a),ct(l,a,t);break;case 1:Ml||(Qa(t,a),e=t.stateNode,typeof e.componentWillUnmount=="function"&&io(t,a,e)),ct(l,a,t);break;case 21:ct(l,a,t);break;case 22:Ml=(e=Ml)||t.memoizedState!==null,ct(l,a,t),Ml=e;break;default:ct(l,a,t)}}function go(l,a){if(a.memoizedState===null&&(l=a.alternate,l!==null&&(l=l.memoizedState,l!==null))){l=l.dehydrated;try{fn(l)}catch(t){el(a,a.return,t)}}}function ho(l,a){if(a.memoizedState===null&&(l=a.alternate,l!==null&&(l=l.memoizedState,l!==null&&(l=l.dehydrated,l!==null))))try{fn(l)}catch(t){el(a,a.return,t)}}function d1(l){switch(l.tag){case 31:case 13:case 19:var a=l.stateNode;return a===null&&(a=l.stateNode=new so),a;case 22:return l=l.stateNode,a=l._retryCache,a===null&&(a=l._retryCache=new so),a;default:throw Error(g(435,l.tag))}}function Xi(l,a){var t=d1(l);a.forEach(function(e){if(!t.has(e)){t.add(e);var n=S1.bind(null,l,e);e.then(n,n)}})}function Fl(l,a){var t=a.deletions;if(t!==null)for(var e=0;e<t.length;e++){var n=t[e],i=l,u=a,f=u;l:for(;f!==null;){switch(f.tag){case 27:if(Rt(f.type)){hl=f.stateNode,$l=!1;break l}break;case 5:hl=f.stateNode,$l=!1;break l;case 3:case 4:hl=f.stateNode.containerInfo,$l=!0;break l}f=f.return}if(hl===null)throw Error(g(160));mo(i,u,n),hl=null,$l=!1,i=n.alternate,i!==null&&(i.return=null),n.return=null}if(a.subtreeFlags&13886)for(a=a.child;a!==null;)po(a,l),a=a.sibling}var Ca=null;function po(l,a){var t=l.alternate,e=l.flags;switch(l.tag){case 0:case 11:case 14:case 15:Fl(a,l),Il(l),e&4&&(jt(3,l,l.return),Rn(3,l),jt(5,l,l.return));break;case 1:Fl(a,l),Il(l),e&512&&(Ml||t===null||Qa(t,t.return)),e&64&&ut&&(l=l.updateQueue,l!==null&&(e=l.callbacks,e!==null&&(t=l.shared.hiddenCallbacks,l.shared.hiddenCallbacks=t===null?e:t.concat(e))));break;case 26:var n=Ca;if(Fl(a,l),Il(l),e&512&&(Ml||t===null||Qa(t,t.return)),e&4){var i=t!==null?t.memoizedState:null;if(e=l.memoizedState,t===null)if(e===null)if(l.stateNode===null){l:{e=l.type,t=l.memoizedProps,n=n.ownerDocument||n;a:switch(e){case"title":i=n.getElementsByTagName("title")[0],(!i||i[dn]||i[ql]||i.namespaceURI==="http://www.w3.org/2000/svg"||i.hasAttribute("itemprop"))&&(i=n.createElement(e),n.head.insertBefore(i,n.querySelector("head > title"))),Ql(i,e,t),i[ql]=l,Cl(i),e=i;break l;case"link":var u=pd("link","href",n).get(e+(t.href||""));if(u){for(var f=0;f<u.length;f++)if(i=u[f],i.getAttribute("href")===(t.href==null||t.href===""?null:t.href)&&i.getAttribute("rel")===(t.rel==null?null:t.rel)&&i.getAttribute("title")===(t.title==null?null:t.title)&&i.getAttribute("crossorigin")===(t.crossOrigin==null?null:t.crossOrigin)){u.splice(f,1);break a}}i=n.createElement(e),Ql(i,e,t),n.head.appendChild(i);break;case"meta":if(u=pd("meta","content",n).get(e+(t.content||""))){for(f=0;f<u.length;f++)if(i=u[f],i.getAttribute("content")===(t.content==null?null:""+t.content)&&i.getAttribute("name")===(t.name==null?null:t.name)&&i.getAttribute("property")===(t.property==null?null:t.property)&&i.getAttribute("http-equiv")===(t.httpEquiv==null?null:t.httpEquiv)&&i.getAttribute("charset")===(t.charSet==null?null:t.charSet)){u.splice(f,1);break a}}i=n.createElement(e),Ql(i,e,t),n.head.appendChild(i);break;default:throw Error(g(468,e))}i[ql]=l,Cl(i),e=i}l.stateNode=e}else yd(n,l.type,l.stateNode);else l.stateNode=hd(n,e,l.memoizedProps);else i!==e?(i===null?t.stateNode!==null&&(t=t.stateNode,t.parentNode.removeChild(t)):i.count--,e===null?yd(n,l.type,l.stateNode):hd(n,e,l.memoizedProps)):e===null&&l.stateNode!==null&&Gc(l,l.memoizedProps,t.memoizedProps)}break;case 27:Fl(a,l),Il(l),e&512&&(Ml||t===null||Qa(t,t.return)),t!==null&&e&4&&Gc(l,l.memoizedProps,t.memoizedProps);break;case 5:if(Fl(a,l),Il(l),e&512&&(Ml||t===null||Qa(t,t.return)),l.flags&32){n=l.stateNode;try{De(n,"")}catch(M){el(l,l.return,M)}}e&4&&l.stateNode!=null&&(n=l.memoizedProps,Gc(l,n,t!==null?t.memoizedProps:n)),e&1024&&(kc=!0);break;case 6:if(Fl(a,l),Il(l),e&4){if(l.stateNode===null)throw Error(g(162));e=l.memoizedProps,t=l.stateNode;try{t.nodeValue=e}catch(M){el(l,l.return,M)}}break;case 3:if(nu=null,n=Ca,Ca=tu(a.containerInfo),Fl(a,l),Ca=n,Il(l),e&4&&t!==null&&t.memoizedState.isDehydrated)try{fn(a.containerInfo)}catch(M){el(l,l.return,M)}kc&&(kc=!1,yo(l));break;case 4:e=Ca,Ca=tu(l.stateNode.containerInfo),Fl(a,l),Il(l),Ca=e;break;case 12:Fl(a,l),Il(l);break;case 31:Fl(a,l),Il(l),e&4&&(e=l.updateQueue,e!==null&&(l.updateQueue=null,Xi(l,e)));break;case 13:Fl(a,l),Il(l),l.child.flags&8192&&l.memoizedState!==null!=(t!==null&&t.memoizedState!==null)&&(Vi=wl()),e&4&&(e=l.updateQueue,e!==null&&(l.updateQueue=null,Xi(l,e)));break;case 22:n=l.memoizedState!==null;var s=t!==null&&t.memoizedState!==null,p=ut,x=Ml;if(ut=p||n,Ml=x||s,Fl(a,l),Ml=x,ut=p,Il(l),e&8192)l:for(a=l.stateNode,a._visibility=n?a._visibility&-2:a._visibility|1,n&&(t===null||s||ut||Ml||oe(l)),t=null,a=l;;){if(a.tag===5||a.tag===26){if(t===null){s=t=a;try{if(i=s.stateNode,n)u=i.style,typeof u.setProperty=="function"?u.setProperty("display","none","important"):u.display="none";else{f=s.stateNode;var _=s.memoizedProps.style,y=_!=null&&_.hasOwnProperty("display")?_.display:null;f.style.display=y==null||typeof y=="boolean"?"":(""+y).trim()}}catch(M){el(s,s.return,M)}}}else if(a.tag===6){if(t===null){s=a;try{s.stateNode.nodeValue=n?"":s.memoizedProps}catch(M){el(s,s.return,M)}}}else if(a.tag===18){if(t===null){s=a;try{var b=s.stateNode;n?ud(b,!0):ud(s.stateNode,!1)}catch(M){el(s,s.return,M)}}}else if((a.tag!==22&&a.tag!==23||a.memoizedState===null||a===l)&&a.child!==null){a.child.return=a,a=a.child;continue}if(a===l)break l;for(;a.sibling===null;){if(a.return===null||a.return===l)break l;t===a&&(t=null),a=a.return}t===a&&(t=null),a.sibling.return=a.return,a=a.sibling}e&4&&(e=l.updateQueue,e!==null&&(t=e.retryQueue,t!==null&&(e.retryQueue=null,Xi(l,t))));break;case 19:Fl(a,l),Il(l),e&4&&(e=l.updateQueue,e!==null&&(l.updateQueue=null,Xi(l,e)));break;case 30:break;case 21:break;default:Fl(a,l),Il(l)}}function Il(l){var a=l.flags;if(a&2){try{for(var t,e=l.return;e!==null;){if(co(e)){t=e;break}e=e.return}if(t==null)throw Error(g(160));switch(t.tag){case 27:var n=t.stateNode,i=Qc(l);Qi(l,i,n);break;case 5:var u=t.stateNode;t.flags&32&&(De(u,""),t.flags&=-33);var f=Qc(l);Qi(l,f,u);break;case 3:case 4:var s=t.stateNode.containerInfo,p=Qc(l);Xc(l,p,s);break;default:throw Error(g(161))}}catch(x){el(l,l.return,x)}l.flags&=-3}a&4096&&(l.flags&=-4097)}function yo(l){if(l.subtreeFlags&1024)for(l=l.child;l!==null;){var a=l;yo(a),a.tag===5&&a.flags&1024&&a.stateNode.reset(),l=l.sibling}}function ft(l,a){if(a.subtreeFlags&8772)for(a=a.child;a!==null;)ro(l,a.alternate,a),a=a.sibling}function oe(l){for(l=l.child;l!==null;){var a=l;switch(a.tag){case 0:case 11:case 14:case 15:jt(4,a,a.return),oe(a);break;case 1:Qa(a,a.return);var t=a.stateNode;typeof t.componentWillUnmount=="function"&&io(a,a.return,t),oe(a);break;case 27:Jn(a.stateNode);case 26:case 5:Qa(a,a.return),oe(a);break;case 22:a.memoizedState===null&&oe(a);break;case 30:oe(a);break;default:oe(a)}l=l.sibling}}function st(l,a,t){for(t=t&&(a.subtreeFlags&8772)!==0,a=a.child;a!==null;){var e=a.alternate,n=l,i=a,u=i.flags;switch(i.tag){case 0:case 11:case 15:st(n,i,t),Rn(4,i);break;case 1:if(st(n,i,t),e=i,n=e.stateNode,typeof n.componentDidMount=="function")try{n.componentDidMount()}catch(p){el(e,e.return,p)}if(e=i,n=e.updateQueue,n!==null){var f=e.stateNode;try{var s=n.shared.hiddenCallbacks;if(s!==null)for(n.shared.hiddenCallbacks=null,n=0;n<s.length;n++)Ks(s[n],f)}catch(p){el(e,e.return,p)}}t&&u&64&&no(i),Yn(i,i.return);break;case 27:fo(i);case 26:case 5:st(n,i,t),t&&e===null&&u&4&&uo(i),Yn(i,i.return);break;case 12:st(n,i,t);break;case 31:st(n,i,t),t&&u&4&&go(n,i);break;case 13:st(n,i,t),t&&u&4&&ho(n,i);break;case 22:i.memoizedState===null&&st(n,i,t),Yn(i,i.return);break;case 30:break;default:st(n,i,t)}a=a.sibling}}function Vc(l,a){var t=null;l!==null&&l.memoizedState!==null&&l.memoizedState.cachePool!==null&&(t=l.memoizedState.cachePool.pool),l=null,a.memoizedState!==null&&a.memoizedState.cachePool!==null&&(l=a.memoizedState.cachePool.pool),l!==t&&(l!=null&&l.refCount++,t!=null&&En(t))}function Zc(l,a){l=null,a.alternate!==null&&(l=a.alternate.memoizedState.cache),a=a.memoizedState.cache,a!==l&&(a.refCount++,l!=null&&En(l))}function Ha(l,a,t,e){if(a.subtreeFlags&10256)for(a=a.child;a!==null;)bo(l,a,t,e),a=a.sibling}function bo(l,a,t,e){var n=a.flags;switch(a.tag){case 0:case 11:case 15:Ha(l,a,t,e),n&2048&&Rn(9,a);break;case 1:Ha(l,a,t,e);break;case 3:Ha(l,a,t,e),n&2048&&(l=null,a.alternate!==null&&(l=a.alternate.memoizedState.cache),a=a.memoizedState.cache,a!==l&&(a.refCount++,l!=null&&En(l)));break;case 12:if(n&2048){Ha(l,a,t,e),l=a.stateNode;try{var i=a.memoizedProps,u=i.id,f=i.onPostCommit;typeof f=="function"&&f(u,a.alternate===null?"mount":"update",l.passiveEffectDuration,-0)}catch(s){el(a,a.return,s)}}else Ha(l,a,t,e);break;case 31:Ha(l,a,t,e);break;case 13:Ha(l,a,t,e);break;case 23:break;case 22:i=a.stateNode,u=a.alternate,a.memoizedState!==null?i._visibility&2?Ha(l,a,t,e):Gn(l,a):i._visibility&2?Ha(l,a,t,e):(i._visibility|=2,$e(l,a,t,e,(a.subtreeFlags&10256)!==0||!1)),n&2048&&Vc(u,a);break;case 24:Ha(l,a,t,e),n&2048&&Zc(a.alternate,a);break;default:Ha(l,a,t,e)}}function $e(l,a,t,e,n){for(n=n&&((a.subtreeFlags&10256)!==0||!1),a=a.child;a!==null;){var i=l,u=a,f=t,s=e,p=u.flags;switch(u.tag){case 0:case 11:case 15:$e(i,u,f,s,n),Rn(8,u);break;case 23:break;case 22:var x=u.stateNode;u.memoizedState!==null?x._visibility&2?$e(i,u,f,s,n):Gn(i,u):(x._visibility|=2,$e(i,u,f,s,n)),n&&p&2048&&Vc(u.alternate,u);break;case 24:$e(i,u,f,s,n),n&&p&2048&&Zc(u.alternate,u);break;default:$e(i,u,f,s,n)}a=a.sibling}}function Gn(l,a){if(a.subtreeFlags&10256)for(a=a.child;a!==null;){var t=l,e=a,n=e.flags;switch(e.tag){case 22:Gn(t,e),n&2048&&Vc(e.alternate,e);break;case 24:Gn(t,e),n&2048&&Zc(e.alternate,e);break;default:Gn(t,e)}a=a.sibling}}var Qn=8192;function Fe(l,a,t){if(l.subtreeFlags&Qn)for(l=l.child;l!==null;)vo(l,a,t),l=l.sibling}function vo(l,a,t){switch(l.tag){case 26:Fe(l,a,t),l.flags&Qn&&l.memoizedState!==null&&I1(t,Ca,l.memoizedState,l.memoizedProps);break;case 5:Fe(l,a,t);break;case 3:case 4:var e=Ca;Ca=tu(l.stateNode.containerInfo),Fe(l,a,t),Ca=e;break;case 22:l.memoizedState===null&&(e=l.alternate,e!==null&&e.memoizedState!==null?(e=Qn,Qn=16777216,Fe(l,a,t),Qn=e):Fe(l,a,t));break;default:Fe(l,a,t)}}function xo(l){var a=l.alternate;if(a!==null&&(l=a.child,l!==null)){a.child=null;do a=l.sibling,l.sibling=null,l=a;while(l!==null)}}function Xn(l){var a=l.deletions;if((l.flags&16)!==0){if(a!==null)for(var t=0;t<a.length;t++){var e=a[t];Hl=e,zo(e,l)}xo(l)}if(l.subtreeFlags&10256)for(l=l.child;l!==null;)So(l),l=l.sibling}function So(l){switch(l.tag){case 0:case 11:case 15:Xn(l),l.flags&2048&&jt(9,l,l.return);break;case 3:Xn(l);break;case 12:Xn(l);break;case 22:var a=l.stateNode;l.memoizedState!==null&&a._visibility&2&&(l.return===null||l.return.tag!==13)?(a._visibility&=-3,ki(l)):Xn(l);break;default:Xn(l)}}function ki(l){var a=l.deletions;if((l.flags&16)!==0){if(a!==null)for(var t=0;t<a.length;t++){var e=a[t];Hl=e,zo(e,l)}xo(l)}for(l=l.child;l!==null;){switch(a=l,a.tag){case 0:case 11:case 15:jt(8,a,a.return),ki(a);break;case 22:t=a.stateNode,t._visibility&2&&(t._visibility&=-3,ki(a));break;default:ki(a)}l=l.sibling}}function zo(l,a){for(;Hl!==null;){var t=Hl;switch(t.tag){case 0:case 11:case 15:jt(8,t,a);break;case 23:case 22:if(t.memoizedState!==null&&t.memoizedState.cachePool!==null){var e=t.memoizedState.cachePool.pool;e!=null&&e.refCount++}break;case 24:En(t.memoizedState.cache)}if(e=t.child,e!==null)e.return=t,Hl=e;else l:for(t=l;Hl!==null;){e=Hl;var n=e.sibling,i=e.return;if(oo(e),e===t){Hl=null;break l}if(n!==null){n.return=i,Hl=n;break l}Hl=i}}}var m1={getCacheForType:function(l){var a=Yl(Al),t=a.data.get(l);return t===void 0&&(t=l(),a.data.set(l,t)),t},cacheSignal:function(){return Yl(Al).controller.signal}},g1=typeof WeakMap=="function"?WeakMap:Map,P=0,ol=null,G=null,X=0,tl=0,ra=null,wt=!1,Ie=!1,Lc=!1,rt=0,bl=0,Ut=0,de=0,Kc=0,oa=0,Pe=0,kn=null,Pl=null,Jc=!1,Vi=0,_o=0,Zi=1/0,Li=null,Ct=null,Dl=0,Ht=null,ln=null,ot=0,Wc=0,$c=null,Ao=null,Vn=0,Fc=null;function da(){return(P&2)!==0&&X!==0?X&-X:S.T!==null?ef():Yf()}function Eo(){if(oa===0)if((X&536870912)===0||L){var l=ja;ja<<=1,(ja&3932160)===0&&(ja=262144),oa=l}else oa=536870912;return l=fa.current,l!==null&&(l.flags|=32),oa}function la(l,a,t){(l===ol&&(tl===2||tl===9)||l.cancelPendingCommit!==null)&&(an(l,0),Bt(l,X,oa,!1)),Ra(l,t),((P&2)===0||l!==ol)&&(l===ol&&((P&2)===0&&(de|=t),bl===4&&Bt(l,X,oa,!1)),Xa(l))}function To(l,a,t){if((P&6)!==0)throw Error(g(327));var e=!t&&(a&127)===0&&(a&l.expiredLanes)===0||qa(l,a),n=e?y1(l,a):Pc(l,a,!0),i=e;do{if(n===0){Ie&&!e&&Bt(l,a,0,!1);break}else{if(t=l.current.alternate,i&&!h1(t)){n=Pc(l,a,!1),i=!1;continue}if(n===2){if(i=a,l.errorRecoveryDisabledLanes&i)var u=0;else u=l.pendingLanes&-536870913,u=u!==0?u:u&536870912?536870912:0;if(u!==0){a=u;l:{var f=l;n=kn;var s=f.current.memoizedState.isDehydrated;if(s&&(an(f,u).flags|=256),u=Pc(f,u,!1),u!==2){if(Lc&&!s){f.errorRecoveryDisabledLanes|=i,de|=i,n=4;break l}i=Pl,Pl=n,i!==null&&(Pl===null?Pl=i:Pl.push.apply(Pl,i))}n=u}if(i=!1,n!==2)continue}}if(n===1){an(l,0),Bt(l,a,0,!0);break}l:{switch(e=l,i=n,i){case 0:case 1:throw Error(g(345));case 4:if((a&4194048)!==a)break;case 6:Bt(e,a,oa,!wt);break l;case 2:Pl=null;break;case 3:case 5:break;default:throw Error(g(329))}if((a&62914560)===a&&(n=Vi+300-wl(),10<n)){if(Bt(e,a,oa,!wt),Ka(e,0,!0)!==0)break l;ot=a,e.timeoutHandle=ed(Mo.bind(null,e,t,Pl,Li,Jc,a,oa,de,Pe,wt,i,"Throttled",-0,0),n);break l}Mo(e,t,Pl,Li,Jc,a,oa,de,Pe,wt,i,null,-0,0)}}break}while(!0);Xa(l)}function Mo(l,a,t,e,n,i,u,f,s,p,x,_,y,b){if(l.timeoutHandle=-1,_=a.subtreeFlags,_&8192||(_&16785408)===16785408){_={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:$a},vo(a,i,_);var M=(i&62914560)===i?Vi-wl():(i&4194048)===i?_o-wl():0;if(M=P1(_,M),M!==null){ot=i,l.cancelPendingCommit=M(Ho.bind(null,l,a,i,t,e,n,u,f,s,x,_,null,y,b)),Bt(l,i,u,!p);return}}Ho(l,a,i,t,e,n,u,f,s)}function h1(l){for(var a=l;;){var t=a.tag;if((t===0||t===11||t===15)&&a.flags&16384&&(t=a.updateQueue,t!==null&&(t=t.stores,t!==null)))for(var e=0;e<t.length;e++){var n=t[e],i=n.getSnapshot;n=n.value;try{if(!ua(i(),n))return!1}catch{return!1}}if(t=a.child,a.subtreeFlags&16384&&t!==null)t.return=a,a=t;else{if(a===l)break;for(;a.sibling===null;){if(a.return===null||a.return===l)return!0;a=a.return}a.sibling.return=a.return,a=a.sibling}}return!0}function Bt(l,a,t,e){a&=~Kc,a&=~de,l.suspendedLanes|=a,l.pingedLanes&=~a,e&&(l.warmLanes|=a),e=l.expirationTimes;for(var n=a;0<n;){var i=31-Ul(n),u=1<<i;e[i]=-1,n&=~u}t!==0&&Ja(l,t,a)}function Ki(){return(P&6)===0?(Zn(0),!1):!0}function Ic(){if(G!==null){if(tl===0)var l=G.return;else l=G,lt=ee=null,gc(l),Ze=null,Mn=0,l=G;for(;l!==null;)eo(l.alternate,l),l=l.return;G=null}}function an(l,a){var t=l.timeoutHandle;t!==-1&&(l.timeoutHandle=-1,H1(t)),t=l.cancelPendingCommit,t!==null&&(l.cancelPendingCommit=null,t()),ot=0,Ic(),ol=l,G=t=Ia(l.current,null),X=a,tl=0,ra=null,wt=!1,Ie=qa(l,a),Lc=!1,Pe=oa=Kc=de=Ut=bl=0,Pl=kn=null,Jc=!1,(a&8)!==0&&(a|=a&32);var e=l.entangledLanes;if(e!==0)for(l=l.entanglements,e&=a;0<e;){var n=31-Ul(e),i=1<<n;a|=l[n],e&=~i}return rt=a,gi(),t}function Oo(l,a){q=null,S.H=Hn,a===Ve||a===zi?(a=ks(),tl=3):a===tc?(a=ks(),tl=4):tl=a===Dc?8:a!==null&&typeof a=="object"&&typeof a.then=="function"?6:1,ra=a,G===null&&(bl=1,Bi(l,xa(a,l.current)))}function No(){var l=fa.current;return l===null?!0:(X&4194048)===X?Aa===null:(X&62914560)===X||(X&536870912)!==0?l===Aa:!1}function Do(){var l=S.H;return S.H=Hn,l===null?Hn:l}function jo(){var l=S.A;return S.A=m1,l}function Ji(){bl=4,wt||(X&4194048)!==X&&fa.current!==null||(Ie=!0),(Ut&134217727)===0&&(de&134217727)===0||ol===null||Bt(ol,X,oa,!1)}function Pc(l,a,t){var e=P;P|=2;var n=Do(),i=jo();(ol!==l||X!==a)&&(Li=null,an(l,a)),a=!1;var u=bl;l:do try{if(tl!==0&&G!==null){var f=G,s=ra;switch(tl){case 8:Ic(),u=6;break l;case 3:case 2:case 9:case 6:fa.current===null&&(a=!0);var p=tl;if(tl=0,ra=null,tn(l,f,s,p),t&&Ie){u=0;break l}break;default:p=tl,tl=0,ra=null,tn(l,f,s,p)}}p1(),u=bl;break}catch(x){Oo(l,x)}while(!0);return a&&l.shellSuspendCounter++,lt=ee=null,P=e,S.H=n,S.A=i,G===null&&(ol=null,X=0,gi()),u}function p1(){for(;G!==null;)wo(G)}function y1(l,a){var t=P;P|=2;var e=Do(),n=jo();ol!==l||X!==a?(Li=null,Zi=wl()+500,an(l,a)):Ie=qa(l,a);l:do try{if(tl!==0&&G!==null){a=G;var i=ra;a:switch(tl){case 1:tl=0,ra=null,tn(l,a,i,1);break;case 2:case 9:if(Qs(i)){tl=0,ra=null,Uo(a);break}a=function(){tl!==2&&tl!==9||ol!==l||(tl=7),Xa(l)},i.then(a,a);break l;case 3:tl=7;break l;case 4:tl=5;break l;case 7:Qs(i)?(tl=0,ra=null,Uo(a)):(tl=0,ra=null,tn(l,a,i,7));break;case 5:var u=null;switch(G.tag){case 26:u=G.memoizedState;case 5:case 27:var f=G;if(u?bd(u):f.stateNode.complete){tl=0,ra=null;var s=f.sibling;if(s!==null)G=s;else{var p=f.return;p!==null?(G=p,Wi(p)):G=null}break a}}tl=0,ra=null,tn(l,a,i,5);break;case 6:tl=0,ra=null,tn(l,a,i,6);break;case 8:Ic(),bl=6;break l;default:throw Error(g(462))}}b1();break}catch(x){Oo(l,x)}while(!0);return lt=ee=null,S.H=e,S.A=n,P=t,G!==null?0:(ol=null,X=0,gi(),bl)}function b1(){for(;G!==null&&!ge();)wo(G)}function wo(l){var a=ao(l.alternate,l,rt);l.memoizedProps=l.pendingProps,a===null?Wi(l):G=a}function Uo(l){var a=l,t=a.alternate;switch(a.tag){case 15:case 0:a=Wr(t,a,a.pendingProps,a.type,void 0,X);break;case 11:a=Wr(t,a,a.pendingProps,a.type.render,a.ref,X);break;case 5:gc(a);default:eo(t,a),a=G=Ds(a,rt),a=ao(t,a,rt)}l.memoizedProps=l.pendingProps,a===null?Wi(l):G=a}function tn(l,a,t,e){lt=ee=null,gc(a),Ze=null,Mn=0;var n=a.return;try{if(u1(l,n,a,t,X)){bl=1,Bi(l,xa(t,l.current)),G=null;return}}catch(i){if(n!==null)throw G=n,i;bl=1,Bi(l,xa(t,l.current)),G=null;return}a.flags&32768?(L||e===1?l=!0:Ie||(X&536870912)!==0?l=!1:(wt=l=!0,(e===2||e===9||e===3||e===6)&&(e=fa.current,e!==null&&e.tag===13&&(e.flags|=16384))),Co(a,l)):Wi(a)}function Wi(l){var a=l;do{if((a.flags&32768)!==0){Co(a,wt);return}l=a.return;var t=s1(a.alternate,a,rt);if(t!==null){G=t;return}if(a=a.sibling,a!==null){G=a;return}G=a=l}while(a!==null);bl===0&&(bl=5)}function Co(l,a){do{var t=r1(l.alternate,l);if(t!==null){t.flags&=32767,G=t;return}if(t=l.return,t!==null&&(t.flags|=32768,t.subtreeFlags=0,t.deletions=null),!a&&(l=l.sibling,l!==null)){G=l;return}G=l=t}while(l!==null);bl=6,G=null}function Ho(l,a,t,e,n,i,u,f,s){l.cancelPendingCommit=null;do $i();while(Dl!==0);if((P&6)!==0)throw Error(g(327));if(a!==null){if(a===l.current)throw Error(g(177));if(i=a.lanes|a.childLanes,i|=Qu,ti(l,t,i,u,f,s),l===ol&&(G=ol=null,X=0),ln=a,Ht=l,ot=t,Wc=i,$c=n,Ao=e,(a.subtreeFlags&10256)!==0||(a.flags&10256)!==0?(l.callbackNode=null,l.callbackPriority=0,z1(La,function(){return Go(),null})):(l.callbackNode=null,l.callbackPriority=0),e=(a.flags&13878)!==0,(a.subtreeFlags&13878)!==0||e){e=S.T,S.T=null,n=A.p,A.p=2,u=P,P|=4;try{o1(l,a,t)}finally{P=u,A.p=n,S.T=e}}Dl=1,Bo(),qo(),Ro()}}function Bo(){if(Dl===1){Dl=0;var l=Ht,a=ln,t=(a.flags&13878)!==0;if((a.subtreeFlags&13878)!==0||t){t=S.T,S.T=null;var e=A.p;A.p=2;var n=P;P|=4;try{po(a,l);var i=df,u=Ss(l.containerInfo),f=i.focusedElem,s=i.selectionRange;if(u!==f&&f&&f.ownerDocument&&xs(f.ownerDocument.documentElement,f)){if(s!==null&&Bu(f)){var p=s.start,x=s.end;if(x===void 0&&(x=p),"selectionStart"in f)f.selectionStart=p,f.selectionEnd=Math.min(x,f.value.length);else{var _=f.ownerDocument||document,y=_&&_.defaultView||window;if(y.getSelection){var b=y.getSelection(),M=f.textContent.length,U=Math.min(s.start,M),fl=s.end===void 0?U:Math.min(s.end,M);!b.extend&&U>fl&&(u=fl,fl=U,U=u);var m=vs(f,U),r=vs(f,fl);if(m&&r&&(b.rangeCount!==1||b.anchorNode!==m.node||b.anchorOffset!==m.offset||b.focusNode!==r.node||b.focusOffset!==r.offset)){var h=_.createRange();h.setStart(m.node,m.offset),b.removeAllRanges(),U>fl?(b.addRange(h),b.extend(r.node,r.offset)):(h.setEnd(r.node,r.offset),b.addRange(h))}}}}for(_=[],b=f;b=b.parentNode;)b.nodeType===1&&_.push({element:b,left:b.scrollLeft,top:b.scrollTop});for(typeof f.focus=="function"&&f.focus(),f=0;f<_.length;f++){var z=_[f];z.element.scrollLeft=z.left,z.element.scrollTop=z.top}}fu=!!of,df=of=null}finally{P=n,A.p=e,S.T=t}}l.current=a,Dl=2}}function qo(){if(Dl===2){Dl=0;var l=Ht,a=ln,t=(a.flags&8772)!==0;if((a.subtreeFlags&8772)!==0||t){t=S.T,S.T=null;var e=A.p;A.p=2;var n=P;P|=4;try{ro(l,a.alternate,a)}finally{P=n,A.p=e,S.T=t}}Dl=3}}function Ro(){if(Dl===4||Dl===3){Dl=0,he();var l=Ht,a=ln,t=ot,e=Ao;(a.subtreeFlags&10256)!==0||(a.flags&10256)!==0?Dl=5:(Dl=0,ln=Ht=null,Yo(l,l.pendingLanes));var n=l.pendingLanes;if(n===0&&(Ct=null),yu(t),a=a.stateNode,_l&&typeof _l.onCommitFiberRoot=="function")try{_l.onCommitFiberRoot(ha,a,void 0,(a.current.flags&128)===128)}catch{}if(e!==null){a=S.T,n=A.p,A.p=2,S.T=null;try{for(var i=l.onRecoverableError,u=0;u<e.length;u++){var f=e[u];i(f.value,{componentStack:f.stack})}}finally{S.T=a,A.p=n}}(ot&3)!==0&&$i(),Xa(l),n=l.pendingLanes,(t&261930)!==0&&(n&42)!==0?l===Fc?Vn++:(Vn=0,Fc=l):Vn=0,Zn(0)}}function Yo(l,a){(l.pooledCacheLanes&=a)===0&&(a=l.pooledCache,a!=null&&(l.pooledCache=null,En(a)))}function $i(){return Bo(),qo(),Ro(),Go()}function Go(){if(Dl!==5)return!1;var l=Ht,a=Wc;Wc=0;var t=yu(ot),e=S.T,n=A.p;try{A.p=32>t?32:t,S.T=null,t=$c,$c=null;var i=Ht,u=ot;if(Dl=0,ln=Ht=null,ot=0,(P&6)!==0)throw Error(g(331));var f=P;if(P|=4,So(i.current),bo(i,i.current,u,t),P=f,Zn(0,!1),_l&&typeof _l.onPostCommitFiberRoot=="function")try{_l.onPostCommitFiberRoot(ha,i)}catch{}return!0}finally{A.p=n,S.T=e,Yo(l,a)}}function Qo(l,a,t){a=xa(t,a),a=Nc(l.stateNode,a,2),l=Ot(l,a,2),l!==null&&(Ra(l,2),Xa(l))}function el(l,a,t){if(l.tag===3)Qo(l,l,t);else for(;a!==null;){if(a.tag===3){Qo(a,l,t);break}else if(a.tag===1){var e=a.stateNode;if(typeof a.type.getDerivedStateFromError=="function"||typeof e.componentDidCatch=="function"&&(Ct===null||!Ct.has(e))){l=xa(t,l),t=Qr(2),e=Ot(a,t,2),e!==null&&(Xr(t,e,a,l),Ra(e,2),Xa(e));break}}a=a.return}}function lf(l,a,t){var e=l.pingCache;if(e===null){e=l.pingCache=new g1;var n=new Set;e.set(a,n)}else n=e.get(a),n===void 0&&(n=new Set,e.set(a,n));n.has(t)||(Lc=!0,n.add(t),l=v1.bind(null,l,a,t),a.then(l,l))}function v1(l,a,t){var e=l.pingCache;e!==null&&e.delete(a),l.pingedLanes|=l.suspendedLanes&t,l.warmLanes&=~t,ol===l&&(X&t)===t&&(bl===4||bl===3&&(X&62914560)===X&&300>wl()-Vi?(P&2)===0&&an(l,0):Kc|=t,Pe===X&&(Pe=0)),Xa(l)}function Xo(l,a){a===0&&(a=Wt()),l=le(l,a),l!==null&&(Ra(l,a),Xa(l))}function x1(l){var a=l.memoizedState,t=0;a!==null&&(t=a.retryLane),Xo(l,t)}function S1(l,a){var t=0;switch(l.tag){case 31:case 13:var e=l.stateNode,n=l.memoizedState;n!==null&&(t=n.retryLane);break;case 19:e=l.stateNode;break;case 22:e=l.stateNode._retryCache;break;default:throw Error(g(314))}e!==null&&e.delete(a),Xo(l,t)}function z1(l,a){return yt(l,a)}var Fi=null,en=null,af=!1,Ii=!1,tf=!1,qt=0;function Xa(l){l!==en&&l.next===null&&(en===null?Fi=en=l:en=en.next=l),Ii=!0,af||(af=!0,A1())}function Zn(l,a){if(!tf&&Ii){tf=!0;do for(var t=!1,e=Fi;e!==null;){if(l!==0){var n=e.pendingLanes;if(n===0)var i=0;else{var u=e.suspendedLanes,f=e.pingedLanes;i=(1<<31-Ul(42|l)+1)-1,i&=n&~(u&~f),i=i&201326741?i&201326741|1:i?i|2:0}i!==0&&(t=!0,Lo(e,i))}else i=X,i=Ka(e,e===ol?i:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),(i&3)===0||qa(e,i)||(t=!0,Lo(e,i));e=e.next}while(t);tf=!1}}function _1(){ko()}function ko(){Ii=af=!1;var l=0;qt!==0&&C1()&&(l=qt);for(var a=wl(),t=null,e=Fi;e!==null;){var n=e.next,i=Vo(e,a);i===0?(e.next=null,t===null?Fi=n:t.next=n,n===null&&(en=t)):(t=e,(l!==0||(i&3)!==0)&&(Ii=!0)),e=n}Dl!==0&&Dl!==5||Zn(l),qt!==0&&(qt=0)}function Vo(l,a){for(var t=l.suspendedLanes,e=l.pingedLanes,n=l.expirationTimes,i=l.pendingLanes&-62914561;0<i;){var u=31-Ul(i),f=1<<u,s=n[u];s===-1?((f&t)===0||(f&e)!==0)&&(n[u]=_e(f,a)):s<=a&&(l.expiredLanes|=f),i&=~f}if(a=ol,t=X,t=Ka(l,l===a?t:0,l.cancelPendingCommit!==null||l.timeoutHandle!==-1),e=l.callbackNode,t===0||l===a&&(tl===2||tl===9)||l.cancelPendingCommit!==null)return e!==null&&e!==null&&bt(e),l.callbackNode=null,l.callbackPriority=0;if((t&3)===0||qa(l,t)){if(a=t&-t,a===l.callbackPriority)return a;switch(e!==null&&bt(e),yu(t)){case 2:case 8:t=Kt;break;case 32:t=La;break;case 268435456:t=Jt;break;default:t=La}return e=Zo.bind(null,l),t=yt(t,e),l.callbackPriority=a,l.callbackNode=t,a}return e!==null&&e!==null&&bt(e),l.callbackPriority=2,l.callbackNode=null,2}function Zo(l,a){if(Dl!==0&&Dl!==5)return l.callbackNode=null,l.callbackPriority=0,null;var t=l.callbackNode;if($i()&&l.callbackNode!==t)return null;var e=X;return e=Ka(l,l===ol?e:0,l.cancelPendingCommit!==null||l.timeoutHandle!==-1),e===0?null:(To(l,e,a),Vo(l,wl()),l.callbackNode!=null&&l.callbackNode===t?Zo.bind(null,l):null)}function Lo(l,a){if($i())return null;To(l,a,!0)}function A1(){B1(function(){(P&6)!==0?yt(Lt,_1):ko()})}function ef(){if(qt===0){var l=Xe;l===0&&(l=Da,Da<<=1,(Da&261888)===0&&(Da=256)),qt=l}return qt}function Ko(l){return l==null||typeof l=="symbol"||typeof l=="boolean"?null:typeof l=="function"?l:ui(""+l)}function Jo(l,a){var t=a.ownerDocument.createElement("input");return t.name=a.name,t.value=a.value,l.id&&t.setAttribute("form",l.id),a.parentNode.insertBefore(t,a),l=new FormData(l),t.parentNode.removeChild(t),l}function E1(l,a,t,e,n){if(a==="submit"&&t&&t.stateNode===n){var i=Ko((n[Jl]||null).action),u=e.submitter;u&&(a=(a=u[Jl]||null)?Ko(a.formAction):u.getAttribute("formAction"),a!==null&&(i=a,u=null));var f=new ri("action","action",null,e,n);l.push({event:f,listeners:[{instance:null,listener:function(){if(e.defaultPrevented){if(qt!==0){var s=u?Jo(n,u):new FormData(n);_c(t,{pending:!0,data:s,method:n.method,action:i},null,s)}}else typeof i=="function"&&(f.preventDefault(),s=u?Jo(n,u):new FormData(n),_c(t,{pending:!0,data:s,method:n.method,action:i},i,s))},currentTarget:n}]})}}for(var nf=0;nf<Gu.length;nf++){var uf=Gu[nf],T1=uf.toLowerCase(),M1=uf[0].toUpperCase()+uf.slice(1);Ua(T1,"on"+M1)}Ua(As,"onAnimationEnd"),Ua(Es,"onAnimationIteration"),Ua(Ts,"onAnimationStart"),Ua("dblclick","onDoubleClick"),Ua("focusin","onFocus"),Ua("focusout","onBlur"),Ua(k0,"onTransitionRun"),Ua(V0,"onTransitionStart"),Ua(Z0,"onTransitionCancel"),Ua(Ms,"onTransitionEnd"),Oe("onMouseEnter",["mouseout","mouseover"]),Oe("onMouseLeave",["mouseout","mouseover"]),Oe("onPointerEnter",["pointerout","pointerover"]),Oe("onPointerLeave",["pointerout","pointerover"]),$t("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),$t("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),$t("onBeforeInput",["compositionend","keypress","textInput","paste"]),$t("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),$t("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),$t("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Ln="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),O1=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Ln));function Wo(l,a){a=(a&4)!==0;for(var t=0;t<l.length;t++){var e=l[t],n=e.event;e=e.listeners;l:{var i=void 0;if(a)for(var u=e.length-1;0<=u;u--){var f=e[u],s=f.instance,p=f.currentTarget;if(f=f.listener,s!==i&&n.isPropagationStopped())break l;i=f,n.currentTarget=p;try{i(n)}catch(x){mi(x)}n.currentTarget=null,i=s}else for(u=0;u<e.length;u++){if(f=e[u],s=f.instance,p=f.currentTarget,f=f.listener,s!==i&&n.isPropagationStopped())break l;i=f,n.currentTarget=p;try{i(n)}catch(x){mi(x)}n.currentTarget=null,i=s}}}}function Q(l,a){var t=a[bu];t===void 0&&(t=a[bu]=new Set);var e=l+"__bubble";t.has(e)||($o(a,l,2,!1),t.add(e))}function cf(l,a,t){var e=0;a&&(e|=4),$o(t,l,e,a)}var Pi="_reactListening"+Math.random().toString(36).slice(2);function ff(l){if(!l[Pi]){l[Pi]=!0,Xf.forEach(function(t){t!=="selectionchange"&&(O1.has(t)||cf(t,!1,l),cf(t,!0,l))});var a=l.nodeType===9?l:l.ownerDocument;a===null||a[Pi]||(a[Pi]=!0,cf("selectionchange",!1,a))}}function $o(l,a,t,e){switch(Ed(a)){case 2:var n=tm;break;case 8:n=em;break;default:n=_f}t=n.bind(null,a,t,l),n=void 0,!Mu||a!=="touchstart"&&a!=="touchmove"&&a!=="wheel"||(n=!0),e?n!==void 0?l.addEventListener(a,t,{capture:!0,passive:n}):l.addEventListener(a,t,!0):n!==void 0?l.addEventListener(a,t,{passive:n}):l.addEventListener(a,t,!1)}function sf(l,a,t,e,n){var i=e;if((a&1)===0&&(a&2)===0&&e!==null)l:for(;;){if(e===null)return;var u=e.tag;if(u===3||u===4){var f=e.stateNode.containerInfo;if(f===n)break;if(u===4)for(u=e.return;u!==null;){var s=u.tag;if((s===3||s===4)&&u.stateNode.containerInfo===n)return;u=u.return}for(;f!==null;){if(u=Ee(f),u===null)return;if(s=u.tag,s===5||s===6||s===26||s===27){e=i=u;continue l}f=f.parentNode}}e=e.return}ls(function(){var p=i,x=Eu(t),_=[];l:{var y=Os.get(l);if(y!==void 0){var b=ri,M=l;switch(l){case"keypress":if(fi(t)===0)break l;case"keydown":case"keyup":b=S0;break;case"focusin":M="focus",b=ju;break;case"focusout":M="blur",b=ju;break;case"beforeblur":case"afterblur":b=ju;break;case"click":if(t.button===2)break l;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":b=es;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":b=s0;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":b=A0;break;case As:case Es:case Ts:b=d0;break;case Ms:b=T0;break;case"scroll":case"scrollend":b=c0;break;case"wheel":b=O0;break;case"copy":case"cut":case"paste":b=g0;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":b=is;break;case"toggle":case"beforetoggle":b=D0}var U=(a&4)!==0,fl=!U&&(l==="scroll"||l==="scrollend"),m=U?y!==null?y+"Capture":null:y;U=[];for(var r=p,h;r!==null;){var z=r;if(h=z.stateNode,z=z.tag,z!==5&&z!==26&&z!==27||h===null||m===null||(z=gn(r,m),z!=null&&U.push(Kn(r,z,h))),fl)break;r=r.return}0<U.length&&(y=new b(y,M,null,t,x),_.push({event:y,listeners:U}))}}if((a&7)===0){l:{if(y=l==="mouseover"||l==="pointerover",b=l==="mouseout"||l==="pointerout",y&&t!==Au&&(M=t.relatedTarget||t.fromElement)&&(Ee(M)||M[Ae]))break l;if((b||y)&&(y=x.window===x?x:(y=x.ownerDocument)?y.defaultView||y.parentWindow:window,b?(M=t.relatedTarget||t.toElement,b=p,M=M?Ee(M):null,M!==null&&(fl=H(M),U=M.tag,M!==fl||U!==5&&U!==27&&U!==6)&&(M=null)):(b=null,M=p),b!==M)){if(U=es,z="onMouseLeave",m="onMouseEnter",r="mouse",(l==="pointerout"||l==="pointerover")&&(U=is,z="onPointerLeave",m="onPointerEnter",r="pointer"),fl=b==null?y:mn(b),h=M==null?y:mn(M),y=new U(z,r+"leave",b,t,x),y.target=fl,y.relatedTarget=h,z=null,Ee(x)===p&&(U=new U(m,r+"enter",M,t,x),U.target=h,U.relatedTarget=fl,z=U),fl=z,b&&M)a:{for(U=N1,m=b,r=M,h=0,z=m;z;z=U(z))h++;z=0;for(var D=r;D;D=U(D))z++;for(;0<h-z;)m=U(m),h--;for(;0<z-h;)r=U(r),z--;for(;h--;){if(m===r||r!==null&&m===r.alternate){U=m;break a}m=U(m),r=U(r)}U=null}else U=null;b!==null&&Fo(_,y,b,U,!1),M!==null&&fl!==null&&Fo(_,fl,M,U,!0)}}l:{if(y=p?mn(p):window,b=y.nodeName&&y.nodeName.toLowerCase(),b==="select"||b==="input"&&y.type==="file")var F=ms;else if(os(y))if(gs)F=G0;else{F=R0;var N=q0}else b=y.nodeName,!b||b.toLowerCase()!=="input"||y.type!=="checkbox"&&y.type!=="radio"?p&&_u(p.elementType)&&(F=ms):F=Y0;if(F&&(F=F(l,p))){ds(_,F,t,x);break l}N&&N(l,y,p),l==="focusout"&&p&&y.type==="number"&&p.memoizedProps.value!=null&&zu(y,"number",y.value)}switch(N=p?mn(p):window,l){case"focusin":(os(N)||N.contentEditable==="true")&&(Ce=N,qu=p,zn=null);break;case"focusout":zn=qu=Ce=null;break;case"mousedown":Ru=!0;break;case"contextmenu":case"mouseup":case"dragend":Ru=!1,zs(_,t,x);break;case"selectionchange":if(X0)break;case"keydown":case"keyup":zs(_,t,x)}var Y;if(Uu)l:{switch(l){case"compositionstart":var k="onCompositionStart";break l;case"compositionend":k="onCompositionEnd";break l;case"compositionupdate":k="onCompositionUpdate";break l}k=void 0}else Ue?ss(l,t)&&(k="onCompositionEnd"):l==="keydown"&&t.keyCode===229&&(k="onCompositionStart");k&&(us&&t.locale!=="ko"&&(Ue||k!=="onCompositionStart"?k==="onCompositionEnd"&&Ue&&(Y=as()):(St=x,Ou="value"in St?St.value:St.textContent,Ue=!0)),N=lu(p,k),0<N.length&&(k=new ns(k,l,null,t,x),_.push({event:k,listeners:N}),Y?k.data=Y:(Y=rs(t),Y!==null&&(k.data=Y)))),(Y=w0?U0(l,t):C0(l,t))&&(k=lu(p,"onBeforeInput"),0<k.length&&(N=new ns("onBeforeInput","beforeinput",null,t,x),_.push({event:N,listeners:k}),N.data=Y)),E1(_,l,p,t,x)}Wo(_,a)})}function Kn(l,a,t){return{instance:l,listener:a,currentTarget:t}}function lu(l,a){for(var t=a+"Capture",e=[];l!==null;){var n=l,i=n.stateNode;if(n=n.tag,n!==5&&n!==26&&n!==27||i===null||(n=gn(l,t),n!=null&&e.unshift(Kn(l,n,i)),n=gn(l,a),n!=null&&e.push(Kn(l,n,i))),l.tag===3)return e;l=l.return}return[]}function N1(l){if(l===null)return null;do l=l.return;while(l&&l.tag!==5&&l.tag!==27);return l||null}function Fo(l,a,t,e,n){for(var i=a._reactName,u=[];t!==null&&t!==e;){var f=t,s=f.alternate,p=f.stateNode;if(f=f.tag,s!==null&&s===e)break;f!==5&&f!==26&&f!==27||p===null||(s=p,n?(p=gn(t,i),p!=null&&u.unshift(Kn(t,p,s))):n||(p=gn(t,i),p!=null&&u.push(Kn(t,p,s)))),t=t.return}u.length!==0&&l.push({event:a,listeners:u})}var D1=/\r\n?/g,j1=/\u0000|\uFFFD/g;function Io(l){return(typeof l=="string"?l:""+l).replace(D1,`
`).replace(j1,"")}function Po(l,a){return a=Io(a),Io(l)===a}function cl(l,a,t,e,n,i){switch(t){case"children":typeof e=="string"?a==="body"||a==="textarea"&&e===""||De(l,e):(typeof e=="number"||typeof e=="bigint")&&a!=="body"&&De(l,""+e);break;case"className":ni(l,"class",e);break;case"tabIndex":ni(l,"tabindex",e);break;case"dir":case"role":case"viewBox":case"width":case"height":ni(l,t,e);break;case"style":If(l,e,i);break;case"data":if(a!=="object"){ni(l,"data",e);break}case"src":case"href":if(e===""&&(a!=="a"||t!=="href")){l.removeAttribute(t);break}if(e==null||typeof e=="function"||typeof e=="symbol"||typeof e=="boolean"){l.removeAttribute(t);break}e=ui(""+e),l.setAttribute(t,e);break;case"action":case"formAction":if(typeof e=="function"){l.setAttribute(t,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof i=="function"&&(t==="formAction"?(a!=="input"&&cl(l,a,"name",n.name,n,null),cl(l,a,"formEncType",n.formEncType,n,null),cl(l,a,"formMethod",n.formMethod,n,null),cl(l,a,"formTarget",n.formTarget,n,null)):(cl(l,a,"encType",n.encType,n,null),cl(l,a,"method",n.method,n,null),cl(l,a,"target",n.target,n,null)));if(e==null||typeof e=="symbol"||typeof e=="boolean"){l.removeAttribute(t);break}e=ui(""+e),l.setAttribute(t,e);break;case"onClick":e!=null&&(l.onclick=$a);break;case"onScroll":e!=null&&Q("scroll",l);break;case"onScrollEnd":e!=null&&Q("scrollend",l);break;case"dangerouslySetInnerHTML":if(e!=null){if(typeof e!="object"||!("__html"in e))throw Error(g(61));if(t=e.__html,t!=null){if(n.children!=null)throw Error(g(60));l.innerHTML=t}}break;case"multiple":l.multiple=e&&typeof e!="function"&&typeof e!="symbol";break;case"muted":l.muted=e&&typeof e!="function"&&typeof e!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(e==null||typeof e=="function"||typeof e=="boolean"||typeof e=="symbol"){l.removeAttribute("xlink:href");break}t=ui(""+e),l.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",t);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":e!=null&&typeof e!="function"&&typeof e!="symbol"?l.setAttribute(t,""+e):l.removeAttribute(t);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":e&&typeof e!="function"&&typeof e!="symbol"?l.setAttribute(t,""):l.removeAttribute(t);break;case"capture":case"download":e===!0?l.setAttribute(t,""):e!==!1&&e!=null&&typeof e!="function"&&typeof e!="symbol"?l.setAttribute(t,e):l.removeAttribute(t);break;case"cols":case"rows":case"size":case"span":e!=null&&typeof e!="function"&&typeof e!="symbol"&&!isNaN(e)&&1<=e?l.setAttribute(t,e):l.removeAttribute(t);break;case"rowSpan":case"start":e==null||typeof e=="function"||typeof e=="symbol"||isNaN(e)?l.removeAttribute(t):l.setAttribute(t,e);break;case"popover":Q("beforetoggle",l),Q("toggle",l),ei(l,"popover",e);break;case"xlinkActuate":Wa(l,"http://www.w3.org/1999/xlink","xlink:actuate",e);break;case"xlinkArcrole":Wa(l,"http://www.w3.org/1999/xlink","xlink:arcrole",e);break;case"xlinkRole":Wa(l,"http://www.w3.org/1999/xlink","xlink:role",e);break;case"xlinkShow":Wa(l,"http://www.w3.org/1999/xlink","xlink:show",e);break;case"xlinkTitle":Wa(l,"http://www.w3.org/1999/xlink","xlink:title",e);break;case"xlinkType":Wa(l,"http://www.w3.org/1999/xlink","xlink:type",e);break;case"xmlBase":Wa(l,"http://www.w3.org/XML/1998/namespace","xml:base",e);break;case"xmlLang":Wa(l,"http://www.w3.org/XML/1998/namespace","xml:lang",e);break;case"xmlSpace":Wa(l,"http://www.w3.org/XML/1998/namespace","xml:space",e);break;case"is":ei(l,"is",e);break;case"innerText":case"textContent":break;default:(!(2<t.length)||t[0]!=="o"&&t[0]!=="O"||t[1]!=="n"&&t[1]!=="N")&&(t=i0.get(t)||t,ei(l,t,e))}}function rf(l,a,t,e,n,i){switch(t){case"style":If(l,e,i);break;case"dangerouslySetInnerHTML":if(e!=null){if(typeof e!="object"||!("__html"in e))throw Error(g(61));if(t=e.__html,t!=null){if(n.children!=null)throw Error(g(60));l.innerHTML=t}}break;case"children":typeof e=="string"?De(l,e):(typeof e=="number"||typeof e=="bigint")&&De(l,""+e);break;case"onScroll":e!=null&&Q("scroll",l);break;case"onScrollEnd":e!=null&&Q("scrollend",l);break;case"onClick":e!=null&&(l.onclick=$a);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!kf.hasOwnProperty(t))l:{if(t[0]==="o"&&t[1]==="n"&&(n=t.endsWith("Capture"),a=t.slice(2,n?t.length-7:void 0),i=l[Jl]||null,i=i!=null?i[t]:null,typeof i=="function"&&l.removeEventListener(a,i,n),typeof e=="function")){typeof i!="function"&&i!==null&&(t in l?l[t]=null:l.hasAttribute(t)&&l.removeAttribute(t)),l.addEventListener(a,e,n);break l}t in l?l[t]=e:e===!0?l.setAttribute(t,""):ei(l,t,e)}}}function Ql(l,a,t){switch(a){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":Q("error",l),Q("load",l);var e=!1,n=!1,i;for(i in t)if(t.hasOwnProperty(i)){var u=t[i];if(u!=null)switch(i){case"src":e=!0;break;case"srcSet":n=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(g(137,a));default:cl(l,a,i,u,t,null)}}n&&cl(l,a,"srcSet",t.srcSet,t,null),e&&cl(l,a,"src",t.src,t,null);return;case"input":Q("invalid",l);var f=i=u=n=null,s=null,p=null;for(e in t)if(t.hasOwnProperty(e)){var x=t[e];if(x!=null)switch(e){case"name":n=x;break;case"type":u=x;break;case"checked":s=x;break;case"defaultChecked":p=x;break;case"value":i=x;break;case"defaultValue":f=x;break;case"children":case"dangerouslySetInnerHTML":if(x!=null)throw Error(g(137,a));break;default:cl(l,a,e,x,t,null)}}Jf(l,i,f,s,p,u,n,!1);return;case"select":Q("invalid",l),e=u=i=null;for(n in t)if(t.hasOwnProperty(n)&&(f=t[n],f!=null))switch(n){case"value":i=f;break;case"defaultValue":u=f;break;case"multiple":e=f;default:cl(l,a,n,f,t,null)}a=i,t=u,l.multiple=!!e,a!=null?Ne(l,!!e,a,!1):t!=null&&Ne(l,!!e,t,!0);return;case"textarea":Q("invalid",l),i=n=e=null;for(u in t)if(t.hasOwnProperty(u)&&(f=t[u],f!=null))switch(u){case"value":e=f;break;case"defaultValue":n=f;break;case"children":i=f;break;case"dangerouslySetInnerHTML":if(f!=null)throw Error(g(91));break;default:cl(l,a,u,f,t,null)}$f(l,e,n,i);return;case"option":for(s in t)t.hasOwnProperty(s)&&(e=t[s],e!=null)&&(s==="selected"?l.selected=e&&typeof e!="function"&&typeof e!="symbol":cl(l,a,s,e,t,null));return;case"dialog":Q("beforetoggle",l),Q("toggle",l),Q("cancel",l),Q("close",l);break;case"iframe":case"object":Q("load",l);break;case"video":case"audio":for(e=0;e<Ln.length;e++)Q(Ln[e],l);break;case"image":Q("error",l),Q("load",l);break;case"details":Q("toggle",l);break;case"embed":case"source":case"link":Q("error",l),Q("load",l);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(p in t)if(t.hasOwnProperty(p)&&(e=t[p],e!=null))switch(p){case"children":case"dangerouslySetInnerHTML":throw Error(g(137,a));default:cl(l,a,p,e,t,null)}return;default:if(_u(a)){for(x in t)t.hasOwnProperty(x)&&(e=t[x],e!==void 0&&rf(l,a,x,e,t,void 0));return}}for(f in t)t.hasOwnProperty(f)&&(e=t[f],e!=null&&cl(l,a,f,e,t,null))}function w1(l,a,t,e){switch(a){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var n=null,i=null,u=null,f=null,s=null,p=null,x=null;for(b in t){var _=t[b];if(t.hasOwnProperty(b)&&_!=null)switch(b){case"checked":break;case"value":break;case"defaultValue":s=_;default:e.hasOwnProperty(b)||cl(l,a,b,null,e,_)}}for(var y in e){var b=e[y];if(_=t[y],e.hasOwnProperty(y)&&(b!=null||_!=null))switch(y){case"type":i=b;break;case"name":n=b;break;case"checked":p=b;break;case"defaultChecked":x=b;break;case"value":u=b;break;case"defaultValue":f=b;break;case"children":case"dangerouslySetInnerHTML":if(b!=null)throw Error(g(137,a));break;default:b!==_&&cl(l,a,y,b,e,_)}}Su(l,u,f,s,p,x,i,n);return;case"select":b=u=f=y=null;for(i in t)if(s=t[i],t.hasOwnProperty(i)&&s!=null)switch(i){case"value":break;case"multiple":b=s;default:e.hasOwnProperty(i)||cl(l,a,i,null,e,s)}for(n in e)if(i=e[n],s=t[n],e.hasOwnProperty(n)&&(i!=null||s!=null))switch(n){case"value":y=i;break;case"defaultValue":f=i;break;case"multiple":u=i;default:i!==s&&cl(l,a,n,i,e,s)}a=f,t=u,e=b,y!=null?Ne(l,!!t,y,!1):!!e!=!!t&&(a!=null?Ne(l,!!t,a,!0):Ne(l,!!t,t?[]:"",!1));return;case"textarea":b=y=null;for(f in t)if(n=t[f],t.hasOwnProperty(f)&&n!=null&&!e.hasOwnProperty(f))switch(f){case"value":break;case"children":break;default:cl(l,a,f,null,e,n)}for(u in e)if(n=e[u],i=t[u],e.hasOwnProperty(u)&&(n!=null||i!=null))switch(u){case"value":y=n;break;case"defaultValue":b=n;break;case"children":break;case"dangerouslySetInnerHTML":if(n!=null)throw Error(g(91));break;default:n!==i&&cl(l,a,u,n,e,i)}Wf(l,y,b);return;case"option":for(var M in t)y=t[M],t.hasOwnProperty(M)&&y!=null&&!e.hasOwnProperty(M)&&(M==="selected"?l.selected=!1:cl(l,a,M,null,e,y));for(s in e)y=e[s],b=t[s],e.hasOwnProperty(s)&&y!==b&&(y!=null||b!=null)&&(s==="selected"?l.selected=y&&typeof y!="function"&&typeof y!="symbol":cl(l,a,s,y,e,b));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var U in t)y=t[U],t.hasOwnProperty(U)&&y!=null&&!e.hasOwnProperty(U)&&cl(l,a,U,null,e,y);for(p in e)if(y=e[p],b=t[p],e.hasOwnProperty(p)&&y!==b&&(y!=null||b!=null))switch(p){case"children":case"dangerouslySetInnerHTML":if(y!=null)throw Error(g(137,a));break;default:cl(l,a,p,y,e,b)}return;default:if(_u(a)){for(var fl in t)y=t[fl],t.hasOwnProperty(fl)&&y!==void 0&&!e.hasOwnProperty(fl)&&rf(l,a,fl,void 0,e,y);for(x in e)y=e[x],b=t[x],!e.hasOwnProperty(x)||y===b||y===void 0&&b===void 0||rf(l,a,x,y,e,b);return}}for(var m in t)y=t[m],t.hasOwnProperty(m)&&y!=null&&!e.hasOwnProperty(m)&&cl(l,a,m,null,e,y);for(_ in e)y=e[_],b=t[_],!e.hasOwnProperty(_)||y===b||y==null&&b==null||cl(l,a,_,y,e,b)}function ld(l){switch(l){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function U1(){if(typeof performance.getEntriesByType=="function"){for(var l=0,a=0,t=performance.getEntriesByType("resource"),e=0;e<t.length;e++){var n=t[e],i=n.transferSize,u=n.initiatorType,f=n.duration;if(i&&f&&ld(u)){for(u=0,f=n.responseEnd,e+=1;e<t.length;e++){var s=t[e],p=s.startTime;if(p>f)break;var x=s.transferSize,_=s.initiatorType;x&&ld(_)&&(s=s.responseEnd,u+=x*(s<f?1:(f-p)/(s-p)))}if(--e,a+=8*(i+u)/(n.duration/1e3),l++,10<l)break}}if(0<l)return a/l/1e6}return navigator.connection&&(l=navigator.connection.downlink,typeof l=="number")?l:5}var of=null,df=null;function au(l){return l.nodeType===9?l:l.ownerDocument}function ad(l){switch(l){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function td(l,a){if(l===0)switch(a){case"svg":return 1;case"math":return 2;default:return 0}return l===1&&a==="foreignObject"?0:l}function mf(l,a){return l==="textarea"||l==="noscript"||typeof a.children=="string"||typeof a.children=="number"||typeof a.children=="bigint"||typeof a.dangerouslySetInnerHTML=="object"&&a.dangerouslySetInnerHTML!==null&&a.dangerouslySetInnerHTML.__html!=null}var gf=null;function C1(){var l=window.event;return l&&l.type==="popstate"?l===gf?!1:(gf=l,!0):(gf=null,!1)}var ed=typeof setTimeout=="function"?setTimeout:void 0,H1=typeof clearTimeout=="function"?clearTimeout:void 0,nd=typeof Promise=="function"?Promise:void 0,B1=typeof queueMicrotask=="function"?queueMicrotask:typeof nd<"u"?function(l){return nd.resolve(null).then(l).catch(q1)}:ed;function q1(l){setTimeout(function(){throw l})}function Rt(l){return l==="head"}function id(l,a){var t=a,e=0;do{var n=t.nextSibling;if(l.removeChild(t),n&&n.nodeType===8)if(t=n.data,t==="/$"||t==="/&"){if(e===0){l.removeChild(n),fn(a);return}e--}else if(t==="$"||t==="$?"||t==="$~"||t==="$!"||t==="&")e++;else if(t==="html")Jn(l.ownerDocument.documentElement);else if(t==="head"){t=l.ownerDocument.head,Jn(t);for(var i=t.firstChild;i;){var u=i.nextSibling,f=i.nodeName;i[dn]||f==="SCRIPT"||f==="STYLE"||f==="LINK"&&i.rel.toLowerCase()==="stylesheet"||t.removeChild(i),i=u}}else t==="body"&&Jn(l.ownerDocument.body);t=n}while(t);fn(a)}function ud(l,a){var t=l;l=0;do{var e=t.nextSibling;if(t.nodeType===1?a?(t._stashedDisplay=t.style.display,t.style.display="none"):(t.style.display=t._stashedDisplay||"",t.getAttribute("style")===""&&t.removeAttribute("style")):t.nodeType===3&&(a?(t._stashedText=t.nodeValue,t.nodeValue=""):t.nodeValue=t._stashedText||""),e&&e.nodeType===8)if(t=e.data,t==="/$"){if(l===0)break;l--}else t!=="$"&&t!=="$?"&&t!=="$~"&&t!=="$!"||l++;t=e}while(t)}function hf(l){var a=l.firstChild;for(a&&a.nodeType===10&&(a=a.nextSibling);a;){var t=a;switch(a=a.nextSibling,t.nodeName){case"HTML":case"HEAD":case"BODY":hf(t),vu(t);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(t.rel.toLowerCase()==="stylesheet")continue}l.removeChild(t)}}function R1(l,a,t,e){for(;l.nodeType===1;){var n=t;if(l.nodeName.toLowerCase()!==a.toLowerCase()){if(!e&&(l.nodeName!=="INPUT"||l.type!=="hidden"))break}else if(e){if(!l[dn])switch(a){case"meta":if(!l.hasAttribute("itemprop"))break;return l;case"link":if(i=l.getAttribute("rel"),i==="stylesheet"&&l.hasAttribute("data-precedence"))break;if(i!==n.rel||l.getAttribute("href")!==(n.href==null||n.href===""?null:n.href)||l.getAttribute("crossorigin")!==(n.crossOrigin==null?null:n.crossOrigin)||l.getAttribute("title")!==(n.title==null?null:n.title))break;return l;case"style":if(l.hasAttribute("data-precedence"))break;return l;case"script":if(i=l.getAttribute("src"),(i!==(n.src==null?null:n.src)||l.getAttribute("type")!==(n.type==null?null:n.type)||l.getAttribute("crossorigin")!==(n.crossOrigin==null?null:n.crossOrigin))&&i&&l.hasAttribute("async")&&!l.hasAttribute("itemprop"))break;return l;default:return l}}else if(a==="input"&&l.type==="hidden"){var i=n.name==null?null:""+n.name;if(n.type==="hidden"&&l.getAttribute("name")===i)return l}else return l;if(l=Ea(l.nextSibling),l===null)break}return null}function Y1(l,a,t){if(a==="")return null;for(;l.nodeType!==3;)if((l.nodeType!==1||l.nodeName!=="INPUT"||l.type!=="hidden")&&!t||(l=Ea(l.nextSibling),l===null))return null;return l}function cd(l,a){for(;l.nodeType!==8;)if((l.nodeType!==1||l.nodeName!=="INPUT"||l.type!=="hidden")&&!a||(l=Ea(l.nextSibling),l===null))return null;return l}function pf(l){return l.data==="$?"||l.data==="$~"}function yf(l){return l.data==="$!"||l.data==="$?"&&l.ownerDocument.readyState!=="loading"}function G1(l,a){var t=l.ownerDocument;if(l.data==="$~")l._reactRetry=a;else if(l.data!=="$?"||t.readyState!=="loading")a();else{var e=function(){a(),t.removeEventListener("DOMContentLoaded",e)};t.addEventListener("DOMContentLoaded",e),l._reactRetry=e}}function Ea(l){for(;l!=null;l=l.nextSibling){var a=l.nodeType;if(a===1||a===3)break;if(a===8){if(a=l.data,a==="$"||a==="$!"||a==="$?"||a==="$~"||a==="&"||a==="F!"||a==="F")break;if(a==="/$"||a==="/&")return null}}return l}var bf=null;function fd(l){l=l.nextSibling;for(var a=0;l;){if(l.nodeType===8){var t=l.data;if(t==="/$"||t==="/&"){if(a===0)return Ea(l.nextSibling);a--}else t!=="$"&&t!=="$!"&&t!=="$?"&&t!=="$~"&&t!=="&"||a++}l=l.nextSibling}return null}function sd(l){l=l.previousSibling;for(var a=0;l;){if(l.nodeType===8){var t=l.data;if(t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"){if(a===0)return l;a--}else t!=="/$"&&t!=="/&"||a++}l=l.previousSibling}return null}function rd(l,a,t){switch(a=au(t),l){case"html":if(l=a.documentElement,!l)throw Error(g(452));return l;case"head":if(l=a.head,!l)throw Error(g(453));return l;case"body":if(l=a.body,!l)throw Error(g(454));return l;default:throw Error(g(451))}}function Jn(l){for(var a=l.attributes;a.length;)l.removeAttributeNode(a[0]);vu(l)}var Ta=new Map,od=new Set;function tu(l){return typeof l.getRootNode=="function"?l.getRootNode():l.nodeType===9?l:l.ownerDocument}var dt=A.d;A.d={f:Q1,r:X1,D:k1,C:V1,L:Z1,m:L1,X:J1,S:K1,M:W1};function Q1(){var l=dt.f(),a=Ki();return l||a}function X1(l){var a=Te(l);a!==null&&a.tag===5&&a.type==="form"?Mr(a):dt.r(l)}var nn=typeof document>"u"?null:document;function dd(l,a,t){var e=nn;if(e&&typeof a=="string"&&a){var n=ba(a);n='link[rel="'+l+'"][href="'+n+'"]',typeof t=="string"&&(n+='[crossorigin="'+t+'"]'),od.has(n)||(od.add(n),l={rel:l,crossOrigin:t,href:a},e.querySelector(n)===null&&(a=e.createElement("link"),Ql(a,"link",l),Cl(a),e.head.appendChild(a)))}}function k1(l){dt.D(l),dd("dns-prefetch",l,null)}function V1(l,a){dt.C(l,a),dd("preconnect",l,a)}function Z1(l,a,t){dt.L(l,a,t);var e=nn;if(e&&l&&a){var n='link[rel="preload"][as="'+ba(a)+'"]';a==="image"&&t&&t.imageSrcSet?(n+='[imagesrcset="'+ba(t.imageSrcSet)+'"]',typeof t.imageSizes=="string"&&(n+='[imagesizes="'+ba(t.imageSizes)+'"]')):n+='[href="'+ba(l)+'"]';var i=n;switch(a){case"style":i=un(l);break;case"script":i=cn(l)}Ta.has(i)||(l=E({rel:"preload",href:a==="image"&&t&&t.imageSrcSet?void 0:l,as:a},t),Ta.set(i,l),e.querySelector(n)!==null||a==="style"&&e.querySelector(Wn(i))||a==="script"&&e.querySelector($n(i))||(a=e.createElement("link"),Ql(a,"link",l),Cl(a),e.head.appendChild(a)))}}function L1(l,a){dt.m(l,a);var t=nn;if(t&&l){var e=a&&typeof a.as=="string"?a.as:"script",n='link[rel="modulepreload"][as="'+ba(e)+'"][href="'+ba(l)+'"]',i=n;switch(e){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":i=cn(l)}if(!Ta.has(i)&&(l=E({rel:"modulepreload",href:l},a),Ta.set(i,l),t.querySelector(n)===null)){switch(e){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(t.querySelector($n(i)))return}e=t.createElement("link"),Ql(e,"link",l),Cl(e),t.head.appendChild(e)}}}function K1(l,a,t){dt.S(l,a,t);var e=nn;if(e&&l){var n=Me(e).hoistableStyles,i=un(l);a=a||"default";var u=n.get(i);if(!u){var f={loading:0,preload:null};if(u=e.querySelector(Wn(i)))f.loading=5;else{l=E({rel:"stylesheet",href:l,"data-precedence":a},t),(t=Ta.get(i))&&vf(l,t);var s=u=e.createElement("link");Cl(s),Ql(s,"link",l),s._p=new Promise(function(p,x){s.onload=p,s.onerror=x}),s.addEventListener("load",function(){f.loading|=1}),s.addEventListener("error",function(){f.loading|=2}),f.loading|=4,eu(u,a,e)}u={type:"stylesheet",instance:u,count:1,state:f},n.set(i,u)}}}function J1(l,a){dt.X(l,a);var t=nn;if(t&&l){var e=Me(t).hoistableScripts,n=cn(l),i=e.get(n);i||(i=t.querySelector($n(n)),i||(l=E({src:l,async:!0},a),(a=Ta.get(n))&&xf(l,a),i=t.createElement("script"),Cl(i),Ql(i,"link",l),t.head.appendChild(i)),i={type:"script",instance:i,count:1,state:null},e.set(n,i))}}function W1(l,a){dt.M(l,a);var t=nn;if(t&&l){var e=Me(t).hoistableScripts,n=cn(l),i=e.get(n);i||(i=t.querySelector($n(n)),i||(l=E({src:l,async:!0,type:"module"},a),(a=Ta.get(n))&&xf(l,a),i=t.createElement("script"),Cl(i),Ql(i,"link",l),t.head.appendChild(i)),i={type:"script",instance:i,count:1,state:null},e.set(n,i))}}function md(l,a,t,e){var n=(n=ea.current)?tu(n):null;if(!n)throw Error(g(446));switch(l){case"meta":case"title":return null;case"style":return typeof t.precedence=="string"&&typeof t.href=="string"?(a=un(t.href),t=Me(n).hoistableStyles,e=t.get(a),e||(e={type:"style",instance:null,count:0,state:null},t.set(a,e)),e):{type:"void",instance:null,count:0,state:null};case"link":if(t.rel==="stylesheet"&&typeof t.href=="string"&&typeof t.precedence=="string"){l=un(t.href);var i=Me(n).hoistableStyles,u=i.get(l);if(u||(n=n.ownerDocument||n,u={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},i.set(l,u),(i=n.querySelector(Wn(l)))&&!i._p&&(u.instance=i,u.state.loading=5),Ta.has(l)||(t={rel:"preload",as:"style",href:t.href,crossOrigin:t.crossOrigin,integrity:t.integrity,media:t.media,hrefLang:t.hrefLang,referrerPolicy:t.referrerPolicy},Ta.set(l,t),i||$1(n,l,t,u.state))),a&&e===null)throw Error(g(528,""));return u}if(a&&e!==null)throw Error(g(529,""));return null;case"script":return a=t.async,t=t.src,typeof t=="string"&&a&&typeof a!="function"&&typeof a!="symbol"?(a=cn(t),t=Me(n).hoistableScripts,e=t.get(a),e||(e={type:"script",instance:null,count:0,state:null},t.set(a,e)),e):{type:"void",instance:null,count:0,state:null};default:throw Error(g(444,l))}}function un(l){return'href="'+ba(l)+'"'}function Wn(l){return'link[rel="stylesheet"]['+l+"]"}function gd(l){return E({},l,{"data-precedence":l.precedence,precedence:null})}function $1(l,a,t,e){l.querySelector('link[rel="preload"][as="style"]['+a+"]")?e.loading=1:(a=l.createElement("link"),e.preload=a,a.addEventListener("load",function(){return e.loading|=1}),a.addEventListener("error",function(){return e.loading|=2}),Ql(a,"link",t),Cl(a),l.head.appendChild(a))}function cn(l){return'[src="'+ba(l)+'"]'}function $n(l){return"script[async]"+l}function hd(l,a,t){if(a.count++,a.instance===null)switch(a.type){case"style":var e=l.querySelector('style[data-href~="'+ba(t.href)+'"]');if(e)return a.instance=e,Cl(e),e;var n=E({},t,{"data-href":t.href,"data-precedence":t.precedence,href:null,precedence:null});return e=(l.ownerDocument||l).createElement("style"),Cl(e),Ql(e,"style",n),eu(e,t.precedence,l),a.instance=e;case"stylesheet":n=un(t.href);var i=l.querySelector(Wn(n));if(i)return a.state.loading|=4,a.instance=i,Cl(i),i;e=gd(t),(n=Ta.get(n))&&vf(e,n),i=(l.ownerDocument||l).createElement("link"),Cl(i);var u=i;return u._p=new Promise(function(f,s){u.onload=f,u.onerror=s}),Ql(i,"link",e),a.state.loading|=4,eu(i,t.precedence,l),a.instance=i;case"script":return i=cn(t.src),(n=l.querySelector($n(i)))?(a.instance=n,Cl(n),n):(e=t,(n=Ta.get(i))&&(e=E({},t),xf(e,n)),l=l.ownerDocument||l,n=l.createElement("script"),Cl(n),Ql(n,"link",e),l.head.appendChild(n),a.instance=n);case"void":return null;default:throw Error(g(443,a.type))}else a.type==="stylesheet"&&(a.state.loading&4)===0&&(e=a.instance,a.state.loading|=4,eu(e,t.precedence,l));return a.instance}function eu(l,a,t){for(var e=t.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),n=e.length?e[e.length-1]:null,i=n,u=0;u<e.length;u++){var f=e[u];if(f.dataset.precedence===a)i=f;else if(i!==n)break}i?i.parentNode.insertBefore(l,i.nextSibling):(a=t.nodeType===9?t.head:t,a.insertBefore(l,a.firstChild))}function vf(l,a){l.crossOrigin==null&&(l.crossOrigin=a.crossOrigin),l.referrerPolicy==null&&(l.referrerPolicy=a.referrerPolicy),l.title==null&&(l.title=a.title)}function xf(l,a){l.crossOrigin==null&&(l.crossOrigin=a.crossOrigin),l.referrerPolicy==null&&(l.referrerPolicy=a.referrerPolicy),l.integrity==null&&(l.integrity=a.integrity)}var nu=null;function pd(l,a,t){if(nu===null){var e=new Map,n=nu=new Map;n.set(t,e)}else n=nu,e=n.get(t),e||(e=new Map,n.set(t,e));if(e.has(l))return e;for(e.set(l,null),t=t.getElementsByTagName(l),n=0;n<t.length;n++){var i=t[n];if(!(i[dn]||i[ql]||l==="link"&&i.getAttribute("rel")==="stylesheet")&&i.namespaceURI!=="http://www.w3.org/2000/svg"){var u=i.getAttribute(a)||"";u=l+u;var f=e.get(u);f?f.push(i):e.set(u,[i])}}return e}function yd(l,a,t){l=l.ownerDocument||l,l.head.insertBefore(t,a==="title"?l.querySelector("head > title"):null)}function F1(l,a,t){if(t===1||a.itemProp!=null)return!1;switch(l){case"meta":case"title":return!0;case"style":if(typeof a.precedence!="string"||typeof a.href!="string"||a.href==="")break;return!0;case"link":if(typeof a.rel!="string"||typeof a.href!="string"||a.href===""||a.onLoad||a.onError)break;return a.rel==="stylesheet"?(l=a.disabled,typeof a.precedence=="string"&&l==null):!0;case"script":if(a.async&&typeof a.async!="function"&&typeof a.async!="symbol"&&!a.onLoad&&!a.onError&&a.src&&typeof a.src=="string")return!0}return!1}function bd(l){return!(l.type==="stylesheet"&&(l.state.loading&3)===0)}function I1(l,a,t,e){if(t.type==="stylesheet"&&(typeof e.media!="string"||matchMedia(e.media).matches!==!1)&&(t.state.loading&4)===0){if(t.instance===null){var n=un(e.href),i=a.querySelector(Wn(n));if(i){a=i._p,a!==null&&typeof a=="object"&&typeof a.then=="function"&&(l.count++,l=iu.bind(l),a.then(l,l)),t.state.loading|=4,t.instance=i,Cl(i);return}i=a.ownerDocument||a,e=gd(e),(n=Ta.get(n))&&vf(e,n),i=i.createElement("link"),Cl(i);var u=i;u._p=new Promise(function(f,s){u.onload=f,u.onerror=s}),Ql(i,"link",e),t.instance=i}l.stylesheets===null&&(l.stylesheets=new Map),l.stylesheets.set(t,a),(a=t.state.preload)&&(t.state.loading&3)===0&&(l.count++,t=iu.bind(l),a.addEventListener("load",t),a.addEventListener("error",t))}}var Sf=0;function P1(l,a){return l.stylesheets&&l.count===0&&cu(l,l.stylesheets),0<l.count||0<l.imgCount?function(t){var e=setTimeout(function(){if(l.stylesheets&&cu(l,l.stylesheets),l.unsuspend){var i=l.unsuspend;l.unsuspend=null,i()}},6e4+a);0<l.imgBytes&&Sf===0&&(Sf=62500*U1());var n=setTimeout(function(){if(l.waitingForImages=!1,l.count===0&&(l.stylesheets&&cu(l,l.stylesheets),l.unsuspend)){var i=l.unsuspend;l.unsuspend=null,i()}},(l.imgBytes>Sf?50:800)+a);return l.unsuspend=t,function(){l.unsuspend=null,clearTimeout(e),clearTimeout(n)}}:null}function iu(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)cu(this,this.stylesheets);else if(this.unsuspend){var l=this.unsuspend;this.unsuspend=null,l()}}}var uu=null;function cu(l,a){l.stylesheets=null,l.unsuspend!==null&&(l.count++,uu=new Map,a.forEach(lm,l),uu=null,iu.call(l))}function lm(l,a){if(!(a.state.loading&4)){var t=uu.get(l);if(t)var e=t.get(null);else{t=new Map,uu.set(l,t);for(var n=l.querySelectorAll("link[data-precedence],style[data-precedence]"),i=0;i<n.length;i++){var u=n[i];(u.nodeName==="LINK"||u.getAttribute("media")!=="not all")&&(t.set(u.dataset.precedence,u),e=u)}e&&t.set(null,e)}n=a.instance,u=n.getAttribute("data-precedence"),i=t.get(u)||e,i===e&&t.set(null,n),t.set(u,n),this.count++,e=iu.bind(this),n.addEventListener("load",e),n.addEventListener("error",e),i?i.parentNode.insertBefore(n,i.nextSibling):(l=l.nodeType===9?l.head:l,l.insertBefore(n,l.firstChild)),a.state.loading|=4}}var Fn={$$typeof:nl,Provider:null,Consumer:null,_currentValue:w,_currentValue2:w,_threadCount:0};function am(l,a,t,e,n,i,u,f,s){this.tag=1,this.containerInfo=l,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=vt(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=vt(0),this.hiddenUpdates=vt(null),this.identifierPrefix=e,this.onUncaughtError=n,this.onCaughtError=i,this.onRecoverableError=u,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=s,this.incompleteTransitions=new Map}function vd(l,a,t,e,n,i,u,f,s,p,x,_){return l=new am(l,a,t,u,s,p,x,_,f),a=1,i===!0&&(a|=24),i=ca(3,null,null,a),l.current=i,i.stateNode=l,a=Pu(),a.refCount++,l.pooledCache=a,a.refCount++,i.memoizedState={element:e,isDehydrated:t,cache:a},ec(i),l}function xd(l){return l?(l=qe,l):qe}function Sd(l,a,t,e,n,i){n=xd(n),e.context===null?e.context=n:e.pendingContext=n,e=Mt(a),e.payload={element:t},i=i===void 0?null:i,i!==null&&(e.callback=i),t=Ot(l,e,a),t!==null&&(la(t,l,a),Nn(t,l,a))}function zd(l,a){if(l=l.memoizedState,l!==null&&l.dehydrated!==null){var t=l.retryLane;l.retryLane=t!==0&&t<a?t:a}}function zf(l,a){zd(l,a),(l=l.alternate)&&zd(l,a)}function _d(l){if(l.tag===13||l.tag===31){var a=le(l,67108864);a!==null&&la(a,l,67108864),zf(l,67108864)}}function Ad(l){if(l.tag===13||l.tag===31){var a=da();a=pu(a);var t=le(l,a);t!==null&&la(t,l,a),zf(l,a)}}var fu=!0;function tm(l,a,t,e){var n=S.T;S.T=null;var i=A.p;try{A.p=2,_f(l,a,t,e)}finally{A.p=i,S.T=n}}function em(l,a,t,e){var n=S.T;S.T=null;var i=A.p;try{A.p=8,_f(l,a,t,e)}finally{A.p=i,S.T=n}}function _f(l,a,t,e){if(fu){var n=Af(e);if(n===null)sf(l,a,e,su,t),Td(l,e);else if(im(n,l,a,t,e))e.stopPropagation();else if(Td(l,e),a&4&&-1<nm.indexOf(l)){for(;n!==null;){var i=Te(n);if(i!==null)switch(i.tag){case 3:if(i=i.stateNode,i.current.memoizedState.isDehydrated){var u=pa(i.pendingLanes);if(u!==0){var f=i;for(f.pendingLanes|=2,f.entangledLanes|=2;u;){var s=1<<31-Ul(u);f.entanglements[1]|=s,u&=~s}Xa(i),(P&6)===0&&(Zi=wl()+500,Zn(0))}}break;case 31:case 13:f=le(i,2),f!==null&&la(f,i,2),Ki(),zf(i,2)}if(i=Af(e),i===null&&sf(l,a,e,su,t),i===n)break;n=i}n!==null&&e.stopPropagation()}else sf(l,a,e,null,t)}}function Af(l){return l=Eu(l),Ef(l)}var su=null;function Ef(l){if(su=null,l=Ee(l),l!==null){var a=H(l);if(a===null)l=null;else{var t=a.tag;if(t===13){if(l=V(a),l!==null)return l;l=null}else if(t===31){if(l=R(a),l!==null)return l;l=null}else if(t===3){if(a.stateNode.current.memoizedState.isDehydrated)return a.tag===3?a.stateNode.containerInfo:null;l=null}else a!==l&&(l=null)}}return su=l,null}function Ed(l){switch(l){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(pe()){case Lt:return 2;case Kt:return 8;case La:case ye:return 32;case Jt:return 268435456;default:return 32}default:return 32}}var Tf=!1,Yt=null,Gt=null,Qt=null,In=new Map,Pn=new Map,Xt=[],nm="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function Td(l,a){switch(l){case"focusin":case"focusout":Yt=null;break;case"dragenter":case"dragleave":Gt=null;break;case"mouseover":case"mouseout":Qt=null;break;case"pointerover":case"pointerout":In.delete(a.pointerId);break;case"gotpointercapture":case"lostpointercapture":Pn.delete(a.pointerId)}}function li(l,a,t,e,n,i){return l===null||l.nativeEvent!==i?(l={blockedOn:a,domEventName:t,eventSystemFlags:e,nativeEvent:i,targetContainers:[n]},a!==null&&(a=Te(a),a!==null&&_d(a)),l):(l.eventSystemFlags|=e,a=l.targetContainers,n!==null&&a.indexOf(n)===-1&&a.push(n),l)}function im(l,a,t,e,n){switch(a){case"focusin":return Yt=li(Yt,l,a,t,e,n),!0;case"dragenter":return Gt=li(Gt,l,a,t,e,n),!0;case"mouseover":return Qt=li(Qt,l,a,t,e,n),!0;case"pointerover":var i=n.pointerId;return In.set(i,li(In.get(i)||null,l,a,t,e,n)),!0;case"gotpointercapture":return i=n.pointerId,Pn.set(i,li(Pn.get(i)||null,l,a,t,e,n)),!0}return!1}function Md(l){var a=Ee(l.target);if(a!==null){var t=H(a);if(t!==null){if(a=t.tag,a===13){if(a=V(t),a!==null){l.blockedOn=a,Gf(l.priority,function(){Ad(t)});return}}else if(a===31){if(a=R(t),a!==null){l.blockedOn=a,Gf(l.priority,function(){Ad(t)});return}}else if(a===3&&t.stateNode.current.memoizedState.isDehydrated){l.blockedOn=t.tag===3?t.stateNode.containerInfo:null;return}}}l.blockedOn=null}function ru(l){if(l.blockedOn!==null)return!1;for(var a=l.targetContainers;0<a.length;){var t=Af(l.nativeEvent);if(t===null){t=l.nativeEvent;var e=new t.constructor(t.type,t);Au=e,t.target.dispatchEvent(e),Au=null}else return a=Te(t),a!==null&&_d(a),l.blockedOn=t,!1;a.shift()}return!0}function Od(l,a,t){ru(l)&&t.delete(a)}function um(){Tf=!1,Yt!==null&&ru(Yt)&&(Yt=null),Gt!==null&&ru(Gt)&&(Gt=null),Qt!==null&&ru(Qt)&&(Qt=null),In.forEach(Od),Pn.forEach(Od)}function ou(l,a){l.blockedOn===a&&(l.blockedOn=null,Tf||(Tf=!0,d.unstable_scheduleCallback(d.unstable_NormalPriority,um)))}var du=null;function Nd(l){du!==l&&(du=l,d.unstable_scheduleCallback(d.unstable_NormalPriority,function(){du===l&&(du=null);for(var a=0;a<l.length;a+=3){var t=l[a],e=l[a+1],n=l[a+2];if(typeof e!="function"){if(Ef(e||t)===null)continue;break}var i=Te(t);i!==null&&(l.splice(a,3),a-=3,_c(i,{pending:!0,data:n,method:t.method,action:e},e,n))}}))}function fn(l){function a(s){return ou(s,l)}Yt!==null&&ou(Yt,l),Gt!==null&&ou(Gt,l),Qt!==null&&ou(Qt,l),In.forEach(a),Pn.forEach(a);for(var t=0;t<Xt.length;t++){var e=Xt[t];e.blockedOn===l&&(e.blockedOn=null)}for(;0<Xt.length&&(t=Xt[0],t.blockedOn===null);)Md(t),t.blockedOn===null&&Xt.shift();if(t=(l.ownerDocument||l).$$reactFormReplay,t!=null)for(e=0;e<t.length;e+=3){var n=t[e],i=t[e+1],u=n[Jl]||null;if(typeof i=="function")u||Nd(t);else if(u){var f=null;if(i&&i.hasAttribute("formAction")){if(n=i,u=i[Jl]||null)f=u.formAction;else if(Ef(n)!==null)continue}else f=u.action;typeof f=="function"?t[e+1]=f:(t.splice(e,3),e-=3),Nd(t)}}}function Dd(){function l(i){i.canIntercept&&i.info==="react-transition"&&i.intercept({handler:function(){return new Promise(function(u){return n=u})},focusReset:"manual",scroll:"manual"})}function a(){n!==null&&(n(),n=null),e||setTimeout(t,20)}function t(){if(!e&&!navigation.transition){var i=navigation.currentEntry;i&&i.url!=null&&navigation.navigate(i.url,{state:i.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var e=!1,n=null;return navigation.addEventListener("navigate",l),navigation.addEventListener("navigatesuccess",a),navigation.addEventListener("navigateerror",a),setTimeout(t,100),function(){e=!0,navigation.removeEventListener("navigate",l),navigation.removeEventListener("navigatesuccess",a),navigation.removeEventListener("navigateerror",a),n!==null&&(n(),n=null)}}}function Mf(l){this._internalRoot=l}mu.prototype.render=Mf.prototype.render=function(l){var a=this._internalRoot;if(a===null)throw Error(g(409));var t=a.current,e=da();Sd(t,e,l,a,null,null)},mu.prototype.unmount=Mf.prototype.unmount=function(){var l=this._internalRoot;if(l!==null){this._internalRoot=null;var a=l.containerInfo;Sd(l.current,2,null,l,null,null),Ki(),a[Ae]=null}};function mu(l){this._internalRoot=l}mu.prototype.unstable_scheduleHydration=function(l){if(l){var a=Yf();l={blockedOn:null,target:l,priority:a};for(var t=0;t<Xt.length&&a!==0&&a<Xt[t].priority;t++);Xt.splice(t,0,l),t===0&&Md(l)}};var jd=c.version;if(jd!=="19.2.5")throw Error(g(527,jd,"19.2.5"));A.findDOMNode=function(l){var a=l._reactInternals;if(a===void 0)throw typeof l.render=="function"?Error(g(188)):(l=Object.keys(l).join(","),Error(g(268,l)));return l=v(a),l=l!==null?C(l):null,l=l===null?null:l.stateNode,l};var cm={bundleType:0,version:"19.2.5",rendererPackageName:"react-dom",currentDispatcherRef:S,reconcilerVersion:"19.2.5"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var gu=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!gu.isDisabled&&gu.supportsFiber)try{ha=gu.inject(cm),_l=gu}catch{}}return ai.createRoot=function(l,a){if(!j(l))throw Error(g(299));var t=!1,e="",n=qr,i=Rr,u=Yr;return a!=null&&(a.unstable_strictMode===!0&&(t=!0),a.identifierPrefix!==void 0&&(e=a.identifierPrefix),a.onUncaughtError!==void 0&&(n=a.onUncaughtError),a.onCaughtError!==void 0&&(i=a.onCaughtError),a.onRecoverableError!==void 0&&(u=a.onRecoverableError)),a=vd(l,1,!1,null,null,t,e,null,n,i,u,Dd),l[Ae]=a.current,ff(l),new Mf(a)},ai.hydrateRoot=function(l,a,t){if(!j(l))throw Error(g(299));var e=!1,n="",i=qr,u=Rr,f=Yr,s=null;return t!=null&&(t.unstable_strictMode===!0&&(e=!0),t.identifierPrefix!==void 0&&(n=t.identifierPrefix),t.onUncaughtError!==void 0&&(i=t.onUncaughtError),t.onCaughtError!==void 0&&(u=t.onCaughtError),t.onRecoverableError!==void 0&&(f=t.onRecoverableError),t.formState!==void 0&&(s=t.formState)),a=vd(l,1,!0,a,t??null,e,n,s,i,u,f,Dd),a.context=xd(null),t=a.current,e=da(),e=pu(e),n=Mt(e),n.callback=null,Ot(t,n,e),t=e,a.current.lanes=t,Ra(a,t),Xa(a),l[Ae]=a.current,ff(l),new mu(a)},ai.version="19.2.5",ai}var qd;function pm(){if(qd)return Of.exports;qd=1;function d(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(d)}catch(c){console.error(c)}}return d(),Of.exports=hm(),Of.exports}var ym=pm();const bm="modulepreload",vm=function(d){return"/"+d},Rd={},ma=function(c,O,g){let j=Promise.resolve();if(O&&O.length>0){let V=function(v){return Promise.all(v.map(C=>Promise.resolve(C).then(E=>({status:"fulfilled",value:E}),E=>({status:"rejected",reason:E}))))};document.getElementsByTagName("link");const R=document.querySelector("meta[property=csp-nonce]"),T=R?.nonce||R?.getAttribute("nonce");j=V(O.map(v=>{if(v=vm(v),v in Rd)return;Rd[v]=!0;const C=v.endsWith(".css"),E=C?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${v}"]${E}`))return;const B=document.createElement("link");if(B.rel=C?"stylesheet":bm,C||(B.as="script"),B.crossOrigin="",B.href=v,T&&B.setAttribute("nonce",T),document.head.appendChild(B),C)return new Promise((ll,J)=>{B.addEventListener("load",ll),B.addEventListener("error",()=>J(new Error(`Unable to preload CSS for ${v}`)))})}))}function H(V){const R=new Event("vite:preloadError",{cancelable:!0});if(R.payload=V,window.dispatchEvent(R),!R.defaultPrevented)throw V}return j.then(V=>{for(const R of V||[])R.status==="rejected"&&H(R.reason);return c().catch(H)})};var wf={exports:{}},Uf={};/**
 * @license React
 * react-compiler-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Yd;function xm(){if(Yd)return Uf;Yd=1;var d=Bf().__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;return Uf.c=function(c){return d.H.useMemoCache(c)},Uf}var Gd;function Sm(){return Gd||(Gd=1,wf.exports=xm()),wf.exports}var hu=Sm();/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Kd=(...d)=>d.filter((c,O,g)=>!!c&&c.trim()!==""&&g.indexOf(c)===O).join(" ").trim();/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const zm=d=>d.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _m=d=>d.replace(/^([A-Z])|[\s-_]+(\w)/g,(c,O,g)=>g?g.toUpperCase():O.toLowerCase());/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qd=d=>{const c=_m(d);return c.charAt(0).toUpperCase()+c.slice(1)};/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var Cf={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Am=d=>{for(const c in d)if(c.startsWith("aria-")||c==="role"||c==="title")return!0;return!1},Em=K.createContext({}),Tm=()=>K.useContext(Em),Mm=K.forwardRef(({color:d,size:c,strokeWidth:O,absoluteStrokeWidth:g,className:j="",children:H,iconNode:V,...R},T)=>{const{size:v=24,strokeWidth:C=2,absoluteStrokeWidth:E=!1,color:B="currentColor",className:ll=""}=Tm()??{},J=g??E?Number(O??C)*24/Number(c??v):O??C;return K.createElement("svg",{ref:T,...Cf,width:c??v??Cf.width,height:c??v??Cf.height,stroke:d??B,strokeWidth:J,className:Kd("lucide",ll,j),...!H&&!Am(R)&&{"aria-hidden":"true"},...R},[...V.map(([W,sl])=>K.createElement(W,sl)),...Array.isArray(H)?H:[H]])});/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const aa=(d,c)=>{const O=K.forwardRef(({className:g,...j},H)=>K.createElement(Mm,{ref:H,iconNode:c,className:Kd(`lucide-${zm(Qd(d))}`,`lucide-${d}`,g),...j}));return O.displayName=Qd(d),O};/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Om=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],Xd=aa("arrow-right",Om);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Nm=[["path",{d:"M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z",key:"l5xja"}],["path",{d:"M9 13a4.5 4.5 0 0 0 3-4",key:"10igwf"}],["path",{d:"M6.003 5.125A3 3 0 0 0 6.401 6.5",key:"105sqy"}],["path",{d:"M3.477 10.896a4 4 0 0 1 .585-.396",key:"ql3yin"}],["path",{d:"M6 18a4 4 0 0 1-1.967-.516",key:"2e4loj"}],["path",{d:"M12 13h4",key:"1ku699"}],["path",{d:"M12 18h6a2 2 0 0 1 2 2v1",key:"105ag5"}],["path",{d:"M12 8h8",key:"1lhi5i"}],["path",{d:"M16 8V5a2 2 0 0 1 2-2",key:"u6izg6"}],["circle",{cx:"16",cy:"13",r:".5",key:"ry7gng"}],["circle",{cx:"18",cy:"3",r:".5",key:"1aiba7"}],["circle",{cx:"20",cy:"21",r:".5",key:"yhc1fs"}],["circle",{cx:"20",cy:"8",r:".5",key:"1e43v0"}]],kd=aa("brain-circuit",Nm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Dm=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]],jm=aa("circle-alert",Dm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const wm=[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3",key:"msslwz"}],["path",{d:"M3 5V19A9 3 0 0 0 21 19V5",key:"1wlel7"}],["path",{d:"M3 12A9 3 0 0 0 21 12",key:"mv7ke4"}]],Jd=aa("database",wm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Um=[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["circle",{cx:"11.5",cy:"14.5",r:"2.5",key:"1bq0ko"}],["path",{d:"M13.3 16.3 15 18",key:"2quom7"}]],Cm=aa("file-search",Um);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Hm=[["path",{d:"M6 3v12",key:"qpgusn"}],["path",{d:"M18 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6z",key:"1d02ji"}],["path",{d:"M6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6z",key:"chk6ph"}],["path",{d:"M15 6a9 9 0 0 0-9 9",key:"or332x"}],["path",{d:"M18 15v6",key:"9wciyi"}],["path",{d:"M21 18h-6",key:"139f0c"}]],Wd=aa("git-branch-plus",Hm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Bm=[["circle",{cx:"18",cy:"18",r:"3",key:"1xkwt0"}],["circle",{cx:"6",cy:"6",r:"3",key:"1lh9wr"}],["path",{d:"M6 21V9a9 9 0 0 0 9 9",key:"7kw0sc"}]],$d=aa("git-merge",Bm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qm=[["rect",{x:"16",y:"16",width:"6",height:"6",rx:"1",key:"4q2zg0"}],["rect",{x:"2",y:"16",width:"6",height:"6",rx:"1",key:"8cvhb9"}],["rect",{x:"9",y:"2",width:"6",height:"6",rx:"1",key:"1egb70"}],["path",{d:"M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3",key:"1jsf9p"}],["path",{d:"M12 12V8",key:"2874zd"}]],Hf=aa("network",qm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Rm=[["path",{d:"M19.07 4.93A10 10 0 0 0 6.99 3.34",key:"z3du51"}],["path",{d:"M4 6h.01",key:"oypzma"}],["path",{d:"M2.29 9.62A10 10 0 1 0 21.31 8.35",key:"qzzz0"}],["path",{d:"M16.24 7.76A6 6 0 1 0 8.23 16.67",key:"1yjesh"}],["path",{d:"M12 18h.01",key:"mhygvu"}],["path",{d:"M17.99 11.66A6 6 0 0 1 15.77 16.67",key:"1u2y91"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}],["path",{d:"m13.41 10.59 5.66-5.66",key:"mhq4k0"}]],Ym=aa("radar",Rm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Gm=[["circle",{cx:"6",cy:"19",r:"3",key:"1kj8tv"}],["path",{d:"M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15",key:"1d8sl"}],["circle",{cx:"18",cy:"5",r:"3",key:"gq8acd"}]],Qm=aa("route",Gm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xm=[["path",{d:"M12 3v18",key:"108xh3"}],["path",{d:"m19 8 3 8a5 5 0 0 1-6 0zV7",key:"zcdpyk"}],["path",{d:"M3 7h1a17 17 0 0 0 8-2 17 17 0 0 0 8 2h1",key:"1yorad"}],["path",{d:"m5 8 3 8a5 5 0 0 1-6 0zV7",key:"eua70x"}],["path",{d:"M7 21h10",key:"1b0cd5"}]],Fd=aa("scale",Xm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const km=[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]],Vm=aa("search",km);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Zm=[["path",{d:"M14 17H5",key:"gfn3mx"}],["path",{d:"M19 7h-9",key:"6i9tg"}],["circle",{cx:"17",cy:"17",r:"3",key:"18b49y"}],["circle",{cx:"7",cy:"7",r:"3",key:"dfmy0x"}]],Lm=aa("settings-2",Zm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Km=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],Vd=aa("shield-check",Km),Jm=5e3;class sn extends K.Component{settleTimer=null;constructor(c){super(c),this.state={hasError:!1,error:null,retryCount:0}}static getDerivedStateFromError(c){return{hasError:!0,error:c}}componentDidCatch(c,O){console.error("ErrorBoundary caught an error:",c,O),this.clearSettleTimer()}componentWillUnmount(){this.clearSettleTimer()}clearSettleTimer(){this.settleTimer!==null&&(clearTimeout(this.settleTimer),this.settleTimer=null)}resetErrorBoundary=()=>{this.clearSettleTimer(),this.setState(c=>({hasError:!1,error:null,retryCount:c.retryCount+1})),this.settleTimer=setTimeout(()=>{this.settleTimer=null,this.setState({retryCount:0})},Jm)};render(){if(this.state.hasError){const c=this.state.retryCount>=3;return o.jsxs("div",{className:"workspace-loading",style:{flexDirection:"column",gap:12,color:"var(--ws-red)"},children:[o.jsx(jm,{size:32,style:{marginBottom:4,opacity:.8}}),o.jsx("div",{style:{fontWeight:500,fontSize:"15px"},children:"Something went wrong in this view."}),o.jsx("div",{style:{fontSize:"13px",opacity:.7,maxWidth:450,textAlign:"center",marginBottom:8,lineHeight:1.5},children:c?"This view continues to encounter a critical error. Please switch to another workspace or reload the page to restore functionality.":"An unexpected problem occurred while rendering this workspace. Your data is safe, but this view cannot be displayed."}),c?o.jsx("button",{className:"ws-btn ws-btn--ghost",style:{borderColor:"var(--ws-border)",color:"var(--ws-text)"},onClick:()=>window.location.reload(),children:"Reload Application"}):o.jsx("button",{className:"ws-btn ws-btn--ghost",style:{borderColor:"var(--ws-red-soft)",color:"var(--ws-red)"},onClick:this.resetErrorBoundary,children:"Try Again"})]})}return this.props.children}}const Wm=K.lazy(()=>ma(()=>import("./DecisionWorkspace-BKQFtyNr.js"),__vite__mapDeps([0,1,2])).then(d=>({default:d.DecisionWorkspace}))),$m=K.lazy(()=>ma(()=>import("./DiffMergeWorkspace-DfaDgl2T.js"),__vite__mapDeps([3,1,4,5,6])).then(d=>({default:d.DiffMergeWorkspace}))),Fm=K.lazy(()=>ma(()=>import("./GraphWorkspace-CeTkK6Qg.js").then(d=>d.a),__vite__mapDeps([7,1,8,4,9,10,11,12,13])).then(d=>({default:d.GraphWorkspace}))),Im=K.lazy(()=>ma(()=>import("./ImportExportWorkspace-CHzYUTOl.js"),__vite__mapDeps([14,1,15,4,16,6,17,5])).then(d=>({default:d.ImportExportWorkspace}))),Pm=K.lazy(()=>ma(()=>import("./LineageDiagram-Dq-BhLNV.js"),__vite__mapDeps([18,1,19,20,21])).then(d=>({default:d.LineageDiagram}))),lg=K.lazy(()=>ma(()=>import("./ReasoningWorkspace-BVlShoff.js"),__vite__mapDeps([22,1,12,11,5,2])).then(d=>({default:d.ReasoningWorkspace}))),ag=K.lazy(()=>ma(()=>import("./SparqlWorkspace-CT9WWG1I.js"),__vite__mapDeps([23,1,24,12,17])).then(d=>({default:d.SparqlWorkspace}))),tg=K.lazy(()=>ma(()=>import("./VocabularyWorkspace-BTccYbUX.js"),__vite__mapDeps([25,1,26,27,16,20,15,6,5])).then(d=>({default:d.VocabularyWorkspace}))),eg=K.lazy(()=>ma(()=>import("./RegistryTab-DjoaSS2H.js"),__vite__mapDeps([28,1,4,29,27])).then(d=>({default:d.RegistryTab}))),ng=K.lazy(()=>ma(()=>import("./EntityResolutionTab-DQWfDZY8.js"),__vite__mapDeps([30,1,4,6,27,13])).then(d=>({default:d.EntityResolutionTab}))),ig=K.lazy(()=>ma(()=>import("./KGOverviewTab-BIX4S7IL.js"),__vite__mapDeps([31,1,6,9])).then(d=>({default:d.KGOverviewTab}))),ug=K.lazy(()=>ma(()=>import("./OntologySummaryTab-DQBwkrv6.js"),__vite__mapDeps([32,1,26,33,27])).then(d=>({default:d.OntologySummaryTab}))),cg=K.lazy(()=>ma(()=>import("./index-_mMYPpGW.js"),__vite__mapDeps([34,1,6,29,17,13,27,5,33,10,9,19,20,21,11,16,24,12])).then(d=>({default:d.OntologyWorkspace}))),fg={checking:"Connecting…",online:"System Online",offline:"Backend Unreachable"},sg=new sm,rg=Array.from({length:42},(d,c)=>({cx:170+c*73%330,cy:170+c*47%210,r:2+c%3,fill:["#56d364","#58a6ff","#f2b66d","#ff9daf"][c%4]})),og=[{id:"explore",label:"Knowledge Explorer",hint:"Graph and vocabulary browsing",icon:Jd},{id:"analyze",label:"Analyze",hint:"Query and inspect the dataset",icon:Cm},{id:"decisions",label:"Decisions",hint:"Decision chains and precedent review",icon:Fd},{id:"enrich",label:"Enrich",hint:"Import, export, and merge workflows",icon:Wd},{id:"manage",label:"Manage",hint:"Lineage and governance tooling",icon:Lm},{id:"ontology-hub",label:"Ontology Hub",hint:"Schema governance, registry, and vocabulary management",icon:$d}],dg=`
  :root {
    --app-bg: #07111f;
    --panel-bg: rgba(7, 17, 31, 0.82);
    --panel-border: rgba(140, 192, 255, 0.14);
    --text-main: #ebf3ff;
    --text-muted: #8fa8c6;
    --accent: #4aa3ff;
    --accent-strong: #7fd0ff;
    --warm: #f2b66d;
    --success: #4cc38a;

    /* ── Shared workspace design tokens ── */
    --ws-bg: #060d1a;
    --ws-surface: rgba(255,255,255,0.028);
    --ws-surface-hover: rgba(74,163,255,0.07);
    --ws-border: rgba(74,163,255,0.13);
    --ws-border-strong: rgba(74,163,255,0.26);
    --ws-text: #ddeeff;
    --ws-text-muted: #5a7a9a;
    --ws-text-dim: #3a5570;
    --ws-accent: #4aa3ff;
    --ws-accent-soft: rgba(74,163,255,0.12);
    --ws-green: #4cc38a;
    --ws-green-soft: rgba(76,195,138,0.12);
    --ws-amber: #f2b66d;
    --ws-amber-soft: rgba(242,182,109,0.12);
    --ws-red: #ff7b72;
    --ws-red-soft: rgba(255,123,114,0.12);
    --ws-purple: #c084fc;
    --ws-purple-soft: rgba(192,132,252,0.1);
    --ws-radius: 14px;
    --ws-radius-sm: 8px;
    --ws-radius-lg: 20px;
  }

  /* ── Shared workspace primitives (available to all workspace components) ── */
  .ws-page {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    background: var(--ws-bg);
    overflow: hidden;
  }

  .ws-scroll {
    flex: 1;
    min-height: 0;
    overflow-y: auto;
    overflow-x: hidden;
    scrollbar-width: thin;
    scrollbar-color: var(--ws-border) transparent;
  }

  .ws-padded {
    padding: 24px 28px;
  }

  .ws-split {
    display: grid;
    height: 100%;
    overflow: hidden;
  }

  .ws-split--2col { grid-template-columns: 300px 1fr; }
  .ws-split--half { grid-template-columns: 1fr 1fr; }
  .ws-split--rows { grid-template-rows: 1fr auto; }

  .ws-panel {
    background: var(--ws-surface);
    border: 1px solid var(--ws-border);
    border-radius: var(--ws-radius);
    overflow: hidden;
  }

  .ws-panel--inset {
    background: rgba(0,0,0,0.22);
    border: 1px solid rgba(74,163,255,0.09);
    border-radius: var(--ws-radius);
  }

  .ws-card {
    background: var(--ws-surface);
    border: 1px solid var(--ws-border);
    border-radius: var(--ws-radius);
    padding: 20px;
    position: relative;
    overflow: hidden;
    transition: border-color 180ms ease, background 180ms ease;
  }

  .ws-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(74,163,255,0.18), transparent);
  }

  .ws-card:hover {
    border-color: var(--ws-border-strong);
    background: var(--ws-surface-hover);
  }

  .ws-eyebrow {
    font-family: "JetBrains Mono", "Fira Code", monospace;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: var(--ws-text-muted);
  }

  .ws-label {
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    color: var(--ws-text-muted);
    margin-bottom: 8px;
    display: block;
  }

  .ws-title {
    font-size: 22px;
    font-weight: 800;
    letter-spacing: -0.035em;
    color: var(--ws-text);
    margin: 0;
  }

  .ws-body {
    font-size: 13px;
    line-height: 1.65;
    color: var(--ws-text-muted);
  }

  .ws-btn {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 9px 16px;
    border-radius: var(--ws-radius-sm);
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    transition: 160ms ease;
    border: 1px solid transparent;
  }

  .ws-btn--primary {
    background: linear-gradient(135deg, rgba(74,163,255,0.28), rgba(56,210,160,0.16));
    border-color: rgba(74,163,255,0.4);
    color: #e8f6ff;
    box-shadow: 0 0 0 1px rgba(74,163,255,0.08) inset;
  }

  .ws-btn--primary:hover:not(:disabled) {
    background: linear-gradient(135deg, rgba(74,163,255,0.4), rgba(56,210,160,0.24));
    border-color: rgba(74,163,255,0.6);
    box-shadow: 0 6px 20px rgba(74,163,255,0.18);
    transform: translateY(-1px);
  }

  .ws-btn--ghost {
    background: rgba(255,255,255,0.04);
    border-color: var(--ws-border);
    color: var(--ws-text-muted);
  }

  .ws-btn--ghost:hover:not(:disabled) {
    background: var(--ws-surface-hover);
    border-color: var(--ws-border-strong);
    color: var(--ws-text);
  }

  .ws-btn--danger {
    background: var(--ws-red-soft);
    border-color: rgba(255,123,114,0.3);
    color: #ff9e97;
  }

  .ws-btn--success {
    background: var(--ws-green-soft);
    border-color: rgba(76,195,138,0.3);
    color: #6ee7b7;
  }

  .ws-btn:disabled {
    opacity: 0.45;
    cursor: not-allowed;
    transform: none !important;
  }

  .ws-input {
    width: 100%;
    padding: 9px 12px;
    background: rgba(0,0,0,0.28);
    border: 1px solid var(--ws-border);
    border-radius: var(--ws-radius-sm);
    color: var(--ws-text);
    font-size: 13px;
    outline: none;
    transition: border-color 160ms ease;
    box-sizing: border-box;
  }

  .ws-input:focus {
    border-color: var(--ws-accent);
    box-shadow: 0 0 0 3px rgba(74,163,255,0.1);
  }

  .ws-textarea {
    width: 100%;
    padding: 12px;
    background: rgba(0,0,0,0.28);
    border: 1px solid var(--ws-border);
    border-radius: var(--ws-radius-sm);
    color: var(--ws-text);
    font-family: "JetBrains Mono", "Fira Code", "Consolas", monospace;
    font-size: 12.5px;
    line-height: 1.7;
    resize: vertical;
    outline: none;
    transition: border-color 160ms ease;
    box-sizing: border-box;
  }

  .ws-textarea:focus {
    border-color: var(--ws-accent);
    box-shadow: 0 0 0 3px rgba(74,163,255,0.1);
  }

  .ws-pill {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 3px 9px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.04em;
    white-space: nowrap;
  }

  .ws-pill--accent { color: #7fd0ff; background: var(--ws-accent-soft); border: 1px solid rgba(74,163,255,0.22); }
  .ws-pill--green  { color: #6ee7b7; background: var(--ws-green-soft);  border: 1px solid rgba(76,195,138,0.28); }
  .ws-pill--amber  { color: #fbbf24; background: var(--ws-amber-soft);  border: 1px solid rgba(242,182,109,0.28); }
  .ws-pill--red    { color: #fca5a5; background: var(--ws-red-soft);    border: 1px solid rgba(255,123,114,0.28); }
  .ws-pill--purple { color: #d8b4fe; background: var(--ws-purple-soft); border: 1px solid rgba(192,132,252,0.22); }
  .ws-pill--mono   { color: var(--ws-text-muted); background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); }

  .ws-divider {
    height: 1px;
    background: var(--ws-border);
    margin: 0;
  }

  .ws-empty {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    padding: 48px 24px;
    gap: 10px;
    color: var(--ws-text-muted);
  }

  .ws-empty-icon { opacity: 0.35; margin-bottom: 4px; }
  .ws-empty-title { font-size: 14px; font-weight: 700; color: var(--ws-text); }
  .ws-empty-body { font-size: 12px; line-height: 1.5; max-width: 36ch; }

  .ws-sidebar {
    border-right: 1px solid var(--ws-border);
    display: flex;
    flex-direction: column;
    overflow: hidden;
    background: rgba(0,0,0,0.12);
  }

  .ws-sidebar-header {
    padding: 18px 16px 14px;
    border-bottom: 1px solid var(--ws-border);
    flex-shrink: 0;
  }

  .ws-sidebar-body {
    flex: 1;
    overflow-y: auto;
    padding: 10px 10px;
    scrollbar-width: thin;
    scrollbar-color: var(--ws-border) transparent;
  }

  .ws-list-item {
    width: 100%;
    text-align: left;
    padding: 10px 12px;
    border-radius: 10px;
    border: 1px solid transparent;
    background: transparent;
    color: var(--ws-text-muted);
    cursor: pointer;
    transition: 140ms ease;
    display: block;
  }

  .ws-list-item:hover {
    background: var(--ws-surface);
    border-color: var(--ws-border);
    color: var(--ws-text);
  }

  .ws-list-item--active {
    background: var(--ws-accent-soft);
    border-color: var(--ws-border-strong);
    color: #e8f6ff;
  }

  .ws-stat-grid {
    display: grid;
    gap: 12px;
  }

  .ws-stat-grid--3 { grid-template-columns: repeat(3, 1fr); }
  .ws-stat-grid--4 { grid-template-columns: repeat(4, 1fr); }
  .ws-stat-grid--2 { grid-template-columns: repeat(2, 1fr); }

  .ws-stat-card {
    padding: 18px 20px;
    border-radius: var(--ws-radius);
    border: 1px solid var(--ws-border);
    background: var(--ws-surface);
    position: relative;
    overflow: hidden;
  }

  .ws-stat-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(74,163,255,0.2), transparent);
  }

  .ws-stat-value {
    font-size: 28px;
    font-weight: 800;
    letter-spacing: -0.04em;
    color: var(--ws-text);
    line-height: 1;
  }

  .ws-stat-label {
    margin-top: 6px;
    font-size: 11px;
    font-weight: 600;
    color: var(--ws-text-dim);
    letter-spacing: 0.04em;
  }

  @keyframes ws-spin { to { transform: rotate(360deg); } }
  .ws-spin { animation: ws-spin 0.8s linear infinite; }

  @keyframes ws-skeleton {
    0%, 100% { opacity: 0.4; }
    50% { opacity: 0.7; }
  }

  .ws-skeleton {
    background: rgba(255,255,255,0.06);
    border-radius: 8px;
    animation: ws-skeleton 1.4s ease-in-out infinite;
  }

  @keyframes ws-slide-up {
    from { opacity: 0; transform: translateY(14px); }
    to { opacity: 1; transform: translateY(0); }
  }

  .ws-animate-in { animation: ws-slide-up 0.22s ease both; }

  .app-shell {
    display: flex;
    width: 100vw;
    height: 100vh;
    overflow: hidden;
    color: var(--text-main);
    background:
      radial-gradient(circle at top left, rgba(74, 163, 255, 0.12), transparent 32%),
      radial-gradient(circle at bottom right, rgba(242, 182, 109, 0.08), transparent 26%),
      linear-gradient(180deg, #091322 0%, #050b15 100%);
    font-family: "Segoe UI", "SF Pro Display", sans-serif;
  }

  .app-rail {
    width: 88px;
    padding: 20px 14px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    border-right: 1px solid var(--panel-border);
    background: rgba(3, 9, 18, 0.92);
    backdrop-filter: blur(18px);
  }

  .brand-pill {
    width: 100%;
    min-height: 56px;
    border-radius: 18px;
    display: grid;
    place-items: center;
    color: var(--text-main);
    background: linear-gradient(135deg, rgba(74, 163, 255, 0.22), rgba(127, 208, 255, 0.08));
    border: 1px solid rgba(127, 208, 255, 0.18);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.08);
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.12em;
  }

  .nav-button {
    border: 1px solid transparent;
    background: transparent;
    color: var(--text-muted);
    border-radius: 18px;
    min-height: 72px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 8px;
    cursor: pointer;
    transition: 160ms ease;
  }

  .nav-button:hover {
    color: var(--text-main);
    background: rgba(74, 163, 255, 0.08);
    border-color: rgba(74, 163, 255, 0.12);
  }

  .nav-button[data-active='true'] {
    color: var(--text-main);
    background: linear-gradient(180deg, rgba(74, 163, 255, 0.18), rgba(74, 163, 255, 0.08));
    border-color: rgba(127, 208, 255, 0.22);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.08);
  }

  .nav-label {
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.02em;
  }

  .workspace-shell {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
  }

  .workspace-header {
    padding: 14px 22px;
    border-bottom: 1px solid var(--panel-border);
    background: linear-gradient(180deg, rgba(7, 17, 31, 0.94), rgba(7, 17, 31, 0.82));
    backdrop-filter: blur(18px);
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 18px;
    min-height: 68px;
  }

  .workspace-header--compact {
    min-height: 60px;
    padding: 10px 18px;
    background: linear-gradient(180deg, rgba(7, 17, 31, 0.92), rgba(7, 17, 31, 0.72));
  }

  .workspace-header--compact .workspace-title {
    font-size: 16px;
  }

  .workspace-header--compact .workspace-subtitle {
    font-size: 11px;
  }

  .workspace-header-main {
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 14px;
  }

  .workspace-kicker {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 6px 10px;
    border-radius: 999px;
    background: rgba(74, 163, 255, 0.08);
    border: 1px solid rgba(127, 208, 255, 0.14);
    color: var(--text-muted);
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    white-space: nowrap;
  }

  .workspace-kicker::before {
    content: "";
    width: 7px;
    height: 7px;
    border-radius: 999px;
    background: linear-gradient(135deg, var(--accent-strong), var(--warm));
    box-shadow: 0 0 14px rgba(127, 208, 255, 0.45);
  }

  .workspace-title-block {
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 3px;
  }

  .workspace-title {
    margin: 0;
    font-size: 20px;
    line-height: 1;
    letter-spacing: -0.03em;
  }

  .workspace-subtitle {
    color: var(--text-muted);
    font-size: 12px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .workspace-tabs {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    justify-content: flex-end;
  }

  .workspace-tab {
    border: 1px solid rgba(127, 208, 255, 0.18);
    background: rgba(9, 19, 34, 0.56);
    color: var(--text-muted);
    border-radius: 999px;
    padding: 8px 12px;
    cursor: pointer;
    font-size: 12px;
    font-weight: 600;
    transition: 160ms ease;
    white-space: nowrap;
  }

  .workspace-tab[data-active='true'] {
    color: var(--text-main);
    background: rgba(74, 163, 255, 0.16);
    border-color: rgba(127, 208, 255, 0.3);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.05);
  }

  .workspace-body {
    flex: 1;
    min-height: 0;
    overflow: hidden;
  }

  /* ── Welcome page ─────────────────────────────────────── */
  .landing-page {
    position: relative;
    flex: 1;
    min-height: 0;
    overflow-y: auto;
    overflow-x: hidden;
    background:
      radial-gradient(ellipse 80% 50% at 50% -10%, rgba(74, 163, 255, 0.18) 0%, transparent 60%),
      radial-gradient(ellipse 60% 40% at 80% 90%, rgba(242, 182, 109, 0.1) 0%, transparent 50%),
      linear-gradient(180deg, #060d1a 0%, #03070f 100%);
    scrollbar-width: thin;
    scrollbar-color: rgba(74,163,255,0.18) transparent;
  }

  .landing-page::before {
    content: "";
    position: fixed;
    inset: 0 0 0 88px;
    pointer-events: none;
    background:
      repeating-linear-gradient(0deg, transparent, transparent 79px, rgba(74,163,255,0.035) 80px),
      repeating-linear-gradient(90deg, transparent, transparent 79px, rgba(74,163,255,0.025) 80px);
    mask-image: radial-gradient(ellipse 90% 80% at 50% 20%, black 30%, transparent 100%);
  }

  .landing-shell {
    position: relative;
    z-index: 1;
    width: min(1360px, 100%);
    margin: 0 auto;
    padding: clamp(28px, 4vw, 56px) clamp(20px, 3vw, 48px);
    display: flex;
    flex-direction: column;
    gap: 56px;
  }

  /* ── Hero ──────────────────────────────────────────────── */
  .landing-hero {
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(380px, 520px);
    gap: clamp(24px, 3vw, 48px);
    align-items: center;
    min-height: min(580px, calc(100vh - 140px));
  }

  .landing-copy {
    display: flex;
    flex-direction: column;
    gap: 0;
  }

  .landing-status-bar {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 24px;
    --status-color: #4cc38a;
    --status-shadow-a: 0 0 0 3px rgba(76, 195, 138, 0.22), 0 0 12px rgba(76, 195, 138, 0.5);
    --status-shadow-b: 0 0 0 5px rgba(76, 195, 138, 0.1), 0 0 20px rgba(76, 195, 138, 0.35);
  }

  .landing-status-bar[data-status='checking'] {
    --status-color: #f2b66d;
    --status-shadow-a: 0 0 0 3px rgba(242, 182, 109, 0.22), 0 0 12px rgba(242, 182, 109, 0.5);
    --status-shadow-b: 0 0 0 5px rgba(242, 182, 109, 0.1), 0 0 20px rgba(242, 182, 109, 0.35);
  }

  .landing-status-bar[data-status='offline'] {
    --status-color: #ff7b72;
    --status-shadow-a: 0 0 0 3px rgba(255, 123, 114, 0.22), 0 0 12px rgba(255, 123, 114, 0.5);
    --status-shadow-b: 0 0 0 5px rgba(255, 123, 114, 0.1), 0 0 20px rgba(255, 123, 114, 0.35);
  }

  .landing-status-dot {
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: var(--status-color);
    box-shadow: var(--status-shadow-a);
    animation: landing-pulse 2.4s ease-in-out infinite;
  }

  .landing-status-text {
    color: var(--status-color);
    font: 700 11px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.1em;
    text-transform: uppercase;
  }

  .landing-status-divider {
    width: 1px;
    height: 14px;
    background: rgba(158, 217, 255, 0.2);
  }

  .landing-status-version {
    color: #5a7a9a;
    font: 600 11px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.06em;
  }

  .landing-kicker {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 5px 12px 5px 8px;
    border-radius: 999px;
    border: 1px solid rgba(74, 163, 255, 0.3);
    background: rgba(74, 163, 255, 0.08);
    color: #7fd0ff;
    font: 700 11px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    width: fit-content;
    margin-bottom: 20px;
  }

  .landing-kicker-mark {
    width: 16px;
    height: 16px;
    border-radius: 6px;
    background: linear-gradient(135deg, #4aa3ff, #56d3a0);
    display: grid;
    place-items: center;
    flex: 0 0 auto;
  }

  .landing-kicker-node { display: none; }

  .landing-kicker-mark::after {
    content: "";
    width: 7px;
    height: 7px;
    border-radius: 999px;
    background: rgba(3, 10, 20, 0.8);
  }

  .landing-title {
    margin: 0 0 20px;
    color: #f0f7ff;
    font-family: "Inter", "Segoe UI", sans-serif;
    font-size: clamp(38px, 4.8vw, 72px);
    line-height: 1.08;
    letter-spacing: -0.04em;
    font-weight: 800;
  }

  .landing-title span {
    color: transparent;
    background: linear-gradient(100deg, #7fd0ff 0%, #4cc38a 50%, #f2b66d 100%);
    -webkit-background-clip: text;
    background-clip: text;
  }

  .landing-subtitle {
    margin: 0 0 32px;
    color: #7a99b8;
    font-size: clamp(14px, 1.2vw, 17px);
    line-height: 1.7;
    max-width: 54ch;
  }

  .landing-cta-row {
    display: flex;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
  }

  .landing-cta-primary {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 22px;
    border-radius: 12px;
    border: 1px solid rgba(74, 163, 255, 0.5);
    background: linear-gradient(135deg, rgba(74, 163, 255, 0.28), rgba(56, 210, 160, 0.18));
    color: #e8f6ff;
    font-size: 14px;
    font-weight: 700;
    cursor: pointer;
    transition: 180ms ease;
    box-shadow: 0 0 0 1px rgba(74, 163, 255, 0.1) inset, 0 8px 24px rgba(74, 163, 255, 0.15);
  }

  .landing-cta-primary:hover {
    transform: translateY(-2px);
    background: linear-gradient(135deg, rgba(74, 163, 255, 0.38), rgba(56, 210, 160, 0.26));
    box-shadow: 0 0 0 1px rgba(74, 163, 255, 0.18) inset, 0 14px 32px rgba(74, 163, 255, 0.22);
  }

  .landing-cta-secondary {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 18px;
    border-radius: 12px;
    border: 1px solid rgba(158, 217, 255, 0.14);
    background: rgba(255, 255, 255, 0.04);
    color: #8fafc8;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: 180ms ease;
  }

  .landing-cta-secondary:hover {
    border-color: rgba(158, 217, 255, 0.26);
    color: #c5dcef;
    background: rgba(255, 255, 255, 0.07);
  }

  /* ── Preview panel ─────────────────────────────────────── */
  .landing-preview {
    position: relative;
    overflow: hidden;
    border-radius: 24px;
    border: 1px solid rgba(74, 163, 255, 0.18);
    background:
      radial-gradient(circle at 40% 30%, rgba(74, 163, 255, 0.14), transparent 46%),
      radial-gradient(circle at 70% 70%, rgba(242, 182, 109, 0.1), transparent 38%),
      linear-gradient(145deg, rgba(8, 17, 28, 0.96), rgba(3, 8, 14, 0.88));
    box-shadow: 0 24px 72px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255,255,255,0.04) inset;
    aspect-ratio: 4/3.2;
    min-height: 340px;
  }

  .landing-preview-topbar {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 38px;
    background: rgba(4, 10, 18, 0.82);
    border-bottom: 1px solid rgba(74, 163, 255, 0.1);
    backdrop-filter: blur(12px);
    display: flex;
    align-items: center;
    padding: 0 14px;
    gap: 8px;
  }

  .landing-preview-dot {
    width: 10px;
    height: 10px;
    border-radius: 999px;
  }

  .landing-preview-dot:nth-child(1) { background: rgba(255, 95, 86, 0.7); }
  .landing-preview-dot:nth-child(2) { background: rgba(255, 189, 46, 0.7); }
  .landing-preview-dot:nth-child(3) { background: rgba(39, 201, 63, 0.7); }

  .landing-preview-tab {
    margin-left: 12px;
    padding: 3px 10px;
    border-radius: 6px;
    background: rgba(74, 163, 255, 0.12);
    border: 1px solid rgba(74, 163, 255, 0.2);
    color: #7fd0ff;
    font: 600 10px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.06em;
  }

  .landing-preview-orbit {
    position: absolute;
    inset: 38px 0 0;
    opacity: 0.95;
  }

  .landing-preview-orbit svg {
    width: 100%;
    height: 100%;
    overflow: visible;
  }

  .landing-preview-line {
    stroke: rgba(74, 163, 255, 0.3);
    stroke-width: 1.2;
    fill: none;
    stroke-dasharray: 4 3;
  }

  .landing-preview-line--warm {
    stroke: rgba(242, 182, 109, 0.3);
  }

  .landing-preview-line--mint {
    stroke: rgba(76, 195, 138, 0.28);
  }

  .landing-node {
    transform-origin: center;
    animation: landing-float 7s ease-in-out infinite;
  }

  .landing-node:nth-child(2n) { animation-delay: -2.2s; }
  .landing-node:nth-child(3n) { animation-delay: -4.1s; }

  .landing-command-card,
  .landing-dossier-card,
  .landing-timeline-card {
    position: absolute;
    border: 1px solid rgba(74, 163, 255, 0.16);
    background: rgba(3, 9, 18, 0.84);
    backdrop-filter: blur(20px);
    box-shadow: 0 12px 32px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.04) inset;
  }

  .landing-command-card {
    top: 50px;
    left: 16px;
    right: 16px;
    border-radius: 14px;
    padding: 10px 14px;
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .landing-command-icon {
    width: 32px;
    height: 32px;
    border-radius: 10px;
    display: grid;
    place-items: center;
    color: #56d3a0;
    background: rgba(76, 195, 138, 0.1);
    border: 1px solid rgba(76, 195, 138, 0.2);
    flex: 0 0 auto;
  }

  .landing-command-label {
    color: #c8dff0;
    font-size: 12px;
    font-weight: 700;
  }

  .landing-command-meta {
    margin-top: 2px;
    color: #4a6a85;
    font: 500 10px/1 "JetBrains Mono", monospace;
  }

  .landing-dossier-card {
    right: 14px;
    bottom: 80px;
    width: min(210px, calc(100% - 28px));
    border-radius: 16px;
    padding: 14px;
  }

  .landing-dossier-kicker {
    color: #56d3a0;
    font: 700 9px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.1em;
    text-transform: uppercase;
  }

  .landing-dossier-title {
    margin-top: 6px;
    color: #e8f4ff;
    font: 800 20px/1 "Inter", sans-serif;
    letter-spacing: -0.04em;
  }

  .landing-dossier-row {
    margin-top: 8px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 8px;
    color: #5e7d98;
    font-size: 10px;
    font-weight: 600;
  }

  .landing-dossier-row strong { color: #f2b66d; font-weight: 700; }

  .landing-timeline-card {
    left: 14px;
    right: 14px;
    bottom: 14px;
    border-radius: 12px;
    padding: 10px 12px;
  }

  .landing-timeline-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 8px;
  }

  .landing-timeline-title {
    color: #5e7d98;
    font: 700 9px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.08em;
    text-transform: uppercase;
  }

  .landing-timeline-badge {
    color: #7fd0ff;
    font: 700 9px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.06em;
  }

  .landing-timeline-track {
    position: relative;
    height: 4px;
    border-radius: 999px;
    background: rgba(74, 163, 255, 0.1);
    overflow: hidden;
  }

  .landing-timeline-track::after {
    content: "";
    position: absolute;
    inset: 0 28% 0 0;
    border-radius: inherit;
    background: linear-gradient(90deg, #4cc38a, #4aa3ff, #f2b66d);
  }

  .landing-timeline-labels {
    display: flex;
    justify-content: space-between;
    margin-top: 6px;
    color: #3a5570;
    font: 600 9px/1 "JetBrains Mono", monospace;
  }

  /* ── Metrics strip ─────────────────────────────────────── */
  .landing-metrics {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 12px;
  }

  .landing-metric {
    padding: 18px 20px;
    border-radius: 16px;
    border: 1px solid rgba(158, 217, 255, 0.09);
    background: rgba(255, 255, 255, 0.025);
    position: relative;
    overflow: hidden;
    transition: border-color 200ms ease;
  }

  .landing-metric::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(158, 217, 255, 0.2), transparent);
  }

  .landing-metric:hover {
    border-color: rgba(158, 217, 255, 0.18);
  }

  .landing-metric-value {
    color: #ddeeff;
    font: 800 28px/1 "Inter", sans-serif;
    letter-spacing: -0.04em;
  }

  .landing-metric[data-tone='mint'] .landing-metric-value { color: #56d3a0; }
  .landing-metric[data-tone='amber'] .landing-metric-value { color: #f2b66d; }
  .landing-metric[data-tone='rose'] .landing-metric-value { color: #ff9daf; }
  .landing-metric[data-tone='cyan'] .landing-metric-value { color: #7fd0ff; }

  .landing-metric-label {
    margin-top: 6px;
    color: #4a6a85;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.02em;
  }

  /* ── Workspace grid ────────────────────────────────────── */
  .landing-section-header {
    display: flex;
    align-items: baseline;
    gap: 14px;
    margin-bottom: 16px;
  }

  .landing-section-title {
    color: #c8dff0;
    font: 700 13px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    margin: 0;
  }

  .landing-section-line {
    flex: 1;
    height: 1px;
    background: rgba(74, 163, 255, 0.1);
  }

  .landing-workspace-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 12px;
  }

  .landing-workspace-card {
    position: relative;
    overflow: hidden;
    padding: 22px;
    border-radius: 18px;
    border: 1px solid rgba(158, 217, 255, 0.09);
    background: rgba(255, 255, 255, 0.025);
    cursor: pointer;
    text-align: left;
    color: inherit;
    transition: border-color 200ms ease, background 200ms ease, transform 200ms ease, box-shadow 200ms ease;
  }

  .landing-workspace-card::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(158, 217, 255, 0.16), transparent);
    opacity: 0;
    transition: opacity 200ms ease;
  }

  .landing-workspace-card:hover {
    border-color: rgba(74, 163, 255, 0.24);
    background: rgba(74, 163, 255, 0.06);
    transform: translateY(-3px);
    box-shadow: 0 12px 32px rgba(0,0,0,0.28);
  }

  .landing-workspace-card:hover::before { opacity: 1; }

  .landing-workspace-card--primary {
    grid-column: span 3;
    display: grid;
    grid-template-columns: 1fr auto;
    align-items: center;
    gap: 24px;
    border-color: rgba(76, 195, 138, 0.22);
    background: linear-gradient(135deg, rgba(76, 195, 138, 0.08), rgba(74, 163, 255, 0.05));
  }

  .landing-workspace-card--primary:hover {
    border-color: rgba(76, 195, 138, 0.38);
    background: linear-gradient(135deg, rgba(76, 195, 138, 0.12), rgba(74, 163, 255, 0.08));
    box-shadow: 0 12px 40px rgba(76, 195, 138, 0.12);
  }

  .landing-workspace-card-icon {
    width: 40px;
    height: 40px;
    border-radius: 12px;
    display: grid;
    place-items: center;
    color: #7fd0ff;
    background: rgba(74, 163, 255, 0.1);
    border: 1px solid rgba(74, 163, 255, 0.2);
    margin-bottom: 14px;
  }

  .landing-workspace-card--primary .landing-workspace-card-icon {
    color: #56d3a0;
    background: rgba(76, 195, 138, 0.1);
    border-color: rgba(76, 195, 138, 0.22);
    width: 48px;
    height: 48px;
    border-radius: 14px;
    margin-bottom: 0;
  }

  .landing-workspace-card-eyebrow {
    color: #56d3a0;
    font: 700 10px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    margin-bottom: 6px;
  }

  .landing-workspace-card-title {
    color: #e2effb;
    font: 700 16px/1.2 "Inter", sans-serif;
    letter-spacing: -0.025em;
    margin-bottom: 6px;
  }

  .landing-workspace-card--primary .landing-workspace-card-title {
    font-size: 20px;
  }

  .landing-workspace-card-desc {
    color: #4a6a85;
    font-size: 12px;
    line-height: 1.5;
    max-width: 36ch;
  }

  .landing-workspace-card-arrow {
    width: 38px;
    height: 38px;
    border-radius: 10px;
    display: grid;
    place-items: center;
    color: #56d3a0;
    background: rgba(76, 195, 138, 0.1);
    border: 1px solid rgba(76, 195, 138, 0.2);
    flex: 0 0 auto;
    transition: 180ms ease;
  }

  .landing-workspace-card--primary:hover .landing-workspace-card-arrow {
    background: rgba(76, 195, 138, 0.18);
    transform: translateX(3px);
  }

  /* ── Capability band ───────────────────────────────────── */
  .landing-capability-band {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
    padding: 14px 18px;
    border: 1px solid rgba(74, 163, 255, 0.1);
    border-radius: 16px;
    background: rgba(3, 9, 18, 0.6);
    backdrop-filter: blur(12px);
  }

  .landing-capability-label {
    color: #3a5570;
    font: 700 10px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    margin-right: 4px;
    white-space: nowrap;
  }

  .landing-capability {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    height: 28px;
    padding: 0 10px;
    border-radius: 999px;
    color: #5a7a9a;
    background: rgba(74, 163, 255, 0.05);
    border: 1px solid rgba(74, 163, 255, 0.12);
    font-size: 11px;
    font-weight: 600;
    transition: 160ms ease;
    cursor: default;
  }

  .landing-capability:hover {
    color: #9be8ff;
    border-color: rgba(74, 163, 255, 0.28);
    background: rgba(74, 163, 255, 0.1);
  }

  /* ── Animations ────────────────────────────────────────── */
  @keyframes landing-float {
    0%, 100% { transform: translateY(0) scale(1); }
    50% { transform: translateY(-8px) scale(1.05); }
  }

  @keyframes landing-pulse {
    0%, 100% { box-shadow: var(--status-shadow-a); }
    50% { box-shadow: var(--status-shadow-b); }
  }

  .workspace-loading {
    height: 100%;
    display: grid;
    place-items: center;
    color: var(--text-muted);
    background: linear-gradient(180deg, rgba(7, 17, 31, 0.8), rgba(5, 11, 21, 0.92));
    font-size: 14px;
  }

  @media (max-width: 980px) {
    .workspace-header {
      flex-direction: column;
      align-items: stretch;
      min-height: auto;
      padding: 12px 18px;
    }

    .workspace-header-main {
      justify-content: space-between;
    }

    .workspace-subtitle {
      white-space: normal;
    }

    .workspace-tabs {
      justify-content: flex-start;
    }

    .landing-hero {
      grid-template-columns: 1fr;
      min-height: auto;
    }

    .landing-workspace-grid {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .landing-workspace-card--primary {
      grid-column: span 2;
    }

    .landing-metrics {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .landing-preview {
      aspect-ratio: 16/10;
      min-height: 320px;
    }
  }

  @media (max-width: 680px) {
    .app-rail {
      width: 72px;
      padding: 14px 9px;
    }

    .landing-shell {
      padding: 20px 16px;
      gap: 36px;
    }

    .landing-workspace-grid {
      grid-template-columns: 1fr;
    }

    .landing-workspace-card--primary {
      grid-column: span 1;
      grid-template-columns: 1fr;
    }

    .landing-workspace-card-arrow {
      display: none;
    }

    .landing-metrics {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .landing-preview {
      min-height: 280px;
    }

    .landing-dossier-card {
      left: 10px;
      right: 10px;
      width: auto;
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .landing-node,
    .landing-workspace-card,
    .landing-cta-primary,
    .landing-cta-secondary {
      animation: none;
      transition: none;
    }
  }
`;function rn(d){const c=hu.c(23),{title:O,subtitle:g,tabs:j,compact:H,kicker:V,children:R}=d,T=H===void 0?!1:H,v=V===void 0?"Workspace":V,C=`workspace-header${T?" workspace-header--compact":""}`;let E;c[0]!==v?(E=o.jsx("div",{className:"workspace-kicker",children:v}),c[0]=v,c[1]=E):E=c[1];let B;c[2]!==O?(B=o.jsx("h1",{className:"workspace-title",children:O}),c[2]=O,c[3]=B):B=c[3];let ll;c[4]!==g?(ll=g?o.jsx("div",{className:"workspace-subtitle",children:g}):null,c[4]=g,c[5]=ll):ll=c[5];let J;c[6]!==B||c[7]!==ll?(J=o.jsxs("div",{className:"workspace-title-block",children:[B,ll]}),c[6]=B,c[7]=ll,c[8]=J):J=c[8];let W;c[9]!==E||c[10]!==J?(W=o.jsxs("div",{className:"workspace-header-main",children:[E,J]}),c[9]=E,c[10]=J,c[11]=W):W=c[11];let sl;c[12]!==j?(sl=j?o.jsx("div",{className:"workspace-tabs",children:j}):null,c[12]=j,c[13]=sl):sl=c[13];let rl;c[14]!==C||c[15]!==W||c[16]!==sl?(rl=o.jsxs("header",{className:C,children:[W,sl]}),c[14]=C,c[15]=W,c[16]=sl,c[17]=rl):rl=c[17];let gl;c[18]!==R?(gl=o.jsx("div",{className:"workspace-body",children:R}),c[18]=R,c[19]=gl):gl=c[19];let nl;return c[20]!==rl||c[21]!==gl?(nl=o.jsxs("section",{className:"workspace-shell",children:[rl,gl]}),c[20]=rl,c[21]=gl,c[22]=nl):nl=c[22],nl}function on(){const d=hu.c(1);let c;return d[0]===Symbol.for("react.memo_cache_sentinel")?(c=o.jsx("div",{className:"workspace-loading",children:"Loading workspace…"}),d[0]=c):c=d[0],c}function Zd(d,c){for(const O of c){const g=d[O];if(typeof g=="number"&&Number.isFinite(g))return g}return null}function Ld(d,c){return d===null?c:d.toLocaleString()}function mg(d){const c=hu.c(107),{onOpenNetwork:O,onOpenVocabulary:g,onOpenReasoning:j,onOpenImport:H,onOpenDecisions:V,onOpenManage:R}=d;let T;c[0]===Symbol.for("react.memo_cache_sentinel")?(T={nodes:null,edges:null,status:"checking"},c[0]=T):T=c[0];const[v,C]=K.useState(T);let E,B;c[1]===Symbol.for("react.memo_cache_sentinel")?(E=()=>{const ti=new AbortController;return fetch("/api/graph/stats",{signal:ti.signal}).then(vg).then(Ja=>{if(!Ja){C(bg);return}C({nodes:Zd(Ja,["node_count","nodeCount","nodes"]),edges:Zd(Ja,["edge_count","edgeCount","edges"]),status:"online"})}).catch(Ja=>{Ja instanceof DOMException&&Ja.name==="AbortError"||C(yg)}),()=>ti.abort()},B=[],c[1]=E,c[2]=B):(E=c[1],B=c[2]),K.useEffect(E,B);const ll=v.status==="online";let J;c[3]!==v.nodes?(J=Ld(v.nodes,"Live"),c[3]=v.nodes,c[4]=J):J=c[4];let W;c[5]!==J?(W={label:"Knowledge nodes",value:J,tone:"cyan"},c[5]=J,c[6]=W):W=c[6];let sl;c[7]!==v.edges?(sl=Ld(v.edges,"Ready"),c[7]=v.edges,c[8]=sl):sl=c[8];let rl;c[9]!==sl?(rl={label:"Relationships mapped",value:sl,tone:"mint"},c[9]=sl,c[10]=rl):rl=c[10];let gl;c[11]===Symbol.for("react.memo_cache_sentinel")?(gl={label:"Graph modes",value:"3",tone:"amber"},c[11]=gl):gl=c[11];const nl=ll?"Dataset online":"Ready to explore",Bl=ll?"Active":"Standby";let jl;c[12]!==Bl||c[13]!==nl?(jl={label:nl,value:Bl,tone:"rose"},c[12]=Bl,c[13]=nl,c[14]=jl):jl=c[14];let Ol;c[15]!==jl||c[16]!==W||c[17]!==rl?(Ol=[W,rl,gl,jl],c[15]=jl,c[16]=W,c[17]=rl,c[18]=Ol):Ol=c[18];const kl=Ol;let Sl;c[19]!==g?(Sl={label:"Vocabulary",description:"Schemes and terms",icon:Jd,onClick:g},c[19]=g,c[20]=Sl):Sl=c[20];let Vl;c[21]!==j?(Vl={label:"Analyze",description:"Inference and queries",icon:kd,onClick:j},c[21]=j,c[22]=Vl):Vl=c[22];let Ma;c[23]!==V?(Ma={label:"Decisions",description:"Chains and precedents",icon:Fd,onClick:V},c[23]=V,c[24]=Ma):Ma=c[24];let ta;c[25]!==H?(ta={label:"Enrich",description:"Import and resolve",icon:Wd,onClick:H},c[25]=H,c[26]=ta):ta=c[26];let Nl;c[27]!==R?(Nl={label:"Manage",description:"Lineage and ontology",icon:Vd,onClick:R},c[27]=R,c[28]=Nl):Nl=c[28];let ka;c[29]!==Sl||c[30]!==Vl||c[31]!==Ma||c[32]!==ta||c[33]!==Nl?(ka=[Sl,Vl,Ma,ta,Nl],c[29]=Sl,c[30]=Vl,c[31]=Ma,c[32]=ta,c[33]=Nl,c[34]=ka):ka=c[34];const Va=ka;let Kl;c[35]===Symbol.for("react.memo_cache_sentinel")?(Kl=o.jsx("div",{className:"landing-status-dot"}),c[35]=Kl):Kl=c[35];const S=fg[v.status];let A;c[36]!==S?(A=o.jsx("span",{className:"landing-status-text",children:S}),c[36]=S,c[37]=A):A=c[37];let w,al;c[38]===Symbol.for("react.memo_cache_sentinel")?(w=o.jsx("div",{className:"landing-status-divider"}),al=o.jsx("span",{className:"landing-status-version",children:"Semantica v2 · Semantic Intelligence"}),c[38]=w,c[39]=al):(w=c[38],al=c[39]);let $;c[40]!==v.status||c[41]!==A?($=o.jsxs("div",{className:"landing-status-bar","data-status":v.status,children:[Kl,A,w,al]}),c[40]=v.status,c[41]=A,c[42]=$):$=c[42];let zl;c[43]===Symbol.for("react.memo_cache_sentinel")?(zl=o.jsxs("div",{className:"landing-kicker","aria-label":"Product category",children:[o.jsx("span",{className:"landing-kicker-mark","aria-hidden":"true"}),"Knowledge Explorer"]}),c[43]=zl):zl=c[43];let il;c[44]===Symbol.for("react.memo_cache_sentinel")?(il=o.jsx("br",{}),c[44]=il):il=c[44];let Z,pl;c[45]===Symbol.for("react.memo_cache_sentinel")?(Z=o.jsxs("h1",{className:"landing-title",children:["Navigate knowledge",il,"like a ",o.jsx("span",{children:"living system."})]}),pl=o.jsx("p",{className:"landing-subtitle",children:"Semantica turns dense knowledge graphs into a navigable command center — discovery, reasoning, provenance, distance intelligence, and decision context, all in one interface."}),c[45]=Z,c[46]=pl):(Z=c[45],pl=c[46]);let Zl;c[47]===Symbol.for("react.memo_cache_sentinel")?(Zl=o.jsx(Hf,{size:16}),c[47]=Zl):Zl=c[47];let ea;c[48]===Symbol.for("react.memo_cache_sentinel")?(ea=o.jsx(Xd,{size:15}),c[48]=ea):ea=c[48];let Oa;c[49]!==O?(Oa=o.jsxs("button",{className:"landing-cta-primary",type:"button",onClick:O,children:[Zl,"Open Semantica Explorer",ea]}),c[49]=O,c[50]=Oa):Oa=c[50];let Za;c[51]===Symbol.for("react.memo_cache_sentinel")?(Za=o.jsx(kd,{size:15}),c[51]=Za):Za=c[51];let na;c[52]!==j?(na=o.jsxs("button",{className:"landing-cta-secondary",type:"button",onClick:j,children:[Za,"Run Reasoning"]}),c[52]=j,c[53]=na):na=c[53];let Ba;c[54]!==Oa||c[55]!==na?(Ba=o.jsxs("div",{className:"landing-cta-row",children:[Oa,na]}),c[54]=Oa,c[55]=na,c[56]=Ba):Ba=c[56];let Na;c[57]!==$||c[58]!==Ba?(Na=o.jsxs("div",{className:"landing-copy",children:[$,zl,Z,pl,Ba]}),c[57]=$,c[58]=Ba,c[59]=Na):Na=c[59];let mt;c[60]===Symbol.for("react.memo_cache_sentinel")?(mt=o.jsxs("div",{className:"landing-preview-topbar","aria-hidden":"true",children:[o.jsx("div",{className:"landing-preview-dot"}),o.jsx("div",{className:"landing-preview-dot"}),o.jsx("div",{className:"landing-preview-dot"}),o.jsx("div",{className:"landing-preview-tab",children:"Semantica Explorer"})]}),c[60]=mt):mt=c[60];let Vt;c[61]===Symbol.for("react.memo_cache_sentinel")?(Vt=o.jsxs("div",{className:"landing-command-card",children:[o.jsx("div",{className:"landing-command-icon",children:o.jsx(Vm,{size:15})}),o.jsxs("div",{children:[o.jsx("div",{className:"landing-command-label",children:"Search command, node, or concept"}),o.jsx("div",{className:"landing-command-meta",children:"distance heatmap · focused view · causal path"})]})]}),c[61]=Vt):Vt=c[61];let ga,gt,ht,me,Zt;c[62]===Symbol.for("react.memo_cache_sentinel")?(ga=o.jsx("path",{className:"landing-preview-line",d:"M110 310 C200 110 390 90 510 240"}),gt=o.jsx("path",{className:"landing-preview-line landing-preview-line--warm",d:"M120 190 C240 270 374 182 508 340"}),ht=o.jsx("path",{className:"landing-preview-line landing-preview-line--mint",d:"M168 378 C274 200 392 218 488 144"}),me=o.jsx("path",{className:"landing-preview-line landing-preview-line--warm",d:"M204 118 C318 340 408 368 526 284"}),Zt=o.jsx("path",{className:"landing-preview-line",d:"M110 310 C180 350 260 360 340 320 C420 280 480 260 510 240"}),c[62]=ga,c[63]=gt,c[64]=ht,c[65]=me,c[66]=Zt):(ga=c[62],gt=c[63],ht=c[64],me=c[65],Zt=c[66]);let pt;c[67]===Symbol.for("react.memo_cache_sentinel")?(pt=o.jsxs("g",{className:"landing-node",children:[o.jsx("circle",{cx:"110",cy:"310",r:"10",fill:"#4cc38a",fillOpacity:"0.9"}),o.jsx("circle",{cx:"110",cy:"310",r:"20",fill:"none",stroke:"rgba(76,195,138,0.24)",strokeWidth:"1.5"}),o.jsx("circle",{cx:"110",cy:"310",r:"34",fill:"none",stroke:"rgba(76,195,138,0.1)",strokeWidth:"1"})]}),c[67]=pt):pt=c[67];let yt;c[68]===Symbol.for("react.memo_cache_sentinel")?(yt=o.jsxs("g",{className:"landing-node",children:[o.jsx("circle",{cx:"204",cy:"118",r:"7",fill:"#4aa3ff",fillOpacity:"0.9"}),o.jsx("circle",{cx:"204",cy:"118",r:"16",fill:"none",stroke:"rgba(74,163,255,0.24)",strokeWidth:"1.5"})]}),c[68]=yt):yt=c[68];let bt;c[69]===Symbol.for("react.memo_cache_sentinel")?(bt=o.jsxs("g",{className:"landing-node",children:[o.jsx("circle",{cx:"510",cy:"240",r:"13",fill:"#f2b66d",fillOpacity:"0.9"}),o.jsx("circle",{cx:"510",cy:"240",r:"26",fill:"none",stroke:"rgba(242,182,109,0.26)",strokeWidth:"1.5"}),o.jsx("circle",{cx:"510",cy:"240",r:"40",fill:"none",stroke:"rgba(242,182,109,0.1)",strokeWidth:"1"})]}),c[69]=bt):bt=c[69];let ge;c[70]===Symbol.for("react.memo_cache_sentinel")?(ge=o.jsxs("g",{className:"landing-node",children:[o.jsx("circle",{cx:"488",cy:"144",r:"6",fill:"#ff9daf",fillOpacity:"0.9"}),o.jsx("circle",{cx:"488",cy:"144",r:"14",fill:"none",stroke:"rgba(255,157,175,0.22)",strokeWidth:"1.5"})]}),c[70]=ge):ge=c[70];let he;c[71]===Symbol.for("react.memo_cache_sentinel")?(he=o.jsxs("g",{className:"landing-node",children:[o.jsx("circle",{cx:"340",cy:"320",r:"9",fill:"#7fd0ff",fillOpacity:"0.9"}),o.jsx("circle",{cx:"340",cy:"320",r:"20",fill:"none",stroke:"rgba(127,208,255,0.22)",strokeWidth:"1.5"})]}),c[71]=he):he=c[71];let wl;c[72]===Symbol.for("react.memo_cache_sentinel")?(wl=o.jsx("div",{className:"landing-preview-orbit",children:o.jsxs("svg",{viewBox:"0 0 640 440",role:"img","aria-hidden":"true",children:[ga,gt,ht,me,Zt,pt,yt,bt,ge,he,o.jsx("g",{opacity:"0.45",children:rg.map(pg)})]})}),c[72]=wl):wl=c[72];let pe,Lt;c[73]===Symbol.for("react.memo_cache_sentinel")?(pe=o.jsx("div",{className:"landing-dossier-kicker",children:"Entity Dossier"}),Lt=o.jsx("div",{className:"landing-dossier-title",children:"NSRP1"}),c[73]=pe,c[74]=Lt):(pe=c[73],Lt=c[74]);let Kt;c[75]===Symbol.for("react.memo_cache_sentinel")?(Kt=o.jsxs("div",{className:"landing-dossier-row",children:[o.jsx("span",{children:"Distance band"}),o.jsx("strong",{children:"Near"})]}),c[75]=Kt):Kt=c[75];let La;c[76]===Symbol.for("react.memo_cache_sentinel")?(La=o.jsxs("div",{className:"landing-dossier-row",children:[o.jsx("span",{children:"Path coherence"}),o.jsx("strong",{children:"0.84"})]}),c[76]=La):La=c[76];let ye;c[77]===Symbol.for("react.memo_cache_sentinel")?(ye=o.jsxs("div",{className:"landing-dossier-card",children:[pe,Lt,Kt,La,o.jsxs("div",{className:"landing-dossier-row",children:[o.jsx("span",{children:"Provenance"}),o.jsx("strong",{children:"Audited"})]})]}),c[77]=ye):ye=c[77];let Jt,be;c[78]===Symbol.for("react.memo_cache_sentinel")?(Jt=o.jsxs("div",{className:"landing-timeline-header",children:[o.jsx("span",{className:"landing-timeline-title",children:"Temporal Evidence"}),o.jsx("span",{className:"landing-timeline-badge",children:"66% coverage"})]}),be=o.jsx("div",{className:"landing-timeline-track"}),c[78]=Jt,c[79]=be):(Jt=c[78],be=c[79]);let ve;c[80]===Symbol.for("react.memo_cache_sentinel")?(ve=o.jsxs("div",{className:"landing-preview","aria-label":"Knowledge graph preview",children:[mt,Vt,wl,ye,o.jsxs("div",{className:"landing-timeline-card",children:[Jt,be,o.jsxs("div",{className:"landing-timeline-labels",children:[o.jsx("span",{children:"1970"}),o.jsx("span",{children:"2030"})]})]})]}),c[80]=ve):ve=c[80];let ha;c[81]!==Na?(ha=o.jsxs("section",{className:"landing-hero",children:[Na,ve]}),c[81]=Na,c[82]=ha):ha=c[82];let _l;c[83]!==kl?(_l=o.jsx("div",{className:"landing-metrics","aria-label":"System status",children:kl.map(hg)}),c[83]=kl,c[84]=_l):_l=c[84];let ia;c[85]===Symbol.for("react.memo_cache_sentinel")?(ia=o.jsxs("div",{className:"landing-section-header",children:[o.jsx("h2",{className:"landing-section-title",children:"Workspaces"}),o.jsx("div",{className:"landing-section-line"})]}),c[85]=ia):ia=c[85];let Ul,xe;c[86]===Symbol.for("react.memo_cache_sentinel")?(Ul=o.jsxs("div",{children:[o.jsx("div",{className:"landing-workspace-card-eyebrow",children:"Primary Workspace"}),o.jsx("div",{className:"landing-workspace-card-title",children:"Semantica Explorer"}),o.jsx("div",{className:"landing-workspace-card-desc",children:"Full graph, grouped communities, focused neighborhoods, and distance intelligence — all in one canvas."})]}),xe={display:"flex",alignItems:"center",gap:"12px"},c[86]=Ul,c[87]=xe):(Ul=c[86],xe=c[87]);let Se;c[88]===Symbol.for("react.memo_cache_sentinel")?(Se=o.jsx("div",{className:"landing-workspace-card-icon",style:{marginBottom:0},children:o.jsx(Hf,{size:22})}),c[88]=Se):Se=c[88];let ze;c[89]===Symbol.for("react.memo_cache_sentinel")?(ze=o.jsxs("div",{style:xe,children:[Se,o.jsx("div",{className:"landing-workspace-card-arrow",children:o.jsx(Xd,{size:18})})]}),c[89]=ze):ze=c[89];let Da;c[90]!==O?(Da=o.jsxs("button",{className:"landing-workspace-card landing-workspace-card--primary",type:"button",onClick:O,children:[Ul,ze]}),c[90]=O,c[91]=Da):Da=c[91];let ja;c[92]!==Va?(ja=Va.map(gg),c[92]=Va,c[93]=ja):ja=c[93];let wa;c[94]!==Da||c[95]!==ja?(wa=o.jsxs("section",{"aria-label":"Workspaces",children:[ia,o.jsxs("div",{className:"landing-workspace-grid",children:[Da,ja]})]}),c[94]=Da,c[95]=ja,c[96]=wa):wa=c[96];let pa;c[97]===Symbol.for("react.memo_cache_sentinel")?(pa=o.jsx("div",{className:"landing-capability-label",children:"Intelligence Layer"}),c[97]=pa):pa=c[97];let Ka;c[98]===Symbol.for("react.memo_cache_sentinel")?(Ka=o.jsxs("div",{className:"landing-capability",children:[o.jsx(Ym,{size:12}),"Distance Heatmap"]}),c[98]=Ka):Ka=c[98];let qa;c[99]===Symbol.for("react.memo_cache_sentinel")?(qa=o.jsxs("div",{className:"landing-capability",children:[o.jsx(Hf,{size:12}),"Focused Neighborhood"]}),c[99]=qa):qa=c[99];let _e;c[100]===Symbol.for("react.memo_cache_sentinel")?(_e=o.jsxs("div",{className:"landing-capability",children:[o.jsx($d,{size:12}),"Grouped Communities"]}),c[100]=_e):_e=c[100];let Wt;c[101]===Symbol.for("react.memo_cache_sentinel")?(Wt=o.jsxs("div",{className:"landing-capability",children:[o.jsx(Qm,{size:12}),"Trace Causal Path"]}),c[101]=Wt):Wt=c[101];let vt;c[102]===Symbol.for("react.memo_cache_sentinel")?(vt=o.jsxs("section",{className:"landing-capability-band","aria-label":"Intelligence capabilities",children:[pa,Ka,qa,_e,Wt,o.jsxs("div",{className:"landing-capability",children:[o.jsx(Vd,{size:12}),"Provenance Dossier"]})]}),c[102]=vt):vt=c[102];let Ra;return c[103]!==ha||c[104]!==_l||c[105]!==wa?(Ra=o.jsx("main",{className:"landing-page",children:o.jsxs("div",{className:"landing-shell",children:[ha,_l,wa,vt]})}),c[103]=ha,c[104]=_l,c[105]=wa,c[106]=Ra):Ra=c[106],Ra}function gg(d){const c=d.icon;return o.jsxs("button",{className:"landing-workspace-card",type:"button",onClick:d.onClick,children:[o.jsx("div",{className:"landing-workspace-card-icon",children:o.jsx(c,{size:18})}),o.jsx("div",{className:"landing-workspace-card-title",children:d.label}),o.jsx("div",{className:"landing-workspace-card-desc",children:d.description})]},d.label)}function hg(d){return o.jsxs("div",{className:"landing-metric","data-tone":d.tone,children:[o.jsx("div",{className:"landing-metric-value",children:d.value}),o.jsx("div",{className:"landing-metric-label",children:d.label})]},d.label)}function pg(d,c){return o.jsx("circle",{cx:d.cx,cy:d.cy*.82,r:d.r*.8,fill:d.fill},c)}function yg(d){return{...d,status:"offline"}}function bg(d){return{...d,status:"offline"}}function vg(d){return d.ok?d.json():null}function xg(){const d=hu.c(19),[c,O]=K.useState("welcome"),[g,j]=K.useState("graph"),[H,V]=K.useState("reasoning"),[R,T]=K.useState("import"),[v,C]=K.useState("lineage"),[E,B]=K.useState(null);let ll;d[0]!==c||d[1]!==H||d[2]!==R||d[3]!==g||d[4]!==E?.nodeId||d[5]!==E?.token||d[6]!==v?(ll=()=>c==="welcome"?o.jsx(mg,{onOpenNetwork:()=>{O("explore"),j("graph")},onOpenVocabulary:()=>{O("explore"),j("vocabulary")},onOpenReasoning:()=>{O("analyze"),V("reasoning")},onOpenImport:()=>{O("enrich"),T("import")},onOpenDecisions:()=>O("decisions"),onOpenManage:()=>O("manage")}):c==="explore"?o.jsx(rn,{title:"Explore",subtitle:g==="graph"?void 0:"Browse the graph and switch views without leaving the workspace.",kicker:g==="graph"?"Graph Studio":"Vocabulary Browser",compact:!0,tabs:o.jsxs(o.Fragment,{children:[o.jsx("button",{className:"workspace-tab","data-active":g==="graph",onClick:()=>j("graph"),children:"Semantica Explorer"}),o.jsx("button",{className:"workspace-tab","data-active":g==="vocabulary",onClick:()=>j("vocabulary"),children:"Vocabulary Browser"})]}),children:o.jsx(sn,{children:o.jsx(K.Suspense,{fallback:o.jsx(on,{}),children:g==="graph"?o.jsx(Fm,{externalFocusNodeId:E?.nodeId,externalFocusToken:E?.token}):o.jsx(tg,{})})},`explore-${g}`)}):c==="analyze"?o.jsx(rn,{title:"Analyze",subtitle:"Query the active graph and test inference rules.",kicker:H==="reasoning"?"Reasoning Engine":"SPARQL Query",tabs:o.jsxs(o.Fragment,{children:[o.jsx("button",{className:"workspace-tab","data-active":H==="reasoning",onClick:()=>V("reasoning"),children:"Reasoning Playground"}),o.jsx("button",{className:"workspace-tab","data-active":H==="sparql",onClick:()=>V("sparql"),children:"SPARQL Querying"})]}),children:o.jsx(sn,{children:o.jsx(K.Suspense,{fallback:o.jsx(on,{}),children:H==="reasoning"?o.jsx(lg,{}):o.jsx(ag,{})})},`analyze-${H}`)}):c==="decisions"?o.jsx(rn,{title:"Decisions",subtitle:"Inspect decision chains, causal context, and precedent matches.",kicker:"Decision Intelligence",children:o.jsx(sn,{children:o.jsx(K.Suspense,{fallback:o.jsx(on,{}),children:o.jsx(Wm,{})})},"decisions")}):c==="enrich"?o.jsx(rn,{title:"Enrich",subtitle:"Import, export, reconcile, and audit graph entities.",kicker:"Knowledge Audit",tabs:o.jsxs(o.Fragment,{children:[o.jsx("button",{className:"workspace-tab","data-active":R==="import",onClick:()=>T("import"),children:"Import and Export"}),o.jsx("button",{className:"workspace-tab","data-active":R==="merge",onClick:()=>T("merge"),children:"Diff and Merge"}),o.jsx("button",{className:"workspace-tab","data-active":R==="resolve",onClick:()=>T("resolve"),children:"Entity Resolution"}),o.jsx("button",{className:"workspace-tab","data-active":R==="registry",onClick:()=>T("registry"),children:"Registry"})]}),children:o.jsx(sn,{children:o.jsx(K.Suspense,{fallback:o.jsx(on,{}),children:R==="import"?o.jsx(Im,{}):R==="merge"?o.jsx($m,{}):R==="resolve"?o.jsx(ng,{}):o.jsx(eg,{})})},`enrich-${R}`)}):c==="ontology-hub"?o.jsx(rn,{title:"Ontology Hub",subtitle:"Load, browse, edit, and govern ontologies and vocabularies.",kicker:"Schema Governance",compact:!0,children:o.jsx(sn,{children:o.jsx(K.Suspense,{fallback:o.jsx(on,{}),children:o.jsx(cg,{onJumpToGraphNode:jl=>{B({nodeId:jl,token:Date.now()}),O("explore"),j("graph")}})})},"ontology-hub")}):o.jsx(rn,{title:"Manage",subtitle:"Review provenance, lineage, ontology, and governance context.",kicker:"Graph Governance",tabs:o.jsxs(o.Fragment,{children:[o.jsx("button",{className:"workspace-tab","data-active":v==="lineage",onClick:()=>C("lineage"),children:"PROV-O Lineage"}),o.jsx("button",{className:"workspace-tab","data-active":v==="kg-overview",onClick:()=>C("kg-overview"),children:"KG Overview"}),o.jsx("button",{className:"workspace-tab","data-active":v==="ontology",onClick:()=>C("ontology"),children:"Ontology Summary"})]}),children:o.jsx(sn,{children:o.jsx(K.Suspense,{fallback:o.jsx(on,{}),children:v==="lineage"?o.jsx(Pm,{}):v==="kg-overview"?o.jsx(ig,{}):o.jsx(ug,{onOpenVocabularyBrowser:()=>{O("explore"),j("vocabulary")}})})},`manage-${v}`)}),d[0]=c,d[1]=H,d[2]=R,d[3]=g,d[4]=E?.nodeId,d[5]=E?.token,d[6]=v,d[7]=ll):ll=d[7];const J=ll;let W;d[8]===Symbol.for("react.memo_cache_sentinel")?(W=o.jsx("style",{children:dg}),d[8]=W):W=d[8];let sl;d[9]===Symbol.for("react.memo_cache_sentinel")?(sl=o.jsx("button",{className:"brand-pill",title:"Semantica Knowledge Explorer",onClick:()=>O("welcome"),style:{cursor:"pointer",border:"1px solid rgba(127,208,255,0.18)"},children:"SKE"}),d[9]=sl):sl=d[9];let rl;d[10]!==c?(rl=og.map(jl=>{const{id:Ol,label:kl,hint:Sl,icon:Vl}=jl;return o.jsxs("button",{className:"nav-button","data-active":c===Ol,onClick:()=>O(Ol),title:Sl,children:[o.jsx(Vl,{size:20}),o.jsx("span",{className:"nav-label",children:kl})]},Ol)}),d[10]=c,d[11]=rl):rl=d[11];let gl;d[12]!==rl?(gl=o.jsxs("aside",{className:"app-rail",children:[sl,rl]}),d[12]=rl,d[13]=gl):gl=d[13];let nl;d[14]!==J?(nl=J(),d[14]=J,d[15]=nl):nl=d[15];let Bl;return d[16]!==gl||d[17]!==nl?(Bl=o.jsxs(rm,{client:sg,children:[W,o.jsxs("div",{className:"app-shell",children:[gl,nl]})]}),d[16]=gl,d[17]=nl,d[18]=Bl):Bl=d[18],Bl}ym.createRoot(document.getElementById("root")).render(o.jsx(xg,{}));export{Xd as A,kd as B,jm as C,$d as G,Hf as N,Fd as S,ma as _,Vm as a,aa as b,hu as c,gm as r};
