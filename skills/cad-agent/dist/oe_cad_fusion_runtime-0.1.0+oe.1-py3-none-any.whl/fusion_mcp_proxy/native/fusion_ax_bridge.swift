import AppKit
import ApplicationServices
import Foundation

struct Options {
    var command = ""
    var bundleID = "com.autodesk.fusion360"
    var windowTitles: [String] = []
    var role: String?
    var labels: [String] = []
    var index = 1
    var maxElements = 500
}

enum HelperError: Error, CustomStringConvertible {
    case message(String)

    var description: String {
        switch self {
        case .message(let value): return value
        }
    }
}

func parseOptions() throws -> Options {
    var options = Options()
    let arguments = Array(CommandLine.arguments.dropFirst())
    guard let command = arguments.first else {
        throw HelperError.message("missing command: expected snapshot or press")
    }
    options.command = command
    var cursor = 1
    while cursor < arguments.count {
        let flag = arguments[cursor]
        guard cursor + 1 < arguments.count else {
            throw HelperError.message("missing value for \(flag)")
        }
        let value = arguments[cursor + 1]
        switch flag {
        case "--bundle-id": options.bundleID = value
        case "--window-title": options.windowTitles.append(value)
        case "--role": options.role = value
        case "--label": options.labels.append(value)
        case "--index":
            guard let parsed = Int(value), parsed >= 1 else {
                throw HelperError.message("--index must be a positive integer")
            }
            options.index = parsed
        case "--max-elements":
            guard let parsed = Int(value), (1...500).contains(parsed) else {
                throw HelperError.message("--max-elements must be between 1 and 500")
            }
            options.maxElements = parsed
        default: throw HelperError.message("unsupported option: \(flag)")
        }
        cursor += 2
    }
    return options
}

func attribute(_ element: AXUIElement, _ name: CFString) -> CFTypeRef? {
    var value: CFTypeRef?
    guard AXUIElementCopyAttributeValue(element, name, &value) == .success else {
        return nil
    }
    return value
}

func stringAttribute(_ element: AXUIElement, _ name: CFString) -> String? {
    attribute(element, name) as? String
}

func children(_ element: AXUIElement) -> [AXUIElement] {
    attribute(element, kAXChildrenAttribute as CFString) as? [AXUIElement] ?? []
}

func pointAttribute(_ element: AXUIElement, _ name: CFString) -> [String: Double]? {
    guard let raw = attribute(element, name), CFGetTypeID(raw) == AXValueGetTypeID() else {
        return nil
    }
    let value = unsafeBitCast(raw, to: AXValue.self)
    var point = CGPoint.zero
    guard AXValueGetValue(value, .cgPoint, &point) else { return nil }
    return ["x": point.x, "y": point.y]
}

func sizeAttribute(_ element: AXUIElement, _ name: CFString) -> [String: Double]? {
    guard let raw = attribute(element, name), CFGetTypeID(raw) == AXValueGetTypeID() else {
        return nil
    }
    let value = unsafeBitCast(raw, to: AXValue.self)
    var size = CGSize.zero
    guard AXValueGetValue(value, .cgSize, &size) else { return nil }
    return ["width": size.width, "height": size.height]
}

func jsonValue(_ raw: CFTypeRef?) -> Any? {
    guard let raw else { return nil }
    if let value = raw as? String { return value }
    if let value = raw as? NSNumber { return value }
    return String(describing: raw)
}

func elementRecord(_ element: AXUIElement, path: String) -> [String: Any] {
    var record: [String: Any] = ["path": path]
    let fields: [(String, CFString)] = [
        ("role", kAXRoleAttribute as CFString),
        ("title", kAXTitleAttribute as CFString),
        ("description", kAXDescriptionAttribute as CFString),
        ("identifier", kAXIdentifierAttribute as CFString),
        ("help", kAXHelpAttribute as CFString),
        ("value", kAXValueAttribute as CFString),
        ("enabled", kAXEnabledAttribute as CFString),
        ("focused", kAXFocusedAttribute as CFString),
    ]
    for (key, axName) in fields {
        if let value = jsonValue(attribute(element, axName)) {
            record[key] = value
        }
    }
    if let position = pointAttribute(element, kAXPositionAttribute as CFString) {
        record["position"] = position
    }
    if let size = sizeAttribute(element, kAXSizeAttribute as CFString) {
        record["size"] = size
    }
    var actionNames: CFArray?
    if AXUIElementCopyActionNames(element, &actionNames) == .success,
       let actions = actionNames as? [String] {
        record["actions"] = actions
    }
    return record
}

func flatten(_ root: AXUIElement, limit: Int) -> [(AXUIElement, [String: Any])] {
    var output: [(AXUIElement, [String: Any])] = []
    var stack: [(AXUIElement, String)] = [(root, "0")]
    while !stack.isEmpty && output.count < limit {
        let (element, path) = stack.removeLast()
        output.append((element, elementRecord(element, path: path)))
        let childElements = children(element)
        for (offset, child) in childElements.enumerated().reversed() {
            stack.append((child, "\(path)/\(offset)"))
        }
    }
    return output
}

func runningApplication(bundleID: String) throws -> NSRunningApplication {
    guard let app = NSRunningApplication.runningApplications(withBundleIdentifier: bundleID).first else {
        throw HelperError.message("application not running for bundle id: \(bundleID)")
    }
    return app
}

func appWindows(_ appElement: AXUIElement) -> [AXUIElement] {
    attribute(appElement, kAXWindowsAttribute as CFString) as? [AXUIElement] ?? []
}

func matchesWindow(_ window: AXUIElement, titles: [String]) -> Bool {
    if titles.isEmpty { return true }
    let title = stringAttribute(window, kAXTitleAttribute as CFString) ?? ""
    return titles.contains(title)
}

func labelText(_ record: [String: Any]) -> String {
    for key in ["title", "description", "value"] {
        if let value = record[key] as? String, !value.isEmpty { return value }
    }
    return ""
}

func emit(_ object: [String: Any]) {
    do {
        let data = try JSONSerialization.data(withJSONObject: object, options: [.sortedKeys])
        print(String(decoding: data, as: UTF8.self))
    } catch {
        print("{\"success\":false,\"error\":\"JSON serialization failed\"}")
    }
}

do {
    let options = try parseOptions()
    guard AXIsProcessTrusted() else {
        throw HelperError.message("Accessibility permission is not granted")
    }
    let running = try runningApplication(bundleID: options.bundleID)
    let appElement = AXUIElementCreateApplication(running.processIdentifier)
    let windows = appWindows(appElement).filter { matchesWindow($0, titles: options.windowTitles) }

    if options.command == "snapshot" {
        var windowRecords: [[String: Any]] = []
        for (windowIndex, window) in windows.enumerated() {
            let flattened = flatten(window, limit: options.maxElements)
            windowRecords.append([
                "index": windowIndex,
                "title": stringAttribute(window, kAXTitleAttribute as CFString) ?? "",
                "role": stringAttribute(window, kAXRoleAttribute as CFString) ?? "",
                "subrole": stringAttribute(window, kAXSubroleAttribute as CFString) ?? "",
                "elements": flattened.map { $0.1 },
                "truncated": flattened.count >= options.maxElements,
            ])
        }
        emit([
            "success": true,
            "command": "snapshot",
            "bundle_id": options.bundleID,
            "pid": running.processIdentifier,
            "accessibility_trusted": true,
            "windows": windowRecords,
        ])
    } else if options.command == "press" {
        guard let requestedRole = options.role else {
            throw HelperError.message("press requires --role")
        }
        var candidates: [(AXUIElement, [String: Any])] = []
        for window in windows {
            candidates.append(contentsOf: flatten(window, limit: options.maxElements).filter {
                ($0.1["role"] as? String) == requestedRole
            })
        }
        if !options.labels.isEmpty {
            candidates = candidates.filter { options.labels.contains(labelText($0.1)) }
        }
        guard options.index <= candidates.count else {
            throw HelperError.message("matching element index \(options.index) not found")
        }
        let target = candidates[options.index - 1]
        let result = AXUIElementPerformAction(target.0, kAXPressAction as CFString)
        guard result == .success else {
            throw HelperError.message("AXPress failed with code \(result.rawValue)")
        }
        emit([
            "success": true,
            "command": "press",
            "bundle_id": options.bundleID,
            "pid": running.processIdentifier,
            "matched_count": candidates.count,
            "pressed": target.1,
        ])
    } else {
        throw HelperError.message("unsupported command: \(options.command)")
    }
} catch {
    emit(["success": false, "error": String(describing: error)])
    exit(2)
}

