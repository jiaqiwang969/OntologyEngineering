"""Aggregate Autodesk's built-in Fusion MCP with bounded macOS UI tools."""

from __future__ import annotations

import argparse
import base64
import json
import os
from pathlib import Path
import tempfile
from typing import Any, Protocol

import anyio
from mcp.server.lowlevel import Server
from mcp.server.lowlevel.helper_types import ReadResourceContents
from mcp.server.stdio import stdio_server
from mcp.types import (
    BlobResourceContents,
    CallToolResult,
    ReadResourceResult,
    Resource,
    TextContent,
    TextResourceContents,
    Tool,
    ToolAnnotations,
)
from pydantic import AnyUrl

from .experience_snapshot import (
    ExperienceSnapshotError,
    build_experience_snapshot_script,
)
from .ui_bridge import (
    CONFIRM_CHOOSER_SELECT,
    CONFIRM_CREATE_DISPOSABLE,
    CONFIRM_OPEN_CHOOSER,
    BridgeError,
    FusionUIBridge,
)
from .mcmaster import (
    ACQUIRE_EMBEDDED_EXACT_STEP_ACTION,
    CONFIRM_ACQUIRE_EMBEDDED_EXACT_STEP,
    CONFIRM_API_DOWNLOAD,
    CONFIRM_IMPORT_LOCAL_STEP,
    CONFIRM_OPEN_CATALOG,
    MCMASTER_EXECUTE_TOOL,
    MCMASTER_READ_TOOL,
    McMasterError,
    McMasterModule,
    build_document_snapshot_script,
    build_import_step_script,
    build_open_catalog_script,
    build_target_snapshot_script,
    mcmaster_tools,
    parse_fusion_script_result,
)
from .upstream import AutodeskFusionUpstream


PROXY_VERSION = "0.3.2"
UI_READ_TOOL = "fusion_mcp_ui_read"
UI_EXECUTE_TOOL = "fusion_mcp_ui_execute"
EXPERIENCE_READ_TOOL = "fusion_mcp_experience_read"
INACTIVE_CANDIDATE_TOOLS = frozenset({EXPERIENCE_READ_TOOL})
MAX_EXPERIENCE_SNAPSHOT_BYTES = 16 * 1024 * 1024


class Upstream(Protocol):
    async def list_tools(self) -> list[Tool]: ...
    async def call_tool(
        self, name: str, arguments: dict[str, object]
    ) -> CallToolResult: ...
    async def info(self) -> dict[str, object]: ...
    async def list_resources(self) -> list[Resource]: ...
    async def read_resource(self, uri: AnyUrl) -> ReadResourceResult: ...


READ_ANNOTATIONS = ToolAnnotations(
    readOnlyHint=True,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=False,
)
EXECUTE_ANNOTATIONS = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=True,
    idempotentHint=False,
    openWorldHint=False,
)


def local_tools() -> list[Tool]:
    return [
        Tool(
            name=UI_READ_TOOL,
            title="Read Fusion native UI state",
            description=(
                "Read bounded macOS Accessibility state for Fusion. Uses Peekaboo for app/window "
                "preflight and a native AXUIElement helper for modal dialogs. It does not open, "
                "click, save, close, upload, or modify a Fusion document."
            ),
            annotations=READ_ANNOTATIONS,
            inputSchema={
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": [
                            "preflight",
                            "status",
                            "chooser_snapshot",
                            "dialog_inspect",
                            "upstream_info",
                        ],
                    },
                    "max_elements": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": 500,
                        "default": 120,
                    },
                },
                "required": ["action"],
            },
        ),
        Tool(
            name=UI_EXECUTE_TOOL,
            title="Execute a bounded Fusion native UI action",
            description=(
                "Execute only an explicitly modeled Fusion UI action through Peekaboo plus native "
                "AXUIElement readback. Mode selection cancels the chooser after verification. "
                "Disposable document creation requires its exact confirmation token and still "
                "requires external pre/post document checks and cleanup."
            ),
            annotations=EXECUTE_ANNOTATIONS,
            inputSchema={
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": [
                            "escape",
                            "open_chooser",
                            "chooser_select",
                            "chooser_create",
                        ],
                    },
                    "mode": {"type": "string", "enum": ["part", "assembly", "hybrid"]},
                    "confirmation": {"type": "string", "minLength": 1},
                },
                "required": ["action"],
                "allOf": [
                    {
                        "if": {"properties": {"action": {"const": "open_chooser"}}},
                        "then": {"required": ["confirmation"]},
                    },
                    {
                        "if": {
                            "properties": {
                                "action": {"enum": ["chooser_select", "chooser_create"]}
                            }
                        },
                        "then": {"required": ["mode", "confirmation"]},
                    },
                ],
            },
        ),
        *mcmaster_tools(),
    ]


class FusionMCPProxyService:
    def __init__(
        self,
        upstream: Upstream,
        ui_bridge: FusionUIBridge | None = None,
        mcmaster: McMasterModule | None = None,
    ) -> None:
        self.upstream = upstream
        self.ui_bridge = ui_bridge or FusionUIBridge()
        self.mcmaster = mcmaster or McMasterModule()

    async def list_tools(self) -> list[Tool]:
        upstream_tools = await self.upstream.list_tools()
        reserved = {
            *(tool.name for tool in local_tools()),
            *INACTIVE_CANDIDATE_TOOLS,
        }
        collisions = reserved.intersection(tool.name for tool in upstream_tools)
        if collisions:
            raise RuntimeError(
                "upstream tool name collision: " + ", ".join(sorted(collisions))
            )
        return [*upstream_tools, *local_tools()]

    async def _run_sync(self, function: Any, *args: Any, **kwargs: Any) -> Any:
        return await anyio.to_thread.run_sync(lambda: function(*args, **kwargs))

    async def call_ui_read(self, arguments: dict[str, object]) -> dict[str, Any]:
        action = str(arguments.get("action", ""))
        if action == "upstream_info":
            return {
                "action": action,
                "upstream": await self.upstream.info(),
                "proxy_version": PROXY_VERSION,
            }
        if action == "preflight":
            return await self._run_sync(self.ui_bridge.preflight)
        if action == "status":
            return await self._run_sync(self.ui_bridge.status)
        if action == "chooser_snapshot":
            return await self._run_sync(self.ui_bridge.chooser_snapshot)
        if action == "dialog_inspect":
            maximum = int(arguments.get("max_elements", 120))
            return await self._run_sync(self.ui_bridge.dialog_inspect, maximum)
        raise BridgeError(f"unsupported UI read action: {action}")

    @staticmethod
    def _require_confirmation(actual: object, expected: str, action: str) -> None:
        if actual != expected:
            raise BridgeError(f"{action} confirmation token is missing or invalid")

    @staticmethod
    def _require_string(arguments: dict[str, object], name: str) -> str:
        value = arguments.get(name)
        if not isinstance(value, str) or not value:
            raise BridgeError(f"{name} is required")
        return value

    @staticmethod
    def _require_integer(arguments: dict[str, object], name: str) -> int:
        value = arguments.get(name)
        if isinstance(value, bool) or not isinstance(value, int):
            raise BridgeError(f"{name} must be an integer")
        return value

    @staticmethod
    def _optional_number(
        arguments: dict[str, object], name: str, default: float
    ) -> float:
        value = arguments.get(name, default)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise BridgeError(f"{name} must be numeric")
        return float(value)

    async def _call_fusion_script(self, script: str) -> dict[str, Any]:
        result = await self.upstream.call_tool(
            "fusion_mcp_execute",
            {"featureType": "script", "object": {"script": script}},
        )
        try:
            return parse_fusion_script_result(result)
        except McMasterError as exc:
            raise BridgeError(str(exc)) from exc

    @staticmethod
    def _optional_string(arguments: dict[str, object], name: str) -> str | None:
        if name not in arguments:
            return None
        value = arguments[name]
        if not isinstance(value, str):
            raise BridgeError(f"{name} must be a string")
        return value

    @staticmethod
    def _validate_experience_snapshot(
        snapshot: object,
        *,
        expected_document_name: str,
        expected_lineage_id: str | None,
        expected_version_id: str | None,
        occurrence_paths: list[str],
        max_occurrences: int,
        max_joints: int,
    ) -> dict[str, Any]:
        if not isinstance(snapshot, dict):
            raise BridgeError("Fusion experience snapshot is not an object")
        if snapshot.get("schema") != "fusion-mcp.experience-snapshot.v1":
            raise BridgeError("Fusion experience snapshot schema is invalid")

        document = snapshot.get("document")
        if not isinstance(document, dict):
            raise BridgeError("Fusion experience snapshot document is invalid")
        if document.get("name") != expected_document_name:
            raise BridgeError("Fusion experience snapshot document name mismatches")
        if (
            expected_lineage_id is not None
            and document.get("lineage_id") != expected_lineage_id
        ):
            raise BridgeError("Fusion experience snapshot lineage mismatches")
        if (
            expected_version_id is not None
            and document.get("version_id") != expected_version_id
        ):
            raise BridgeError("Fusion experience snapshot version mismatches")

        occurrences = snapshot.get("occurrences")
        joints = snapshot.get("joints")
        cardinality = snapshot.get("cardinality")
        if not isinstance(occurrences, list) or len(occurrences) > max_occurrences:
            raise BridgeError("Fusion experience snapshot occurrences are invalid")
        if not isinstance(joints, list) or len(joints) > max_joints:
            raise BridgeError("Fusion experience snapshot joints are invalid")
        if not isinstance(cardinality, dict):
            raise BridgeError("Fusion experience snapshot cardinality is invalid")
        captured_count = cardinality.get("captured_occurrence_count")
        standard_count = cardinality.get("standard_joint_count")
        as_built_count = cardinality.get("as_built_joint_count")
        if (
            isinstance(captured_count, bool)
            or not isinstance(captured_count, int)
            or captured_count != len(occurrences)
        ):
            raise BridgeError(
                "Fusion experience snapshot occurrence cardinality mismatches"
            )
        if (
            isinstance(standard_count, bool)
            or not isinstance(standard_count, int)
            or standard_count < 0
            or isinstance(as_built_count, bool)
            or not isinstance(as_built_count, int)
            or as_built_count < 0
            or standard_count + as_built_count != len(joints)
        ):
            raise BridgeError("Fusion experience snapshot joint cardinality mismatches")

        expected_scope = (
            "requested_occurrences" if occurrence_paths else "all_occurrences"
        )
        if snapshot.get("snapshot_scope") != expected_scope:
            raise BridgeError("Fusion experience snapshot scope mismatches")
        if snapshot.get("requested_occurrence_paths") != occurrence_paths:
            raise BridgeError(
                "Fusion experience snapshot occurrence-path filter mismatches"
            )
        return snapshot

    async def _call_experience_read_candidate(
        self, arguments: dict[str, object]
    ) -> dict[str, Any]:
        allowed_arguments = {
            "action",
            "expected_document_name",
            "expected_lineage_id",
            "expected_version_id",
            "occurrence_paths",
            "max_occurrences",
            "max_joints",
        }
        unexpected = sorted(set(arguments).difference(allowed_arguments))
        if unexpected:
            raise BridgeError(
                "unsupported experience read argument(s): " + ", ".join(unexpected)
            )
        action = str(arguments.get("action", ""))
        if action != "document_snapshot":
            raise BridgeError(f"unsupported experience read action: {action}")
        raw_paths = arguments.get("occurrence_paths", [])
        if not isinstance(raw_paths, list):
            raise BridgeError("occurrence_paths must be an array")
        paths = list(raw_paths)
        expected_document_name = self._require_string(
            arguments, "expected_document_name"
        )
        expected_lineage_id = self._optional_string(arguments, "expected_lineage_id")
        expected_version_id = self._optional_string(arguments, "expected_version_id")
        max_occurrences = arguments.get("max_occurrences", 100)
        max_joints = arguments.get("max_joints", 100)
        with tempfile.TemporaryDirectory(
            prefix="fusion-mcp-experience-"
        ) as temporary_directory:
            output_path = Path(temporary_directory) / "snapshot.json"
            try:
                script = build_experience_snapshot_script(
                    expected_document_name=expected_document_name,
                    expected_lineage_id=expected_lineage_id,
                    expected_version_id=expected_version_id,
                    occurrence_paths=paths,
                    max_occurrences=max_occurrences,  # type: ignore[arg-type]
                    max_joints=max_joints,  # type: ignore[arg-type]
                    output_path=str(output_path),
                )
            except ExperienceSnapshotError as exc:
                raise BridgeError(str(exc)) from exc
            upstream_result = await self.upstream.call_tool(
                "fusion_mcp_execute",
                {"featureType": "script", "object": {"script": script}},
            )
            if upstream_result.isError:
                raise BridgeError(
                    "Autodesk Fusion MCP reported an experience snapshot error"
                )
            if not output_path.is_file():
                raise BridgeError(
                    "Fusion script completed without the proxy-controlled snapshot file"
                )
            try:
                with output_path.open("rb") as stream:
                    payload = stream.read(MAX_EXPERIENCE_SNAPSHOT_BYTES + 1)
                if len(payload) > MAX_EXPERIENCE_SNAPSHOT_BYTES:
                    raise BridgeError("Fusion experience snapshot exceeds 16 MiB")
                snapshot = json.loads(payload.decode("utf-8"))
            except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise BridgeError(
                    "Fusion experience snapshot file is unreadable or invalid"
                ) from exc
            snapshot = self._validate_experience_snapshot(
                snapshot,
                expected_document_name=expected_document_name,
                expected_lineage_id=expected_lineage_id,
                expected_version_id=expected_version_id,
                occurrence_paths=paths,
                max_occurrences=max_occurrences,  # type: ignore[arg-type]
                max_joints=max_joints,  # type: ignore[arg-type]
            )
        return {
            "action": action,
            "proxy_version": PROXY_VERSION,
            "transport": "proxy_controlled_temporary_file",
            "snapshot": snapshot,
        }

    async def call_mcmaster_read(self, arguments: dict[str, object]) -> dict[str, Any]:
        action = str(arguments.get("action", ""))
        try:
            if action == "normalize_part_number":
                return {
                    "action": action,
                    **self.mcmaster.normalize(
                        self._require_string(arguments, "part_number")
                    ),
                }
            if action == "inspect_local_step":
                return {
                    "action": action,
                    **self.mcmaster.inspect_step(
                        self._require_string(arguments, "path")
                    ),
                }
            if action == "api_status":
                return {"action": action, **self.mcmaster.api_status()}
            if action == "api_product":
                product = await self._run_sync(
                    self.mcmaster.api_product,
                    self._require_string(arguments, "part_number"),
                )
                return {"action": action, **product}
            if action == "fusion_target_snapshot":
                script = build_target_snapshot_script(
                    self._require_string(arguments, "expected_document_name"),
                    self._require_string(arguments, "target_component_name"),
                    str(arguments["part_number"])
                    if isinstance(arguments.get("part_number"), str)
                    else None,
                )
                return {"action": action, **await self._call_fusion_script(script)}
        except McMasterError as exc:
            raise BridgeError(str(exc)) from exc
        raise BridgeError(f"unsupported McMaster read action: {action}")

    async def call_mcmaster_execute(
        self, arguments: dict[str, object]
    ) -> dict[str, Any]:
        action = str(arguments.get("action", ""))
        confirmation = arguments.get("confirmation")
        try:
            if action == "open_catalog":
                self._require_confirmation(confirmation, CONFIRM_OPEN_CATALOG, action)
                expected_document = self._require_string(
                    arguments, "expected_document_name"
                )
                part_number = (
                    str(arguments["part_number"])
                    if isinstance(arguments.get("part_number"), str)
                    else None
                )
                before = await self._call_fusion_script(
                    build_document_snapshot_script(expected_document)
                )
                opened = await self._call_fusion_script(
                    build_open_catalog_script(expected_document, part_number)
                )
                return {
                    "action": action,
                    "before": before,
                    "opened": opened,
                    # Backward-compatible field for callers of this
                    # open-catalog-only operation. It describes neither the
                    # embedded CDP adapter nor every programmatic UI surface.
                    "search_requires_user_interaction": True,
                    "interaction_capabilities": {
                        "open_catalog_adapter": "fusion-native-command",
                        "ax_value_assignment_supported": False,
                        "embedded_cdp_recipe_available": True,
                        "embedded_cdp_search_requires_mouse": False,
                        "embedded_cdp_recipe_id": (
                            "McMasterEmbeddedCDPExactStepAcquisition"
                        ),
                        "end_to_end_current_release_validation": "required",
                    },
                    "next_tool": MCMASTER_EXECUTE_TOOL,
                    "next_action": ACQUIRE_EMBEDDED_EXACT_STEP_ACTION,
                    "reason": (
                        "This operation only opens the catalog. Background AX value "
                        "assignment is not represented as a completed search; a separately "
                        "validated embedded-CDP recipe can dispatch semantic DOM events "
                        "without mouse input."
                    ),
                }
            if action == ACQUIRE_EMBEDDED_EXACT_STEP_ACTION:
                self._require_confirmation(
                    confirmation, CONFIRM_ACQUIRE_EMBEDDED_EXACT_STEP, action
                )
                expected_document = self._require_string(
                    arguments, "expected_document_name"
                )
                devtools_port = self._require_integer(arguments, "devtools_port")
                timeout_seconds = self._optional_number(
                    arguments, "timeout_seconds", 30.0
                )
                before = await self._call_fusion_script(
                    build_document_snapshot_script(expected_document)
                )
                acquired = await self._run_sync(
                    self.mcmaster.acquire_embedded_exact_step,
                    part_number=self._require_string(arguments, "part_number"),
                    format=self._require_string(arguments, "format"),
                    target_path=self._require_string(arguments, "target_path"),
                    devtools_port=devtools_port,
                    timeout_seconds=timeout_seconds,
                )
                return {
                    "action": action,
                    "source_channel": "mcmaster_fusion_download",
                    **acquired,
                    "context": {
                        "expected_document_name": expected_document,
                        "before": before,
                        "interaction_surface": "fusion-embedded-webview",
                        "devtools": acquired["evidence"]["recipe_report"]["devtools"],
                    },
                    "import_performed": False,
                    "automatic_rollback_performed": False,
                    "pattern_application_seed": {
                        "pattern_uri": (
                            "https://w3id.org/cad-geometry/data/"
                            "workflow-memory#S10ExactStepRecipe"
                        ),
                        "tool": MCMASTER_EXECUTE_TOOL,
                        "action": ACQUIRE_EMBEDDED_EXACT_STEP_ACTION,
                        "parameter_bindings": {
                            "part_number": acquired["part_number"],
                            "format": acquired["format"],
                            "target_path": acquired["target_path"],
                            "devtools_port": devtools_port,
                            "timeout_seconds": timeout_seconds,
                        },
                        "execution_authorized_by_recipe": False,
                    },
                }
            if action == "api_download":
                self._require_confirmation(confirmation, CONFIRM_API_DOWNLOAD, action)
                downloaded = await self._run_sync(
                    self.mcmaster.api_download,
                    self._require_string(arguments, "part_number"),
                    self._require_string(arguments, "cad_path"),
                    self._require_string(arguments, "destination"),
                )
                return {"action": action, "download": downloaded}
            if action == "import_local_step":
                self._require_confirmation(
                    confirmation, CONFIRM_IMPORT_LOCAL_STEP, action
                )
                part_number = self._require_string(arguments, "part_number")
                file_record = self.mcmaster.inspect_step(
                    self._require_string(arguments, "path")
                )
                expected_sha256 = self._require_string(
                    arguments, "expected_sha256"
                ).lower()
                if file_record["sha256"] != expected_sha256:
                    raise BridgeError(
                        "STEP SHA-256 does not match expected_sha256; import refused"
                    )
                expected_document = self._require_string(
                    arguments, "expected_document_name"
                )
                target_component = self._require_string(
                    arguments, "target_component_name"
                )
                source_channel = str(
                    arguments.get("source_channel", "manual_mcmaster_download")
                )
                before = await self._call_fusion_script(
                    build_target_snapshot_script(
                        expected_document, target_component, part_number
                    )
                )
                operation = await self._call_fusion_script(
                    build_import_step_script(
                        file_record=file_record,
                        expected_document_name=expected_document,
                        target_component_name=target_component,
                        part_number=part_number,
                        source_channel=source_channel,
                    )
                )
                after = await self._call_fusion_script(
                    build_target_snapshot_script(
                        expected_document, target_component, part_number
                    )
                )
                structural_delta = any(
                    int(after[key]) > int(before[key])
                    for key in (
                        "target_body_count",
                        "target_occurrence_count",
                        "root_all_occurrence_count",
                    )
                )
                checks = {
                    "sha256_match": file_record["sha256"] == expected_sha256,
                    "document_match": after["document_name"] == expected_document,
                    "target_component_match": (
                        after["target_component_name"] == target_component
                    ),
                    "structural_delta": structural_delta,
                    "operation_reported_import": operation.get("imported") is True,
                    "provenance_present": bool(after.get("provenance_attribute")),
                }
                return {
                    "action": action,
                    "status": "PASS" if all(checks.values()) else "FAIL",
                    "all_checks_pass": all(checks.values()),
                    "checks": checks,
                    "source_file": file_record,
                    "before": before,
                    "operation": operation,
                    "after": after,
                    "automatic_rollback_performed": False,
                }
        except McMasterError as exc:
            raise BridgeError(str(exc)) from exc
        raise BridgeError(f"unsupported McMaster execute action: {action}")

    async def call_ui_execute(self, arguments: dict[str, object]) -> dict[str, Any]:
        action = str(arguments.get("action", ""))
        mode = arguments.get("mode")
        confirmation = arguments.get("confirmation")
        if action == "escape":
            return await self._run_sync(self.ui_bridge.escape)
        if action == "open_chooser":
            self._require_confirmation(confirmation, CONFIRM_OPEN_CHOOSER, action)
            return await self._run_sync(self.ui_bridge.open_chooser)
        if action == "chooser_select":
            self._require_confirmation(confirmation, CONFIRM_CHOOSER_SELECT, action)
            if mode is None:
                raise BridgeError("chooser_select requires mode")
            return await self._run_sync(self.ui_bridge.chooser_select, str(mode))
        if action == "chooser_create":
            self._require_confirmation(confirmation, CONFIRM_CREATE_DISPOSABLE, action)
            if mode is None:
                raise BridgeError("chooser_create requires mode")
            return await self._run_sync(self.ui_bridge.chooser_create, str(mode))
        raise BridgeError(f"unsupported UI execute action: {action}")

    async def call_tool(
        self, name: str, arguments: dict[str, object]
    ) -> CallToolResult:
        if name in INACTIVE_CANDIDATE_TOOLS:
            raise BridgeError(
                f"{name} is an inactive Candidate and is not registered for public routing"
            )
        if name == UI_READ_TOOL:
            result = await self.call_ui_read(arguments)
        elif name == UI_EXECUTE_TOOL:
            result = await self.call_ui_execute(arguments)
        elif name == MCMASTER_READ_TOOL:
            result = await self.call_mcmaster_read(arguments)
        elif name == MCMASTER_EXECUTE_TOOL:
            result = await self.call_mcmaster_execute(arguments)
        else:
            return await self.upstream.call_tool(name, arguments)
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=json.dumps(result, ensure_ascii=False, sort_keys=True),
                )
            ],
            structuredContent=result,
            isError=False,
        )


def create_server(
    upstream: Upstream | None = None,
    ui_bridge: FusionUIBridge | None = None,
    mcmaster: McMasterModule | None = None,
) -> Server:
    service = FusionMCPProxyService(
        upstream
        or AutodeskFusionUpstream(
            os.environ.get("FUSION_MCP_UPSTREAM", "http://127.0.0.1:27182/mcp")
        ),
        ui_bridge,
        mcmaster,
    )
    server = Server(
        "fusion-mcp-proxy",
        version=PROXY_VERSION,
        instructions=(
            "Aggregates Autodesk's built-in Fusion MCP tools with bounded macOS native-UI "
            "inspection, official McMaster-Carr API/file provenance, and hash-bound STEP "
            "import. Official Fusion operations are forwarded unchanged. Inactive Candidate "
            "capabilities are not registered or publicly routed."
        ),
    )

    @server.list_tools()
    async def handle_list_tools() -> list[Tool]:
        return await service.list_tools()

    @server.call_tool(validate_input=True)
    async def handle_call_tool(
        name: str, arguments: dict[str, object]
    ) -> CallToolResult:
        return await service.call_tool(name, arguments)

    @server.list_resources()
    async def handle_list_resources() -> list[Resource]:
        return await service.upstream.list_resources()

    @server.read_resource()
    async def handle_read_resource(uri: AnyUrl) -> list[ReadResourceContents]:
        result = await service.upstream.read_resource(uri)
        forwarded: list[ReadResourceContents] = []
        for content in result.contents:
            meta = content.meta if hasattr(content, "meta") else None
            if isinstance(content, TextResourceContents):
                forwarded.append(
                    ReadResourceContents(content.text, content.mimeType, meta)
                )
            elif isinstance(content, BlobResourceContents):
                forwarded.append(
                    ReadResourceContents(
                        base64.b64decode(content.blob), content.mimeType, meta
                    )
                )
        return forwarded

    return server


async def _run_stdio(server: Server) -> None:
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Legacy development-only Fusion proxy. Production Fusion access must "
            "use fusion-mcp-cell so every official tool call holds the PID owner lease."
        )
    )
    parser.add_argument(
        "--upstream",
        default=os.environ.get("FUSION_MCP_UPSTREAM", "http://127.0.0.1:27182/mcp"),
    )
    parser.add_argument(
        "--allow-unsafe-legacy-development-proxy",
        action="store_true",
        help=(
            "Explicitly acknowledge that this unguarded legacy entrypoint is for "
            "isolated development only; never use it with a production Fusion PID."
        ),
    )
    args = parser.parse_args()
    if not args.allow_unsafe_legacy_development_proxy:
        parser.error(
            "fusion-mcp-proxy is fail-closed because it bypasses the Fusion PID "
            "owner lease; configure fusion-mcp-cell instead"
        )
    upstream = AutodeskFusionUpstream(args.upstream)
    anyio.run(_run_stdio, create_server(upstream))


if __name__ == "__main__":
    main()
