"""Create one exact, short-lived dirty-document recovery authorization.

The receipt is deliberately narrower than an acceptance plan: the source plan
must contain exactly one MCP call, and the published receipt authorizes only
that call's tool name and canonical arguments digest for one Fusion process,
one state directory, and one visibly modified Fusion document title.

This command performs no Fusion, MCP, or GUI operation.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import stat
import time
import uuid
from pathlib import Path
from typing import Any

from .acceptance_client import AcceptanceInputError, _validate_plan
from .runtime_guard import (
    FusionRequestEvidence,
    PeekabooWindowProbe,
    is_darwin_process_start_token,
)

RECEIPT_SCHEMA = "fusion-mcp.dirty-recovery-authorization.v2"
DEFAULT_TTL_SECONDS = 600
MIN_TTL_SECONDS = 30
MAX_TTL_SECONDS = 900
_MAX_PLAN_BYTES = 4 * 1024 * 1024
_MAX_TEXT_LENGTH = 500


class DirtyRecoveryReceiptError(ValueError):
    """The requested receipt cannot be created safely."""


def _absolute(path: Path) -> Path:
    return Path(os.path.abspath(path.expanduser()))


def _strict_json(encoded: bytes) -> object:
    def unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        value: dict[str, Any] = {}
        for key, item in pairs:
            if key in value:
                raise ValueError("duplicate JSON object key")
            value[key] = item
        return value

    def reject_constant(value: str) -> None:
        raise ValueError(f"non-finite JSON number: {value}")

    try:
        return json.loads(
            encoded.decode("utf-8"),
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise DirtyRecoveryReceiptError(
            "acceptance plan must be strict UTF-8 JSON"
        ) from exc


def _read_owner_only_plan(path: Path) -> dict[str, Any]:
    source = _absolute(path)
    try:
        canonical = source.resolve(strict=True)
    except OSError as exc:
        raise DirtyRecoveryReceiptError("acceptance plan is unavailable") from exc
    if canonical != source:
        raise DirtyRecoveryReceiptError(
            "acceptance plan path must not contain a symlink"
        )
    try:
        path_metadata = os.lstat(source)
    except OSError as exc:
        raise DirtyRecoveryReceiptError("acceptance plan is unavailable") from exc
    if stat.S_ISLNK(path_metadata.st_mode):
        raise DirtyRecoveryReceiptError("acceptance plan must not be a symlink")

    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(source, flags)
    except OSError as exc:
        raise DirtyRecoveryReceiptError(
            "acceptance plan cannot be opened safely"
        ) from exc
    try:
        before = os.fstat(descriptor)
        if (
            before.st_dev != path_metadata.st_dev
            or before.st_ino != path_metadata.st_ino
            or not stat.S_ISREG(before.st_mode)
            or before.st_uid != os.geteuid()
            or before.st_nlink != 1
            or stat.S_IMODE(before.st_mode) != 0o600
            or not 0 < before.st_size <= _MAX_PLAN_BYTES
        ):
            raise DirtyRecoveryReceiptError(
                "acceptance plan must be one owner-only mode 0600 regular inode"
            )
        chunks: list[bytes] = []
        remaining = before.st_size
        while remaining:
            chunk = os.read(descriptor, min(1 << 20, remaining))
            if not chunk:
                raise DirtyRecoveryReceiptError(
                    "acceptance plan changed while it was being read"
                )
            chunks.append(chunk)
            remaining -= len(chunk)
        after = os.fstat(descriptor)
        if (
            after.st_dev != before.st_dev
            or after.st_ino != before.st_ino
            or after.st_size != before.st_size
            or after.st_mtime_ns != before.st_mtime_ns
        ):
            raise DirtyRecoveryReceiptError(
                "acceptance plan changed while it was being read"
            )
    finally:
        os.close(descriptor)

    raw = _strict_json(b"".join(chunks))
    try:
        plan = _validate_plan(raw)
    except AcceptanceInputError as exc:
        raise DirtyRecoveryReceiptError(str(exc)) from exc
    if len(plan["calls"]) != 1:
        raise DirtyRecoveryReceiptError(
            "dirty recovery authorization requires exactly one planned call"
        )
    return plan


def _canonical_state_directory(path: Path) -> Path:
    requested = _absolute(path)
    try:
        canonical = requested.resolve(strict=True)
        metadata = canonical.stat()
    except OSError as exc:
        raise DirtyRecoveryReceiptError(
            "Fusion state directory is unavailable"
        ) from exc
    if (
        not stat.S_ISDIR(metadata.st_mode)
        or metadata.st_uid != os.geteuid()
        or stat.S_IMODE(metadata.st_mode) != 0o700
    ):
        raise DirtyRecoveryReceiptError(
            "Fusion state directory must be an owner-held mode 0700 directory"
        )
    return canonical


def _bounded_exact_text(value: str, *, label: str) -> str:
    if (
        not isinstance(value, str)
        or not value
        or value != value.strip()
        or len(value) > _MAX_TEXT_LENGTH
        or any(character in value for character in ("\x00", "\r", "\n"))
    ):
        raise DirtyRecoveryReceiptError(f"{label} is not one bounded exact string")
    return value


def _validate_title(value: str) -> str:
    title = _bounded_exact_text(value, label="modified document title")
    if PeekabooWindowProbe._modified_document_titles([title]) != [title]:
        raise DirtyRecoveryReceiptError(
            "modified document title must contain an asterisk before "
            "the Autodesk Fusion suffix"
        )
    return title


def _validate_ttl(ttl_seconds: int | float) -> float:
    if isinstance(ttl_seconds, bool) or not isinstance(ttl_seconds, int | float):
        raise DirtyRecoveryReceiptError("TTL must be a finite number of seconds")
    ttl = float(ttl_seconds)
    if (
        not math.isfinite(ttl)
        or ttl < MIN_TTL_SECONDS
        or ttl > MAX_TTL_SECONDS
    ):
        raise DirtyRecoveryReceiptError(
            f"TTL must be between {MIN_TTL_SECONDS} and {MAX_TTL_SECONDS} seconds"
        )
    return ttl


def build_receipt(
    *,
    plan_path: Path,
    node_id: str,
    fusion_pid: int,
    fusion_start_time: str,
    fusion_start_token: str,
    state_directory: Path,
    modified_document_title: str,
    ttl_seconds: int | float = DEFAULT_TTL_SECONDS,
    now_unix: float | None = None,
) -> dict[str, object]:
    """Build an exact receipt payload without publishing it."""
    plan = _read_owner_only_plan(plan_path)
    node = _bounded_exact_text(node_id, label="node ID")
    start_time = _bounded_exact_text(
        fusion_start_time, label="Fusion process start time"
    )
    start_token = _bounded_exact_text(
        fusion_start_token, label="Fusion process start token"
    )
    if not is_darwin_process_start_token(start_token):
        raise DirtyRecoveryReceiptError(
            "Fusion process start token is not one canonical macOS libproc token"
        )
    title = _validate_title(modified_document_title)
    if (
        isinstance(fusion_pid, bool)
        or not isinstance(fusion_pid, int)
        or not 0 < fusion_pid <= 2_147_483_647
    ):
        raise DirtyRecoveryReceiptError("Fusion PID must be one positive integer")
    ttl = _validate_ttl(ttl_seconds)
    if now_unix is None:
        now_unix = time.time()
    if (
        isinstance(now_unix, bool)
        or not isinstance(now_unix, int | float)
        or not math.isfinite(float(now_unix))
        or float(now_unix) < 0
    ):
        raise DirtyRecoveryReceiptError("current Unix time must be finite")

    call = plan["calls"][0]
    tool = call["tool"]
    if len(tool) > 200:
        raise DirtyRecoveryReceiptError("planned tool name exceeds the receipt bound")
    evidence = FusionRequestEvidence.from_request(
        request_id=None,
        tool=tool,
        arguments=call["arguments"],
    )
    canonical_state = _canonical_state_directory(state_directory)
    return {
        "schema": RECEIPT_SCHEMA,
        "node_id": node,
        "fusion_pid": fusion_pid,
        "fusion_start_time": start_time,
        "fusion_start_token": start_token,
        "state_directory": str(canonical_state),
        "modified_document_title": title,
        "allowed_request": {
            "tool": evidence.tool,
            "arguments_sha256": evidence.arguments_sha256,
        },
        "expires_at_unix": float(now_unix) + ttl,
    }


def _require_output_parent(path: Path) -> tuple[Path, Path]:
    target = _absolute(path)
    parent = target.parent
    try:
        canonical_parent = parent.resolve(strict=True)
        metadata = os.lstat(parent)
    except OSError as exc:
        raise DirtyRecoveryReceiptError(
            "receipt output directory is unavailable"
        ) from exc
    if canonical_parent != parent or stat.S_ISLNK(metadata.st_mode):
        raise DirtyRecoveryReceiptError(
            "receipt output path must not contain a symlink"
        )
    if (
        not stat.S_ISDIR(metadata.st_mode)
        or metadata.st_uid != os.geteuid()
        or stat.S_IMODE(metadata.st_mode) != 0o700
    ):
        raise DirtyRecoveryReceiptError(
            "receipt output directory must be owner-held mode 0700"
        )
    try:
        existing = os.lstat(target)
    except FileNotFoundError:
        pass
    except OSError as exc:
        raise DirtyRecoveryReceiptError(
            "receipt output path cannot be inspected safely"
        ) from exc
    else:
        if stat.S_ISLNK(existing.st_mode):
            raise DirtyRecoveryReceiptError("receipt output must not be a symlink")
        if existing.st_uid != os.geteuid():
            raise DirtyRecoveryReceiptError(
                "existing receipt output is not owned by this user"
            )
        raise DirtyRecoveryReceiptError("receipt output already exists")
    return target, parent


def publish_receipt(path: Path, receipt: dict[str, object]) -> Path:
    """Atomically publish a new owner-only receipt without replacing a path."""
    target, parent = _require_output_parent(path)
    encoded = (
        json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")
    temporary = parent / f".{target.name}.tmp-{os.getpid()}-{uuid.uuid4().hex}"
    descriptor = -1
    published = False
    try:
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        descriptor = os.open(temporary, flags, 0o600)
        os.fchmod(descriptor, 0o600)
        view = memoryview(encoded)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise OSError("receipt write made no progress")
            view = view[written:]
        os.fsync(descriptor)
        os.close(descriptor)
        descriptor = -1
        try:
            os.link(temporary, target, follow_symlinks=False)
        except FileExistsError as exc:
            raise DirtyRecoveryReceiptError("receipt output already exists") from exc
        published = True
    except DirtyRecoveryReceiptError:
        raise
    except OSError as exc:
        raise DirtyRecoveryReceiptError(
            "receipt could not be published atomically"
        ) from exc
    finally:
        if descriptor >= 0:
            os.close(descriptor)
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass
        if published:
            directory_descriptor = os.open(parent, os.O_RDONLY)
            try:
                os.fsync(directory_descriptor)
            finally:
                os.close(directory_descriptor)

    metadata = os.lstat(target)
    if (
        not stat.S_ISREG(metadata.st_mode)
        or metadata.st_uid != os.geteuid()
        or metadata.st_nlink != 1
        or stat.S_IMODE(metadata.st_mode) != 0o600
    ):
        raise DirtyRecoveryReceiptError(
            "published receipt is not one owner-only mode 0600 regular inode"
        )
    return target


def create_receipt(
    *,
    plan_path: Path,
    output_path: Path,
    node_id: str,
    fusion_pid: int,
    fusion_start_time: str,
    fusion_start_token: str,
    state_directory: Path,
    modified_document_title: str,
    ttl_seconds: int | float = DEFAULT_TTL_SECONDS,
    now_unix: float | None = None,
) -> Path:
    """Build and atomically publish one dirty-recovery receipt."""
    receipt = build_receipt(
        plan_path=plan_path,
        node_id=node_id,
        fusion_pid=fusion_pid,
        fusion_start_time=fusion_start_time,
        fusion_start_token=fusion_start_token,
        state_directory=state_directory,
        modified_document_title=modified_document_title,
        ttl_seconds=ttl_seconds,
        now_unix=now_unix,
    )
    return publish_receipt(output_path, receipt)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--node-id", required=True)
    parser.add_argument("--fusion-pid", type=int, required=True)
    parser.add_argument("--fusion-start-time", required=True)
    parser.add_argument("--fusion-start-token", required=True)
    parser.add_argument("--state-directory", type=Path, required=True)
    parser.add_argument("--modified-document-title", required=True)
    parser.add_argument(
        "--ttl-seconds",
        type=int,
        default=DEFAULT_TTL_SECONDS,
        help=(
            f"authorization lifetime ({MIN_TTL_SECONDS}-"
            f"{MAX_TTL_SECONDS} seconds; default: {DEFAULT_TTL_SECONDS})"
        ),
    )
    return parser


def main() -> None:
    args = _parser().parse_args()
    try:
        output = create_receipt(
            plan_path=args.plan,
            output_path=args.output,
            node_id=args.node_id,
            fusion_pid=args.fusion_pid,
            fusion_start_time=args.fusion_start_time,
            fusion_start_token=args.fusion_start_token,
            state_directory=args.state_directory,
            modified_document_title=args.modified_document_title,
            ttl_seconds=args.ttl_seconds,
        )
    except DirtyRecoveryReceiptError as exc:
        raise SystemExit(f"dirty recovery receipt refused: {exc}") from exc
    print(output)


if __name__ == "__main__":
    main()
