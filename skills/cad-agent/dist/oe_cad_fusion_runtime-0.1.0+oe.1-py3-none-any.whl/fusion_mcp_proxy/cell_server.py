"""Expose one complete, host-local Autodesk Fusion MCP cell over stdio.

The process is intended to run beside Fusion.  For another Mac, launch it via
strict SSH as the remote command; do not forward Fusion's loopback MCP port.
"""

from __future__ import annotations

import argparse
import base64
import os
import sys
from collections.abc import Awaitable, Callable
from io import TextIOWrapper
from pathlib import Path
from typing import Protocol, TypeVar

import anyio
import anyio.lowlevel
import mcp.types as mcp_types
from mcp.server.lowlevel import Server
from mcp.server.lowlevel.helper_types import ReadResourceContents
from mcp.shared.message import SessionMessage
from mcp.types import (
    BlobResourceContents,
    CallToolResult,
    ReadResourceResult,
    Resource,
    TextResourceContents,
    Tool,
)
from pydantic import AnyUrl

from fusion_mcp_proxy.self_retirement import probe_retirement

from .runtime_guard import (
    DEFAULT_UPSTREAM,
    FusionRuntimeGuard,
    FusionRuntimeGuardError,
    FusionRequestEvidence,
    MacOSFusionProcessProbe,
    PeekabooWindowProbe,
)
from .script_safety import (
    UnsafeFusionScriptError,
    classify_untitled_preservation_role,
    reject_unsafe_execute_script,
)
from .tool_catalog import AUDITED_FUSION_RELEASES, audited_fusion_tools
from .upstream import PersistentAutodeskFusionUpstream

CELL_SERVER_VERSION = "0.1.0"
_T = TypeVar("_T")
CLIENT_ACK_NOTIFICATION = "notifications/fusion-mcp-cell/delivery-ack"
CLIENT_ACK_CAPABILITY = "fusionMcpCellDeliveryAck"
UNTITLED_PRESERVATION_CAPABILITY = "fusionMcpUntitledDocumentPreservation"
UNTITLED_PRESERVATION_INSTRUCTIONS = (
    "An untitled or never-saved Fusion document is a protected engineering "
    "artifact when its locale-default name is untitled, native isSaved is false, "
    "or dataFile is absent, even when native isModified is false. "
    "Before unrelated work, workspace cleanup, close, quit, restart, or PID "
    "retirement, inspect native identity and content, derive a semantic name, and "
    "resolve the exact project/folder plus no-overwrite result in a separate "
    "read-only request. Then perform Document.saveAs through Fusion MCP/API only. "
    "After external UI settle, verify exact name, lineage, version, isSaved=true, "
    "isModified=false, and relevant native state with a fresh MCP session/request. "
    "HOLD on identity, name, destination, transport, or result ambiguity. Never "
    "infer discard; only an explicit user instruction for the exact document can "
    "waive preservation, and an ambiguous PID must receive no further MCP call. "
    "Protected execute scripts declare exactly one top-level "
    "FUSION_MCP_UNTITLED_PRESERVATION_ROLE whose value is inspect, "
    "destination-preflight, save-as, or readback; ordinary read tools need no "
    "role. Every production cell on one execution node must share one stable "
    "owner-only canonical safety state root; it must not rotate per project, "
    "attempt, or call."
)
REQUIRED_FUSION_TOOLS = frozenset(
    {
        "fusion_mcp_read",
        "fusion_mcp_execute",
        "fusion_mcp_update",
        "fusion_mcp_electronics_read",
    }
)


class Upstream(Protocol):
    async def open(self) -> None: ...
    def abandon(self) -> None: ...
    async def list_tools(self) -> list[Tool]: ...
    async def call_tool(
        self, name: str, arguments: dict[str, object]
    ) -> CallToolResult: ...
    async def list_resources(self) -> list[Resource]: ...
    async def read_resource(self, uri: AnyUrl) -> ReadResourceResult: ...


class GuardedFusionCellService:
    def __init__(
        self,
        upstream: Upstream,
        guard: FusionRuntimeGuard,
    ) -> None:
        self.upstream = upstream
        self.guard = guard
        # This immutable-by-convention snapshot is built only from the audited
        # package-local catalog.  Configured cells can therefore initialize and
        # enumerate tools while Fusion is stopped, without taking a PID lease.
        self._tool_cache = tuple(audited_fusion_tools())

    async def bootstrap_tools(self, *, deadline: float | None = None) -> None:
        """Compatibility no-op: validate only the package-local catalog."""
        del deadline
        names = {tool.name for tool in self._tool_cache}
        if names != REQUIRED_FUSION_TOOLS:
            raise FusionRuntimeGuardError(
                "local Fusion MCP catalog does not contain the exact four tools"
            )

    async def list_tools(self, *, delivery_id: int | str | None = None) -> list[Tool]:
        # tools/list is served from the audited package-local catalog and does
        # not bind or touch Fusion, so it has no delivery marker to retain.
        return [tool.model_copy(deep=True) for tool in self._tool_cache]

    async def _with_open_upstream(self, operation: Callable[[], Awaitable[_T]]) -> _T:
        # Every selected operation gets one new MCP session.  Initialize, its
        # initialized-notification wire-completion barrier, the post-initialize
        # runtime proof, and the selected request all remain inside the same
        # guard.run transaction and one in-flight marker.  A failed proof or
        # request abandons that session locally; it must never trigger DELETE,
        # retry, or a health probe against the now-ambiguous Fusion PID.
        try:
            await self.upstream.open()
            self.guard.verify_after_upstream_initialize()
            return await operation()
        except BaseException:
            self.upstream.abandon()
            raise

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, object],
        *,
        delivery_id: int | str | None = None,
    ) -> CallToolResult:
        if name not in {tool.name for tool in self._tool_cache}:
            raise FusionRuntimeGuardError(f"unknown Fusion MCP tool: {name}")
        try:
            reject_unsafe_execute_script(name, arguments)
        except UnsafeFusionScriptError as exc:
            raise FusionRuntimeGuardError(
                "Fusion script rejected before runtime activation: " + str(exc)
            ) from None
        preservation_role = classify_untitled_preservation_role(name, arguments)
        return await self.guard.run(
            lambda: self._with_open_upstream(
                lambda: self.upstream.call_tool(name, arguments)
            ),
            delivery_id=delivery_id,
            request_evidence=FusionRequestEvidence.from_request(
                request_id=delivery_id,
                tool=name,
                arguments=arguments,
                preservation_role=preservation_role,
            ),
        )

    async def list_resources(
        self, *, delivery_id: int | str | None = None
    ) -> list[Resource]:
        return await self.guard.run(
            lambda: self._with_open_upstream(self.upstream.list_resources),
            delivery_id=delivery_id,
            request_evidence=FusionRequestEvidence.from_request(
                request_id=delivery_id,
                tool="resources/list",
                arguments={},
                preservation_role="read-only",
            ),
        )

    async def read_resource(
        self, uri: AnyUrl, *, delivery_id: int | str | None = None
    ) -> ReadResourceResult:
        return await self.guard.run(
            lambda: self._with_open_upstream(lambda: self.upstream.read_resource(uri)),
            delivery_id=delivery_id,
            request_evidence=FusionRequestEvidence.from_request(
                request_id=delivery_id,
                tool="resources/read",
                arguments={"uri": str(uri)},
                preservation_role="read-only",
            ),
        )


def create_cell_server(
    service: GuardedFusionCellService,
    *,
    node_id: str,
) -> Server:
    server = Server(
        f"fusion-mcp-cell-{node_id}",
        version=CELL_SERVER_VERSION,
        instructions=(
            f"Complete Autodesk Fusion MCP tool surface for execution node {node_id}. "
            "The upstream remains loopback-only on that node. Every upstream request is "
            "serialized under a PID-bound owner lease; loading/recovery/save/security "
            "windows fail closed, and an upstream runtime exception retires that Fusion PID."
            f" {UNTITLED_PRESERVATION_INSTRUCTIONS}"
        ),
    )

    @server.list_tools()
    async def handle_list_tools() -> list[Tool]:
        return await service.list_tools(delivery_id=server.request_context.request_id)

    # A cache miss invokes our list-tools handler, which is package-local and
    # remains safe before any Fusion PID has been discovered.
    # Local schema validation protects audited releases from malformed calls.
    # An unknown release can only pass fields already audited; it then fails the
    # release gate before upstream HTTP/open.  New unknown-release fields fail
    # closed locally and never touch Fusion.
    @server.call_tool(validate_input=True)
    async def handle_call_tool(
        name: str, arguments: dict[str, object]
    ) -> CallToolResult:
        return await service.call_tool(
            name,
            arguments,
            delivery_id=server.request_context.request_id,
        )

    @server.list_resources()
    async def handle_list_resources() -> list[Resource]:
        return await service.list_resources(
            delivery_id=server.request_context.request_id
        )

    @server.read_resource()
    async def handle_read_resource(uri: AnyUrl) -> list[ReadResourceContents]:
        result = await service.read_resource(
            uri,
            delivery_id=server.request_context.request_id,
        )
        forwarded: list[ReadResourceContents] = []
        for content in result.contents:
            meta = content.meta if hasattr(content, "meta") else None
            if isinstance(content, TextResourceContents):
                forwarded.append(
                    ReadResourceContents(content.text, content.mimeType, meta)
                )
            elif isinstance(content, BlobResourceContents):
                forwarded.append(
                    ReadResourceContents(
                        base64.b64decode(content.blob), content.mimeType, meta
                    )
                )
        return forwarded

    return server


class AsyncTextWriter(Protocol):
    async def write(self, value: str) -> object: ...
    async def flush(self) -> object: ...


def _consume_delivery_control(
    message: mcp_types.JSONRPCMessage,
    guard: FusionRuntimeGuard,
) -> bool:
    """Consume only an exact delivery probe response or explicit exact ACK."""
    root = message.root
    if isinstance(root, mcp_types.JSONRPCResponse) and guard.acknowledge_delivery_probe(
        root.id
    ):
        return True
    if (
        isinstance(root, mcp_types.JSONRPCNotification)
        and root.method == CLIENT_ACK_NOTIFICATION
    ):
        params = root.params or {}
        request_id = params.get("requestId")
        if isinstance(request_id, (int, str)) and not isinstance(request_id, bool):
            guard.acknowledge_client_consumption(
                request_id,
                acknowledgement_kind="explicit_notification",
            )
        return True
    return False


async def _write_session_message(
    stdout: AsyncTextWriter,
    session_message: SessionMessage,
    guard: FusionRuntimeGuard,
) -> None:
    message = session_message.message
    encoded = message.model_dump_json(by_alias=True, exclude_none=True)
    await stdout.write(encoded + "\n")
    await stdout.flush()
    root = message.root
    # Only a successful JSON-RPC response can correspond to a completed Fusion
    # operation.  A JSONRPCError may be generated locally for a *different*
    # request while an earlier Fusion response is still pending delivery.
    if isinstance(root, mcp_types.JSONRPCResponse):
        delivery_probe_id = guard.mark_delivery_flushed(root.id)
        if delivery_probe_id is not None:
            # This standard server-to-client ping is ordered after the flushed
            # Fusion response.  Its response proves a normal MCP client read the
            # preceding response even when it knows nothing about our optional
            # explicit ACK extension, so an otherwise idle global cell does not
            # retain the PID writer lease forever after one successful call.
            ping = mcp_types.JSONRPCMessage(
                mcp_types.JSONRPCRequest(
                    jsonrpc="2.0",
                    id=delivery_probe_id,
                    method="ping",
                )
            )
            await stdout.write(
                ping.model_dump_json(by_alias=True, exclude_none=True) + "\n"
            )
            await stdout.flush()


async def _lifecycle_watchdog(
    upstream: PersistentAutodeskFusionUpstream,
    last_activity: list[float],
    *,
    idle_exit_seconds: float,
    check_seconds: float,
    initial_ppid: int,
    sibling_probe_seconds: float = 60.0,
) -> None:
    # MCP stdio clients (codex included) respawn a replacement cell after a
    # timeout without closing the abandoned cell's stdin, so EOF alone cannot
    # end this process.  The cell must therefore retire itself: immediately on
    # client-process death or a spawned identical replacement, and after a
    # long stdio-idle window otherwise.  The replacement probe shells out to
    # ps, so it runs on a worker thread and only when the cell is quiescent;
    # the event loop is never blocked and an in-flight request is never
    # abandoned, so there is no session to DELETE and no ambiguity to
    # preserve.
    sibling_probe_interval = max(sibling_probe_seconds, check_seconds)
    next_sibling_probe = anyio.current_time() + sibling_probe_interval
    while True:
        await anyio.sleep(check_seconds)
        idle = anyio.current_time() - last_activity[0]
        ppid = os.getppid()
        if ppid == 1 or ppid != initial_ppid:
            reason = f"client process gone (ppid {initial_ppid} -> {ppid})"
        elif idle_exit_seconds > 0 and idle >= idle_exit_seconds:
            reason = f"stdio idle for {idle:.0f}s (limit {idle_exit_seconds:.0f}s)"
        elif anyio.current_time() >= next_sibling_probe and idle >= check_seconds:
            next_sibling_probe = anyio.current_time() + sibling_probe_interval
            abandoned = await anyio.to_thread.run_sync(
                probe_retirement, initial_ppid
            )
            if abandoned is None:
                continue
            reason = abandoned
        else:
            continue
        print(f"fusion-mcp-cell: self-retiring: {reason}", file=sys.stderr, flush=True)
        try:
            with anyio.CancelScope(shield=True):
                with anyio.move_on_after(10.0):
                    await upstream.close()
        finally:
            os._exit(0)


async def _run_stdio(
    server: Server,
    service: GuardedFusionCellService,
    guard: FusionRuntimeGuard,
    upstream: PersistentAutodeskFusionUpstream,
    *,
    idle_exit_seconds: float = 3600.0,
    watchdog_check_seconds: float = 15.0,
) -> None:
    # This is an intentionally small copy of MCP's stdio transport.  The guard
    # retains the durable marker through stdout.flush(), then clears it only on
    # an explicit client ACK or a later request observed after that flush.
    stdin = anyio.wrap_file(
        TextIOWrapper(sys.stdin.buffer, encoding="utf-8", errors="replace")
    )
    stdout = anyio.wrap_file(TextIOWrapper(sys.stdout.buffer, encoding="utf-8"))
    read_sender, read_stream = anyio.create_memory_object_stream[
        SessionMessage | Exception
    ](0)
    write_stream, write_receiver = anyio.create_memory_object_stream[SessionMessage](0)
    last_activity = [anyio.current_time()]

    async def stdin_reader() -> None:
        try:
            async with read_sender:
                async for line in stdin:
                    last_activity[0] = anyio.current_time()
                    try:
                        message = mcp_types.JSONRPCMessage.model_validate_json(line)
                    except (ValueError, TypeError) as exc:
                        await read_sender.send(exc)
                        continue
                    if _consume_delivery_control(message, guard):
                        continue
                    await read_sender.send(SessionMessage(message))
                guard.retire_ambiguous_delivery(
                    "stdio input closed before client consumption was acknowledged"
                )
        except anyio.ClosedResourceError:
            guard.retire_ambiguous_delivery(
                "stdio input closed before client consumption was acknowledged"
            )
            await anyio.lowlevel.checkpoint()

    async def stdout_writer() -> None:
        try:
            async with write_receiver:
                async for session_message in write_receiver:
                    last_activity[0] = anyio.current_time()
                    try:
                        await _write_session_message(stdout, session_message, guard)
                    except (BrokenPipeError, OSError, anyio.BrokenResourceError) as exc:
                        # The upstream result may have committed while the client
                        # never received it.  Retire without an MCP probe/retry.
                        guard.retire_ambiguous_delivery(
                            f"response delivery failed: {type(exc).__name__}: {exc}"
                        )
                        raise
        except anyio.ClosedResourceError:
            guard.retire_ambiguous_delivery(
                "response delivery failed: stdout resource closed"
            )
            await anyio.lowlevel.checkpoint()

    # The task group is outside every guarded request deadline.  The dedicated
    # upstream actor it owns is the only task that enters, uses, and exits each
    # operation-scoped HTTP/MCP context; request cancellation can therefore
    # never invert their task-local cancel-scope stack.
    # Entering this lazy guard is purely local.  PID discovery, the cross-process
    # owner lease, Peekaboo preflight, the in-flight marker, upstream initialize,
    # and the selected operation all begin only inside the first guard.run.
    with guard:
        async with anyio.create_task_group() as owner_group:
            await upstream.start_owner(owner_group)
            owner_group.start_soon(
                lambda: _lifecycle_watchdog(
                    upstream,
                    last_activity,
                    idle_exit_seconds=idle_exit_seconds,
                    check_seconds=watchdog_check_seconds,
                    initial_ppid=os.getppid(),
                )
            )
            try:
                async with anyio.create_task_group() as group:
                    group.start_soon(stdin_reader)
                    group.start_soon(stdout_writer)
                    await server.run(
                        read_stream,
                        write_stream,
                        server.create_initialization_options(
                            experimental_capabilities={
                                CLIENT_ACK_CAPABILITY: {
                                    "version": "1",
                                    "notification": CLIENT_ACK_NOTIFICATION,
                                    "implicitAckOnNextRequestAfterFlush": False,
                                    "standardServerPingAfterFlush": True,
                                },
                                UNTITLED_PRESERVATION_CAPABILITY: {
                                    "version": "2",
                                    "triggers": [
                                        "locale-untitled-name",
                                        "isSaved=false",
                                        "dataFile=None",
                                    ],
                                    "independentOfIsModified": True,
                                    "semanticNameRequired": True,
                                    "saveSurface": "Fusion MCP/API Document.saveAs",
                                    "noOverwriteRequired": True,
                                    "destinationPreflightSeparateRequest": True,
                                    "externalSettleRequired": True,
                                    "postSaveReadbackRequired": True,
                                    "freshSessionReadbackRequired": True,
                                    "holdOnAmbiguity": True,
                                    "samePidMcpForbiddenAfterAmbiguity": True,
                                    "canonicalSafetyStateRootRequired": True,
                                    "visibleUntitledRuntimeGate": True,
                                    "scriptRoleConstant": (
                                        "FUSION_MCP_UNTITLED_PRESERVATION_ROLE"
                                    ),
                                    "scriptRoleValues": [
                                        "inspect",
                                        "destination-preflight",
                                        "save-as",
                                        "readback",
                                    ],
                                    "scriptStaticPolicy": "fail-closed-allowlist",
                                    "saveAsUniqueCadMutatorRequired": True,
                                    "appliesBefore": [
                                        "unrelated-work",
                                        "workspace-cleanup",
                                        "close",
                                        "quit",
                                        "restart",
                                        "pid-retirement",
                                    ],
                                    "explicitExactDocumentDiscardOverrideOnly": True,
                                },
                            }
                        ),
                    )
                    group.cancel_scope.cancel()
            finally:
                # The actor closes its own contexts.  Known-complete operations
                # release their exact session; timeout/cancellation cleanup has
                # no DELETE, reconnect, or probe path.
                with anyio.CancelScope(shield=True):
                    await upstream.close()
                owner_group.cancel_scope.cancel()


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--node-id", required=True)
    parser.add_argument("--expected-hostname", required=True)
    parser.add_argument("--upstream", default=DEFAULT_UPSTREAM)
    parser.add_argument("--peekaboo", required=True)
    parser.add_argument(
        "--peekaboo-mode",
        choices=("local", "bridge", "local-ondemand"),
        required=True,
    )
    parser.add_argument(
        "--state-directory",
        type=Path,
        default=Path(os.environ.get("TMPDIR", "/tmp")) / "cad-agent-fusion-mcp",
        help=(
            "stable owner-only canonical safety state root for this execution "
            "node; production callers must not rotate it per project or request"
        ),
    )
    parser.add_argument("--timeout-seconds", type=float, default=120.0)
    parser.add_argument("--startup-timeout-seconds", type=float, default=90.0)
    parser.add_argument(
        "--idle-exit-seconds",
        type=float,
        default=3600.0,
        help=(
            "self-retire after this long with no stdio traffic; guards against "
            "MCP clients that respawn a replacement cell without closing the "
            "abandoned cell's stdin (0 disables)"
        ),
    )
    parser.add_argument(
        "--dirty-recovery-receipt",
        type=Path,
        help=(
            "owner-only mode 0600 one-shot authorization for one exact request "
            "against one exact pre-existing modified Fusion document"
        ),
    )
    parser.add_argument(
        "--health-attestation-challenge",
        type=Path,
        help=(
            "Owner-only same-host new-PID recovery challenge for one exact "
            "document-read health probe; the cell writes its receipt only after "
            "an exact delivery ACK"
        ),
    )
    return parser


def main() -> None:
    args = _parser().parse_args()

    process_probe = MacOSFusionProcessProbe(
        upstream_url=args.upstream,
        expected_hostname=args.expected_hostname,
    )
    window_probe = PeekabooWindowProbe(
        executable=args.peekaboo,
        mode=args.peekaboo_mode,
    )
    guard = FusionRuntimeGuard(
        process_probe,
        window_probe,
        node_id=args.node_id,
        state_directory=args.state_directory.expanduser().resolve(),
        timeout_seconds=args.timeout_seconds,
        startup_timeout_seconds=args.startup_timeout_seconds,
        dirty_recovery_receipt=args.dirty_recovery_receipt,
        health_attestation_challenge=args.health_attestation_challenge,
        lazy_activation=True,
        allowed_releases=AUDITED_FUSION_RELEASES,
    )
    upstream = PersistentAutodeskFusionUpstream(
        args.upstream,
        timeout_seconds=args.timeout_seconds,
    )
    service = GuardedFusionCellService(upstream, guard)

    async def _run() -> None:
        await _run_stdio(
            create_cell_server(service, node_id=args.node_id),
            service,
            guard,
            upstream,
            idle_exit_seconds=args.idle_exit_seconds,
        )

    anyio.run(_run)


if __name__ == "__main__":
    main()
