"""Executable native binding recipe for the clean S17 A0015 v6 artifact.

This module binds contextual roles and stable selectors to one exact saved
Fusion version.  It contains no thresholds, measured values, contact labels,
or verdicts.  Those remain owned by the trusted S17 profile and the runtime
evaluator.

The hips-to-torso allowance is bound as a composite native AABB envelope from
explicit version-bound boundary faces on both participants.  It is deliberately
not described as exact topological containment: the trusted profile still owns
the tight allowed-overlap volume, while the observer proves only that the
measured intersection stays inside both native participant envelopes.
"""

from __future__ import annotations

from typing import Any

from fusion_mcp_proxy.functional_assembly_snapshot import (
    BINDING_PLAN_SCHEMA,
    build_functional_assembly_snapshot_script,
)


CAD = "https://w3id.org/cad-geometry#"

PROFILE_IRI = CAD + "S17FunctionalPoseInvariantProfile"
EXPECTED_DOCUMENT = {
    "name": "S17_Minifigure_Assembly_A0015",
    "lineage_id": "urn:adsk.wipprod:dm.lineage:3S2F_gzGRQyRc23LvBG6gg",
    "version_id": (
        "urn:adsk.wipprod:fs.file:vf.3S2F_gzGRQyRc23LvBG6gg?version=6"
    ),
}
EXPECTED_NATIVE_INVENTORY = {
    "scoped_occurrence_count": 9,
    "native_occurrence_count": 15,
    "scoped_joint_count": 8,
    "native_joint_count": 8,
    "root_solid_body_count": 0,
}

_LEFT_HIP_TOKEN = (
    "/v4BAAAARlJLZXkAH4sIAAAAAAAA/61SPUqEMRAFC8+RXgYyySRfYim4WFvYyZJfEBYV"
    "0cJGC29gYbV4APu9gdp4BTs7z2DhJN+6uCLYyBQz8+blve/LRAolJAdyxrFSrnfUECs+"
    "tha38429w8XN28v97JWYoYS2IpcQhsEnsDI5IG8QQmvJD1Umr5PHzDrMpGiUtsaBcRmB"
    "VNAQqg/gZPY14cD10mu+Obu7vpw8P9jHp/ft/auVlzaqypAhFmSHqPhwDRUGwhALZSxD"
    "Yu5/qPQvDlpKJJNgiC4CoVUQyFsoUrlSTPDK/OFVUZHPlACxK0R2dVb3K5Im1lQt9dsm"
    "oYVGLzgRmzf/vg2NpmdGgZP5CWPfWwNwBHRfnxtBpbt4PLk4ziVPa0hlelbS0WmZ5nAe"
    "xM5EiEknQxPaFW3lgGPXBqqVKwaKAy5XQ/k1VOPw+/HxLcn+msaQSwasO6xE9C8Oes1e"
    "9n9dV2zMr+D6E/gZZXvHAgAA"
)
_LEFT_LEG_TOKEN = (
    "/v4BAAAARlJLZXkAH4sIAAAAAAAA/61SO0oEQRAFE/EWnUtBVXdNf1LRxRMIBsvSXxBERR"
    "QPsJiLsZiIgQfYMxjsFYz0Ggb29OysCgsmUgP16s2b97p7GoUUWItqpwFJ2ybuGS0+dxf"
    "3D1uH08X8Y/l4+sZVIYXSImXvjXERNEYL7DoC34/sTMHoVHSUqk+vTEFSsghSFQQOCsGi"
    "lqApsuEuERczZN3Mn4/vpvtPt7Dz+v6yvRyzrAlJ5UgQYlcdfPQQlEQI5ChY79G7VLX8"
    "Dy5txbb4jB4zkDUFuGgCG30A7rzPnc5Z4x8rzkGTwkxAxKlmcQHnUqqGlhUbU5K17bRZ"
    "KCGNEbWpGt7nt7+hagIOhFwRaiT0DwWKcH59lnKaFR/z7DLHk4s8S/7Ki72JEBPRx0Bvc"
    "lBhBcMj25sG1xISR4NEfnNrFbbb0d+Rofp5g+P6I7nBUf6Kw7ax0VG2GvsKfwE8VWr+nQ"
    "IAAA=="
)
_LEFT_WRIST_ARM_TOKEN = (
    "/v4BAAAARlJLZXkAH4sIAAAAAAAA/7VUvWocMRCGPIn6MDCj0eqnCgR8JH0IbsKhlbRgML"
    "EJCWlSBPIGadIYu/Az3FOkMO7dXR4jhUfSne8Wzm6cMAv7afTp+zQzy6LSCiVI3tSR9m1"
    "lasaqvy9XPy9evPmw+rH+fXl6Z4ShFVuVS4zOhQQWkwcTBoJYlya4CVPgFCiLjjBjKM7qi"
    "cHqMoIZBoYRGaHYIZcxoMhQ97q6uV0f09tf1+/c1+9/Xn3bepWhCNl68MFEMNPkIJIRr"
    "cDZhuALRhau+Qcq7cY2mZHHlAHNKLVZbSAEpyFa7dBnP6DXT3uNTNYxIuSJpSeWLMSBWa"
    "onF9H5nMi1bhvFyjpU8hrEvPp3DRIkBnUybTSbxhPv0tRmJ0kM+1xog6QmMec9aKIaz75"
    "8zCUvp5jK8lNJJ+dlmePnqF4vlFooLxSodzkSKKA/erdTwSb3vlN4l5uxdAWoeFPsLuoR"
    "PQuvXIu+f1hXzwy2uj26CjWWbp9wz1Yvan58uKS56GMlPd/6f7WqlsSHh2QqoK3z4c394"
    "/1ngHvWEvcTlAHjJgQAAA=="
)
_LEFT_WRIST_HAND_TOKEN = (
    "/v4BAAAARlJLZXkAH4sIAAAAAAAA/61RPUpEMRAGT5LCTgLJJC8/pYKLhbWNyJI3mYAgKq"
    "KNhY03sLBaFLzDVh5B0AvYWXkHCyd5u+suLGwj8x7zzU++bzJRAoRi0+z1gCC0yNaMEz8"
    "704fJ1sHJ9P7r7ens03IHCONEppS8jyidwiBt7LRMNbTRF4XRYNSZebgz5VIIvZNaI9dN"
    "TLIn7WQswWd03qGHQetjW736u93H5/fJ9+HL8e1cqyMbQqIoqQ9K2i6ADM6S9EDgAKJFq"
    "LPbf2BpE9ugtIrINwJy0hbsZej4bhmBdOgRS94wcdLWmMIMxkJloCBDAJIACoCw5xFc27"
    "YVRhgAUR2LV/2BQzn+Q3sZodvTcEmreQKWEkr0FzfnmfK4JKTxFeHpJY1zuk5ibyTESFQ"
    "aWc/sM2QwfPBXqaDltDgaWtYVVVOFmemZwcLDBgVYUTBrigugZmtYptZtR9XmI6zEv3CH"
    "WtvKAgAA"
)
_RIGHT_HIP_TOKEN = (
    "/v4BAAAARlJLZXkAH4sIAAAAAAAA/61SO0qtQQwGC9cxvQQmM5mXpeDB2sJODvMEQVRECx"
    "st3IGFlbgAe3egNm7Bzu6u4RZm5tefc+GKjQwhjy/JFyaRQgnJD1njZCk/POoRK/5uPN7"
    "cre3sP16/v94fvhFnKKGtKDVG50IGK7MHCgYhdpeCazIHnQMW7sOZlIzS1ngwviCQihpi"
    "CxG8LKFldGx/ct2tH95eXSxeHuzT85/N3cuZSxvVZCyQKjJDUlzcYgNHGFOlgtVlzv2NL"
    "mPiqKVEMhlc8gkIrYJIwUKVytdqYlDmB66GikKhDIijQ2JWb/X4ImlSy83S+G0SWmhtB"
    "Cti8s7PUY6hYXEsfmyHUWBlvoNxbI+rcdKc0w03BZUeZOn4/KjUsmwx1+VpzQcndVniW"
    "RRbCyEWoreCvvpt0U8AcPI6oLo5Z6DYY3MG5ReoJnC1fLotOa4L5ym3p/JVhrmJ/g+D/o"
    "dejptV88NPWfE/AM8TJ5/XAgAA"
)
_RIGHT_LEG_TOKEN = (
    "/v4BAAAARlJLZXkAH4sIAAAAAAAA/61Su0pEMRAFG/Ev0svATJKbRyu6+AWCxbJMHhcWRE"
    "UUP2CxF2uxEQs/YL/BYn/BSn/Dwtxkd32wWMkE5szk5Jy8UEiBJahkaki6WumhY8TH7vzu"
    "futwPJ+9Lx5OXnVhSKGMSJnZWh/BYHSgfUfAQ6m97TF6FT2lojMwU5CUHIJUPYIOCsGhk"
    "WAoaqu7RLq3zet69nR8O95/vIGdl7fn7cXKy9mQVI4EIXZFgSNDUBIhkKfgmJF9Klz9Dy"
    "p1x2xzOUOIEJPpQBuvgfvkIGBwATFEJ/lvr+wl9R0FCCZ70NFwUXAE3jv07EilXtXb1kI"
    "J6bwoSRXzwb9poBWKqL5MfY7WVN+b5hcTRTi7Ok05TXqOeXKR4/Q8TxJfstgbCTESrlBg"
    "EDsosIA2ZJ2pcE0hcdQo8qu3ZmH9KcN/aTHUGxTXi+QGRfnDDpcHbHqyxiov8SeU537lq"
    "QIAAA=="
)
_RIGHT_WRIST_ARM_TOKEN = (
    "/v4BAAAARlJLZXkAH4sIAAAAAAAA/7VTvWocMRAGP4l6M6DRjP4qQ8Am6UNwYw7tSguGEB"
    "tjkyaFwW+QJk1IijyDn8KFce/u/BguPJJufXdwuIqZXebTzKfvk3ZYrYzSEigZOzKhrbhW"
    "nHrev/35e+/jye3N8u7P10cWhlHkVC4peR9HcHoMwNEipLrk6Cc9RhojZtERZorFOzMRO"
    "FMGYGsJBk0airO5DFGLDHavv/cPy2P89OvfZ//9+ungx+xVbBGyCxAiJ+Bp8pCQRStSdj"
    "GGohMJl/+DSjuxJkNOB4aJ0QOHPEDAYsC4Eq2bkIjC217eWY8mWxhwnEShZIjjkEGEg3O"
    "BDWJoX5sVKWdZSbJiXv3bNAix5TYWXpV6q02nFXScOaBwe9srB/tUh7Orb7nkxZTGsrgo"
    "4+l5WeR0mdSHI6WOVD0MVO9DgQL6Y9adCla1L51C61oFZgaNrhWtLrcOlKZv0demvevYr"
    "au3DGbdHn0fNm1sueuGVaezdlxp+7DvZ/1en6peiXYPiSvA2Xl3c3N7//n1hrXEC+fCeto"
    "WBAAA"
)
_RIGHT_WRIST_HAND_TOKEN = (
    "/v4BAAAARlJLZXkAH4sIAAAAAAAA/61RPUqEMRAFTzKFnQxkJvnyUyq4WFjbiCz58gOCqI"
    "g2FjbewMJqUfAOW3kEQS9gZ+UdLEzy7a6uLNrIJMybN5N5w0QAgyhGxdOA2LZIVUbDx8b"
    "0ZrK2czC9fnu6O3pVpYJBaojJe2NcQC2CReU6Ql9D5UwWwcngKJY+pdLHnFMwGolCyUvn"
    "sU+k0WVrYtBGB8OD1su6eDRXm7f3z5P33Yf9y7lWl5S1PjlMvRWoOstotUpoOLFmdipwn"
    "V39Q5c2sRbExsuMSXFCFblH66TArg9adtJw8OZ3LfKdkEZk7DJT3YlFH1JGm4Ki2MfALr"
    "ZtK5AgpYLqinjVL2wJhC7XgiTZfgeofU9pTuI7yT9IAf3JxXFMcZyL4PgshcPTNI7+3MP"
    "WCGAEtpRgfbddYAHD4a9MBY0j2BtKViXFTHkwmhkvPP+hwEsKckVyAURbyXJravuqNh9h"
    "Kf4Eku18qNYCAAA="
)

# These four vertex tokens are version-bound physical landmarks, not world-AABB
# labels.  In each mirrored source component, the toe is the longer protruding
# end of the owner-local foot geometry (0.53848 cm versus the 0.35052 cm heel
# end); the local signs differ across the mirror and are not used as a world
# direction verdict.  The identity therefore remains attached to the same
# native topology when a leg is rotated, so a backward leg reverses the
# measured signed direction instead of silently relabelling its extrema.
_LEFT_LEG_HEEL_VERTEX_TOKEN = (
    "/v4BAAAARlJLZXkAH4sIAAAAAAAA/62RPUqEMRCGwUa8RXoZmEnmy08v4gkEi2WZ/"
    "IFgIcui9ou9WIuNWHiAPYPFXsFKr2Fhko8FOxtJYJ68vLwzZFBphe1QqzST9uPFXb"
    "Hq+3j7+HRwtthuvnbPVx/cHFoZq3IRcS4ksJg8cJgIpD85uIopmBQot5zuzFFT9g"
    "jaVASOBsGj1WApseMpE1c397rdvF48LE5e7uHo/fPtcLfv5V3MpiSCmKaWIEkgGo"
    "0QKVD0IighNy//Q8qY2FcpKFiAvKvA1RL4JBF4EimTLcXiHxOXaMlgISDi3HpxhR"
    "ByboGeDTtXs/fjt1kZRUarVhqodqexDYN+1LGKWTB7wfwSUN2U1brcLVclXV6XZZ"
    "a1qHPlFXTfqeopDTvQHnQHHOvmMQAPph87FMbPDAIAAA=="
)
_LEFT_LEG_TOE_VERTEX_TOKEN = (
    "/v4BAAAARlJLZXkAH4sIAAAAAAAA/62RPUpEQQzHwUa8xfQSSGby5qMX8QSCxbJk"
    "vkCwkGVR+8VerMVGLDzAnsFir2Cl17Bw5r19YGcjM0x+CX/+CRNUWmE71CJNpP2Yc"
    "a9Y9X28fXw6OFtsN1+756sPbgqtjFW5iDgXElhMHjgMBNJTDq5iCiYFys2nK3PUl"
    "D2CNhWBo0HwaDVYSux4yMTVTb1uN68XD4uTl3s4ev98O9zNvbyL2ZREENPQHCQJR"
    "KMRIgWKXgQl5Kblf3AZJ/ZVCgoWIO8qcLUEPkkEHkTKYEux+MfEJVoyWAiIOLdeX"
    "CGEnJuhZ8PO1ez9+NusjCKjVQsN1PjzfRsGzRjb5X3Bz4XhlwLVTVmty91yVdLld"
    "VlmWYs6V15BU6jTBrpjB5yBOuB+yaYPPL0/8fLXYAwCAAA="
)
_RIGHT_LEG_HEEL_VERTEX_TOKEN = (
    "/v4BAAAARlJLZXkAH4sIAAAAAAAA/62RP0pEMRDGwUa8RXoZmEnm5U8v4gkEi2WZ"
    "SfJAsJBlUfvFXqzFRiw8wJ7BYq9gpdewMHm724mVpMhvPobvm2TQWIPtULtpSzZOF"
    "XfFm+/j9ePTwdlsvfraPF99cOuwxnlTqkgIKYPHHIHTQCC95BRGzMnlRKX59M6il"
    "kpEsG5EYHUIEb0FT5kDD4V4DNus29XrxcPs5OUejt4/3w43+6wYtLiaCTQPzUGyg"
    "DqLoJRIowhKKq2X/8FlmlhCbW/QDLn4AdgnBhlLBEWNiqg5Wvk7qyZL40AK6msCz"
    "l6aQyRIKWKSSK6MbvptNs4Qs2lXA9Pztx7YBKJpM9M6fhGHnRh3IpqbuljWu/mi5"
    "svrOi+yFHNuooHuetrAduyAe6AOOK2+j2KnKVr9A1d5h24YAgAA"
)
_RIGHT_LEG_TOE_VERTEX_TOKEN = (
    "/v4BAAAARlJLZXkAH4sIAAAAAAAA/61RPUqEQQwFG/EW00sgmck3P72IJxAsliXz"
    "84FgIcui9ou9WIuNWHiAPYPFXsFKr2Fh5lsXxMJKJkPehMd7SQaNNaiHNNMW2Ti9u"
    "Fe8+Txc3z/snczWq4/N48UbK8Ma501tIiGkAh5LBE4DgfQnpzBiSa4kqqrTmTVbqh"
    "HBuhGBs0OI6C14Khx4qMRj2Hpdr57P7mZHT7dw8Pr+sr/ZecWQq2uFIJdBFaQIZG"
    "cRMiXKUQQlVeXyP6hMHUtoOkMuUKofgH1ikLFGyJhjRswlWvnbqyVL40AZsm8JuHh"
    "RhUiQUsQkkVwd3bRtNs4Qs9GkwGgMWw3UAtH0Mxrfa8f4s2h/MdFctcWy3cwXrZx"
    "ftnmVpZhTEw3oVOZYAXbYAe2A7aDrdY/eTL8q+gXQ+rjmGAIAAA=="
)

# The hand endpoints use the matched owner-local outer-tip vertices of the
# mirrored hand components; the proximal endpoints are the native wrist Joint
# origins below.  Their semantic identity is therefore independent of the
# current world-X sign.
_LEFT_HAND_DISTAL_VERTEX_TOKEN = (
    "/v4BAAAARlJLZXkAH4sIAAAAAAAA/61SsUpFMQwFv6SDmwTaNLdNRxdxcHYRefTm"
    "5oLgICIiDi7+gYPTQ8F/eJOfIOgPuDn5Dw6mfTzQyUU6nJMmOUmaeofO2wmGYc2Qu"
    "0XtJrmvndXdcmv/eHX78fJw+k4WgS4mN2mtOReB5IWByhCgNpNKnr2UKCVMpmORdZ"
    "pnlZwgBDF/LBVGDQnKzHmSlJNkXNd62/bP+Wb3/vF1+XnwdHS9qTUoMVctoCN7oIE"
    "ROJFCRsWEWEiw9U7/oNI7JvbBF7GJUBPQLCPwYLNNghp4FJmnPzqugWKcTSESNgVl"
    "YEYFRI+oMloLqb82uWg66Ayipbb6fRvRN/xhUkcX+pY2/p5AvxPoR4J3l3p+oVeL"
    "c5WTM11M9aK6Q8cOmvCeEWy0Eb8hoRHfy6T+KdBwcOkbxPDquCoCAAA="
)
_RIGHT_HAND_DISTAL_VERTEX_TOKEN = (
    "/v4BAAAARlJLZXkAH4sIAAAAAAAA/61SPUqEMRAFT5LCTgYyk//SRrawthFZ8k0m"
    "IFjIsohsYeMNLKwWBe+wlUcQ9AJ2Vt7BwuTbXZAVrCRF3ry8N28YohUp3Q62G9eI4"
    "ljZznj1dbC6W+5Nzla3Hy8PF++2KUgZr4rkHEJi8Joj2OQQci9tClVzMpywtD5Nm"
    "UutwsEDIrd3kzIMgh5SjaGwD54DrbPe9vVzuDm8f3xdfh4/nS62WU5sjFkSyBA1WB"
    "cJorcCgYQ8UbJMfXb7D13Gib1GCtlUEEsCttAAMRkNbmBvnAnEOfydhdlpE3QFVwn"
    "7TiJklgpR2GIZClMq47atMgojqXaZZm35mw3rRqBp+AdlNxR2End0o9n8Npsds1ZX"
    "MpvL9XQmfH4p05LnWZ2oqKBrjxrQHXaAW0Ad6DHSjx+FlGtTuW8SWRSDPgIAAA=="
)

# The v6 hips press region is not one analytic cylinder.  These explicit native
# boundary faces witness its +/-X, +/-Y, minimum-Z, and maximum-Z envelope on
# both press features.  Bounds are derived live by the observer, never copied
# into this binding plan.
_HIPS_PRESS_REGION_TOKENS = [
    (
        "/v4BAAAARlJLZXkAH4sIAAAAAAAA/7VUPWpcMRCGFD6H+iCQRqM/l4YsqV2kM4t+IWDsY"
        "OLCTVLkBilcmRzAvW/gpMkV3LnLGVJEGu17az82JIUXCfTNvG/mmxmJJxgw0ZZspxwIHFn"
        "YPYb9fn339ebV25O7L48/v50+YGMAU4blEoK1PnEjkuPoteShm+htFcmr5GVueRoTowZlt"
        "OPaZckRguKh+sCdyL4maRveaN0cnF5/vlr9uDX3338dHn+atZSGKkLmscimEKEF11C5RR"
        "liwSyLTY37Elmo4qCEkKgTt9FFjtIAD+gNLwJcKTp40P/QqhLQZ0xcSsoQm6ozikYkdKyp"
        "GqRpI1PMO8/aYZt4i7bM030oUHS2LYdDbBzAzJLTw+wyDDdhZstxS456whEsnl+e5ZLXNa"
        "Syvijp/YeyzuFjYEcrxlYUzXveNw02MDbQF4IzBdi7QVFbXwcwAaILenx9BH2NLnv6gbof"
        "/5JnVlNP84w1ssHC3lGy2l0yPpeaWTgBPTQVaU61IuFtL5KGS8+EatlzL/q/eplZ5tmFTL"
        "2MWmHzM5h6G7ZafN/7sHY0CbubfKk3trdh/QFE7Q+tZQUAAA=="
    ),
    (
        "/v4BAAAARlJLZXkAH4sIAAAAAAAA/7VSPY4VMQyWKDhH+lWk2HH+KJF4oqagQ0/5lZBWgB"
        "AU2+wW3ICCasUB6PcGQMMV6Og4AwWeZGbePhgJin1yRvni+ezPdqIECsUGvMNA6PuJJo8V"
        "v85u3l/fe/zs5t2Pbx/PvxMzUGgrSo3RuZClVdlLCgZknI4UXFM56BygcB5mUjKorfHS+A"
        "KSMGoZW4jSqxJaBsd41rq+f/7h6mL39ZP9/OXngyeXq5Y22FQsMlVghYQc3GKTjiCmSgW"
        "qy8y9iyy94qiVAjJZuuSTJLAoIwUrq0Jfq4kBzT+0GiCFQlkC9AyJVb3VfUTKpJabpT5tE"
        "lqEoAVvjsWnaLbpPjSOnRcMh5odEwePOcjm/nSB8HOgPQTC3yx3i6VEevn2Rall32Ku+9c"
        "1P39V9yW+ieLhTohdTymB637EkMFY2P90uFJQPB0UffBNABfQ6aq3QkcG/YO+T7adZ1XTt"
        "/PobjA/aeoe6gPTWyXr7ZLpWGpl0QLM0NRdc1Eb36I2T3o8y16LPm0v5r96WVn26EKWXk"
        "ati/KhN+xemtG4nZMPa6NJ3G7yrt7YyYb1Gz1FTEFpBQAA"
    ),
    (
        "/v4BAAAARlJLZXkAH4sIAAAAAAAA/7VUPY6UMQyVKDhHehQpdpw/SiRGW1PQoVF+JaTVgh"
        "BbbMMW3ICCasUB6PcGQMMV6Og4AwVOMvPtzGgQFDtKpLz4e/azHetTAoXiBXzCROjHjbrF"
        "it+Pbj/cPDh7cfv+5/dP5z+IGSi0FaXG6FzI0qrsJQUDMvYrBddUDjoHKByHmZQMamu8NL"
        "6AJIxaxhai9KqElsEx3mjdPDz/eH21+vbZfvn66/Gzd4uWNthULDJVYIWE7Nxik44gpkoFq"
        "svMvY8oI+OolQIyWbrkkySwKCMFK6tCX6uJAc0/tBoghUJZAowIiVW91aNFyqSWm6XRbRJ"
        "aBB8EH47F2Tvw6u+hUY+TN0yD2hhQeCbvcbqbO3SzGzd7x/GHHLPDUSK9urwotaxbzHX9p"
        "uaXr+u6xLdRPFkJsRreEjjnpwwZzI3jy4ALBcXzSdF3tg5wCwZdjeHrLehrVtnDT9Tt9Jc"
        "4i5rejTOX7k8wBnhGmNGPpKyPp0z7UguLtsBMTT00d3OFHXUc5xiTkcuJazH/VcvCsnsPs"
        "q1l5oqbn8G2tnnXB99P3qwjReLxIu9rxk7WrD9aRXznZQUAAA=="
    ),
    (
        "/v4BAAAARlJLZXkAH4sIAAAAAAAA/71UPY4VMQyWKDhHehQpcZxMQonE09YUdOgpvxLSakGI"
        "LbZhC25AQbXiAPR7A6DhCnR0nIECx5mZtw9GgmIXOVK+eD77s51olAChyDTteiDwfMLuceLn"
        "g+t3V/dOnl2//f71w+k3JAYI40SpMU5TyNKp7CUGq2XsRwxTUzmYHHShPMTEZME466X1RUuE"
        "aGRsIUqvSmhZT4Rnrav7p+8vL3ZfPrpPn388fPJm1TIWmopFpqpJIQEFt9jkhDqmikXXKRP3"
        "NrJwxdEopdFmOSWfJGoHMmJwsirwtdoYwP5Fq2nAUDBLrTlDIlXvDI9I2dRyc8jTRmFE8EHQ"
        "NpE4RXuBfB8GDO+09HCo2dE55pgDFA2/h4U5zB3C/uD4Gxwl0ovzs1LLvsVc969qfv6y7kt8"
        "HcWjnRA7JktN9T0mSGAs4C8MVwqIp4NiDr4d68+A6Yrr6SPoNrrs6QdCtu08q5q5mWeY6VfA"
        "D7jjxbtRstkuGY+lVhYuwA5Nw5pLrYbxoq7ZzHiS7Ol2h73Yf+plZbmjC1l6GbXC/DNYels6"
        "OHyH/zGsjSZhu8nbemN3NqxfxUsDKmUFAAA="
    ),
    (
        "/v4BAAAARlJLZXkAH4sIAAAAAAAA/7VSO05dMRCVUrAO98iSxx7/UiLxRE2RDj35K0VCCU"
        "JQ0CQFO6BIhVgAPTuANNkCXbqsIUXmjrkPHhBBATpX8vG5xz6esZXQQhGARhhMB57hpDjx"
        "d/Pq7PzDzt7V6e9fF/u3SA4tjBO1peR9LNKpEiRGCzJNU4y+qxJNiVBpH3Jitto4G6QNF"
        "STqZGTqMcmgauwFPPG7rPON/R/fTxY/L931zZ+Pu99WWcbqrlKVuQElZE2Le+rSI6TcsEL"
        "zhbxvsQufOBmlAG2RPocsEZyWCaOTTenQmk1R2xeyOmiMFYsE4B0ypQZnuEXK5l66Q+42C"
        "iOCU4IGT+G0OgjH92G04ZEkL+xTKaxLRIeg3OwJj5cBX/YDDwh8ICiRvx5/qa0ueyptedj"
        "K54O2rOkoia2FEAuOlFPQNlEi49P8h+nKosWnYcF7bc1lZqInovjwhiYTDAO4NwNDQ1aQ3"
        "yn8JwBnYtci5wBgjBjgBzMYcP/wDiPgmSL1q4pcudzaqeYzzOUN4Kq8uchZn/DuXXymSHx"
        "VkW/Y6Pfu4j/oBaaQ5AQAAA=="
    ),
    (
        "/v4BAAAARlJLZXkAH4sIAAAAAAAA/7VRPW4VMRCWKDiH+8iSZzz22pSReKJOQYee/CshR"
        "RAhKNJAwQ1SUEUcgD43ABquQEfHGSiYHWc375EnkSLR7K6//fzNfJ6xUagMB/AKA2GQP5"
        "oZr/4cXV1cPnr24urjrx+fT38SK1BZr2pLaZpi0d6UoCk60Gn+pTh1U6ItESrXYSVlh9a"
        "7oF2ooAmT1anHpIOpsReYGF97XT4+/fThfPP9i//67feTk/erl3XYTao6N2CHjJzcU9cT"
        "QcqNKrSpsPY+qsiJkzUGyBU95ZA1gUedKHrdDIbWXIro/uPVASlWKhpAKmR2Dd7KiIzLv"
        "XRPMm1SVgXGvExsLnMHuQ+LVlahzL+Uva0CriCU8YMCudsdYk6j22lhR2VUfv3uVW1121"
        "Np2zetvDxr25reJnW8UWojYs1q9ZQhg/Gg7AhcJaieDwndcHsquwCcgVFW3t2Yc0cszMD"
        "zjOY4bOAWQHuWi8FIRQlYS6G8drUa+weaxDs1uar83qmWMyzuI0gYu37pen+0+uBTPNCk"
        "u1OT9zjoh57iXxlxFrPoBAAA"
    ),
]

_TORSO_HIP_SOCKET_REGION_TOKENS = [
    (
        "/v4BAAAARlJLZXkAH4sIAAAAAAAA/61SPUqEMRAFT5JeBvIz+ZJ0Irh4AtFClskkAUFUFj2B"
        "jdhpLXsAe1svYG1nZyf2NhYm+fhWLdRGJmTeTF7eC0mk0ELWUDWrEWnfK2ydQbyv313frG3v"
        "350/PywPn7AytDCDSJnIucAwSPaAwSqgVmJwRXIwHFSqOpUZc4le6wScbAH0ZCGwKuB1TjJq"
        "pUJKo9dy7/H27WXj8mJ3ccWv+X7lhaYMxRGY5COgDAQhWwlE0bIhl4xr58J/UOknTsqzL86B"
        "8UMGJJsgxloys4q6ZO/4Dy/D5KhECdIEBCzWA3kKkFEOLg2uaLb9tlEYoQOKmkw1r7vbzbf3"
        "MMr1XMfUkF2+wbEhW/5SYpeMx2dHKad5Ic7zReaDkzxPdEpicybETPhKgfbAWxVWMA7dVzpc"
        "UZTYGSn6s7diyf5x2qcZQ/Z5qrX4wUH/5vB9cVKcouIPGysjAq4CAAA="
    ),
    (
        "/v4BAAAARlJLZXkAH4sIAAAAAAAA/61SvUoEMRAGnyS9DGTys0k6ERSfQLSQYzJJQBAV0"
        "SewETut5R7A/lpfwNrOzk7sbSxMsnfHCR42kt2dmcyX7xv2ixRKyLqwRhwz5Xtl2s4gv"
        "jZn9w8be0ez67fn6cmrqQgl9CBSJnIucAwSPZhgEaiVJrgiOWgOmCpPRcZcolcqASdbwH"
        "iyEBgLeJWTjAoxpDRqTQ9fHj/ft25vDi7u+CM/LbWMLkNxBDr5CEYGgpCtBKJoWZNL2rW"
        "5zD+w9IkTevbFOdB+yGDIJoixlsyMUZXsHf+hpZkclShB6mDAFOuBPAXIRg4uDa4otv1"
        "vG6GFRi1qaOL1Md0NjaMrlQ66MStb2D37gVHLY67TxrOr05TTpBDnyUXm4/M8SXRJYnt"
        "XiF3hKwQazY5oZgOO1bLREtUSFPs1XdtcPT7OIvswan6bRgSsUdC/KOhFU46cqr84X7J"
        "/F3WL6huKP8oRwQIAAA=="
    ),
    (
        "/v4BAAAARlJLZXkAH4sIAAAAAAAA/61SPUqEMRAFT5JeBvL/04ng4glEC1kmMwkIorLo"
        "CWzETmvZA9hv6wWs7ezsxN7Gwnz53FULtZEJmfcmL/NCEim0kC1Uy2pEOnZmh4oXb+uL"
        "65u17f3F+dP9/PDRNoUWxgsuiCEkAi8pgk1OAQ7UplAlJUNJcevTlLnUHLVmIHYVbEQHi"
        "VSFqAvLrJVKzKPXfO/h9vV54/Jid3ZFL+Vu5WVN9TUgGI4ZrEwIqTgJiNmRwcAmDOey/9"
        "Cln5hVpFhDABN9AYuOIedGiUhlXUsM9IeXIQxYswRpkgVbXQSMmKBY6QP7UDW5fttWGK"
        "GTFS2ZZt52t/39PYwKPQ/woyB7+8+CHPIXanvLfHx2xIWnFalMZ4UOTsqU8RTF5kSIiYh"
        "NAsMDbzXYwDh0X+lwJVFiZ5Toz9pKJfvHGT7NGLLPS67FDw76N4fvi8uOy2j4HTnwdmi"
        "uAgAA"
    ),
    (
        "/v4BAAAARlJLZXkAH4sIAAAAAAAA/61Su0pEMRAFvyS9DGTyuEk6ERS/QLSQZTJJQBAV0"
        "S+wETutZT/Aflt/wNrOzk7sbSxMcneXFVxsJNzMTObknCHnSqGErAtrxDFTvlemnQzia3"
        "N2/7CxdzS7fnuenryailBCDyJlIucCwyDZgwkWgVppgiuSg+aAqfJUZMwleqUScLIFjCc"
        "LgbGAVznJqBBDSqPW9PDl8fN96/bm4OKOP/LTUsvoMhRHoJOPYGQgCNlKIIqWNbmkXZvL"
        "/ANLnzihZ1+cA+2HDIZsghhrycwYVcne8R9amslRiRKkDgZMsR7IU4Bs5ODS4Ipi21/b"
        "CC00alFDE2/63Q2NoyuVDroxK0fYPfuBUctrrtPGs6vTlNOkEOfJRebj8zxJdElie1eIX"
        "eErBBrNjmhmA47VstES1RIU+zVd21y9Ps4i+zBq/jeNCFijoH9R0IumHDlV/3C+ZN8Xd"
        "YvqG5tR4yHBAgAA"
    ),
]


BINDING_PLAN: dict[str, Any] = {
    "schema": BINDING_PLAN_SCHEMA,
    "reference_frame_bindings": [
        {
            "frame_role": CAD + "S17BodyFrameRole",
            "occurrence_id": "torso",
        }
    ],
    "occurrence_role_bindings": [
        {
            "id": "torso",
            "functional_role": CAD + "BodyRole",
            "full_path": "S12_Minifigure_Torso_A0002:1+TORSO:1",
        },
        {
            "id": "head",
            "functional_role": CAD + "HeadRole",
            "full_path": "S11_Minifigure_Head_A0002:1+HEAD:1",
        },
        {
            "id": "hips",
            "functional_role": CAD + "HipsRole",
            "full_path": (
                "S13_Minifigure_Hips_A0015_FitCorrected:1+"
                "S13_HIPS_COMPONENT:1"
            ),
        },
        {
            "id": "left-leg",
            "functional_role": CAD + "LeftLegRole",
            "full_path": "S14_Minifigure_Legs_A0002:1+Left Leg:1",
        },
        {
            "id": "right-leg",
            "functional_role": CAD + "RightLegRole",
            "full_path": "S14_Minifigure_Legs_A0002:1+Right Leg:1",
        },
        {
            "id": "left-arm",
            "functional_role": CAD + "LeftArmRole",
            "full_path": "S15_Minifigure_Arms_A0002:1+Left Arm:1",
        },
        {
            "id": "right-arm",
            "functional_role": CAD + "RightArmRole",
            "full_path": "S15_Minifigure_Arms_A0002:1+Right Arm:1",
        },
        {
            "id": "left-hand",
            "functional_role": CAD + "LeftHandRole",
            "full_path": "S16_Minifigure_Hands_A0002:1+Left Hand:1",
        },
        {
            "id": "right-hand",
            "functional_role": CAD + "RightHandRole",
            "full_path": "S16_Minifigure_Hands_A0002:1+Left Hand(镜像):1",
        },
    ],
    "landmark_bindings": [
        {
            "id": "left-leg-heel",
            "occurrence_id": "left-leg",
            "functional_role": CAD + "LeftLegRole",
            "landmark_role": CAD + "HeelLandmarkRole",
            "selector": {
                "kind": "entity_token_point",
                "entity_token": _LEFT_LEG_HEEL_VERTEX_TOKEN,
            },
        },
        {
            "id": "left-leg-toe",
            "occurrence_id": "left-leg",
            "functional_role": CAD + "LeftLegRole",
            "landmark_role": CAD + "ToeLandmarkRole",
            "selector": {
                "kind": "entity_token_point",
                "entity_token": _LEFT_LEG_TOE_VERTEX_TOKEN,
            },
        },
        {
            "id": "right-leg-heel",
            "occurrence_id": "right-leg",
            "functional_role": CAD + "RightLegRole",
            "landmark_role": CAD + "HeelLandmarkRole",
            "selector": {
                "kind": "entity_token_point",
                "entity_token": _RIGHT_LEG_HEEL_VERTEX_TOKEN,
            },
        },
        {
            "id": "right-leg-toe",
            "occurrence_id": "right-leg",
            "functional_role": CAD + "RightLegRole",
            "landmark_role": CAD + "ToeLandmarkRole",
            "selector": {
                "kind": "entity_token_point",
                "entity_token": _RIGHT_LEG_TOE_VERTEX_TOKEN,
            },
        },
        {
            "id": "left-hand-proximal",
            "occurrence_id": "left-hand",
            "functional_role": CAD + "LeftHandRole",
            "landmark_role": CAD + "ProximalLandmarkRole",
            "selector": {
                "kind": "joint_geometry_origin",
                "joint_id": "left-wrist-joint",
                "side": "one",
            },
        },
        {
            "id": "left-hand-distal",
            "occurrence_id": "left-hand",
            "functional_role": CAD + "LeftHandRole",
            "landmark_role": CAD + "DistalLandmarkRole",
            "selector": {
                "kind": "entity_token_point",
                "entity_token": _LEFT_HAND_DISTAL_VERTEX_TOKEN,
            },
        },
        {
            "id": "right-hand-proximal",
            "occurrence_id": "right-hand",
            "functional_role": CAD + "RightHandRole",
            "landmark_role": CAD + "ProximalLandmarkRole",
            "selector": {
                "kind": "joint_geometry_origin",
                "joint_id": "right-wrist-joint",
                "side": "one",
            },
        },
        {
            "id": "right-hand-distal",
            "occurrence_id": "right-hand",
            "functional_role": CAD + "RightHandRole",
            "landmark_role": CAD + "DistalLandmarkRole",
            "selector": {
                "kind": "entity_token_point",
                "entity_token": _RIGHT_HAND_DISTAL_VERTEX_TOKEN,
            },
        },
        {
            "id": "hips-center",
            "occurrence_id": "hips",
            "functional_role": CAD + "HipsRole",
            "landmark_role": CAD + "HipsCenterLandmarkRole",
            "selector": {
                "kind": "occurrence_origin",
            },
        },
        {
            "id": "left-leg-hip-pivot",
            "occurrence_id": "left-leg",
            "functional_role": CAD + "LeftLegRole",
            "landmark_role": CAD + "HipPivotLandmarkRole",
            "selector": {
                "kind": "joint_geometry_origin",
                "joint_id": "left-leg-joint",
                "side": "one",
            },
        },
        {
            "id": "right-leg-hip-pivot",
            "occurrence_id": "right-leg",
            "functional_role": CAD + "RightLegRole",
            "landmark_role": CAD + "HipPivotLandmarkRole",
            "selector": {
                "kind": "joint_geometry_origin",
                "joint_id": "right-leg-joint",
                "side": "one",
            },
        },
        {
            "id": "left-foot-reference",
            "occurrence_id": "left-leg",
            "functional_role": CAD + "LeftLegRole",
            "landmark_role": CAD + "FootReferenceLandmarkRole",
            "selector": {
                "kind": "entity_token_point",
                "entity_token": _LEFT_LEG_TOE_VERTEX_TOKEN,
            },
        },
        {
            "id": "right-foot-reference",
            "occurrence_id": "right-leg",
            "functional_role": CAD + "RightLegRole",
            "landmark_role": CAD + "FootReferenceLandmarkRole",
            "selector": {
                "kind": "entity_token_point",
                "entity_token": _RIGHT_LEG_TOE_VERTEX_TOKEN,
            },
        },
    ],
    "interface_pair_bindings": [
        {
            "id": "left-wrist-pair",
            "interface_pair_role": CAD + "S17LeftWristPairRole",
            "first": {
                "id": "left-hand-post-interface",
                "interface_role": CAD + "S17LeftHandPostInterfaceRole",
                "occurrence_id": "left-hand",
                "entity_tokens": [_LEFT_WRIST_HAND_TOKEN],
            },
            "second": {
                "id": "left-arm-wrist-socket-interface",
                "interface_role": CAD + "S17LeftArmWristSocketInterfaceRole",
                "occurrence_id": "left-arm",
                "entity_tokens": [_LEFT_WRIST_ARM_TOKEN],
            },
        },
        {
            "id": "right-wrist-pair",
            "interface_pair_role": CAD + "S17RightWristPairRole",
            "first": {
                "id": "right-hand-post-interface",
                "interface_role": CAD + "S17RightHandPostInterfaceRole",
                "occurrence_id": "right-hand",
                "entity_tokens": [_RIGHT_WRIST_HAND_TOKEN],
            },
            "second": {
                "id": "right-arm-wrist-socket-interface",
                "interface_role": CAD + "S17RightArmWristSocketInterfaceRole",
                "occurrence_id": "right-arm",
                "entity_tokens": [_RIGHT_WRIST_ARM_TOKEN],
            },
        },
        {
            "id": "left-hip-leg-pair",
            "interface_pair_role": CAD + "S17LeftHipLegPairRole",
            "first": {
                "id": "left-leg-moving-interface",
                "interface_role": CAD + "S17LeftLegMovingInterfaceRole",
                "occurrence_id": "left-leg",
                "entity_tokens": [_LEFT_LEG_TOKEN],
            },
            "second": {
                "id": "left-hip-fixed-interface",
                "interface_role": CAD + "S17LeftHipFixedInterfaceRole",
                "occurrence_id": "hips",
                "entity_tokens": [_LEFT_HIP_TOKEN],
            },
        },
        {
            "id": "right-hip-leg-pair",
            "interface_pair_role": CAD + "S17RightHipLegPairRole",
            "first": {
                "id": "right-leg-moving-interface",
                "interface_role": CAD + "S17RightLegMovingInterfaceRole",
                "occurrence_id": "right-leg",
                "entity_tokens": [_RIGHT_LEG_TOKEN],
            },
            "second": {
                "id": "right-hip-fixed-interface",
                "interface_role": CAD + "S17RightHipFixedInterfaceRole",
                "occurrence_id": "hips",
                "entity_tokens": [_RIGHT_HIP_TOKEN],
            },
        },
        {
            "id": "hips-torso-pair",
            "interface_pair_role": CAD + "S17HipsTorsoPairRole",
            "first": {
                "id": "hips-press-region-interface",
                "interface_role": CAD + "S17HipsPressInterfaceRole",
                "occurrence_id": "hips",
                "entity_tokens": _HIPS_PRESS_REGION_TOKENS,
            },
            "second": {
                "id": "torso-hip-socket-region-interface",
                "interface_role": CAD + "S17TorsoHipSocketInterfaceRole",
                "occurrence_id": "torso",
                "entity_tokens": _TORSO_HIP_SOCKET_REGION_TOKENS,
            },
        },
    ],
    "joint_bindings": [
        {
            "id": "hips-torso-joint",
            "joint_role": CAD + "S17HipsTorsoJointRole",
            "name": "Hips to Torso",
            "moving_occurrence_id": "hips",
            "fixed_occurrence_id": "torso",
        },
        {
            "id": "head-joint",
            "joint_role": CAD + "S17HeadJointRole",
            "name": "Head to Torso",
            "moving_occurrence_id": "head",
            "fixed_occurrence_id": "torso",
        },
        {
            "id": "left-arm-joint",
            "joint_role": CAD + "S17LeftArmJointRole",
            "name": "Left Arm to Torso",
            "moving_occurrence_id": "left-arm",
            "fixed_occurrence_id": "torso",
        },
        {
            "id": "right-arm-joint",
            "joint_role": CAD + "S17RightArmJointRole",
            "name": "Right Arm to Torso",
            "moving_occurrence_id": "right-arm",
            "fixed_occurrence_id": "torso",
        },
        {
            "id": "left-wrist-joint",
            "joint_role": CAD + "S17LeftWristJointRole",
            "name": "Left Hand to Left Arm",
            "moving_occurrence_id": "left-hand",
            "fixed_occurrence_id": "left-arm",
            "moving_interface_id": "left-hand-post-interface",
            "fixed_interface_id": "left-arm-wrist-socket-interface",
        },
        {
            "id": "right-wrist-joint",
            "joint_role": CAD + "S17RightWristJointRole",
            "name": "Right Hand to Right Arm",
            "moving_occurrence_id": "right-hand",
            "fixed_occurrence_id": "right-arm",
            "moving_interface_id": "right-hand-post-interface",
            "fixed_interface_id": "right-arm-wrist-socket-interface",
        },
        {
            "id": "left-leg-joint",
            "joint_role": CAD + "S17LeftLegJointRole",
            "name": "Left Leg to Hips",
            "moving_occurrence_id": "left-leg",
            "fixed_occurrence_id": "hips",
            "moving_interface_id": "left-leg-moving-interface",
            "fixed_interface_id": "left-hip-fixed-interface",
        },
        {
            "id": "right-leg-joint",
            "joint_role": CAD + "S17RightLegJointRole",
            "name": "Right Leg to Hips",
            "moving_occurrence_id": "right-leg",
            "fixed_occurrence_id": "hips",
            "moving_interface_id": "right-leg-moving-interface",
            "fixed_interface_id": "right-hip-fixed-interface",
        },
    ],
}


def build_snapshot_script() -> str:
    """Build the exact read-only Fusion script for this saved version."""

    return build_functional_assembly_snapshot_script(
        expected_document_name=EXPECTED_DOCUMENT["name"],
        expected_lineage_id=EXPECTED_DOCUMENT["lineage_id"],
        expected_version_id=EXPECTED_DOCUMENT["version_id"],
        binding_plan=BINDING_PLAN,
    )


if __name__ == "__main__":
    print(build_snapshot_script())


__all__ = [
    "BINDING_PLAN",
    "EXPECTED_DOCUMENT",
    "EXPECTED_NATIVE_INVENTORY",
    "PROFILE_IRI",
    "build_snapshot_script",
]
