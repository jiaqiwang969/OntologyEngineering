#!/usr/bin/env python3
"""Deterministically build and verify the release-locked S19 native bridge."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import plistlib
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Sequence


LOCK_PATH = Path(__file__).with_name("motion_study_qt_probe.v36.lock.json")
RESULT_SCHEMA = "cad-agent.motion-study-native-build-result.v1"


class MotionStudyBuildError(RuntimeError):
    """Raised when a release lock or deterministic build condition fails."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_lock(path: Path = LOCK_PATH) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise MotionStudyBuildError(f"unable to read lock {path}: {exc}") from exc
    if value.get("schema") != "cad-agent.motion-study-native-lock.v1":
        raise MotionStudyBuildError("unsupported Motion Study native lock schema")
    return value


def default_repo_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _run(command: Sequence[str], *, env: dict[str, str] | None = None) -> str:
    try:
        completed = subprocess.run(
            list(command),
            check=False,
            capture_output=True,
            text=True,
            env=env,
        )
    except OSError as exc:
        raise MotionStudyBuildError(
            f"unable to execute {command[0]!r}: {exc}"
        ) from exc
    if completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip()
        raise MotionStudyBuildError(
            f"command failed ({completed.returncode}): "
            + " ".join(command)
            + (f"\n{detail}" if detail else "")
        )
    return completed.stdout


def _require_file(path: Path, label: str) -> Path:
    resolved = path.expanduser().resolve()
    if not resolved.is_file():
        raise MotionStudyBuildError(f"{label} is not a file: {resolved}")
    return resolved


def _require_directory(path: Path, label: str) -> Path:
    resolved = path.expanduser().resolve()
    if not resolved.is_dir():
        raise MotionStudyBuildError(f"{label} is not a directory: {resolved}")
    return resolved


def _arm64_uuid(path: Path) -> str:
    output = _run(["xcrun", "dwarfdump", "--uuid", str(path)])
    match = re.search(
        r"^UUID:\s+([0-9A-Fa-f-]+)\s+\(arm64\)",
        output,
        flags=re.MULTILINE,
    )
    if match is None:
        raise MotionStudyBuildError(f"arm64 Mach-O UUID not found: {path}")
    return match.group(1).upper()


def _fusion_release(fusion_contents: Path) -> str:
    plist_path = _require_file(fusion_contents / "Info.plist", "Fusion Info.plist")
    try:
        with plist_path.open("rb") as stream:
            info = plistlib.load(stream)
    except (OSError, plistlib.InvalidFileException) as exc:
        raise MotionStudyBuildError(f"unable to read {plist_path}: {exc}") from exc
    release = str(info.get("CFBundleShortVersionString", ""))
    if not release:
        raise MotionStudyBuildError("Fusion Info.plist has no release version")
    return release


def _source_path(lock: dict[str, Any], repo_root: Path) -> Path:
    relative = Path(str(lock["source"]["path"]))
    if relative.is_absolute() or ".." in relative.parts:
        raise MotionStudyBuildError("locked source path must be repository-relative")
    return _require_file(repo_root / relative, "locked bridge source")


def _check_source(lock: dict[str, Any], repo_root: Path) -> tuple[Path, str]:
    source = _source_path(lock, repo_root)
    actual = sha256_file(source)
    expected = str(lock["source"]["sha256"])
    if actual != expected:
        raise MotionStudyBuildError(
            f"bridge source hash drift: expected {expected}, actual {actual}"
        )
    return source, actual


def _check_toolchain(lock: dict[str, Any], qt_prefix: Path) -> dict[str, str]:
    expected = lock["toolchain"]
    architecture = platform.machine()
    if architecture != expected["architecture"]:
        raise MotionStudyBuildError(
            f"host architecture mismatch: expected {expected['architecture']}, "
            f"actual {architecture}"
        )

    clang_line = _run(["xcrun", "--sdk", "macosx", "clang++", "--version"])
    clang_line = clang_line.splitlines()[0]
    if (
        f"Apple clang version {expected['apple_clang_version']}" not in clang_line
        or expected["apple_clang_build"] not in clang_line
    ):
        raise MotionStudyBuildError(
            "Apple clang release drift: " + clang_line
        )

    sdk_version = _run(
        ["xcrun", "--sdk", "macosx", "--show-sdk-version"]
    ).strip()
    if sdk_version != expected["macos_sdk_version"]:
        raise MotionStudyBuildError(
            f"macOS SDK drift: expected {expected['macos_sdk_version']}, "
            f"actual {sdk_version}"
        )

    qmake = _require_file(qt_prefix / "bin/qmake", "Qt qmake")
    qt_version = _run([str(qmake), "-query", "QT_VERSION"]).strip()
    if qt_version != expected["qt_header_version"]:
        raise MotionStudyBuildError(
            f"Qt header release drift: expected {expected['qt_header_version']}, "
            f"actual {qt_version}"
        )
    for framework in ("QtCore", "QtGui", "QtWidgets"):
        _require_directory(
            qt_prefix / f"lib/{framework}.framework/Headers",
            f"{framework} headers",
        )
    _require_directory(
        qt_prefix / "share/qt/mkspecs/macx-clang",
        "Qt macx-clang mkspec",
    )
    return {
        "architecture": architecture,
        "clang": clang_line,
        "macos_sdk": sdk_version,
        "qt_headers": qt_version,
    }


def _check_fusion(
    lock: dict[str, Any], fusion_contents: Path
) -> tuple[dict[str, Any], dict[str, Path]]:
    expected = lock["fusion"]
    release = _fusion_release(fusion_contents)
    if release != expected["release"]:
        raise MotionStudyBuildError(
            f"Fusion release drift: expected {expected['release']}, actual {release}"
        )

    paths: dict[str, Path] = {}
    uuids: dict[str, str] = {}
    for item in [
        *expected["linked_libraries"],
        *expected["private_runtime_images"],
    ]:
        relative = str(item["path"])
        path = _require_file(fusion_contents / relative, f"Fusion image {relative}")
        actual_uuid = _arm64_uuid(path)
        locked_uuid = str(item["arm64_uuid"]).upper()
        if actual_uuid != locked_uuid:
            raise MotionStudyBuildError(
                f"Fusion image UUID drift for {relative}: "
                f"expected {locked_uuid}, actual {actual_uuid}"
            )
        paths[relative] = path
        uuids[relative] = actual_uuid
    return {"release": release, "arm64_uuids": uuids}, paths


def preflight(
    lock: dict[str, Any],
    *,
    repo_root: Path,
    fusion_contents: Path,
    qt_prefix: Path,
) -> dict[str, Any]:
    repo_root = _require_directory(repo_root, "repository root")
    fusion_contents = _require_directory(fusion_contents, "Fusion Contents")
    qt_prefix = _require_directory(qt_prefix, "Qt prefix")
    source, source_hash = _check_source(lock, repo_root)
    fusion, _ = _check_fusion(lock, fusion_contents)
    toolchain = _check_toolchain(lock, qt_prefix)
    api_include = _require_directory(
        fusion_contents / "Libraries/Neutron/CPP/include",
        "Fusion C++ API include directory",
    )
    return {
        "profile_id": lock["profile_id"],
        "source": str(source),
        "source_sha256": source_hash,
        "fusion_contents": str(fusion_contents),
        "fusion": fusion,
        "fusion_api_include": str(api_include),
        "toolchain": toolchain,
    }


def compile_command(
    lock: dict[str, Any],
    *,
    source: Path,
    output: Path,
    fusion_contents: Path,
    qt_prefix: Path,
) -> list[str]:
    architecture = str(lock["toolchain"]["architecture"])
    cxx_standard = str(lock["toolchain"]["cxx_standard"])
    install_name = str(lock["binary"]["install_name"])
    api_include = fusion_contents / "Libraries/Neutron/CPP/include"
    linked = {
        item["path"]: fusion_contents / item["path"]
        for item in lock["fusion"]["linked_libraries"]
    }
    return [
        "xcrun",
        "--sdk",
        "macosx",
        "clang++",
        f"-std={cxx_standard}",
        "-arch",
        architecture,
        "-O2",
        "-fPIC",
        "-dynamiclib",
        "-Wall",
        "-Wextra",
        "-Wpedantic",
        "-Werror",
        "-DQT_NO_VERSION_TAGGING",
        f"-F{qt_prefix / 'lib'}",
        f"-I{qt_prefix / 'lib/QtWidgets.framework/Headers'}",
        f"-I{qt_prefix / 'lib/QtWidgets.framework'}",
        f"-I{qt_prefix / 'lib/QtGui.framework/Headers'}",
        f"-I{qt_prefix / 'lib/QtGui.framework'}",
        f"-I{qt_prefix / 'lib/QtCore.framework/Headers'}",
        f"-I{qt_prefix / 'lib/QtCore.framework'}",
        f"-I{qt_prefix / 'share/qt/mkspecs/macx-clang'}",
        f"-I{qt_prefix / 'include'}",
        f"-I{api_include}",
        str(source),
        str(linked["Libraries/Neutron/XInterface10.dylib"]),
        str(linked["Libraries/Neutron/FusionXInterface10.dylib"]),
        "-lobjc",
        "-framework",
        "CoreGraphics",
        "-framework",
        "CoreFoundation",
        "-Wl,-undefined,dynamic_lookup",
        f"-Wl,-install_name,{install_name}",
        "-o",
        str(output),
    ]


def _otool_dependencies(path: Path) -> list[str]:
    output = _run(["otool", "-L", str(path)])
    dependencies: list[str] = []
    for line in output.splitlines()[1:]:
        stripped = line.strip()
        if stripped:
            dependencies.append(stripped.split(" (compatibility version", 1)[0])
    return dependencies


def _export_offsets(path: Path) -> dict[str, int]:
    output = _run(["nm", "-gU", str(path)])
    result: dict[str, int] = {}
    pattern = re.compile(r"^([0-9A-Fa-f]+)\s+\S\s+_(\S+)$")
    for line in output.splitlines():
        match = pattern.match(line.strip())
        if match is not None:
            result[match.group(2)] = int(match.group(1), 16)
    return result


def _build_versions(path: Path) -> tuple[str, str]:
    output = _run(["otool", "-l", str(path)])
    match = re.search(
        r"cmd LC_BUILD_VERSION\s+"
        r"cmdsize \d+\s+"
        r"platform \d+\s+"
        r"minos ([0-9.]+)\s+"
        r"sdk ([0-9.]+)",
        output,
    )
    if match is None:
        raise MotionStudyBuildError("LC_BUILD_VERSION was not found")
    return match.group(1), match.group(2)


def verify_binary(lock: dict[str, Any], path: Path) -> dict[str, Any]:
    path = _require_file(path, "Motion Study bridge binary")
    expected = lock["binary"]
    actual_hash = sha256_file(path)
    if actual_hash != expected["sha256"]:
        raise MotionStudyBuildError(
            f"binary hash drift: expected {expected['sha256']}, "
            f"actual {actual_hash}"
        )

    file_description = _run(["file", str(path)]).strip()
    if "Mach-O 64-bit dynamically linked shared library arm64" not in file_description:
        raise MotionStudyBuildError(
            "bridge is not an arm64 Mach-O shared library: " + file_description
        )

    actual_uuid = _arm64_uuid(path)
    if actual_uuid != str(expected["arm64_uuid"]).upper():
        raise MotionStudyBuildError(
            f"binary UUID drift: expected {expected['arm64_uuid']}, "
            f"actual {actual_uuid}"
        )

    install_lines = [
        line.strip()
        for line in _run(["otool", "-D", str(path)]).splitlines()[1:]
        if line.strip()
    ]
    if install_lines != [expected["install_name"]]:
        raise MotionStudyBuildError(
            f"install name drift: expected {expected['install_name']!r}, "
            f"actual {install_lines!r}"
        )

    dependencies = _otool_dependencies(path)
    if dependencies != expected["required_dependencies"]:
        raise MotionStudyBuildError(
            "linked dependency drift: expected "
            + repr(expected["required_dependencies"])
            + ", actual "
            + repr(dependencies)
        )
    for fragment in expected["forbidden_linked_dependency_fragments"]:
        if any(fragment in dependency for dependency in dependencies):
            raise MotionStudyBuildError(
                f"forbidden linked Qt dependency present: {fragment}"
            )

    offsets = _export_offsets(path)
    observed_offsets: dict[str, str] = {}
    for symbol, hexadecimal_offset in expected["required_exports"].items():
        locked_offset = int(hexadecimal_offset, 16)
        actual_offset = offsets.get(symbol)
        if actual_offset != locked_offset:
            raise MotionStudyBuildError(
                f"export offset drift for {symbol}: expected "
                f"0x{locked_offset:04x}, actual "
                + ("missing" if actual_offset is None else f"0x{actual_offset:04x}")
            )
        observed_offsets[symbol] = f"0x{actual_offset:04x}"

    undefined = _run(["nm", "-u", str(path)])
    for fragment in expected["forbidden_undefined_symbol_fragments"]:
        if fragment in undefined:
            raise MotionStudyBuildError(
                f"forbidden undefined symbol fragment present: {fragment}"
            )

    minos, sdk = _build_versions(path)
    toolchain = lock["toolchain"]
    if minos != toolchain["macos_deployment_target"]:
        raise MotionStudyBuildError(
            f"deployment target drift: expected "
            f"{toolchain['macos_deployment_target']}, actual {minos}"
        )
    if sdk != toolchain["macos_sdk_version"]:
        raise MotionStudyBuildError(
            f"binary SDK drift: expected {toolchain['macos_sdk_version']}, "
            f"actual {sdk}"
        )

    return {
        "path": str(path),
        "sha256": actual_hash,
        "arm64_uuid": actual_uuid,
        "install_name": install_lines[0],
        "dependencies": dependencies,
        "required_exports": observed_offsets,
        "macos_deployment_target": minos,
        "macos_sdk": sdk,
    }


def build(
    lock: dict[str, Any],
    *,
    repo_root: Path,
    fusion_contents: Path,
    qt_prefix: Path,
    output: Path,
) -> dict[str, Any]:
    checks = preflight(
        lock,
        repo_root=repo_root,
        fusion_contents=fusion_contents,
        qt_prefix=qt_prefix,
    )
    output = output.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        verification = verify_binary(lock, output)
        return {"reused": True, "preflight": checks, "binary": verification}

    source = Path(checks["source"])
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=output.name + ".",
        suffix=".building",
        dir=output.parent,
    )
    os.close(descriptor)
    temporary = Path(temporary_name)
    try:
        command = compile_command(
            lock,
            source=source,
            output=temporary,
            fusion_contents=fusion_contents.expanduser().resolve(),
            qt_prefix=qt_prefix.expanduser().resolve(),
        )
        environment = os.environ.copy()
        environment["MACOSX_DEPLOYMENT_TARGET"] = str(
            lock["toolchain"]["macos_deployment_target"]
        )
        _run(command, env=environment)
        verification = verify_binary(lock, temporary)
        try:
            os.link(temporary, output)
        except FileExistsError:
            verification = verify_binary(lock, output)
            return {
                "reused": True,
                "concurrent_identical_build": True,
                "preflight": checks,
                "binary": verification,
            }
        final_verification = verify_binary(lock, output)
        return {
            "reused": False,
            "preflight": checks,
            "binary": final_verification,
            "compile_command": command,
        }
    finally:
        temporary.unlink(missing_ok=True)


def _common_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--lock",
        type=Path,
        default=LOCK_PATH,
        help="release lock JSON (defaults to the colocated v36 lock)",
    )
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=default_repo_root(),
        help="cad-agent repository root",
    )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="operation", required=True)

    preflight_parser = subparsers.add_parser(
        "preflight", help="verify source, Fusion release, UUIDs, Qt, and compiler"
    )
    _common_arguments(preflight_parser)
    preflight_parser.add_argument("--fusion-contents", type=Path, required=True)
    preflight_parser.add_argument("--qt-prefix", type=Path, default=Path("/opt/homebrew"))

    build_parser = subparsers.add_parser(
        "build", help="preflight, compile, and verify the locked dylib"
    )
    _common_arguments(build_parser)
    build_parser.add_argument("--fusion-contents", type=Path, required=True)
    build_parser.add_argument("--qt-prefix", type=Path, default=Path("/opt/homebrew"))
    build_parser.add_argument(
        "--output",
        type=Path,
        default=Path("/private/tmp/cad-agent-motion-study-api-bridge-v36.dylib"),
    )

    verify_parser = subparsers.add_parser(
        "verify-binary", help="verify an existing dylib against the lock"
    )
    _common_arguments(verify_parser)
    verify_parser.add_argument("binary_path", type=Path)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    arguments = _parser().parse_args(argv)
    try:
        lock = load_lock(arguments.lock.expanduser().resolve())
        if arguments.operation == "preflight":
            result = preflight(
                lock,
                repo_root=arguments.repo_root,
                fusion_contents=arguments.fusion_contents,
                qt_prefix=arguments.qt_prefix,
            )
        elif arguments.operation == "build":
            result = build(
                lock,
                repo_root=arguments.repo_root,
                fusion_contents=arguments.fusion_contents,
                qt_prefix=arguments.qt_prefix,
                output=arguments.output,
            )
        else:
            result = verify_binary(lock, arguments.binary_path)
        payload = {
            "schema": RESULT_SCHEMA,
            "ok": True,
            "operation": arguments.operation,
            "profile_id": lock["profile_id"],
            "result": result,
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    except (KeyError, MotionStudyBuildError) as exc:
        payload = {
            "schema": RESULT_SCHEMA,
            "ok": False,
            "operation": getattr(arguments, "operation", None),
            "error": str(exc),
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
        return 1


if __name__ == "__main__":
    sys.exit(main())
