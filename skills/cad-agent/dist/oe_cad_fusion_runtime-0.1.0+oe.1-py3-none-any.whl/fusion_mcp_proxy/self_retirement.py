"""Self-retirement watchdog for stdio MCP server processes.

MCP stdio clients (codex included) respawn a replacement server after a
timeout without closing the abandoned server's stdin pipe, so EOF never
arrives and abandoned processes accumulate for days.  This watchdog retires
the process in two cases, both decided from observable process state only:

1. the client process is gone (this process was orphaned); or
2. the same client process has spawned a strictly newer sibling with an
   identical command line, which means this instance was abandoned.

The watchdog runs on a daemon thread and must never take the server down on
its own errors: every probe failure is swallowed and simply retried on the
next poll.
"""

from __future__ import annotations

import os
import subprocess
import sys
import threading
import time
from dataclasses import dataclass

_LSTART_FORMAT = "%a %b %d %H:%M:%S %Y"


@dataclass(frozen=True)
class ProcessRow:
    pid: int
    started_at: float
    command: str


def _process_rows(pids: list[int]) -> list[ProcessRow]:
    if not pids:
        return []
    result = subprocess.run(
        ["ps", "-p", ",".join(str(pid) for pid in pids), "-o", "pid=,lstart=,command="],
        capture_output=True,
        text=True,
        check=False,
        timeout=10,
    )
    rows: list[ProcessRow] = []
    for line in result.stdout.splitlines():
        parts = line.split(None, 6)
        if len(parts) < 7:
            continue
        pid_text, weekday, month, day, clock, year, command = parts
        try:
            pid = int(pid_text)
            started_at = time.mktime(
                time.strptime(
                    f"{weekday} {month} {day} {clock} {year}", _LSTART_FORMAT
                )
            )
        except ValueError:
            continue
        rows.append(ProcessRow(pid=pid, started_at=started_at, command=command))
    return rows


def _sibling_pids(ppid: int) -> list[int]:
    result = subprocess.run(
        ["pgrep", "-P", str(ppid)],
        capture_output=True,
        text=True,
        check=False,
        timeout=10,
    )
    pids: list[int] = []
    for line in result.stdout.split():
        try:
            pids.append(int(line))
        except ValueError:
            continue
    return pids


def decide_retirement(
    me: ProcessRow, siblings: list[ProcessRow], *, initial_ppid: int, ppid: int
) -> str | None:
    """Return a retirement reason, or None to keep running."""
    if ppid == 1 or ppid != initial_ppid:
        return f"client process gone (ppid {initial_ppid} -> {ppid})"
    for row in siblings:
        if row.pid == me.pid or row.command != me.command:
            continue
        if row.started_at > me.started_at:
            return (
                f"abandoned: client {ppid} spawned identical replacement "
                f"pid {row.pid}"
            )
    return None


def probe_retirement(initial_ppid: int) -> str | None:
    """One-shot synchronous probe; never raises.

    Safe to call from a worker thread of an async server as well as from the
    daemon-thread watchdog below.
    """
    try:
        ppid = os.getppid()
        my_pid = os.getpid()
        me_rows = _process_rows([my_pid])
        if not me_rows:
            return None
        siblings = _process_rows(
            [pid for pid in _sibling_pids(ppid) if pid != my_pid]
        )
        return decide_retirement(
            me_rows[0], siblings, initial_ppid=initial_ppid, ppid=ppid
        )
    except Exception:
        return None


def _watch(poll_seconds: float) -> None:
    initial_ppid = os.getppid()
    while True:
        time.sleep(poll_seconds)
        reason = probe_retirement(initial_ppid)
        if reason is None:
            continue
        print(f"fusion-mcp-cell: self-retiring: {reason}", file=sys.stderr, flush=True)
        os._exit(0)


def start_self_retirement_watchdog(poll_seconds: float = 60.0) -> None:
    thread = threading.Thread(
        target=_watch,
        args=(poll_seconds,),
        name="self-retirement-watchdog",
        daemon=True,
    )
    thread.start()
