"""Generate schema-bound, serial Fusion MCP live-acceptance plans.

This module is deliberately offline: it reads a prior acceptance report and
writes JSON plans, but it never starts Fusion, a GUI bridge, an MCP server, or
an MCP client.  The intended sequence is:

1. generate and run ``schema-first`` (zero tool calls);
2. run one read-only ``project-preflight`` against the exact target ID;
3. generate ``model`` from that host's captured schemas;
4. after an external settle/modal census, generate separate ``read``,
   ``close``, ``reopen``, and ``verify`` plans.

Every generated argument object is validated against the exact captured input
schema for its tool.  A missing, oversized, malformed, or digest-mismatched
schema fails closed instead of falling back to a remembered tool shape.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import tempfile
import textwrap
import uuid
from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from jsonschema import ValidationError
from jsonschema.validators import validator_for

from .acceptance_client import (
    DEFAULT_REQUIRED_TOOLS,
    PLAN_SCHEMA,
    REPORT_SCHEMA,
)

_MARKER_PARAMETER = "MCP_CELL_ACCEPTANCE_MARKER"
_LENGTH_PARAMETER = "MCP_CELL_LENGTH"
_WIDTH_PARAMETER = "MCP_CELL_WIDTH"
_HEIGHT_PARAMETER = "MCP_CELL_HEIGHT"
_UNDO_PARAMETER = "MCP_CELL_UNDO_PROBE"
_BODY_NAME = "MCP_CELL_ACCEPTANCE_BOX"
_SKETCH_NAME = "MCP_CELL_ACCEPTANCE_SKETCH"
_EXTRUDE_NAME = "MCP_CELL_ACCEPTANCE_EXTRUDE"
_EMPTY_ROOT_NAME = "MCP_EMPTY_PARAMETRIC_CHECKPOINT_ROOT"
_FORBIDDEN_SCRIPT_FRAGMENTS = (
    "Commands.Start",
    "Commands.SetPreciseSelections",
    "CommandDefinition.execute",
    "executeTextCommand",
    "adsk.doEvents",
)
_SAFE_NODE = re.compile(r"[^A-Za-z0-9_-]+")


class PlanGenerationError(ValueError):
    """The requested plan cannot be grounded in captured schemas."""


def _canonical_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")


def _sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def schema_first_plan() -> dict[str, Any]:
    """Return the only plan that may be generated without captured schemas."""
    return {
        "schema": PLAN_SCHEMA,
        "required_tools": list(DEFAULT_REQUIRED_TOOLS),
        "calls": [],
    }


def load_captured_tool_schemas(
    path: Path, *, expected_node: str | None = None
) -> dict[str, dict[str, Any]]:
    """Load and content-verify schemas from a production acceptance report."""
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise PlanGenerationError(f"cannot read schema report: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise PlanGenerationError("schema report is not valid JSON") from exc
    if not isinstance(report, Mapping) or report.get("schema") != REPORT_SCHEMA:
        raise PlanGenerationError(
            f"schema report must use the exact {REPORT_SCHEMA} contract"
        )
    if report.get("status") != "pass":
        raise PlanGenerationError("schema-first acceptance report did not pass")
    initialize = report.get("initialize")
    if not isinstance(initialize, Mapping) or (
        not isinstance(initialize.get("production_acceptance"), Mapping)
        or initialize["production_acceptance"].get("status") != "success"
    ):
        raise PlanGenerationError("report is not from a production Fusion MCP cell")
    if expected_node is not None:
        server = initialize.get("server")
        expected_server_name = f"fusion-mcp-cell-{expected_node}"
        if (
            not isinstance(server, Mapping)
            or server.get("name") != expected_server_name
        ):
            raise PlanGenerationError(
                "schema report cell identity does not match --node: expected "
                + expected_server_name
            )
    tools_list = report.get("tools_list")
    if not isinstance(tools_list, Mapping) or tools_list.get("status") != "success":
        raise PlanGenerationError("schema report has no successful tools/list result")
    rows = tools_list.get("tools")
    if not isinstance(rows, list):
        raise PlanGenerationError("schema report tools must be an array")

    schemas: dict[str, dict[str, Any]] = {}
    for index, row in enumerate(rows):
        if not isinstance(row, Mapping):
            raise PlanGenerationError(f"tools[{index}] is not an object")
        name = row.get("name")
        schema_record = row.get("input_schema")
        if not isinstance(name, str) or not name:
            raise PlanGenerationError(f"tools[{index}] has no valid name")
        if not isinstance(schema_record, Mapping):
            raise PlanGenerationError(f"{name} has no captured schema record")
        if schema_record.get("captured") is not True:
            raise PlanGenerationError(f"{name} input schema was not captured")
        payload = schema_record.get("payload")
        if not isinstance(payload, dict):
            raise PlanGenerationError(f"{name} captured schema is not an object")
        encoded = _canonical_bytes(payload)
        digest = _sha256(encoded)
        if schema_record.get("bytes") != len(encoded):
            raise PlanGenerationError(f"{name} captured schema byte count drifted")
        if schema_record.get("sha256") != digest:
            raise PlanGenerationError(f"{name} captured schema digest drifted")
        if row.get("input_schema_sha256") != digest:
            raise PlanGenerationError(f"{name} top-level schema digest drifted")
        try:
            validator_type = validator_for(payload)
            validator_type.check_schema(payload)
        except Exception as exc:
            raise PlanGenerationError(f"{name} input schema is invalid: {exc}") from exc
        if name in schemas:
            raise PlanGenerationError(f"duplicate captured schema for {name}")
        schemas[name] = payload

    missing = sorted(set(DEFAULT_REQUIRED_TOOLS) - set(schemas))
    if missing:
        raise PlanGenerationError(
            "required captured schemas are missing: " + ", ".join(missing)
        )
    return schemas


def _validate_arguments(
    schemas: Mapping[str, dict[str, Any]],
    tool: str,
    arguments: dict[str, Any],
) -> None:
    schema = schemas.get(tool)
    if schema is None:
        raise PlanGenerationError(f"no captured input schema for {tool}")
    validator = validator_for(schema)(schema)
    errors = sorted(validator.iter_errors(arguments), key=lambda item: list(item.path))
    if not errors:
        return
    error: ValidationError = errors[0]
    location = ".".join(str(value) for value in error.path) or "$"
    raise PlanGenerationError(
        f"captured schema rejects {tool} arguments at {location}: {error.message}"
    )


def _call(
    schemas: Mapping[str, dict[str, Any]],
    *,
    identifier: str,
    tool: str,
    arguments: dict[str, Any],
    expect_mcp_error: bool = False,
    expect_inner_success: bool | None = True,
    capture_response: bool = False,
) -> dict[str, Any]:
    _validate_arguments(schemas, tool, arguments)
    return {
        "id": identifier,
        "tool": tool,
        "arguments": arguments,
        "expect_mcp_error": expect_mcp_error,
        "expect_inner_success": expect_inner_success,
        "capture_response": capture_response,
    }


def _plan(calls: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "schema": PLAN_SCHEMA,
        "required_tools": list(DEFAULT_REQUIRED_TOOLS),
        "calls": calls,
    }


def _python_literal(value: str) -> str:
    return json.dumps(value, ensure_ascii=True)


def _check_script(script: str) -> str:
    hits = [fragment for fragment in _FORBIDDEN_SCRIPT_FRAGMENTS if fragment in script]
    if hits:
        raise PlanGenerationError(
            "generated script contains prohibited interactive/event-loop surface: "
            + ", ".join(hits)
        )
    if "def run(_context: str):" not in script:
        raise PlanGenerationError(
            "generated Fusion script has no exact run entry point"
        )
    return script


def _execute_arguments(script: str) -> dict[str, Any]:
    return {
        "featureType": "script",
        "object": {"script": _check_script(script)},
    }


def _geometry_helpers(
    marker: str,
    *,
    creation_id: str | None = None,
    lineage_id: str | None = None,
    version_id: str | None = None,
    cloud_name: str | None = None,
    project_id: str | None = None,
    folder_id: str | None = None,
    version_number: int | None = None,
    require_modified: bool | None = None,
) -> str:
    if (lineage_id is None) != (version_id is None):
        raise PlanGenerationError(
            "saved geometry binding needs both lineage and version or neither"
        )
    return textwrap.dedent(
        f"""
        MARKER = {_python_literal(marker)}
        MARKER_PARAMETER = {_python_literal(_MARKER_PARAMETER)}
        LENGTH_PARAMETER = {_python_literal(_LENGTH_PARAMETER)}
        WIDTH_PARAMETER = {_python_literal(_WIDTH_PARAMETER)}
        HEIGHT_PARAMETER = {_python_literal(_HEIGHT_PARAMETER)}
        UNDO_PARAMETER = {_python_literal(_UNDO_PARAMETER)}
        BODY_NAME = {_python_literal(_BODY_NAME)}
        SKETCH_NAME = {_python_literal(_SKETCH_NAME)}
        EXTRUDE_NAME = {_python_literal(_EXTRUDE_NAME)}
        EXPECTED_CREATION_ID = {_python_literal(creation_id) if creation_id is not None else "None"}
        EXPECTED_LINEAGE_ID = {_python_literal(lineage_id) if lineage_id is not None else "None"}
        EXPECTED_VERSION_ID = {_python_literal(version_id) if version_id is not None else "None"}
        EXPECTED_CLOUD_NAME = {_python_literal(cloud_name) if cloud_name is not None else "None"}
        EXPECTED_PROJECT_ID = {_python_literal(project_id) if project_id is not None else "None"}
        EXPECTED_FOLDER_ID = {_python_literal(folder_id) if folder_id is not None else "None"}
        EXPECTED_VERSION_NUMBER = {version_number!r}
        EXPECTED_MODIFIED = {require_modified!r}

        def active_target():
            app = adsk.core.Application.get()
            document = app.activeDocument
            design = adsk.fusion.Design.cast(app.activeProduct)
            if not document or not design:
                raise RuntimeError("No active Fusion design")
            if app.documents.count != 1 or document != app.activeDocument:
                raise RuntimeError("Acceptance target is not the only active document")
            ui = app.userInterface
            if not ui or ui.activeCommand != "SelectCommand":
                raise RuntimeError("Acceptance target is not in SelectCommand")
            if ui.activeSelections.count != 0:
                raise RuntimeError("Acceptance target has active selections")
            if design.designType != adsk.fusion.DesignTypes.ParametricDesignType:
                raise RuntimeError("Acceptance target is not a parametric design")
            root = design.rootComponent
            if design.activeEditObject not in (None, root):
                raise RuntimeError("Acceptance target has an active edit object")
            if design.snapshots.hasPendingSnapshot:
                raise RuntimeError("Acceptance target has a pending snapshot")
            marker = design.userParameters.itemByName(MARKER_PARAMETER)
            if not marker or marker.comment != MARKER:
                raise RuntimeError("Active document is not the exact acceptance target")
            if EXPECTED_CREATION_ID is not None and document.creationId != EXPECTED_CREATION_ID:
                raise RuntimeError("Acceptance document creation ID mismatch")
            if EXPECTED_CLOUD_NAME is not None and document.name != EXPECTED_CLOUD_NAME:
                raise RuntimeError("Acceptance document cloud name mismatch")
            if EXPECTED_MODIFIED is not None and bool(document.isModified) is not EXPECTED_MODIFIED:
                raise RuntimeError("Acceptance document modified-state mismatch")
            if EXPECTED_LINEAGE_ID is not None:
                data_file = document.dataFile
                if not document.isSaved or not data_file:
                    raise RuntimeError("Acceptance document has no saved identity")
                if not data_file.isComplete:
                    raise RuntimeError("Acceptance DataFile is not complete")
                if data_file.id != EXPECTED_LINEAGE_ID:
                    raise RuntimeError("Acceptance lineage mismatch")
                if data_file.versionId != EXPECTED_VERSION_ID:
                    raise RuntimeError("Acceptance version mismatch")
                if data_file.name != EXPECTED_CLOUD_NAME:
                    raise RuntimeError("Acceptance DataFile name mismatch")
                if EXPECTED_VERSION_NUMBER is not None:
                    if data_file.versionNumber != EXPECTED_VERSION_NUMBER:
                        raise RuntimeError("Acceptance version number mismatch")
                    if data_file.latestVersionNumber != data_file.versionNumber:
                        raise RuntimeError("Acceptance DataFile is not latest")
                if EXPECTED_PROJECT_ID is not None:
                    parent_project = data_file.parentProject
                    if not parent_project or parent_project.id != EXPECTED_PROJECT_ID:
                        raise RuntimeError("Acceptance parent project mismatch")
                if EXPECTED_FOLDER_ID is not None:
                    parent_folder = data_file.parentFolder
                    if not parent_folder or parent_folder.id != EXPECTED_FOLDER_ID:
                        raise RuntimeError("Acceptance parent folder mismatch")
                    if not parent_folder.isRoot:
                        raise RuntimeError("Acceptance parent folder is not root")
                    if parent_folder.parentProject.id != data_file.parentProject.id:
                        raise RuntimeError("Acceptance folder/project mismatch")
                    if data_file.parentProject.rootFolder.id != parent_folder.id:
                        raise RuntimeError("Acceptance document is not in project root")
            return app, document, design

        def box_state(design, expected_probe):
            if expected_probe not in ("absent", "present"):
                raise RuntimeError("Invalid undo-probe expectation")
            expected_parameters = {{
                MARKER_PARAMETER: 0.1,
                LENGTH_PARAMETER: 2.0,
                WIDTH_PARAMETER: 3.0,
                HEIGHT_PARAMETER: 1.0,
            }}
            for name, expected_cm in expected_parameters.items():
                parameter = design.userParameters.itemByName(name)
                if not parameter or abs(parameter.value - expected_cm) > 1e-8:
                    raise RuntimeError("Native driving parameter mismatch: " + name)
            actual_parameter_names = set()
            for index in range(design.userParameters.count):
                parameter = design.userParameters.item(index)
                if not parameter or not parameter.name:
                    raise RuntimeError("Acceptance user-parameter inventory is invalid")
                actual_parameter_names.add(parameter.name)
            expected_parameter_names = set(expected_parameters)
            if expected_probe == "present":
                expected_parameter_names.add(UNDO_PARAMETER)
            if actual_parameter_names != expected_parameter_names:
                raise RuntimeError("Acceptance user-parameter inventory mismatch")
            root = design.rootComponent
            if root.features.baseFeatures.count != 0:
                raise RuntimeError("Acceptance model must not contain BaseFeatures")
            if root.sketches.count != 1:
                raise RuntimeError("Expected exactly one acceptance sketch")
            sketch = root.sketches.item(0)
            if (
                not sketch
                or not sketch.isValid
                or sketch.name != SKETCH_NAME
                or int(sketch.healthState)
                != int(adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState)
                or sketch.errorOrWarningMessage
                or not sketch.isFullyConstrained
                or sketch.profiles.count != 1
                or sketch.sketchCurves.sketchLines.count != 4
                or sketch.geometricConstraints.count != 5
                or sketch.sketchDimensions.count != 2
            ):
                raise RuntimeError("Acceptance sketch identity/health mismatch")
            dimensions = {{}}
            for index in range(sketch.sketchDimensions.count):
                dimension = adsk.fusion.SketchLinearDimension.cast(
                    sketch.sketchDimensions.item(index)
                )
                if not dimension or not dimension.isDriving:
                    raise RuntimeError("Acceptance sketch dimension is not driving")
                orientation = int(dimension.orientation)
                if orientation in dimensions:
                    raise RuntimeError("Acceptance sketch dimension orientation is duplicated")
                dimensions[orientation] = dimension.parameter.expression
            expected_dimensions = {{
                int(adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation):
                    LENGTH_PARAMETER,
                int(adsk.fusion.DimensionOrientations.VerticalDimensionOrientation):
                    WIDTH_PARAMETER,
            }}
            if dimensions != expected_dimensions:
                raise RuntimeError("Acceptance sketch expressions are not parameter-driven")
            extrudes = root.features.extrudeFeatures
            if extrudes.count != 1:
                raise RuntimeError("Expected exactly one acceptance ExtrudeFeature")
            extrude = extrudes.item(0)
            distance = (
                adsk.fusion.DistanceExtentDefinition.cast(extrude.extentOne)
                if extrude
                else None
            )
            if (
                not extrude
                or not extrude.isValid
                or extrude.name != EXTRUDE_NAME
                or extrude.isSuppressed
                or int(extrude.healthState)
                != int(adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState)
                or extrude.errorOrWarningMessage
                or int(extrude.operation)
                != int(adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
                or extrude.hasTwoExtents
                or extrude.bodies.count != 1
                or not distance
                or distance.distance.expression != HEIGHT_PARAMETER
                or abs(distance.distance.value - 1.0) > 1e-8
                or abs(extrude.taperAngleOne.value) > 1e-10
            ):
                raise RuntimeError("Acceptance ExtrudeFeature identity/health mismatch")
            timeline = design.timeline
            if timeline is None:
                raise RuntimeError("Acceptance parametric timeline is unavailable")
            timeline_groups = timeline.timelineGroups
            timeline_group_count = (
                timeline_groups.count if timeline_groups is not None else 0
            )
            if timeline.count != 2 or timeline.markerPosition != 2:
                raise RuntimeError("Acceptance timeline is not exactly Sketch then Extrude")
            if timeline_group_count != 0:
                raise RuntimeError("Acceptance timeline contains unexpected groups")
            timeline_sketch = timeline.item(0)
            timeline_extrude = timeline.item(1)
            if (
                not timeline_sketch
                or timeline_sketch.isGroup
                or not timeline_extrude
                or timeline_extrude.isGroup
                or adsk.fusion.Sketch.cast(timeline_sketch.entity) != sketch
                or adsk.fusion.ExtrudeFeature.cast(timeline_extrude.entity) != extrude
            ):
                raise RuntimeError("Acceptance timeline entity order mismatch")
            if root.bRepBodies.count != 1:
                raise RuntimeError("Expected exactly one root BRep body")
            body = root.bRepBodies.item(0)
            if body.name != BODY_NAME or not body.isValid or not body.isSolid:
                raise RuntimeError("Exact solid-body identity/health mismatch")
            if (body.faces.count, body.edges.count, body.vertices.count) != (6, 12, 8):
                raise RuntimeError("Box topology mismatch")
            if abs(body.volume - 6.0) > 1e-7:
                raise RuntimeError("Box volume mismatch")
            bounds = body.preciseBoundingBox
            spans = [
                bounds.maxPoint.x - bounds.minPoint.x,
                bounds.maxPoint.y - bounds.minPoint.y,
                bounds.maxPoint.z - bounds.minPoint.z,
            ]
            expected = [2.0, 3.0, 1.0]
            if any(abs(actual - wanted) > 1e-8 for actual, wanted in zip(spans, expected)):
                raise RuntimeError("Box bounding dimensions mismatch")
            minima = [bounds.minPoint.x, bounds.minPoint.y, bounds.minPoint.z]
            if any(abs(value) > 1e-8 for value in minima):
                raise RuntimeError("Box is not rooted at the positive XY origin")
            return {{
                "body_count": root.bRepBodies.count,
                "sketch_count": root.sketches.count,
                "extrude_count": extrudes.count,
                "timeline_count": timeline.count,
                "timeline_groups": timeline_group_count,
                "faces": body.faces.count,
                "edges": body.edges.count,
                "vertices": body.vertices.count,
                "valid": bool(body.isValid),
                "solid": bool(body.isSolid),
                "volume_cm3": body.volume,
                "bbox_cm": spans,
                "bbox_min_cm": minima,
                "parameter_names": sorted(actual_parameter_names),
            }}
        """
    ).strip()


def _box_builder() -> str:
    return textwrap.dedent(
        """
        def build_box(design):
            app = adsk.core.Application.get()
            document = app.activeDocument
            ui = app.userInterface
            root = design.rootComponent
            if (
                not document
                or app.documents.count != 1
                or design != adsk.fusion.Design.cast(app.activeProduct)
            ):
                raise RuntimeError("Acceptance build target is not the sole active design")
            if not ui or ui.activeCommand != "SelectCommand":
                raise RuntimeError("Acceptance build target is not in SelectCommand")
            if ui.activeSelections.count != 0:
                raise RuntimeError("Acceptance build target has active selections")
            if design.activeEditObject not in (None, root):
                raise RuntimeError("Acceptance build target has an active edit object")
            if design.snapshots.hasPendingSnapshot:
                raise RuntimeError("Acceptance build target has a pending snapshot")
            parameters = design.userParameters
            if parameters.count != 0:
                raise RuntimeError("Acceptance target already has user parameters")
            parameters.add(
                MARKER_PARAMETER,
                adsk.core.ValueInput.createByString("1 mm"),
                "mm",
                MARKER,
            )
            parameters.add(
                LENGTH_PARAMETER,
                adsk.core.ValueInput.createByString("20 mm"),
                "mm",
                "Acceptance box X dimension",
            )
            parameters.add(
                WIDTH_PARAMETER,
                adsk.core.ValueInput.createByString("30 mm"),
                "mm",
                "Acceptance box Y dimension",
            )
            parameters.add(
                HEIGHT_PARAMETER,
                adsk.core.ValueInput.createByString("10 mm"),
                "mm",
                "Acceptance box Z dimension",
            )
            if parameters.itemByName(UNDO_PARAMETER):
                raise RuntimeError("Undo probe parameter already exists")
            sketch = root.sketches.add(root.xYConstructionPlane)
            if not sketch:
                raise RuntimeError("Could not create the acceptance sketch")
            sketch.name = SKETCH_NAME
            lines = sketch.sketchCurves.sketchLines
            bottom = lines.addByTwoPoints(
                adsk.core.Point3D.create(0.0, 0.0, 0.0),
                adsk.core.Point3D.create(2.0, 0.0, 0.0),
            )
            right = lines.addByTwoPoints(
                bottom.endSketchPoint,
                adsk.core.Point3D.create(2.0, 3.0, 0.0),
            )
            top = lines.addByTwoPoints(
                right.endSketchPoint,
                adsk.core.Point3D.create(0.0, 3.0, 0.0),
            )
            left = lines.addByTwoPoints(
                top.endSketchPoint,
                bottom.startSketchPoint,
            )
            if not bottom or not right or not top or not left:
                raise RuntimeError("Could not create the acceptance rectangle edges")
            constraints = sketch.geometricConstraints
            constraints.addHorizontal(bottom)
            constraints.addVertical(right)
            constraints.addHorizontal(top)
            constraints.addVertical(left)
            constraints.addCoincident(
                bottom.startSketchPoint,
                sketch.originPoint,
            )
            if constraints.count != 5:
                raise RuntimeError("Acceptance rectangle constraint inventory mismatch")
            length_dimension = sketch.sketchDimensions.addDistanceDimension(
                bottom.startSketchPoint,
                bottom.endSketchPoint,
                adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation,
                adsk.core.Point3D.create(1.0, -0.5, 0.0),
            )
            width_dimension = sketch.sketchDimensions.addDistanceDimension(
                right.startSketchPoint,
                right.endSketchPoint,
                adsk.fusion.DimensionOrientations.VerticalDimensionOrientation,
                adsk.core.Point3D.create(2.5, 1.5, 0.0),
            )
            if not length_dimension or not width_dimension:
                raise RuntimeError("Could not create acceptance driving dimensions")
            length_dimension.parameter.expression = LENGTH_PARAMETER
            width_dimension.parameter.expression = WIDTH_PARAMETER
            if not design.computeAll():
                raise RuntimeError("Acceptance sketch computeAll returned false")
            if not sketch.isFullyConstrained or sketch.profiles.count != 1:
                raise RuntimeError("Acceptance sketch is not fully constrained")
            extrudes = root.features.extrudeFeatures
            extrude_input = extrudes.createInput(
                sketch.profiles.item(0),
                adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
            )
            if not extrude_input:
                raise RuntimeError("Could not create acceptance Extrude input")
            extent = adsk.fusion.DistanceExtentDefinition.create(
                adsk.core.ValueInput.createByString(HEIGHT_PARAMETER)
            )
            if not extent or not extrude_input.setOneSideExtent(
                extent,
                adsk.fusion.ExtentDirections.PositiveExtentDirection,
            ):
                raise RuntimeError("Could not bind the acceptance Extrude extent")
            extrude = extrudes.add(extrude_input)
            if not extrude or extrude.bodies.count != 1:
                raise RuntimeError("Could not create one acceptance Extrude body")
            extrude.name = EXTRUDE_NAME
            if not design.computeAll():
                raise RuntimeError("Acceptance Extrude computeAll returned false")
            body = extrude.bodies.item(0)
            body.name = BODY_NAME
            return box_state(design, "absent")
        """
    ).strip()


def _create_box_script(marker: str) -> str:
    helpers = _geometry_helpers(marker)
    builder = _box_builder()
    run_script = textwrap.dedent(
        """
        def run(_context: str):
            app = adsk.core.Application.get()
            if app.documents.count != 0:
                raise RuntimeError(
                    "Acceptance requires zero open documents before creation"
                )
            document = app.documents.add(
                adsk.core.DocumentTypes.FusionDesignDocumentType
            )
            design = adsk.fusion.Design.cast(app.activeProduct)
            if not design:
                raise RuntimeError("New document is not a Fusion design")
            design.designType = adsk.fusion.DesignTypes.ParametricDesignType
            if design.designType != adsk.fusion.DesignTypes.ParametricDesignType:
                raise RuntimeError("Could not create a parametric acceptance design")
            state = build_box(design)
            print(json.dumps({
                "success": True,
                "stage": "box_created",
                "document": {
                    "creation_id": document.creationId,
                    "is_saved": bool(document.isSaved),
                    "is_modified": bool(document.isModified),
                },
                "geometry": state,
            }, sort_keys=True))
        """
    ).strip()
    return _check_script(
        "\n\n".join(
            [
                "import adsk.core\nimport adsk.fusion\nimport json",
                helpers,
                builder,
                run_script,
            ]
        )
    )


def _parameter_response_script(
    marker: str,
    *,
    expected_probe: str = "absent",
    creation_id: str | None = None,
    lineage_id: str | None = None,
    version_id: str | None = None,
    cloud_name: str | None = None,
    project_id: str | None = None,
    folder_id: str | None = None,
    version_number: int | None = None,
) -> str:
    if expected_probe not in {"absent", "present"}:
        raise PlanGenerationError("probe expectation must be absent or present")
    helpers = _geometry_helpers(
        marker,
        creation_id=creation_id,
        lineage_id=lineage_id,
        version_id=version_id,
        cloud_name=cloud_name,
        project_id=project_id,
        folder_id=folder_id,
        version_number=version_number,
        require_modified=True if lineage_id is not None else None,
    )
    return _check_script(
        "\n\n".join(
            [
                "import adsk.core\nimport adsk.fusion\nimport json",
                helpers,
                textwrap.dedent(
                    """
                    def run(_context: str):
                        app, document, design = active_target()
                        original = box_state(design, EXPECTED_PROBE)
                        length = design.userParameters.itemByName(LENGTH_PARAMETER)
                        width = design.userParameters.itemByName(WIDTH_PARAMETER)
                        height = design.userParameters.itemByName(HEIGHT_PARAMETER)
                        length_expression = length.expression
                        width_expression = width.expression
                        height_expression = height.expression
                        length.expression = "25 mm"
                        try:
                            if not design.computeAll():
                                raise RuntimeError("Parameter response computeAll returned false")
                            body = design.rootComponent.bRepBodies.item(0)
                            bounds = body.preciseBoundingBox
                            expanded = bounds.maxPoint.x - bounds.minPoint.x
                            if abs(expanded - 2.5) > 1e-8:
                                raise RuntimeError("Length parameter did not drive the solid")
                        finally:
                            length.expression = length_expression
                            restored = design.computeAll()
                        if not restored:
                            raise RuntimeError("Length response restoration computeAll failed")
                        width.expression = "35 mm"
                        try:
                            if not design.computeAll():
                                raise RuntimeError("Width response computeAll returned false")
                            body = design.rootComponent.bRepBodies.item(0)
                            bounds = body.preciseBoundingBox
                            expanded_width = bounds.maxPoint.y - bounds.minPoint.y
                            if abs(expanded_width - 3.5) > 1e-8:
                                raise RuntimeError("Width parameter did not drive the solid")
                        finally:
                            width.expression = width_expression
                            restored = design.computeAll()
                        if not restored:
                            raise RuntimeError("Width response restoration computeAll failed")
                        height.expression = "15 mm"
                        try:
                            if not design.computeAll():
                                raise RuntimeError("Height response computeAll returned false")
                            body = design.rootComponent.bRepBodies.item(0)
                            bounds = body.preciseBoundingBox
                            expanded_height = bounds.maxPoint.z - bounds.minPoint.z
                            if abs(expanded_height - 1.5) > 1e-8:
                                raise RuntimeError("Height parameter did not drive the solid")
                        finally:
                            height.expression = height_expression
                            restored = design.computeAll()
                        if not restored:
                            raise RuntimeError("Height response restoration computeAll failed")
                        if (
                            length.expression != length_expression
                            or width.expression != width_expression
                            or height.expression != height_expression
                        ):
                            raise RuntimeError("Driving expressions were not restored exactly")
                        final = box_state(design, EXPECTED_PROBE)
                        print(json.dumps({
                            "success": True,
                            "stage": "native_parameter_response",
                            "document_creation_id": document.creationId,
                            "expanded_length_cm": expanded,
                            "expanded_width_cm": expanded_width,
                            "expanded_height_cm": expanded_height,
                            "restored_expressions": {
                                "length": length_expression,
                                "width": width_expression,
                                "height": height_expression,
                            },
                            "original": original,
                            "restored": final,
                        }, sort_keys=True))
                    """
                )
                .replace("EXPECTED_PROBE", _python_literal(expected_probe))
                .strip(),
            ]
        )
    )


def _empty_document_guards(
    *,
    creation_id: str,
    expected_design_type: str,
    require_saved: bool,
    require_modified: bool,
    lineage_id: str | None = None,
    version_id: str | None = None,
    cloud_name: str | None = None,
    project_id: str | None = None,
    folder_id: str | None = None,
    version_number: int | None = None,
) -> str:
    if expected_design_type not in {"direct", "parametric"}:
        raise PlanGenerationError(
            "empty-document design type must be direct or parametric"
        )
    design_type = (
        "adsk.fusion.DesignTypes.DirectDesignType"
        if expected_design_type == "direct"
        else "adsk.fusion.DesignTypes.ParametricDesignType"
    )
    lines = [
        "    if app.documents.count != 1 or document != app.activeDocument:",
        '        raise RuntimeError("Recovery target is not the only active document")',
        f"    if document.creationId != {_python_literal(creation_id)}:",
        '        raise RuntimeError("Recovery document creation ID mismatch")',
        f"    if design.designType != {design_type}:",
        '        raise RuntimeError("Recovery document design type mismatch")',
        "    ui = app.userInterface",
        '    if not ui or ui.activeCommand != "SelectCommand":',
        '        raise RuntimeError("Recovery document is not in the SelectCommand state")',
        "    if ui.activeSelections.count != 0:",
        '        raise RuntimeError("Recovery document has active selections")',
        f"    if bool(document.isModified) is not {require_modified!r}:",
        '        raise RuntimeError("Recovery document modified-state mismatch")',
    ]
    if require_saved:
        lines.extend(
            [
                "    data_file = document.dataFile",
                "    if not document.isSaved or not data_file or not data_file.isComplete:",
                '        raise RuntimeError("Recovery document is not saved")',
            ]
        )
        if lineage_id is not None:
            lines.extend(
                [
                    f"    if data_file.id != {_python_literal(lineage_id)}:",
                    '        raise RuntimeError("Recovery lineage mismatch")',
                ]
            )
        if version_id is not None:
            lines.extend(
                [
                    f"    if data_file.versionId != {_python_literal(version_id)}:",
                    '        raise RuntimeError("Recovery version mismatch")',
                ]
            )
        if cloud_name is not None:
            lines.extend(
                [
                    f"    if document.name != {_python_literal(cloud_name)} or data_file.name != {_python_literal(cloud_name)}:",
                    '        raise RuntimeError("Recovery cloud name mismatch")',
                ]
            )
        if project_id is not None:
            lines.extend(
                [
                    "    parent_project = data_file.parentProject",
                    f"    if not parent_project or parent_project.id != {_python_literal(project_id)}:",
                    '        raise RuntimeError("Recovery parent project mismatch")',
                ]
            )
        if folder_id is not None:
            lines.extend(
                [
                    "    parent_folder = data_file.parentFolder",
                    f"    if not parent_folder or parent_folder.id != {_python_literal(folder_id)}:",
                    '        raise RuntimeError("Recovery parent folder mismatch")',
                ]
            )
        if version_number is not None:
            lines.extend(
                [
                    f"    if data_file.versionNumber != {version_number}:",
                    '        raise RuntimeError("Recovery version number mismatch")',
                    "    if data_file.latestVersionNumber != data_file.versionNumber:",
                    '        raise RuntimeError("Recovery DataFile is not the latest version")',
                ]
            )
    else:
        lines.extend(
            [
                "    if document.isSaved or document.dataFile is not None:",
                '        raise RuntimeError("Recovery document unexpectedly has cloud identity")',
            ]
        )
    lines.extend(
        [
            "    root = design.rootComponent",
            "    if design.allComponents.count != 1:",
            '        raise RuntimeError("Recovery document has unexpected components")',
            "    if root.bRepBodies.count != 0 or root.meshBodies.count != 0:",
            '        raise RuntimeError("Recovery document is not geometrically empty")',
            "    if root.occurrences.count != 0 or root.allOccurrences.count != 0:",
            '        raise RuntimeError("Recovery document has unexpected occurrences")',
            "    if root.sketches.count != 0 or root.features.baseFeatures.count != 0:",
            '        raise RuntimeError("Recovery document has unexpected native features")',
            "    if root.features.count != 0:",
            '        raise RuntimeError("Recovery document has unexpected features")',
        ]
    )
    if expected_design_type == "parametric":
        lines.extend(
            [
                "    if design.snapshots.hasPendingSnapshot:",
                '        raise RuntimeError("Recovery document has a pending snapshot")',
                "    if design.activeEditObject not in (None, root):",
                '        raise RuntimeError("Recovery document has an active edit object")',
                "    if design.userParameters.count != 0:",
                '        raise RuntimeError("Recovery document has unexpected user parameters")',
                "    timeline = design.timeline",
                "    if timeline is None:",
                '        raise RuntimeError("Recovery parametric timeline is unavailable")',
                "    timeline_groups = timeline.timelineGroups",
                "    timeline_group_count = (",
                "        timeline_groups.count if timeline_groups is not None else 0",
                "    )",
                "    if timeline.count != 0 or timeline.markerPosition != 0:",
                '        raise RuntimeError("Recovery document timeline is not empty")',
                "    if timeline_group_count != 0:",
                '        raise RuntimeError("Recovery document timeline has groups")',
            ]
        )
    return "\n".join(lines)


def _create_empty_parametric_document_script() -> str:
    """Create one blank parametric design and read back its native identity."""
    return _check_script(
        textwrap.dedent(
            f"""
            import adsk.core
            import adsk.fusion
            import json

            EMPTY_ROOT_NAME = {_python_literal(_EMPTY_ROOT_NAME)}

            def run(_context: str):
                app = adsk.core.Application.get()
                ui = app.userInterface
                if not ui:
                    raise RuntimeError("Fusion user interface is unavailable")
                if app.documents.count != 0 or app.activeDocument is not None:
                    raise RuntimeError(
                        "Empty checkpoint creation requires zero open documents"
                    )
                if ui.activeSelections.count != 0:
                    raise RuntimeError(
                        "Empty checkpoint creation requires zero active selections"
                    )
                document = app.documents.add(
                    adsk.core.DocumentTypes.FusionDesignDocumentType
                )
                if (
                    not document
                    or app.documents.count != 1
                    or document != app.activeDocument
                ):
                    raise RuntimeError(
                        "New empty checkpoint is not the sole active document"
                    )
                design = adsk.fusion.Design.cast(app.activeProduct)
                if not design:
                    raise RuntimeError("New empty checkpoint is not a Fusion design")
                design.designType = adsk.fusion.DesignTypes.ParametricDesignType
                if design.designType != adsk.fusion.DesignTypes.ParametricDesignType:
                    raise RuntimeError(
                        "Could not create a parametric empty checkpoint"
                    )
                root = design.rootComponent
                if not root:
                    raise RuntimeError("New empty checkpoint has no root component")
                root.name = EMPTY_ROOT_NAME
                if root.name != EMPTY_ROOT_NAME:
                    raise RuntimeError("Empty checkpoint root identity was not retained")
                if not document.creationId:
                    raise RuntimeError("Empty checkpoint creation ID is unavailable")
                if document.isSaved or document.dataFile is not None:
                    raise RuntimeError("New empty checkpoint unexpectedly has cloud identity")
                if not document.isModified:
                    raise RuntimeError("New empty checkpoint is not marked modified")
                if ui.activeCommand != "SelectCommand":
                    raise RuntimeError("New empty checkpoint is not in SelectCommand")
                if ui.activeSelections.count != 0:
                    raise RuntimeError("New empty checkpoint has active selections")
                if design.allComponents.count != 1:
                    raise RuntimeError("New empty checkpoint has unexpected components")
                if root.bRepBodies.count != 0 or root.meshBodies.count != 0:
                    raise RuntimeError("New empty checkpoint is not geometrically empty")
                if root.occurrences.count != 0 or root.allOccurrences.count != 0:
                    raise RuntimeError("New empty checkpoint has unexpected occurrences")
                if root.sketches.count != 0 or root.features.count != 0:
                    raise RuntimeError("New empty checkpoint has unexpected native features")
                if root.features.baseFeatures.count != 0:
                    raise RuntimeError("New empty checkpoint has unexpected base features")
                if design.userParameters.count != 0:
                    raise RuntimeError("New empty checkpoint has unexpected parameters")
                timeline = design.timeline
                if timeline is None:
                    raise RuntimeError("New checkpoint parametric timeline is unavailable")
                timeline_groups = timeline.timelineGroups
                timeline_group_count = (
                    timeline_groups.count if timeline_groups is not None else 0
                )
                if (
                    timeline.count != 0
                    or timeline.markerPosition != 0
                    or timeline_group_count != 0
                ):
                    raise RuntimeError("New empty checkpoint timeline is not empty")
                if design.snapshots.hasPendingSnapshot:
                    raise RuntimeError("New empty checkpoint has a pending snapshot")
                if design.activeEditObject not in (None, root):
                    raise RuntimeError("New empty checkpoint has an active edit object")
                print(json.dumps({{
                    "success": True,
                    "stage": "empty_parametric_checkpoint_created",
                    "open_document_count": app.documents.count,
                    "active": {{
                        "creation_id": document.creationId,
                        "name": document.name,
                        "is_saved": bool(document.isSaved),
                        "is_modified": bool(document.isModified),
                        "has_data_file": document.dataFile is not None,
                        "design_type": "parametric",
                        "root_name": root.name,
                        "all_components": design.allComponents.count,
                        "bodies": root.bRepBodies.count,
                        "mesh_bodies": root.meshBodies.count,
                        "occurrences": root.occurrences.count,
                        "all_occurrences": root.allOccurrences.count,
                        "sketches": root.sketches.count,
                        "features": root.features.count,
                        "base_features": root.features.baseFeatures.count,
                        "user_parameters": design.userParameters.count,
                        "timeline_count": timeline.count,
                        "timeline_marker": timeline.markerPosition,
                        "timeline_groups": timeline_group_count,
                        "pending_snapshot": bool(design.snapshots.hasPendingSnapshot),
                        "active_edit_is_root_or_none": (
                            design.activeEditObject in (None, root)
                        ),
                        "active_command": ui.activeCommand,
                        "active_selection_count": ui.activeSelections.count,
                    }},
                }}, sort_keys=True))
            """
        ).strip()
    )


def _inspect_empty_document_script() -> str:
    return _check_script(
        textwrap.dedent(
            """
            import adsk.core
            import adsk.fusion
            import json

            def run(_context: str):
                app = adsk.core.Application.get()
                document = app.activeDocument
                design = adsk.fusion.Design.cast(app.activeProduct)
                if not document or not design:
                    raise RuntimeError("No active recovery design")
                root = design.rootComponent
                design_type = int(design.designType)
                direct = int(adsk.fusion.DesignTypes.DirectDesignType)
                parametric = int(adsk.fusion.DesignTypes.ParametricDesignType)
                ui = app.userInterface
                if app.documents.count != 1 or document != app.activeDocument:
                    raise RuntimeError("Recovery target is not the only active document")
                if document.isSaved or document.dataFile is not None:
                    raise RuntimeError("Recovery inspection requires an unsaved document")
                if not document.isModified:
                    raise RuntimeError("Recovery inspection requires the known modified document")
                if design_type not in (direct, parametric):
                    raise RuntimeError("Recovery design type is unsupported")
                if not ui or ui.activeCommand != "SelectCommand":
                    raise RuntimeError("Recovery document is not in SelectCommand")
                if ui.activeSelections.count != 0:
                    raise RuntimeError("Recovery document has active selections")
                if design.allComponents.count != 1:
                    raise RuntimeError("Recovery document has unexpected components")
                if root.bRepBodies.count or root.meshBodies.count:
                    raise RuntimeError("Recovery document is not geometrically empty")
                if root.occurrences.count or root.allOccurrences.count:
                    raise RuntimeError("Recovery document has unexpected occurrences")
                if root.sketches.count or root.features.count:
                    raise RuntimeError("Recovery document has unexpected native features")
                pending_snapshot = None
                active_edit_is_root_or_none = None
                timeline_count = None
                timeline_marker = None
                timeline_group_count = None
                user_parameter_count = None
                if design_type == parametric:
                    pending_snapshot = bool(design.snapshots.hasPendingSnapshot)
                    active_edit_is_root_or_none = (
                        design.activeEditObject in (None, root)
                    )
                    timeline = design.timeline
                    if timeline is None:
                        raise RuntimeError("Recovery parametric timeline is unavailable")
                    timeline_groups = timeline.timelineGroups
                    timeline_group_count = (
                        timeline_groups.count if timeline_groups is not None else 0
                    )
                    timeline_count = timeline.count
                    timeline_marker = timeline.markerPosition
                    user_parameter_count = design.userParameters.count
                    if pending_snapshot:
                        raise RuntimeError("Recovery document has a pending snapshot")
                    if not active_edit_is_root_or_none:
                        raise RuntimeError("Recovery document has an active edit object")
                    if (
                        user_parameter_count
                        or timeline_count
                        or timeline_marker
                        or timeline_group_count
                    ):
                        raise RuntimeError("Parametric recovery document is not empty")
                row = {
                    "creation_id": document.creationId,
                    "name": document.name,
                    "is_saved": bool(document.isSaved),
                    "is_modified": bool(document.isModified),
                    "has_data_file": document.dataFile is not None,
                    "design_type": (
                        "direct" if design_type == direct
                        else "parametric" if design_type == parametric
                        else "other"
                    ),
                    "all_components": design.allComponents.count,
                    "bodies": root.bRepBodies.count,
                    "mesh_bodies": root.meshBodies.count,
                    "occurrences": root.occurrences.count,
                    "all_occurrences": root.allOccurrences.count,
                    "sketches": root.sketches.count,
                    "base_features": root.features.baseFeatures.count,
                    "extrudes": root.features.extrudeFeatures.count,
                    "pending_snapshot": pending_snapshot,
                    "active_edit_is_root_or_none": active_edit_is_root_or_none,
                    "active_command": app.userInterface.activeCommand,
                    "active_selection_count": app.userInterface.activeSelections.count,
                    "timeline_count": timeline_count,
                    "timeline_marker": timeline_marker,
                    "timeline_groups": timeline_group_count,
                    "user_parameters": user_parameter_count,
                }
                print(json.dumps({
                    "success": True,
                    "stage": "inspect_empty_recovery_document",
                    "open_document_count": app.documents.count,
                    "active": row,
                }, sort_keys=True))
            """
        ).strip()
    )


def _convert_empty_document_script(*, creation_id: str) -> str:
    guards = _empty_document_guards(
        creation_id=creation_id,
        expected_design_type="direct",
        require_saved=False,
        require_modified=True,
    )
    return _check_script(
        "\n".join(
            [
                "import adsk.core",
                "import adsk.fusion",
                "import json",
                "",
                "def run(_context: str):",
                "    app = adsk.core.Application.get()",
                "    document = app.activeDocument",
                "    design = adsk.fusion.Design.cast(app.activeProduct)",
                "    if not document or not design:",
                '        raise RuntimeError("No active recovery design")',
                guards,
                "    design.designType = adsk.fusion.DesignTypes.ParametricDesignType",
                "    if design.designType != adsk.fusion.DesignTypes.ParametricDesignType:",
                '        raise RuntimeError("Recovery conversion to parametric failed")',
                "    if document.creationId != " + _python_literal(creation_id) + ":",
                '        raise RuntimeError("Recovery identity changed during conversion")',
                "    if design.snapshots.hasPendingSnapshot:",
                '        raise RuntimeError("Conversion introduced a pending snapshot")',
                "    if design.activeEditObject not in (None, design.rootComponent):",
                '        raise RuntimeError("Conversion left an active edit object")',
                "    if design.userParameters.count != 0:",
                '        raise RuntimeError("Conversion introduced user parameters")',
                "    timeline = design.timeline",
                "    if timeline is None:",
                '        raise RuntimeError("Conversion parametric timeline is unavailable")',
                "    timeline_groups = timeline.timelineGroups",
                "    timeline_group_count = (",
                "        timeline_groups.count if timeline_groups is not None else 0",
                "    )",
                "    if timeline.count != 0 or timeline.markerPosition != 0:",
                '        raise RuntimeError("Conversion introduced timeline state")',
                "    if timeline_group_count != 0:",
                '        raise RuntimeError("Conversion introduced timeline groups")',
                "    print(json.dumps({",
                '        "success": True,',
                '        "stage": "empty_recovery_converted_to_parametric",',
                '        "creation_id": document.creationId,',
                '        "is_saved": bool(document.isSaved),',
                '        "is_modified": bool(document.isModified),',
                "    }, sort_keys=True))",
            ]
        )
    )


def _verify_empty_parametric_script(
    *,
    creation_id: str,
    require_saved: bool,
    lineage_id: str | None = None,
    version_id: str | None = None,
) -> str:
    guards = _empty_document_guards(
        creation_id=creation_id,
        expected_design_type="parametric",
        require_saved=require_saved,
        require_modified=not require_saved,
        lineage_id=lineage_id,
        version_id=version_id,
    )
    return _check_script(
        "\n".join(
            [
                "import adsk.core",
                "import adsk.fusion",
                "import json",
                "",
                "def run(_context: str):",
                "    app = adsk.core.Application.get()",
                "    document = app.activeDocument",
                "    design = adsk.fusion.Design.cast(app.activeProduct)",
                "    if not document or not design:",
                '        raise RuntimeError("No active recovery design")',
                guards,
                "    data_file = document.dataFile",
                "    print(json.dumps({",
                '        "success": True,',
                '        "stage": "empty_parametric_recovery_verified",',
                '        "creation_id": document.creationId,',
                '        "is_saved": bool(document.isSaved),',
                '        "is_modified": bool(document.isModified),',
                '        "lineage_id": data_file.id if data_file else None,',
                '        "version_id": data_file.versionId if data_file else None,',
                '        "is_complete": bool(data_file.isComplete) if data_file else None,',
                "    }, sort_keys=True))",
            ]
        )
    )


def _save_empty_parametric_script(
    *,
    creation_id: str,
    cloud_name: str,
    project_id: str,
    folder_id: str,
    project_name: str | None,
) -> str:
    guards = _empty_document_guards(
        creation_id=creation_id,
        expected_design_type="parametric",
        require_saved=False,
        require_modified=True,
    )
    project_guards = [
        f"    if project.id != {_python_literal(project_id)}:",
        '        raise RuntimeError("Recovery project ID mismatch")',
    ]
    if project_name is not None:
        project_guards.extend(
            [
                f"    if project.name != {_python_literal(project_name)}:",
                '        raise RuntimeError("Recovery project name mismatch")',
            ]
        )
    return _check_script(
        "\n".join(
            [
                "import adsk.core",
                "import adsk.fusion",
                "import json",
                "",
                f"CLOUD_NAME = {_python_literal(cloud_name)}",
                "",
                "def run(_context: str):",
                "    app = adsk.core.Application.get()",
                "    document = app.activeDocument",
                "    design = adsk.fusion.Design.cast(app.activeProduct)",
                "    if not document or not design:",
                '        raise RuntimeError("No active recovery design")',
                guards,
                "    project = app.data.dataProjects.itemById("
                + _python_literal(project_id)
                + ")",
                "    if not project or not project.rootFolder:",
                '        raise RuntimeError("No exact recovery project root folder")',
                *project_guards,
                f"    if project.rootFolder.id != {_python_literal(folder_id)}:",
                '        raise RuntimeError("Recovery root folder ID mismatch")',
                "    data_files = project.rootFolder.dataFiles",
                "    if data_files.count > 256:",
                '        raise RuntimeError("Recovery collision scan exceeds bounded limit")',
                "    for index in range(data_files.count):",
                "        candidate = data_files.item(index)",
                "        if candidate and candidate.name == CLOUD_NAME:",
                '            raise RuntimeError("Recovery cloud name already exists")',
                "    response = {",
                '        "success": True,',
                '        "stage": "empty_parametric_recovery_save_as_submitted",',
                f'        "creation_id": {_python_literal(creation_id)},',
                '        "name": CLOUD_NAME,',
                f'        "project_id": {_python_literal(project_id)},',
                f'        "folder_id": {_python_literal(folder_id)},',
                "    }",
                '    saved = document.saveAs(CLOUD_NAME, project.rootFolder, "", "")',
                "    if not saved:",
                '        raise RuntimeError("Empty recovery Save As returned false")',
                '    response["saved_returned"] = True',
                "    print(json.dumps(response, sort_keys=True))",
            ]
        )
    )


def _capture_saved_empty_identity_script(
    *,
    pre_save_creation_id: str,
    cloud_name: str,
    project_id: str,
    folder_id: str,
    project_name: str | None,
) -> str:
    project_guards = [
        f"    if parent_project.id != {_python_literal(project_id)}:",
        '        raise RuntimeError("Saved recovery project ID mismatch")',
    ]
    if project_name is not None:
        project_guards.extend(
            [
                f"    if parent_project.name != {_python_literal(project_name)}:",
                '        raise RuntimeError("Saved recovery project name mismatch")',
            ]
        )
    return _check_script(
        "\n".join(
            [
                "import adsk.core",
                "import adsk.fusion",
                "import json",
                "",
                "def run(_context: str):",
                "    app = adsk.core.Application.get()",
                "    document = app.activeDocument",
                "    design = adsk.fusion.Design.cast(app.activeProduct)",
                "    if not document or not design:",
                '        raise RuntimeError("No active saved recovery design")',
                "    if app.documents.count != 1:",
                '        raise RuntimeError("Saved recovery document is not sole active")',
                f"    if document.name != {_python_literal(cloud_name)}:",
                '        raise RuntimeError("Saved recovery document name mismatch")',
                "    data_file = document.dataFile",
                "    if not document.isSaved or document.isModified or not data_file:",
                '        raise RuntimeError("Saved recovery identity is not stable and clean")',
                "    if not data_file.isComplete:",
                '        raise RuntimeError("Saved recovery DataFile is not complete")',
                f"    if data_file.name != {_python_literal(cloud_name)}:",
                '        raise RuntimeError("Saved recovery DataFile name mismatch")',
                "    parent_project = data_file.parentProject",
                "    parent_folder = data_file.parentFolder",
                "    if not parent_project or not parent_folder:",
                '        raise RuntimeError("Saved recovery parent identity is unavailable")',
                *project_guards,
                f"    if parent_folder.id != {_python_literal(folder_id)}:",
                '        raise RuntimeError("Saved recovery root folder ID mismatch")',
                "    if not parent_folder.isRoot:",
                '        raise RuntimeError("Saved recovery parent folder is not root")',
                "    folder_project = parent_folder.parentProject",
                "    if not folder_project or folder_project.id != parent_project.id:",
                '        raise RuntimeError("Saved recovery folder/project mismatch")',
                "    if parent_project.rootFolder.id != parent_folder.id:",
                '        raise RuntimeError("Saved recovery is not in exact project root")',
                "    if data_file.versionNumber != 1:",
                '        raise RuntimeError("Saved empty checkpoint is not version 1")',
                "    if data_file.latestVersionNumber != data_file.versionNumber:",
                '        raise RuntimeError("Saved empty checkpoint is not latest")',
                "    root = design.rootComponent",
                "    if design.designType != adsk.fusion.DesignTypes.ParametricDesignType:",
                '        raise RuntimeError("Saved recovery is not parametric")',
                "    if design.userParameters.count != 0:",
                '        raise RuntimeError("Saved recovery has unexpected parameters")',
                "    timeline = design.timeline",
                "    if timeline is None:",
                '        raise RuntimeError("Saved recovery parametric timeline is unavailable")',
                "    timeline_groups = timeline.timelineGroups",
                "    timeline_group_count = (",
                "        timeline_groups.count if timeline_groups is not None else 0",
                "    )",
                "    if timeline.count != 0 or timeline.markerPosition != 0:",
                '        raise RuntimeError("Saved recovery timeline is not empty")',
                "    if timeline_group_count != 0:",
                '        raise RuntimeError("Saved recovery timeline has groups")',
                "    if root.features.count != 0 or root.sketches.count != 0:",
                '        raise RuntimeError("Saved recovery has unexpected features")',
                "    if root.bRepBodies.count != 0 or root.meshBodies.count != 0:",
                '        raise RuntimeError("Saved recovery is not geometrically empty")',
                "    print(json.dumps({",
                '        "success": True,',
                '        "stage": "saved_empty_recovery_identity_captured",',
                '        "creation_id": document.creationId,',
                '        "pre_save_creation_id": '
                + _python_literal(pre_save_creation_id)
                + ",",
                '        "creation_id_rotated": document.creationId != '
                + _python_literal(pre_save_creation_id)
                + ",",
                '        "name": document.name,',
                '        "lineage_id": data_file.id,',
                '        "version_id": data_file.versionId,',
                '        "version_number": data_file.versionNumber,',
                '        "is_complete": bool(data_file.isComplete),',
                '        "project_id": parent_project.id,',
                '        "project_name": parent_project.name,',
                '        "folder_id": parent_folder.id,',
                "    }, sort_keys=True))",
            ]
        )
    )


def _build_saved_empty_document_script(
    *,
    marker: str,
    creation_id: str,
    lineage_id: str,
    version_id: str,
    cloud_name: str,
    project_id: str,
    folder_id: str,
    version_number: int,
) -> str:
    helpers = _geometry_helpers(
        marker,
        creation_id=creation_id,
        lineage_id=lineage_id,
        version_id=version_id,
        cloud_name=cloud_name,
    )
    builder = _box_builder()
    guards = _empty_document_guards(
        creation_id=creation_id,
        expected_design_type="parametric",
        require_saved=True,
        require_modified=False,
        lineage_id=lineage_id,
        version_id=version_id,
        cloud_name=cloud_name,
        project_id=project_id,
        folder_id=folder_id,
        version_number=version_number,
    )
    run_script = "\n".join(
        [
            "def run(_context: str):",
            "    app = adsk.core.Application.get()",
            "    document = app.activeDocument",
            "    design = adsk.fusion.Design.cast(app.activeProduct)",
            "    if not document or not design:",
            '        raise RuntimeError("No active recovery design")',
            guards,
            "    state = build_box(design)",
            "    print(json.dumps({",
            '        "success": True,',
            '        "stage": "saved_recovery_box_created",',
            '        "creation_id": document.creationId,',
            '        "lineage_id": document.dataFile.id,',
            '        "version_id": document.dataFile.versionId,',
            '        "is_modified": bool(document.isModified),',
            '        "geometry": state,',
            "    }, sort_keys=True))",
        ]
    )
    return _check_script(
        "\n\n".join(
            [
                "import adsk.core\nimport adsk.fusion\nimport json",
                helpers,
                builder,
                run_script,
            ]
        )
    )


def _project_preflight_script(*, project_id: str, project_name: str | None) -> str:
    project_guards = [
        f"    if project.id != {_python_literal(project_id)}:",
        '        raise RuntimeError("Active project ID mismatch")',
    ]
    if project_name is not None:
        project_guards.extend(
            [
                f"    if project.name != {_python_literal(project_name)}:",
                '        raise RuntimeError("Active project name mismatch")',
            ]
        )
    return _check_script(
        "\n".join(
            [
                "import adsk.core",
                "import json",
                "",
                "def run(_context: str):",
                "    app = adsk.core.Application.get()",
                "    if app.documents.count != 0:",
                '        raise RuntimeError("Project preflight requires zero open documents")',
                (
                    "    project = app.data.dataProjects.itemById("
                    f"{_python_literal(project_id)})"
                ),
                "    if not project or not project.rootFolder:",
                '        raise RuntimeError("No exact project root folder is available")',
                *project_guards,
                "    print(json.dumps({",
                '        "success": True,',
                '        "stage": "active_project_preflight",',
                '        "open_document_count": app.documents.count,',
                '        "project": {"id": project.id, "name": project.name},',
                '        "root_folder": {"id": project.rootFolder.id, "name": project.rootFolder.name},',
                "    }, sort_keys=True))",
            ]
        )
    )


def _verify_script(
    marker: str,
    *,
    probe: str,
    cloud_name: str | None = None,
    lineage_id: str | None = None,
    version_id: str | None = None,
    creation_id: str | None = None,
    project_id: str | None = None,
    folder_id: str | None = None,
    version_number: int | None = None,
    require_modified: bool | None = None,
) -> str:
    if probe not in {"absent", "present"}:
        raise PlanGenerationError("probe expectation must be absent or present")
    helpers = _geometry_helpers(
        marker,
        creation_id=creation_id,
        lineage_id=lineage_id,
        version_id=version_id,
        cloud_name=cloud_name,
        project_id=project_id,
        folder_id=folder_id,
        version_number=version_number,
        require_modified=require_modified,
    )
    run_lines = [
        "def run(_context: str):",
        "    app, document, design = active_target()",
        f"    state = box_state(design, {_python_literal(probe)})",
        "    probe = design.userParameters.itemByName(UNDO_PARAMETER)",
    ]
    if probe == "present":
        run_lines.extend(
            [
                (
                    "    if not probe or abs(probe.value - 0.7) > 1e-8 "
                    "or probe.comment != MARKER:"
                ),
                '        raise RuntimeError("Undo probe is not restored exactly")',
            ]
        )
    else:
        run_lines.extend(
            [
                "    if probe:",
                '        raise RuntimeError("Undo probe is unexpectedly present")',
            ]
        )
    if cloud_name is not None:
        run_lines.extend(
            [
                "    if not document.isSaved:",
                '        raise RuntimeError("Saved target has no saved document state")',
                f"    if document.name != {_python_literal(cloud_name)}:",
                '        raise RuntimeError("Saved target name mismatch")',
                "    data_file = document.dataFile",
                "    if not data_file or not data_file.isComplete:",
                '        raise RuntimeError("Saved target has no DataFile")',
                "    if data_file.latestVersionNumber != data_file.versionNumber:",
                '        raise RuntimeError("Saved target is not the latest complete version")',
            ]
        )
        if lineage_id is not None:
            run_lines.extend(
                [
                    f"    if data_file.id != {_python_literal(lineage_id)}:",
                    '        raise RuntimeError("Saved target lineage mismatch")',
                ]
            )
        if version_id is not None:
            run_lines.extend(
                [
                    f"    if data_file.versionId != {_python_literal(version_id)}:",
                    '        raise RuntimeError("Saved target version mismatch")',
                ]
            )
        identity = (
            '{"lineage_id": data_file.id, "version_id": data_file.versionId, '
            '"name": document.name, "creation_id": document.creationId}'
        )
    else:
        identity = (
            '{"lineage_id": None, "version_id": None, "name": document.name, '
            '"creation_id": document.creationId}'
        )
    run_lines.extend(
        [
            "    print(json.dumps({",
            '        "success": True,',
            '        "stage": "native_verify",',
            f'        "identity": {identity},',
            f'        "probe": {_python_literal(probe)},',
            '        "geometry": state,',
            "    }, sort_keys=True))",
        ]
    )
    return _check_script(
        "\n\n".join(
            [
                "import adsk.core\nimport adsk.fusion\nimport json",
                helpers,
                "\n".join(run_lines),
            ]
        )
    )


def _add_probe_script(
    marker: str,
    *,
    creation_id: str | None = None,
    cloud_name: str | None = None,
    lineage_id: str | None = None,
    version_id: str | None = None,
    project_id: str | None = None,
    folder_id: str | None = None,
    version_number: int | None = None,
) -> str:
    helpers = _geometry_helpers(
        marker,
        creation_id=creation_id,
        cloud_name=cloud_name,
        lineage_id=lineage_id,
        version_id=version_id,
        project_id=project_id,
        folder_id=folder_id,
        version_number=version_number,
        require_modified=True if lineage_id is not None else None,
    )
    return _check_script(
        "\n\n".join(
            [
                "import adsk.core\nimport adsk.fusion\nimport json",
                helpers,
                textwrap.dedent(
                    """
                    def run(_context: str):
                        app, document, design = active_target()
                        state = box_state(design, "absent")
                        if design.userParameters.itemByName(UNDO_PARAMETER):
                            raise RuntimeError("Undo probe already exists")
                        probe = design.userParameters.add(
                            UNDO_PARAMETER,
                            adsk.core.ValueInput.createByString("7 mm"),
                            "mm",
                            MARKER,
                        )
                        if not probe or abs(probe.value - 0.7) > 1e-8:
                            raise RuntimeError("Undo probe creation failed")
                        final = box_state(design, "present")
                        print(json.dumps({
                            "success": True,
                            "stage": "undo_probe_added",
                            "document_creation_id": document.creationId,
                            "probe_value_cm": probe.value,
                            "geometry_before": state,
                            "geometry_after": final,
                        }, sort_keys=True))
                    """
                ).strip(),
            ]
        )
    )


def _save_as_script(
    marker: str,
    cloud_name: str,
    *,
    project_id: str,
    project_name: str | None,
) -> str:
    helpers = _geometry_helpers(marker)
    project_guards = [
        f"    if project.id != {_python_literal(project_id)}:",
        '        raise RuntimeError("Active project ID mismatch")',
    ]
    if project_name is not None:
        project_guards.extend(
            [
                f"    if project.name != {_python_literal(project_name)}:",
                '        raise RuntimeError("Active project name mismatch")',
            ]
        )
    run_lines = [
        "def run(_context: str):",
        "    app, document, design = active_target()",
        '    state = box_state(design, "present")',
        "    probe = design.userParameters.itemByName(UNDO_PARAMETER)",
        (
            "    if not probe or abs(probe.value - 0.7) > 1e-8 "
            "or probe.comment != MARKER:"
        ),
        (
            '        raise RuntimeError("Undo/redo probe is not restored '
            'before Save As")'
        ),
        "    if document.isSaved or document.dataFile is not None:",
        '        raise RuntimeError("Refusing Save As for an already saved document")',
        "    if not document.isModified:",
        (
            '        raise RuntimeError("Acceptance target is unexpectedly clean '
            'before Save As")'
        ),
        (
            "    project = app.data.dataProjects.itemById("
            f"{_python_literal(project_id)})"
        ),
        "    if not project or not project.rootFolder:",
        ('        raise RuntimeError("No exact project root folder is available")'),
        *project_guards,
        "    creation_id = document.creationId",
        "    response = {",
        '        "success": True,',
        '        "stage": "save_as_submitted",',
        '        "saved_returned": True,',
        '        "document": {"name": CLOUD_NAME, "creation_id": creation_id},',
        f'        "project": {{"id": {_python_literal(project_id)}}},',
        '        "geometry": state,',
        "    }",
        '    saved = document.saveAs(CLOUD_NAME, project.rootFolder, "", "")',
        "    if not saved:",
        '        raise RuntimeError("Document.saveAs returned false")',
        "    print(json.dumps(response, sort_keys=True))",
    ]
    return _check_script(
        "\n\n".join(
            [
                "import adsk.core\nimport adsk.fusion\nimport json",
                helpers,
                f"CLOUD_NAME = {_python_literal(cloud_name)}",
                "\n".join(run_lines),
            ]
        )
    )


def _save_existing_script(
    marker: str,
    cloud_name: str,
    *,
    lineage_id: str,
    version_id: str,
    creation_id: str | None = None,
    project_id: str | None = None,
    folder_id: str | None = None,
    version_number: int | None = None,
) -> str:
    helpers = _geometry_helpers(
        marker,
        creation_id=creation_id,
        cloud_name=cloud_name,
        lineage_id=lineage_id,
        version_id=version_id,
        project_id=project_id,
        folder_id=folder_id,
        version_number=version_number,
        require_modified=True,
    )
    run_lines = [
        "def run(_context: str):",
        "    app, document, design = active_target()",
        '    state = box_state(design, "present")',
        "    probe = design.userParameters.itemByName(UNDO_PARAMETER)",
        (
            "    if not probe or abs(probe.value - 0.7) > 1e-8 "
            "or probe.comment != MARKER:"
        ),
        '        raise RuntimeError("Undo/redo probe is not restored before save")',
        "    data_file = document.dataFile",
        "    if not document.isSaved or not data_file:",
        '        raise RuntimeError("Recovery model has no saved identity")',
        f"    if document.name != {_python_literal(cloud_name)}:",
        '        raise RuntimeError("Recovery model name mismatch")',
        f"    if data_file.id != {_python_literal(lineage_id)}:",
        '        raise RuntimeError("Recovery model lineage mismatch")',
        f"    if data_file.versionId != {_python_literal(version_id)}:",
        '        raise RuntimeError("Recovery model pre-save version mismatch")',
        "    if not document.isModified:",
        '        raise RuntimeError("Recovery model is unexpectedly clean before save")',
        "    current_creation_id = document.creationId",
        "    response = {",
        '        "success": True,',
        '        "stage": "existing_recovery_save_submitted",',
        '        "saved_returned": True,',
        '        "document": {',
        '            "name": CLOUD_NAME,',
        '            "creation_id": current_creation_id,',
        f'            "lineage_id": {_python_literal(lineage_id)},',
        f'            "source_version_id": {_python_literal(version_id)},',
        "        },",
        '        "geometry": state,',
        "    }",
        '    saved = document.save("Fusion MCP dual-cell acceptance model")',
        "    if not saved:",
        '        raise RuntimeError("Recovery model save returned false")',
        "    print(json.dumps(response, sort_keys=True))",
    ]
    return _check_script(
        "\n\n".join(
            [
                "import adsk.core\nimport adsk.fusion\nimport json",
                helpers,
                f"CLOUD_NAME = {_python_literal(cloud_name)}",
                "\n".join(run_lines),
            ]
        )
    )


def _electronics_arguments(
    schema: dict[str, Any], entity_type: str | None
) -> dict[str, Any]:
    properties = schema.get("properties")
    if not isinstance(properties, Mapping):
        raise PlanGenerationError("electronics schema has no properties object")
    entity_schema = properties.get("entity_type")
    if not isinstance(entity_schema, Mapping):
        raise PlanGenerationError("electronics schema has no entity_type property")
    enum = entity_schema.get("enum")
    if entity_type is None:
        if isinstance(enum, list) and "electronics.Net" in enum:
            entity_type = "electronics.Net"
        else:
            raise PlanGenerationError(
                "electronics entity type is not unambiguous; pass --electronics-entity-type"
            )
    return {"entity_type": entity_type}


def build_model_plan(
    schemas: Mapping[str, dict[str, Any]],
    *,
    marker: str,
    cloud_name: str,
    electronics_error_layer: str,
    electronics_entity_type: str | None = None,
    project_id: str,
    project_name: str | None = None,
) -> dict[str, Any]:
    """Build the single-session model/undo/redo/save acceptance plan."""
    if electronics_error_layer not in {"inner", "mcp"}:
        raise PlanGenerationError("electronics error layer must be inner or mcp")
    if not isinstance(project_id, str) or not project_id.strip():
        raise PlanGenerationError("exact Fusion API project ID is required")
    electronics_args = _electronics_arguments(
        schemas["fusion_mcp_electronics_read"], electronics_entity_type
    )
    calls = [
        _call(
            schemas,
            identifier="read-baseline-open-documents",
            tool="fusion_mcp_read",
            arguments={"queryType": "document", "operation": "open"},
            capture_response=True,
        ),
        _call(
            schemas,
            identifier="electronics-route-expected-mechanical-precondition",
            tool="fusion_mcp_electronics_read",
            arguments=electronics_args,
            expect_mcp_error=electronics_error_layer == "mcp",
            expect_inner_success=(None if electronics_error_layer == "mcp" else False),
            capture_response=True,
        ),
        _call(
            schemas,
            identifier="preflight-active-project-before-mutation",
            tool="fusion_mcp_execute",
            arguments=_execute_arguments(
                _project_preflight_script(
                    project_id=project_id,
                    project_name=project_name,
                )
            ),
            capture_response=True,
        ),
        _call(
            schemas,
            identifier="create-isolated-20x30x10mm-parametric-sketch-extrude-box",
            tool="fusion_mcp_execute",
            arguments=_execute_arguments(_create_box_script(marker)),
            capture_response=True,
        ),
        _call(
            schemas,
            identifier="verify-native-box-topology-volume-bounds",
            tool="fusion_mcp_execute",
            arguments=_execute_arguments(_verify_script(marker, probe="absent")),
            capture_response=True,
        ),
        _call(
            schemas,
            identifier="verify-native-length-parameter-drives-solid-and-restores",
            tool="fusion_mcp_execute",
            arguments=_execute_arguments(_parameter_response_script(marker)),
            capture_response=True,
        ),
        _call(
            schemas,
            identifier="add-undo-probe-parameter",
            tool="fusion_mcp_execute",
            arguments=_execute_arguments(_add_probe_script(marker)),
            capture_response=True,
        ),
        _call(
            schemas,
            identifier="undo-probe-parameter",
            tool="fusion_mcp_update",
            arguments={"featureType": "undo"},
            capture_response=True,
        ),
        _call(
            schemas,
            identifier="verify-probe-absent-after-undo",
            tool="fusion_mcp_execute",
            arguments=_execute_arguments(_verify_script(marker, probe="absent")),
            capture_response=True,
        ),
        _call(
            schemas,
            identifier="redo-probe-parameter",
            tool="fusion_mcp_update",
            arguments={"featureType": "redo"},
            capture_response=True,
        ),
        _call(
            schemas,
            identifier="verify-probe-restored-after-redo",
            tool="fusion_mcp_execute",
            arguments=_execute_arguments(_verify_script(marker, probe="present")),
            capture_response=True,
        ),
        _call(
            schemas,
            identifier="save-as-unique-cloud-artifact",
            tool="fusion_mcp_execute",
            arguments=_execute_arguments(
                _save_as_script(
                    marker,
                    cloud_name,
                    project_id=project_id,
                    project_name=project_name,
                )
            ),
            capture_response=True,
        ),
    ]
    return _plan(calls)


def build_inspect_empty_recovery_plan(
    schemas: Mapping[str, dict[str, Any]],
) -> dict[str, Any]:
    """Build one read-only fingerprint of a possible failed-create document."""
    return _plan(
        [
            _call(
                schemas,
                identifier="inspect-only-active-recovery-document",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(_inspect_empty_document_script()),
                capture_response=True,
            )
        ]
    )


def build_create_empty_checkpoint_plan(
    schemas: Mapping[str, dict[str, Any]],
) -> dict[str, Any]:
    """Create and natively read back one new blank parametric document."""
    return _plan(
        [
            _call(
                schemas,
                identifier="create-and-read-back-empty-parametric-checkpoint",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(
                    _create_empty_parametric_document_script()
                ),
                capture_response=True,
            )
        ]
    )


def build_convert_empty_recovery_plan(
    schemas: Mapping[str, dict[str, Any]], *, creation_id: str
) -> dict[str, Any]:
    """Convert one exact empty DirectDesign document and nothing else."""
    return _plan(
        [
            _call(
                schemas,
                identifier="convert-exact-empty-direct-document-to-parametric",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(
                    _convert_empty_document_script(creation_id=creation_id)
                ),
                capture_response=True,
            )
        ]
    )


def build_verify_empty_recovery_plan(
    schemas: Mapping[str, dict[str, Any]],
    *,
    creation_id: str,
    lineage_id: str | None = None,
    version_id: str | None = None,
) -> dict[str, Any]:
    """Read back one exact empty parametric document before or after Save As."""
    if (lineage_id is None) != (version_id is None):
        raise PlanGenerationError(
            "empty recovery verification needs both lineage and version or neither"
        )
    return _plan(
        [
            _call(
                schemas,
                identifier=(
                    "verify-exact-saved-empty-parametric-recovery"
                    if lineage_id is not None
                    else "verify-exact-unsaved-empty-parametric-recovery"
                ),
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(
                    _verify_empty_parametric_script(
                        creation_id=creation_id,
                        require_saved=lineage_id is not None,
                        lineage_id=lineage_id,
                        version_id=version_id,
                    )
                ),
                capture_response=True,
            )
        ]
    )


def build_save_empty_recovery_plan(
    schemas: Mapping[str, dict[str, Any]],
    *,
    creation_id: str,
    cloud_name: str,
    project_id: str,
    folder_id: str,
    project_name: str | None = None,
) -> dict[str, Any]:
    """Save one exact empty parametric recovery document before modeling."""
    if not isinstance(project_id, str) or not project_id.strip():
        raise PlanGenerationError("exact Fusion API project ID is required")
    return _plan(
        [
            _call(
                schemas,
                identifier="save-as-exact-empty-parametric-recovery",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(
                    _save_empty_parametric_script(
                        creation_id=creation_id,
                        cloud_name=cloud_name,
                        project_id=project_id,
                        folder_id=folder_id,
                        project_name=project_name,
                    )
                ),
                capture_response=True,
            )
        ]
    )


def build_capture_saved_empty_recovery_plan(
    schemas: Mapping[str, dict[str, Any]],
    *,
    creation_id: str,
    cloud_name: str,
    project_id: str,
    folder_id: str,
    project_name: str | None = None,
) -> dict[str, Any]:
    """Capture stable cloud identity after Save As may rotate creationId.

    ``creation_id`` is the pre-Save-As document ID and is retained only as
    provenance in the response.  The saved document is bound independently by
    its sole-active status, exact cloud/project/root identity, clean complete
    version-1 state, and empty native parametric structure.
    """
    return _plan(
        [
            _call(
                schemas,
                identifier="capture-stable-saved-empty-recovery-identity",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(
                    _capture_saved_empty_identity_script(
                        pre_save_creation_id=creation_id,
                        cloud_name=cloud_name,
                        project_id=project_id,
                        folder_id=folder_id,
                        project_name=project_name,
                    )
                ),
                capture_response=True,
            )
        ]
    )


def build_saved_recovery_model_plan(
    schemas: Mapping[str, dict[str, Any]],
    *,
    marker: str,
    creation_id: str,
    cloud_name: str,
    project_id: str,
    folder_id: str,
    lineage_id: str,
    version_id: str,
    version_number: int,
) -> dict[str, Any]:
    """Build the model in one already-saved exact empty checkpoint."""
    return _plan(
        [
            _call(
                schemas,
                identifier="build-parametric-box-in-exact-saved-empty-recovery",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(
                    _build_saved_empty_document_script(
                        marker=marker,
                        creation_id=creation_id,
                        cloud_name=cloud_name,
                        project_id=project_id,
                        folder_id=folder_id,
                        lineage_id=lineage_id,
                        version_id=version_id,
                        version_number=version_number,
                    )
                ),
                capture_response=True,
            ),
        ]
    )


def _saved_model_binding(
    *,
    marker: str,
    creation_id: str,
    cloud_name: str,
    project_id: str,
    folder_id: str,
    lineage_id: str,
    version_id: str,
    version_number: int,
    probe: str,
) -> dict[str, Any]:
    return {
        "marker": marker,
        "probe": probe,
        "creation_id": creation_id,
        "cloud_name": cloud_name,
        "project_id": project_id,
        "folder_id": folder_id,
        "lineage_id": lineage_id,
        "version_id": version_id,
        "version_number": version_number,
        "require_modified": True,
    }


def build_verify_saved_recovery_model_plan(
    schemas: Mapping[str, dict[str, Any]],
    *,
    marker: str,
    creation_id: str,
    cloud_name: str,
    project_id: str,
    folder_id: str,
    lineage_id: str,
    version_id: str,
    version_number: int,
) -> dict[str, Any]:
    """Verify one dirty model against the exact empty-checkpoint identity."""
    return _plan(
        [
            _call(
                schemas,
                identifier="verify-recovered-native-box-topology-volume-bounds",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(
                    _verify_script(
                        **_saved_model_binding(
                            marker=marker,
                            creation_id=creation_id,
                            cloud_name=cloud_name,
                            project_id=project_id,
                            folder_id=folder_id,
                            lineage_id=lineage_id,
                            version_id=version_id,
                            version_number=version_number,
                            probe="absent",
                        )
                    )
                ),
                capture_response=True,
            ),
        ]
    )


def build_add_recovery_probe_plan(
    schemas: Mapping[str, dict[str, Any]], **binding: Any
) -> dict[str, Any]:
    return _plan(
        [
            _call(
                schemas,
                identifier="add-recovery-undo-probe-parameter",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(_add_probe_script(**binding)),
                capture_response=True,
            )
        ]
    )


def _update_only_plan(
    schemas: Mapping[str, dict[str, Any]], *, feature_type: str
) -> dict[str, Any]:
    return _plan(
        [
            _call(
                schemas,
                identifier=f"{feature_type}-recovery-probe-parameter",
                tool="fusion_mcp_update",
                arguments={"featureType": feature_type},
                capture_response=True,
            )
        ]
    )


def build_recovery_undo_plan(
    schemas: Mapping[str, dict[str, Any]],
) -> dict[str, Any]:
    return _update_only_plan(schemas, feature_type="undo")


def build_recovery_redo_plan(
    schemas: Mapping[str, dict[str, Any]],
) -> dict[str, Any]:
    return _update_only_plan(schemas, feature_type="redo")


def _verify_recovery_probe_plan(
    schemas: Mapping[str, dict[str, Any]], *, probe: str, **binding: Any
) -> dict[str, Any]:
    return _plan(
        [
            _call(
                schemas,
                identifier=f"verify-recovery-probe-{probe}",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(
                    _verify_script(**_saved_model_binding(probe=probe, **binding))
                ),
                capture_response=True,
            )
        ]
    )


def build_verify_recovery_undo_plan(
    schemas: Mapping[str, dict[str, Any]], **binding: Any
) -> dict[str, Any]:
    return _verify_recovery_probe_plan(schemas, probe="absent", **binding)


def build_verify_recovery_redo_plan(
    schemas: Mapping[str, dict[str, Any]], **binding: Any
) -> dict[str, Any]:
    return _verify_recovery_probe_plan(schemas, probe="present", **binding)


def build_recovery_parameter_response_plan(
    schemas: Mapping[str, dict[str, Any]], **binding: Any
) -> dict[str, Any]:
    return _plan(
        [
            _call(
                schemas,
                identifier="verify-recovered-three-axis-parameter-response",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(
                    _parameter_response_script(expected_probe="present", **binding)
                ),
                capture_response=True,
            )
        ]
    )


def build_save_existing_recovery_plan(
    schemas: Mapping[str, dict[str, Any]],
    *,
    marker: str,
    creation_id: str,
    cloud_name: str,
    project_id: str,
    folder_id: str,
    lineage_id: str,
    source_version_id: str,
    source_version_number: int,
) -> dict[str, Any]:
    """Submit one exact existing-model save; post-save identity is captured later."""
    return _plan(
        [
            _call(
                schemas,
                identifier="save-exact-existing-recovery-lineage",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(
                    _save_existing_script(
                        marker,
                        cloud_name,
                        creation_id=creation_id,
                        project_id=project_id,
                        folder_id=folder_id,
                        lineage_id=lineage_id,
                        version_id=source_version_id,
                        version_number=source_version_number,
                    )
                ),
                capture_response=True,
            )
        ]
    )


def _capture_saved_model_script(
    *,
    marker: str,
    creation_id: str,
    cloud_name: str,
    project_id: str,
    folder_id: str,
    lineage_id: str,
    source_version_id: str,
    source_version_number: int,
) -> str:
    helpers = _geometry_helpers(marker)
    expected_next = source_version_number + 1
    return _check_script(
        "\n\n".join(
            [
                "import adsk.core\nimport adsk.fusion\nimport json",
                helpers,
                "\n".join(
                    [
                        f"SOURCE_VERSION_ID = {_python_literal(source_version_id)}",
                        f"SOURCE_VERSION_NUMBER = {source_version_number}",
                        "source_version_number = SOURCE_VERSION_NUMBER",
                        "",
                        "def run(_context: str):",
                        "    app, document, design = active_target()",
                        "    if app.documents.count != 1:",
                        '        raise RuntimeError("Saved model is not the only open document")',
                        f"    if document.creationId != {_python_literal(creation_id)}:",
                        '        raise RuntimeError("Saved model creation ID mismatch")',
                        f"    if document.name != {_python_literal(cloud_name)}:",
                        '        raise RuntimeError("Saved model name mismatch")',
                        "    data_file = document.dataFile",
                        "    if not document.isSaved or document.isModified or not data_file:",
                        '        raise RuntimeError("Saved model is not stable and clean")',
                        "    if not data_file.isComplete:",
                        '        raise RuntimeError("Saved model DataFile is incomplete")',
                        f"    if data_file.name != {_python_literal(cloud_name)}:",
                        '        raise RuntimeError("Saved model DataFile name mismatch")',
                        f"    if data_file.id != {_python_literal(lineage_id)}:",
                        '        raise RuntimeError("Saved model lineage mismatch")',
                        "    if data_file.versionId == SOURCE_VERSION_ID:",
                        '        raise RuntimeError("Saved model version did not advance")',
                        "    if data_file.versionNumber != source_version_number + 1:",
                        '        raise RuntimeError("Saved model version number did not advance once")',
                        "    if data_file.latestVersionNumber != data_file.versionNumber:",
                        '        raise RuntimeError("Saved model is not the latest version")',
                        "    parent_project = data_file.parentProject",
                        "    parent_folder = data_file.parentFolder",
                        f"    if not parent_project or parent_project.id != {_python_literal(project_id)}:",
                        '        raise RuntimeError("Saved model project mismatch")',
                        f"    if not parent_folder or parent_folder.id != {_python_literal(folder_id)}:",
                        '        raise RuntimeError("Saved model folder mismatch")',
                        "    if not parent_folder.isRoot or parent_project.rootFolder.id != parent_folder.id:",
                        '        raise RuntimeError("Saved model is not in exact project root")',
                        '    state = box_state(design, "present")',
                        "    print(json.dumps({",
                        '        "success": True,',
                        '        "stage": "saved_model_identity_captured",',
                        '        "creation_id": document.creationId,',
                        '        "lineage_id": data_file.id,',
                        '        "version_id": data_file.versionId,',
                        '        "version_number": data_file.versionNumber,',
                        '        "is_complete": bool(data_file.isComplete),',
                        f'        "expected_version_number": {expected_next},',
                        '        "geometry": state,',
                        "    }, sort_keys=True))",
                    ]
                ),
            ]
        )
    )


def build_capture_saved_model_plan(
    schemas: Mapping[str, dict[str, Any]], **identity: Any
) -> dict[str, Any]:
    """Capture the next complete exact cloud version after save settle/census."""
    return _plan(
        [
            _call(
                schemas,
                identifier="capture-stable-saved-model-identity",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(_capture_saved_model_script(**identity)),
                capture_response=True,
            )
        ]
    )


def _failed_partial_box_helpers(
    *,
    marker: str,
    creation_id: str,
    cloud_name: str,
    project_id: str,
    folder_id: str,
    lineage_id: str,
    version_id: str,
    version_number: int,
) -> str:
    """Return exact-target and bounded read-only partial-branch helpers."""
    constants = "\n".join(
        [
            f"MARKER = {_python_literal(marker)}",
            f"MARKER_PARAMETER = {_python_literal(_MARKER_PARAMETER)}",
            f"LENGTH_PARAMETER = {_python_literal(_LENGTH_PARAMETER)}",
            f"WIDTH_PARAMETER = {_python_literal(_WIDTH_PARAMETER)}",
            f"HEIGHT_PARAMETER = {_python_literal(_HEIGHT_PARAMETER)}",
            f"SKETCH_NAME = {_python_literal(_SKETCH_NAME)}",
            f"EXPECTED_CREATION_ID = {_python_literal(creation_id)}",
            f"EXPECTED_CLOUD_NAME = {_python_literal(cloud_name)}",
            f"EXPECTED_PROJECT_ID = {_python_literal(project_id)}",
            f"EXPECTED_FOLDER_ID = {_python_literal(folder_id)}",
            f"EXPECTED_LINEAGE_ID = {_python_literal(lineage_id)}",
            f"EXPECTED_VERSION_ID = {_python_literal(version_id)}",
            f"EXPECTED_VERSION_NUMBER = {version_number}",
        ]
    )
    helpers = textwrap.dedent(
        """
        def partial_target():
            app = adsk.core.Application.get()
            document = app.activeDocument
            design = adsk.fusion.Design.cast(app.activeProduct)
            if not document or not design:
                raise RuntimeError("No active failed-branch Fusion design")
            if app.documents.count != 1 or document != app.activeDocument:
                raise RuntimeError("Failed branch is not the sole active document")
            ui = app.userInterface
            if not ui or ui.activeCommand != "SelectCommand":
                raise RuntimeError("Failed branch is not in SelectCommand")
            if ui.activeSelections.count != 0:
                raise RuntimeError("Failed branch has active selections")
            if design.designType != adsk.fusion.DesignTypes.ParametricDesignType:
                raise RuntimeError("Failed branch is not parametric")
            root = design.rootComponent
            if design.activeEditObject not in (None, root):
                raise RuntimeError("Failed branch has an active edit object")
            if design.snapshots.hasPendingSnapshot:
                raise RuntimeError("Failed branch has a pending snapshot")
            if document.creationId != EXPECTED_CREATION_ID:
                raise RuntimeError("Failed branch creation ID mismatch")
            if document.name != EXPECTED_CLOUD_NAME:
                raise RuntimeError("Failed branch cloud name mismatch")
            if not document.isSaved or not document.isModified:
                raise RuntimeError("Failed branch is not saved-and-modified")
            data_file = document.dataFile
            if not data_file or not data_file.isComplete:
                raise RuntimeError("Failed branch has no complete DataFile")
            if data_file.name != EXPECTED_CLOUD_NAME:
                raise RuntimeError("Failed branch DataFile name mismatch")
            if data_file.id != EXPECTED_LINEAGE_ID:
                raise RuntimeError("Failed branch lineage mismatch")
            if data_file.versionId != EXPECTED_VERSION_ID:
                raise RuntimeError("Failed branch version mismatch")
            if data_file.versionNumber != EXPECTED_VERSION_NUMBER:
                raise RuntimeError("Failed branch version number mismatch")
            if data_file.latestVersionNumber != data_file.versionNumber:
                raise RuntimeError("Failed branch is not based on the latest version")
            parent_project = data_file.parentProject
            parent_folder = data_file.parentFolder
            if not parent_project or parent_project.id != EXPECTED_PROJECT_ID:
                raise RuntimeError("Failed branch project mismatch")
            if not parent_folder or parent_folder.id != EXPECTED_FOLDER_ID:
                raise RuntimeError("Failed branch folder mismatch")
            if not parent_folder.isRoot:
                raise RuntimeError("Failed branch folder is not the project root")
            if parent_project.rootFolder.id != parent_folder.id:
                raise RuntimeError("Failed branch project-root binding mismatch")
            return app, document, design, root, ui, data_file

        def partial_fingerprint(design, root, ui, data_file):
            parameter_count = design.userParameters.count
            sketch_count = root.sketches.count
            native_timeline = design.timeline
            if native_timeline is None:
                raise RuntimeError("Failed branch parametric timeline is unavailable")
            timeline_groups = native_timeline.timelineGroups
            timeline_group_count = (
                timeline_groups.count if timeline_groups is not None else 0
            )
            timeline_count = native_timeline.count
            if parameter_count > 8:
                raise RuntimeError("Failed branch parameter inventory exceeds bound")
            if sketch_count > 2:
                raise RuntimeError("Failed branch sketch inventory exceeds bound")
            if timeline_count > 4:
                raise RuntimeError("Failed branch timeline inventory exceeds bound")

            parameters = []
            for index in range(parameter_count):
                parameter = design.userParameters.item(index)
                if not parameter:
                    raise RuntimeError("Failed branch has an unreadable parameter")
                parameters.append({
                    "name": parameter.name,
                    "expression": parameter.expression,
                    "unit": parameter.unit,
                    "value_cm": parameter.value,
                    "comment": parameter.comment,
                })
            parameters.sort(key=lambda row: row["name"])

            sketches = []
            for sketch_index in range(sketch_count):
                sketch = root.sketches.item(sketch_index)
                if not sketch:
                    raise RuntimeError("Failed branch has an unreadable sketch")
                line_count = sketch.sketchCurves.sketchLines.count
                dimension_count = sketch.sketchDimensions.count
                constraint_count = sketch.geometricConstraints.count
                profile_count = sketch.profiles.count
                point_count = sketch.sketchPoints.count
                if line_count > 16 or point_count > 32:
                    raise RuntimeError("Failed branch sketch geometry exceeds bound")
                if dimension_count > 8 or constraint_count > 32 or profile_count > 4:
                    raise RuntimeError("Failed branch sketch semantics exceed bound")
                lines = []
                for line_index in range(line_count):
                    line = sketch.sketchCurves.sketchLines.item(line_index)
                    if not line:
                        raise RuntimeError("Failed branch has an unreadable sketch line")
                    start = line.startSketchPoint.geometry
                    end = line.endSketchPoint.geometry
                    lines.append({
                        "start_cm": [start.x, start.y, start.z],
                        "end_cm": [end.x, end.y, end.z],
                        "construction": bool(line.isConstruction),
                        "fixed": bool(line.isFixed),
                        "valid": bool(line.isValid),
                    })
                dimensions = []
                for dimension_index in range(dimension_count):
                    raw_dimension = sketch.sketchDimensions.item(dimension_index)
                    linear = adsk.fusion.SketchLinearDimension.cast(raw_dimension)
                    dimensions.append({
                        "object_type": raw_dimension.objectType,
                        "linear": linear is not None,
                        "driving": bool(linear.isDriving) if linear else None,
                        "orientation": int(linear.orientation) if linear else None,
                        "expression": linear.parameter.expression if linear else None,
                    })
                constraints = []
                for constraint_index in range(constraint_count):
                    constraint = sketch.geometricConstraints.item(constraint_index)
                    constraints.append(constraint.objectType if constraint else None)
                sketches.append({
                    "name": sketch.name,
                    "valid": bool(sketch.isValid),
                    "health_state": int(sketch.healthState),
                    "health_message": sketch.errorOrWarningMessage,
                    "fully_constrained": bool(sketch.isFullyConstrained),
                    "profiles": profile_count,
                    "points": point_count,
                    "lines": lines,
                    "dimensions": dimensions,
                    "constraint_types": constraints,
                })

            timeline = []
            for index in range(timeline_count):
                item = native_timeline.item(index)
                entity = item.entity if item else None
                timeline.append({
                    "is_group": bool(item.isGroup) if item else None,
                    "entity_type": entity.objectType if entity else None,
                    "is_first_sketch": (
                        sketch_count == 1
                        and adsk.fusion.Sketch.cast(entity) == root.sketches.item(0)
                    ),
                })
            return {
                "identity": {
                    "creation_id": EXPECTED_CREATION_ID,
                    "cloud_name": EXPECTED_CLOUD_NAME,
                    "project_id": data_file.parentProject.id,
                    "folder_id": data_file.parentFolder.id,
                    "lineage_id": data_file.id,
                    "version_id": data_file.versionId,
                    "version_number": data_file.versionNumber,
                    "is_saved": True,
                    "is_modified": True,
                },
                "interaction": {
                    "active_command": ui.activeCommand,
                    "active_selection_count": ui.activeSelections.count,
                    "active_edit_is_root_or_none": design.activeEditObject in (None, root),
                    "pending_snapshot": bool(design.snapshots.hasPendingSnapshot),
                },
                "inventory": {
                    "all_components": design.allComponents.count,
                    "occurrences": root.occurrences.count,
                    "all_occurrences": root.allOccurrences.count,
                    "bodies": root.bRepBodies.count,
                    "mesh_bodies": root.meshBodies.count,
                    "features": root.features.count,
                    "base_features": root.features.baseFeatures.count,
                    "extrudes": root.features.extrudeFeatures.count,
                    "sketches": sketch_count,
                    "parameters": parameter_count,
                    "timeline_count": timeline_count,
                    "timeline_marker": native_timeline.markerPosition,
                    "timeline_groups": timeline_group_count,
                },
                "parameters": parameters,
                "sketch_records": sketches,
                "timeline": timeline,
            }
        """
    ).strip()
    return constants + "\n\n" + helpers


def _inspect_failed_partial_box_script(**binding: Any) -> str:
    helpers = _failed_partial_box_helpers(**binding)
    return _check_script(
        "\n\n".join(
            [
                "import adsk.core\nimport adsk.fusion\nimport json",
                helpers,
                textwrap.dedent(
                    """
                    def run(_context: str):
                        app, document, design, root, ui, data_file = partial_target()
                        fingerprint = partial_fingerprint(design, root, ui, data_file)
                        print(json.dumps({
                            "success": True,
                            "stage": "failed_partial_box_inspected",
                            "open_document_count": app.documents.count,
                            "fingerprint": fingerprint,
                        }, sort_keys=True))
                    """
                ).strip(),
            ]
        )
    )


def build_inspect_failed_partial_box_plan(
    schemas: Mapping[str, dict[str, Any]], **binding: Any
) -> dict[str, Any]:
    """Inspect one exact dirty failed box branch without changing Fusion state."""
    return _plan(
        [
            _call(
                schemas,
                identifier="inspect-exact-failed-partial-box-branch",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(
                    _inspect_failed_partial_box_script(**binding)
                ),
                capture_response=True,
            )
        ]
    )


def _discard_empty_failed_branch_script(**binding: Any) -> str:
    helpers = _failed_partial_box_helpers(**binding)
    return _check_script(
        "\n\n".join(
            [
                "import adsk.core\nimport adsk.fusion\nimport json",
                helpers,
                textwrap.dedent(
                    """
                    def run(_context: str):
                        app, document, design, root, ui, data_file = partial_target()
                        fingerprint = partial_fingerprint(design, root, ui, data_file)
                        expected_inventory = {
                            "all_components": 1,
                            "occurrences": 0,
                            "all_occurrences": 0,
                            "bodies": 0,
                            "mesh_bodies": 0,
                            "features": 0,
                            "base_features": 0,
                            "extrudes": 0,
                            "sketches": 0,
                            "parameters": 0,
                            "timeline_count": 0,
                            "timeline_marker": 0,
                            "timeline_groups": 0,
                        }
                        expected_interaction = {
                            "active_command": "SelectCommand",
                            "active_selection_count": 0,
                            "active_edit_is_root_or_none": True,
                            "pending_snapshot": False,
                        }
                        if fingerprint["inventory"] != expected_inventory:
                            raise RuntimeError("Failed branch is not natively empty")
                        if fingerprint["interaction"] != expected_interaction:
                            raise RuntimeError("Failed branch interaction state drifted")
                        if (
                            fingerprint["parameters"] != []
                            or fingerprint["sketch_records"] != []
                            or fingerprint["timeline"] != []
                        ):
                            raise RuntimeError("Failed branch fingerprint is not empty")
                        response = {
                            "success": True,
                            "stage": "exact_empty_failed_branch_discard_submitted",
                            "fingerprint": fingerprint,
                        }
                        closed = document.close(False)
                        if not closed:
                            raise RuntimeError("Exact failed branch close returned false")
                        print(json.dumps(response, sort_keys=True))
                    """
                ).strip(),
            ]
        )
    )


def build_discard_empty_failed_branch_plan(
    schemas: Mapping[str, dict[str, Any]], **binding: Any
) -> dict[str, Any]:
    """Discard only an exact saved-v1 dirty branch proven natively empty."""
    return _plan(
        [
            _call(
                schemas,
                identifier="discard-exact-empty-failed-box-branch",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(
                    _discard_empty_failed_branch_script(**binding)
                ),
                capture_response=True,
            )
        ]
    )


def build_project_preflight_plan(
    schemas: Mapping[str, dict[str, Any]],
    *,
    project_id: str,
    project_name: str | None = None,
) -> dict[str, Any]:
    """Build one read-only exact-project canary with zero document mutations."""
    if not isinstance(project_id, str) or not project_id.strip():
        raise PlanGenerationError("exact Fusion API project ID is required")
    return _plan(
        [
            _call(
                schemas,
                identifier="preflight-exact-project-read-only-canary",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(
                    _project_preflight_script(
                        project_id=project_id,
                        project_name=project_name,
                    )
                ),
                capture_response=True,
            )
        ]
    )


def build_read_plan(
    schemas: Mapping[str, dict[str, Any]],
    *,
    marker: str,
    cloud_name: str,
    lineage_id: str | None = None,
    version_id: str | None = None,
) -> dict[str, Any]:
    """Build a post-save identity and native-state read plan."""
    return _plan(
        [
            _call(
                schemas,
                identifier="read-saved-native-identity-and-geometry",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(
                    _verify_script(
                        marker,
                        probe="present",
                        cloud_name=cloud_name,
                        lineage_id=lineage_id,
                        version_id=version_id,
                    )
                ),
                capture_response=True,
            ),
        ]
    )


def build_close_plan(
    schemas: Mapping[str, dict[str, Any]],
    *,
    marker: str,
    cloud_name: str,
    lineage_id: str,
    version_id: str,
) -> dict[str, Any]:
    """Close one exact clean saved document in the same native transaction."""
    script = _verify_script(
        marker,
        probe="present",
        cloud_name=cloud_name,
        lineage_id=lineage_id,
        version_id=version_id,
        require_modified=False,
    )
    prefix, _separator, _entry = script.rpartition("def run(_context: str):")
    if not prefix:
        raise PlanGenerationError("exact close could not bind verifier helpers")
    close_run = textwrap.dedent(
        f"""
        def run(_context: str):
            app, document, design = active_target()
            state = box_state(design, "present")
            probe = design.userParameters.itemByName(UNDO_PARAMETER)
            if not probe or abs(probe.value - 0.7) > 1e-8 or probe.comment != MARKER:
                raise RuntimeError("Undo probe is not present before exact close")
            if not document.isSaved or document.isModified:
                raise RuntimeError("Exact close target is not saved and clean")
            data_file = document.dataFile
            if not data_file or not data_file.isComplete:
                raise RuntimeError("Exact close DataFile is not complete")
            if data_file.latestVersionNumber != data_file.versionNumber:
                raise RuntimeError("Exact close target is not latest")
            if document.name != {_python_literal(cloud_name)}:
                raise RuntimeError("Exact close name mismatch")
            if data_file.id != {_python_literal(lineage_id)}:
                raise RuntimeError("Exact close lineage mismatch")
            if data_file.versionId != {_python_literal(version_id)}:
                raise RuntimeError("Exact close version mismatch")
            response = {{
                "success": True,
                "stage": "exact_clean_document_close_submitted",
                "lineage_id": {_python_literal(lineage_id)},
                "version_id": {_python_literal(version_id)},
                "geometry": state,
            }}
            closed = document.close(False)
            if not closed:
                raise RuntimeError("Exact clean document close returned false")
            print(json.dumps(response, sort_keys=True))
        """
    ).strip()
    return _plan(
        [
            _call(
                schemas,
                identifier="close-exact-active-clean-document",
                tool="fusion_mcp_execute",
                arguments=_execute_arguments(_check_script(prefix + close_run)),
                capture_response=True,
            ),
        ]
    )


def build_reopen_plan(
    schemas: Mapping[str, dict[str, Any]], *, file_id: str
) -> dict[str, Any]:
    """Build one exact document-open lifecycle request."""
    return _plan(
        [
            _call(
                schemas,
                identifier="reopen-exact-saved-document",
                tool="fusion_mcp_execute",
                arguments={
                    "featureType": "document",
                    "object": {"operation": "open", "fileId": file_id},
                },
                capture_response=True,
            )
        ]
    )


def build_verify_plan(
    schemas: Mapping[str, dict[str, Any]],
    *,
    marker: str,
    cloud_name: str,
    lineage_id: str,
    version_id: str,
) -> dict[str, Any]:
    """Build a post-reopen exact identity/native persistence plan."""
    return build_read_plan(
        schemas,
        marker=marker,
        cloud_name=cloud_name,
        lineage_id=lineage_id,
        version_id=version_id,
    )


def _owner_only_atomic_write(path: Path, value: object) -> None:
    path = Path(os.path.abspath(path.expanduser()))
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    if path.is_symlink():
        raise PlanGenerationError("plan output path must not be a symlink")
    if path.exists():
        metadata = path.stat()
        if not stat.S_ISREG(metadata.st_mode) or metadata.st_uid != os.geteuid():
            raise PlanGenerationError(
                "existing plan must be an owner-held regular file"
            )
    encoded = (
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")
    temporary: Path | None = None
    try:
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=f".{path.name}.tmp-", dir=path.parent
        )
        temporary = Path(temporary_name)
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        temporary = None
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _default_identity(node: str) -> tuple[str, str]:
    safe_node = _SAFE_NODE.sub("-", node).strip("-") or "fusion"
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    suffix = uuid.uuid4().hex[:10]
    marker = f"fusion-mcp-live-acceptance:{safe_node}:{stamp}:{suffix}"
    cloud_name = f"Fusion-MCP-Acceptance-{safe_node}-{stamp}-{suffix}"
    return marker, cloud_name


def _add_schema_report(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--schema-report", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--node", required=True)


def _add_saved_identity(parser: argparse.ArgumentParser, *, exact: bool) -> None:
    parser.add_argument("--marker", required=True)
    parser.add_argument("--cloud-name", required=True)
    parser.add_argument("--lineage-id", required=exact)
    parser.add_argument("--version-id", required=exact)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="phase", required=True)

    schema = subparsers.add_parser("schema-first")
    schema.add_argument("--output", type=Path, required=True)

    model = subparsers.add_parser("model")
    _add_schema_report(model)
    model.add_argument("--marker")
    model.add_argument("--cloud-name")
    model.add_argument(
        "--electronics-error-layer", choices=("inner", "mcp"), required=True
    )
    model.add_argument("--electronics-entity-type")
    model.add_argument("--project-id", required=True)
    model.add_argument("--project-name")

    inspect_empty = subparsers.add_parser("inspect-empty-recovery")
    _add_schema_report(inspect_empty)

    create_empty = subparsers.add_parser("create-empty-checkpoint")
    _add_schema_report(create_empty)

    convert_empty = subparsers.add_parser("convert-empty-recovery")
    _add_schema_report(convert_empty)
    convert_empty.add_argument("--creation-id", required=True)

    verify_empty = subparsers.add_parser("verify-empty-recovery")
    _add_schema_report(verify_empty)
    verify_empty.add_argument("--creation-id", required=True)
    verify_empty.add_argument("--lineage-id")
    verify_empty.add_argument("--version-id")

    save_empty = subparsers.add_parser("save-empty-recovery")
    _add_schema_report(save_empty)
    save_empty.add_argument("--creation-id", required=True)
    save_empty.add_argument("--cloud-name", required=True)
    save_empty.add_argument("--project-id", required=True)
    save_empty.add_argument("--folder-id", required=True)
    save_empty.add_argument("--project-name")

    capture_empty = subparsers.add_parser("capture-saved-empty-recovery")
    _add_schema_report(capture_empty)
    capture_empty.add_argument("--creation-id", required=True)
    capture_empty.add_argument("--cloud-name", required=True)
    capture_empty.add_argument("--project-id", required=True)
    capture_empty.add_argument("--folder-id", required=True)
    capture_empty.add_argument("--project-name")

    recovery_binding_phases = (
        "build-saved-recovery-model",
        "inspect-failed-partial-box",
        "discard-empty-failed-branch",
        "verify-saved-recovery-model",
        "add-recovery-probe",
        "verify-recovery-undo",
        "verify-recovery-redo",
        "recovery-parameter-response",
    )
    for phase in recovery_binding_phases:
        phase_parser = subparsers.add_parser(phase)
        _add_schema_report(phase_parser)
        phase_parser.add_argument("--marker", required=True)
        phase_parser.add_argument("--creation-id", required=True)
        phase_parser.add_argument("--cloud-name", required=True)
        phase_parser.add_argument("--project-id", required=True)
        phase_parser.add_argument("--folder-id", required=True)
        phase_parser.add_argument("--lineage-id", required=True)
        phase_parser.add_argument("--version-id", required=True)
        phase_parser.add_argument("--version-number", type=int, required=True)

    for phase in ("recovery-undo", "recovery-redo"):
        phase_parser = subparsers.add_parser(phase)
        _add_schema_report(phase_parser)

    for phase in ("save-existing-recovery", "capture-saved-model"):
        phase_parser = subparsers.add_parser(phase)
        _add_schema_report(phase_parser)
        phase_parser.add_argument("--marker", required=True)
        phase_parser.add_argument("--creation-id", required=True)
        phase_parser.add_argument("--cloud-name", required=True)
        phase_parser.add_argument("--project-id", required=True)
        phase_parser.add_argument("--folder-id", required=True)
        phase_parser.add_argument("--lineage-id", required=True)
        phase_parser.add_argument("--source-version-id", required=True)
        phase_parser.add_argument("--source-version-number", type=int, required=True)

    project_preflight = subparsers.add_parser("project-preflight")
    _add_schema_report(project_preflight)
    project_preflight.add_argument("--project-id", required=True)
    project_preflight.add_argument("--project-name")

    read = subparsers.add_parser("read")
    _add_schema_report(read)
    _add_saved_identity(read, exact=False)

    close = subparsers.add_parser("close")
    _add_schema_report(close)
    _add_saved_identity(close, exact=True)

    reopen = subparsers.add_parser("reopen")
    _add_schema_report(reopen)
    reopen.add_argument("--file-id", required=True)

    verify = subparsers.add_parser("verify")
    _add_schema_report(verify)
    _add_saved_identity(verify, exact=True)
    return parser


def main() -> None:
    parser = _parser()
    args = parser.parse_args()
    try:
        summary: dict[str, Any] = {"phase": args.phase}
        if args.phase == "schema-first":
            plan = schema_first_plan()
        else:
            schemas = load_captured_tool_schemas(
                args.schema_report.expanduser(), expected_node=args.node
            )
            if args.phase == "project-preflight":
                plan = build_project_preflight_plan(
                    schemas,
                    project_id=args.project_id,
                    project_name=args.project_name,
                )
            elif args.phase == "model":
                generated_marker, generated_name = _default_identity(args.node)
                marker = args.marker or generated_marker
                cloud_name = args.cloud_name or generated_name
                plan = build_model_plan(
                    schemas,
                    marker=marker,
                    cloud_name=cloud_name,
                    electronics_error_layer=args.electronics_error_layer,
                    electronics_entity_type=args.electronics_entity_type,
                    project_id=args.project_id,
                    project_name=args.project_name,
                )
                summary.update({"marker": marker, "cloud_name": cloud_name})
            elif args.phase == "inspect-empty-recovery":
                plan = build_inspect_empty_recovery_plan(schemas)
            elif args.phase == "create-empty-checkpoint":
                plan = build_create_empty_checkpoint_plan(schemas)
            elif args.phase == "convert-empty-recovery":
                plan = build_convert_empty_recovery_plan(
                    schemas, creation_id=args.creation_id
                )
            elif args.phase == "verify-empty-recovery":
                plan = build_verify_empty_recovery_plan(
                    schemas,
                    creation_id=args.creation_id,
                    lineage_id=args.lineage_id,
                    version_id=args.version_id,
                )
            elif args.phase == "save-empty-recovery":
                plan = build_save_empty_recovery_plan(
                    schemas,
                    creation_id=args.creation_id,
                    cloud_name=args.cloud_name,
                    project_id=args.project_id,
                    folder_id=args.folder_id,
                    project_name=args.project_name,
                )
            elif args.phase == "capture-saved-empty-recovery":
                plan = build_capture_saved_empty_recovery_plan(
                    schemas,
                    creation_id=args.creation_id,
                    cloud_name=args.cloud_name,
                    project_id=args.project_id,
                    folder_id=args.folder_id,
                    project_name=args.project_name,
                )
            elif args.phase == "build-saved-recovery-model":
                plan = build_saved_recovery_model_plan(
                    schemas,
                    marker=args.marker,
                    creation_id=args.creation_id,
                    cloud_name=args.cloud_name,
                    project_id=args.project_id,
                    folder_id=args.folder_id,
                    lineage_id=args.lineage_id,
                    version_id=args.version_id,
                    version_number=args.version_number,
                )
            elif args.phase == "inspect-failed-partial-box":
                plan = build_inspect_failed_partial_box_plan(
                    schemas,
                    marker=args.marker,
                    creation_id=args.creation_id,
                    cloud_name=args.cloud_name,
                    project_id=args.project_id,
                    folder_id=args.folder_id,
                    lineage_id=args.lineage_id,
                    version_id=args.version_id,
                    version_number=args.version_number,
                )
            elif args.phase == "discard-empty-failed-branch":
                plan = build_discard_empty_failed_branch_plan(
                    schemas,
                    marker=args.marker,
                    creation_id=args.creation_id,
                    cloud_name=args.cloud_name,
                    project_id=args.project_id,
                    folder_id=args.folder_id,
                    lineage_id=args.lineage_id,
                    version_id=args.version_id,
                    version_number=args.version_number,
                )
            elif args.phase in {
                "verify-saved-recovery-model",
                "add-recovery-probe",
                "verify-recovery-undo",
                "verify-recovery-redo",
                "recovery-parameter-response",
            }:
                builders = {
                    "verify-saved-recovery-model": build_verify_saved_recovery_model_plan,
                    "add-recovery-probe": build_add_recovery_probe_plan,
                    "verify-recovery-undo": build_verify_recovery_undo_plan,
                    "verify-recovery-redo": build_verify_recovery_redo_plan,
                    "recovery-parameter-response": build_recovery_parameter_response_plan,
                }
                plan = builders[args.phase](
                    schemas,
                    marker=args.marker,
                    creation_id=args.creation_id,
                    cloud_name=args.cloud_name,
                    project_id=args.project_id,
                    folder_id=args.folder_id,
                    lineage_id=args.lineage_id,
                    version_id=args.version_id,
                    version_number=args.version_number,
                )
            elif args.phase == "recovery-undo":
                plan = build_recovery_undo_plan(schemas)
            elif args.phase == "recovery-redo":
                plan = build_recovery_redo_plan(schemas)
            elif args.phase in {"save-existing-recovery", "capture-saved-model"}:
                builder = (
                    build_save_existing_recovery_plan
                    if args.phase == "save-existing-recovery"
                    else build_capture_saved_model_plan
                )
                plan = builder(
                    schemas,
                    marker=args.marker,
                    creation_id=args.creation_id,
                    cloud_name=args.cloud_name,
                    project_id=args.project_id,
                    folder_id=args.folder_id,
                    lineage_id=args.lineage_id,
                    source_version_id=args.source_version_id,
                    source_version_number=args.source_version_number,
                )
            elif args.phase == "read":
                plan = build_read_plan(
                    schemas,
                    marker=args.marker,
                    cloud_name=args.cloud_name,
                    lineage_id=args.lineage_id,
                    version_id=args.version_id,
                )
            elif args.phase == "close":
                plan = build_close_plan(
                    schemas,
                    marker=args.marker,
                    cloud_name=args.cloud_name,
                    lineage_id=args.lineage_id,
                    version_id=args.version_id,
                )
            elif args.phase == "reopen":
                plan = build_reopen_plan(schemas, file_id=args.file_id)
            elif args.phase == "verify":
                plan = build_verify_plan(
                    schemas,
                    marker=args.marker,
                    cloud_name=args.cloud_name,
                    lineage_id=args.lineage_id,
                    version_id=args.version_id,
                )
            else:  # pragma: no cover - argparse owns the exhaustive choices.
                raise PlanGenerationError("unknown plan phase")
        _owner_only_atomic_write(args.output, plan)
        summary.update(
            {
                "output": str(args.output.expanduser().resolve()),
                "plan_sha256": _sha256(_canonical_bytes(plan)),
                "calls": len(plan["calls"]),
            }
        )
    except PlanGenerationError as exc:
        parser.error(str(exc))
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
