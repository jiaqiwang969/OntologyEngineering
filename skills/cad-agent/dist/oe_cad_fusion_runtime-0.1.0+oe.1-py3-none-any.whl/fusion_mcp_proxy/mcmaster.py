"""Bounded McMaster-Carr lookup, CAD download, and Fusion import support."""

from __future__ import annotations

import hashlib
import json
import os
import re
import ssl
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any, Mapping

from mcp.types import CallToolResult, TextContent, Tool, ToolAnnotations

from .mcmaster_embedded_cdp import (
    RECIPE_ID as EMBEDDED_EXACT_STEP_RECIPE_ID,
    STEP_FORMAT as EMBEDDED_STEP_FORMAT,
    McMasterEmbeddedCDPError,
    acquire_exact_step,
    validate_download_url,
)


MCMASTER_READ_TOOL = "fusion_mcp_mcmaster_read"
MCMASTER_EXECUTE_TOOL = "fusion_mcp_mcmaster_execute"
ACQUIRE_EMBEDDED_EXACT_STEP_ACTION = "acquire_embedded_exact_step"

CONFIRM_OPEN_CATALOG = "MCMASTER-OPEN-CATALOG"
CONFIRM_API_DOWNLOAD = "MCMASTER-API-DOWNLOAD"
CONFIRM_IMPORT_LOCAL_STEP = "MCMASTER-IMPORT-LOCAL-STEP"
CONFIRM_ACQUIRE_EMBEDDED_EXACT_STEP = "MCMASTER-ACQUIRE-EMBEDDED-STEP"

MCMASTER_API_BASE_URL = "https://api.mcmaster.com/v1"
MCMASTER_PRODUCT_BASE_URL = "https://www.mcmaster.com"
SUPPORTED_STEP_SUFFIXES = frozenset({".step", ".stp"})
SOURCE_CHANNELS = frozenset(
    {
        "mcmaster_api",
        "mcmaster_fusion_download",
        "manual_mcmaster_download",
    }
)
MAX_CAD_BYTES = 250 * 1024 * 1024


class McMasterError(RuntimeError):
    """A McMaster operation failed or violated its bounded contract."""


def normalize_part_number(value: str) -> str:
    """Normalize a McMaster part number without claiming that it exists."""

    normalized = "".join(value.split()).upper()
    if not re.fullmatch(r"[A-Z0-9]{3,24}", normalized):
        raise McMasterError("part_number must contain only ASCII letters and digits")
    if not any(character.isalpha() for character in normalized) or not any(
        character.isdigit() for character in normalized
    ):
        raise McMasterError("part_number must contain both letters and digits")
    return normalized


def product_url(part_number: str) -> str:
    normalized = normalize_part_number(part_number)
    return f"{MCMASTER_PRODUCT_BASE_URL}/{normalized}"


def inspect_local_step(path_value: str) -> dict[str, Any]:
    path = Path(path_value).expanduser()
    if not path.is_absolute():
        raise McMasterError("path must be absolute")
    try:
        resolved = path.resolve(strict=True)
    except FileNotFoundError as exc:
        raise McMasterError(f"STEP file does not exist: {path}") from exc
    if not resolved.is_file():
        raise McMasterError(f"STEP path is not a file: {resolved}")
    if resolved.suffix.lower() not in SUPPORTED_STEP_SUFFIXES:
        raise McMasterError("only .step and .stp files are supported")
    size = resolved.stat().st_size
    if size <= 0:
        raise McMasterError("STEP file is empty")
    if size > MAX_CAD_BYTES:
        raise McMasterError(f"STEP file exceeds {MAX_CAD_BYTES} bytes")
    digest = hashlib.sha256()
    with resolved.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return {
        "path": str(resolved),
        "filename": resolved.name,
        "suffix": resolved.suffix.lower(),
        "size_bytes": size,
        "sha256": digest.hexdigest(),
    }


def _preflight_embedded_target_path(
    path_value: str | os.PathLike[str],
) -> str:
    """Close local target gates before the historical CDP recipe can run."""

    try:
        target = Path(path_value).expanduser()
    except TypeError as exc:
        raise McMasterError("target_path must be a path string") from exc
    if not target.is_absolute():
        raise McMasterError("target_path must be absolute")
    if target.suffix.lower() not in SUPPORTED_STEP_SUFFIXES:
        raise McMasterError("target_path must end in .step or .stp")
    try:
        parent = target.parent.resolve(strict=True)
    except FileNotFoundError as exc:
        raise McMasterError("target_path parent directory does not exist") from exc
    if not parent.is_dir():
        raise McMasterError("target_path parent path is not a directory")
    resolved = parent / target.name
    if os.path.lexists(resolved):
        raise McMasterError("target_path already exists; overwrite is refused")
    return str(resolved)


@dataclass(frozen=True)
class McMasterApiConfig:
    """Approved-customer API configuration; secrets are never serialized."""

    token: str | None = field(default=None, repr=False)
    certificate_file: str | None = None
    private_key_file: str | None = None
    certificate_password: str | None = field(default=None, repr=False)
    base_url: str = MCMASTER_API_BASE_URL
    timeout_seconds: float = 60.0

    @classmethod
    def from_environment(
        cls, environment: Mapping[str, str] | None = None
    ) -> "McMasterApiConfig":
        values = environment if environment is not None else os.environ
        return cls(
            token=values.get("MCMASTER_API_TOKEN") or None,
            certificate_file=values.get("MCMASTER_API_CERT_FILE") or None,
            private_key_file=values.get("MCMASTER_API_KEY_FILE") or None,
            certificate_password=values.get("MCMASTER_API_CERT_PASSWORD") or None,
        )

    def status(self) -> dict[str, Any]:
        certificate = (
            Path(self.certificate_file).expanduser() if self.certificate_file else None
        )
        private_key = (
            Path(self.private_key_file).expanduser() if self.private_key_file else None
        )
        missing: list[str] = []
        if not self.token:
            missing.append("MCMASTER_API_TOKEN")
        if certificate is None:
            missing.append("MCMASTER_API_CERT_FILE")
        elif not certificate.is_file():
            missing.append("MCMASTER_API_CERT_FILE(existing file)")
        if private_key is not None and not private_key.is_file():
            missing.append("MCMASTER_API_KEY_FILE(existing file)")
        return {
            "configured": not missing,
            "missing": missing,
            "base_url": self.base_url,
            "certificate_configured": certificate is not None,
            "separate_private_key_configured": private_key is not None,
            "token_configured": bool(self.token),
            "credential_values_exposed": False,
            "requires_mcmaster_approved_customer_certificate": True,
        }

    def ssl_context(self) -> ssl.SSLContext:
        status = self.status()
        if not status["configured"]:
            raise McMasterError(
                "McMaster API is not configured: " + ", ".join(status["missing"])
            )
        assert self.certificate_file is not None
        context = ssl.create_default_context()
        context.load_cert_chain(
            certfile=str(Path(self.certificate_file).expanduser()),
            keyfile=(
                str(Path(self.private_key_file).expanduser())
                if self.private_key_file
                else None
            ),
            password=self.certificate_password,
        )
        return context


class McMasterApiClient:
    """Small client for McMaster's documented Product Information API."""

    def __init__(self, config: McMasterApiConfig | None = None) -> None:
        self.config = config or McMasterApiConfig.from_environment()

    def status(self) -> dict[str, Any]:
        return self.config.status()

    def _url(self, relative_path: str) -> str:
        base = self.config.base_url.rstrip("/") + "/"
        url = urllib.parse.urljoin(base, relative_path.lstrip("/"))
        base_parts = urllib.parse.urlsplit(base)
        url_parts = urllib.parse.urlsplit(url)
        if (
            url_parts.scheme != "https"
            or url_parts.netloc != base_parts.netloc
            or not url.startswith(base)
        ):
            raise McMasterError(
                "refused McMaster API URL outside the configured HTTPS root"
            )
        return url

    def _request(self, relative_path: str) -> tuple[bytes, Mapping[str, str]]:
        if not self.config.token:
            raise McMasterError("MCMASTER_API_TOKEN is not configured")
        request = urllib.request.Request(
            self._url(relative_path),
            headers={
                "Accept": "application/json, application/octet-stream",
                "Authorization": f"Bearer {self.config.token}",
                "User-Agent": "cad-agent-fusion-mcp-mcmaster/0.2.0",
            },
            method="GET",
        )
        try:
            with urllib.request.urlopen(
                request,
                context=self.config.ssl_context(),
                timeout=self.config.timeout_seconds,
            ) as response:
                content_length = response.headers.get("Content-Length")
                if content_length and int(content_length) > MAX_CAD_BYTES:
                    raise McMasterError("McMaster response exceeds the CAD size limit")
                payload = response.read(MAX_CAD_BYTES + 1)
                if len(payload) > MAX_CAD_BYTES:
                    raise McMasterError("McMaster response exceeds the CAD size limit")
                return payload, dict(response.headers.items())
        except urllib.error.HTTPError as exc:
            detail = exc.read(4096).decode("utf-8", errors="replace")
            raise McMasterError(
                f"McMaster API HTTP {exc.code}: {detail or exc.reason}"
            ) from exc
        except urllib.error.URLError as exc:
            raise McMasterError(f"McMaster API request failed: {exc.reason}") from exc

    def product(self, part_number: str) -> dict[str, Any]:
        normalized = normalize_part_number(part_number)
        encoded = urllib.parse.quote(normalized, safe="")
        payload, _ = self._request(f"products/{encoded}")
        try:
            product = json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise McMasterError("McMaster product response was not valid JSON") from exc
        return {
            "part_number": normalized,
            "product_url": product_url(normalized),
            "product": product,
            "source": "McMaster-Carr Product Information API",
        }

    @staticmethod
    def _validated_cad_path(cad_path: str) -> str:
        decoded = urllib.parse.unquote(cad_path).strip().lstrip("/")
        if not decoded or "\\" in decoded:
            raise McMasterError("cad_path must be a non-empty relative POSIX path")
        parsed = urllib.parse.urlsplit(decoded)
        if parsed.scheme or parsed.netloc or parsed.query or parsed.fragment:
            raise McMasterError("cad_path must not contain a URL, query, or fragment")
        pure = PurePosixPath(parsed.path)
        if any(part in {"", ".", ".."} for part in pure.parts):
            raise McMasterError("cad_path contains an unsafe path segment")
        if pure.suffix.lower() not in SUPPORTED_STEP_SUFFIXES:
            raise McMasterError("cad_path must identify a .step or .stp file")
        return str(pure)

    def download_step(
        self, part_number: str, cad_path: str, destination_value: str
    ) -> dict[str, Any]:
        normalized = normalize_part_number(part_number)
        relative = self._validated_cad_path(cad_path)
        destination = Path(destination_value).expanduser()
        if not destination.is_absolute():
            raise McMasterError("destination must be absolute")
        destination = destination.resolve(strict=False)
        if destination.suffix.lower() not in SUPPORTED_STEP_SUFFIXES:
            raise McMasterError("destination must end in .step or .stp")
        if destination.exists():
            raise McMasterError("destination already exists; overwrite is refused")
        if not destination.parent.is_dir():
            raise McMasterError("destination parent directory does not exist")
        payload, headers = self._request(
            "cad/" + urllib.parse.quote(relative, safe="/")
        )
        temporary_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="wb",
                prefix=f".{destination.name}.",
                suffix=".download",
                dir=destination.parent,
                delete=False,
            ) as temporary:
                temporary.write(payload)
                temporary.flush()
                os.fsync(temporary.fileno())
                temporary_path = Path(temporary.name)
            temporary_path.replace(destination)
        except Exception:
            if temporary_path is not None:
                temporary_path.unlink(missing_ok=True)
            raise
        record = inspect_local_step(str(destination))
        return {
            **record,
            "part_number": normalized,
            "product_url": product_url(normalized),
            "cad_path": relative,
            "content_type": headers.get("Content-Type"),
            "source_channel": "mcmaster_api",
            "overwrite_performed": False,
        }


READ_ANNOTATIONS = ToolAnnotations(
    readOnlyHint=True,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=False,
)
EXECUTE_ANNOTATIONS = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=True,
    idempotentHint=False,
    openWorldHint=False,
)


def mcmaster_tools() -> list[Tool]:
    return [
        Tool(
            name=MCMASTER_READ_TOOL,
            title="Read McMaster-Carr catalog and CAD provenance",
            description=(
                "Normalize an exact McMaster part number, inspect a local STEP and its SHA-256, "
                "report approved Product Information API configuration, query one subscribed "
                "product through that official API, or read the bounded Fusion target state. "
                "It does not scrape mcmaster.com or expose credentials."
            ),
            annotations=READ_ANNOTATIONS,
            inputSchema={
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": [
                            "normalize_part_number",
                            "inspect_local_step",
                            "api_status",
                            "api_product",
                            "fusion_target_snapshot",
                        ],
                    },
                    "part_number": {"type": "string", "minLength": 3, "maxLength": 24},
                    "path": {"type": "string", "minLength": 1},
                    "expected_document_name": {"type": "string", "minLength": 1},
                    "target_component_name": {"type": "string", "minLength": 1},
                },
                "required": ["action"],
                "allOf": [
                    {
                        "if": {
                            "properties": {
                                "action": {
                                    "enum": ["normalize_part_number", "api_product"]
                                }
                            }
                        },
                        "then": {"required": ["part_number"]},
                    },
                    {
                        "if": {
                            "properties": {"action": {"const": "inspect_local_step"}}
                        },
                        "then": {"required": ["path"]},
                    },
                    {
                        "if": {
                            "properties": {
                                "action": {"const": "fusion_target_snapshot"}
                            }
                        },
                        "then": {
                            "required": [
                                "expected_document_name",
                                "target_component_name",
                            ]
                        },
                    },
                ],
            },
        ),
        Tool(
            name=MCMASTER_EXECUTE_TOOL,
            title="Download or import bounded McMaster-Carr CAD",
            description=(
                "Open Fusion's official McMaster-Carr catalog, download one approved-customer "
                "API STEP, acquire one exact STEP through Fusion's bounded embedded-WebView CDP "
                "recipe without mouse input, or import a hash-bound local STEP into one exact "
                "Fusion document and component with pre/post readback. Each action requires its "
                "own confirmation token. Unrestricted website automation and credential storage "
                "are excluded."
            ),
            annotations=EXECUTE_ANNOTATIONS,
            inputSchema={
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": [
                            "open_catalog",
                            ACQUIRE_EMBEDDED_EXACT_STEP_ACTION,
                            "api_download",
                            "import_local_step",
                        ],
                    },
                    "part_number": {"type": "string", "minLength": 3, "maxLength": 24},
                    "format": {"const": EMBEDDED_STEP_FORMAT},
                    "target_path": {"type": "string", "minLength": 1},
                    "devtools_port": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": 65_535,
                    },
                    "timeout_seconds": {
                        "type": "number",
                        "minimum": 1,
                        "maximum": 120,
                        "default": 30,
                    },
                    "cad_path": {"type": "string", "minLength": 1},
                    "destination": {"type": "string", "minLength": 1},
                    "path": {"type": "string", "minLength": 1},
                    "expected_sha256": {
                        "type": "string",
                        "pattern": "^[A-Fa-f0-9]{64}$",
                    },
                    "expected_document_name": {"type": "string", "minLength": 1},
                    "target_component_name": {"type": "string", "minLength": 1},
                    "source_channel": {
                        "type": "string",
                        "enum": sorted(SOURCE_CHANNELS),
                        "default": "manual_mcmaster_download",
                    },
                    "confirmation": {"type": "string", "minLength": 1},
                },
                "required": ["action", "confirmation"],
                "allOf": [
                    {
                        "if": {"properties": {"action": {"const": "open_catalog"}}},
                        "then": {"required": ["expected_document_name"]},
                    },
                    {
                        "if": {
                            "properties": {
                                "action": {"const": ACQUIRE_EMBEDDED_EXACT_STEP_ACTION}
                            }
                        },
                        "then": {
                            "required": [
                                "part_number",
                                "format",
                                "target_path",
                                "devtools_port",
                                "expected_document_name",
                            ]
                        },
                    },
                    {
                        "if": {"properties": {"action": {"const": "api_download"}}},
                        "then": {
                            "required": ["part_number", "cad_path", "destination"]
                        },
                    },
                    {
                        "if": {
                            "properties": {"action": {"const": "import_local_step"}}
                        },
                        "then": {
                            "required": [
                                "part_number",
                                "path",
                                "expected_sha256",
                                "expected_document_name",
                                "target_component_name",
                            ]
                        },
                    },
                ],
            },
        ),
    ]


def _fusion_header(constants: Mapping[str, str]) -> str:
    assignments = "".join(
        f"{name} = {json.dumps(value)}\n" for name, value in constants.items()
    )
    return (
        "import adsk.core\n"
        "import adsk.fusion\n"
        "import json\n\n"
        + assignments
        + "\n"
        + r"""
def _design_and_document():
    app = adsk.core.Application.get()
    document = app.activeDocument
    if document is None:
        raise RuntimeError("Fusion has no active document")
    if document.name != EXPECTED_DOCUMENT:
        raise RuntimeError(
            "active Fusion document mismatch: " + document.name
        )
    design = adsk.fusion.Design.cast(app.activeProduct)
    if design is None:
        raise RuntimeError("active Fusion product is not a Design")
    return app, document, design


def _target_component(design):
    root = design.rootComponent
    components = [root]
    occurrences = root.allOccurrences
    for index in range(occurrences.count):
        components.append(occurrences.item(index).component)
    unique = []
    seen = set()
    for component in components:
        token = component.entityToken
        if token in seen:
            continue
        seen.add(token)
        if component.name == TARGET_COMPONENT:
            unique.append(component)
    if len(unique) != 1:
        raise RuntimeError(
            "expected exactly one target component named "
            + TARGET_COMPONENT
            + ", found "
            + str(len(unique))
        )
    return unique[0]


def _snapshot(document, design, target):
    provenance = None
    if PART_NUMBER:
        attribute = target.attributes.itemByName(
            "cad-agent.mcmaster", "part-" + PART_NUMBER
        )
        provenance = None if attribute is None else attribute.value
    return {
        "document_name": document.name,
        "document_is_saved": document.isSaved,
        "document_is_modified": document.isModified,
        "target_component_name": target.name,
        "target_body_count": target.bRepBodies.count,
        "target_occurrence_count": target.occurrences.count,
        "root_all_occurrence_count": design.rootComponent.allOccurrences.count,
        "part_number": PART_NUMBER or None,
        "provenance_attribute": provenance,
    }
"""
    )


def build_document_snapshot_script(expected_document_name: str) -> str:
    expected = json.dumps(expected_document_name)
    return f"""import adsk.core
import json

EXPECTED_DOCUMENT = {expected}

def run(_context: str):
    app = adsk.core.Application.get()
    document = app.activeDocument
    if document is None:
        raise RuntimeError("Fusion has no active document")
    if document.name != EXPECTED_DOCUMENT:
        raise RuntimeError("active Fusion document mismatch: " + document.name)
    print(json.dumps({{
        "document_name": document.name,
        "document_is_saved": document.isSaved,
        "document_is_modified": document.isModified,
    }}, sort_keys=True))
"""


def build_open_catalog_script(
    expected_document_name: str, part_number: str | None = None
) -> str:
    expected = json.dumps(expected_document_name)
    normalized = normalize_part_number(part_number) if part_number else None
    part = json.dumps(normalized)
    return f"""import adsk.core
import json

EXPECTED_DOCUMENT = {expected}
PART_NUMBER = {part}

def run(_context: str):
    app = adsk.core.Application.get()
    document = app.activeDocument
    if document is None:
        raise RuntimeError("Fusion has no active document")
    if document.name != EXPECTED_DOCUMENT:
        raise RuntimeError("active Fusion document mismatch: " + document.name)
    definition = app.userInterface.commandDefinitions.itemById(
        "InsertMcMasterCarrComponentCommand"
    )
    if definition is None:
        raise RuntimeError("InsertMcMasterCarrComponentCommand is unavailable")
    definition.execute()
    adsk.doEvents()
    print(json.dumps({{
        "opened": True,
        "command_id": definition.id,
        "document_name": document.name,
        "requested_part_number": PART_NUMBER,
        "search_automated": False,
    }}, sort_keys=True))
"""


def build_target_snapshot_script(
    expected_document_name: str,
    target_component_name: str,
    part_number: str | None = None,
) -> str:
    constants = {
        "EXPECTED_DOCUMENT": expected_document_name,
        "TARGET_COMPONENT": target_component_name,
        "PART_NUMBER": normalize_part_number(part_number) if part_number else "",
    }
    return (
        _fusion_header(constants)
        + r"""

def run(_context: str):
    _, document, design = _design_and_document()
    target = _target_component(design)
    print(json.dumps(_snapshot(document, design, target), sort_keys=True))
"""
    )


def build_import_step_script(
    *,
    file_record: Mapping[str, Any],
    expected_document_name: str,
    target_component_name: str,
    part_number: str,
    source_channel: str,
) -> str:
    normalized = normalize_part_number(part_number)
    if source_channel not in SOURCE_CHANNELS:
        raise McMasterError(f"unsupported source_channel: {source_channel}")
    provenance = json.dumps(
        {
            "schema": "cad-agent.mcmaster-provenance.v1",
            "supplier": "McMaster-Carr",
            "part_number": normalized,
            "product_url": product_url(normalized),
            "source_channel": source_channel,
            "filename": str(file_record["filename"]),
            "sha256": str(file_record["sha256"]),
            "size_bytes": int(file_record["size_bytes"]),
            "geometry_kind": "supplier STEP",
            "proxy": False,
        },
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    )
    constants = {
        "EXPECTED_DOCUMENT": expected_document_name,
        "TARGET_COMPONENT": target_component_name,
        "PART_NUMBER": normalized,
        "STEP_PATH": str(file_record["path"]),
        "EXPECTED_SHA256": str(file_record["sha256"]),
        "SOURCE_CHANNEL": source_channel,
        "PROVENANCE": provenance,
    }
    return (
        _fusion_header(constants)
        + r"""

def run(_context: str):
    app, document, design = _design_and_document()
    target = _target_component(design)
    before = _snapshot(document, design, target)
    options = app.importManager.createSTEPImportOptions(STEP_PATH)
    if options is None:
        raise RuntimeError("Fusion could not create STEP import options")
    created = app.importManager.importToTarget2(options, target)
    if created is None:
        raise RuntimeError("Fusion STEP import returned no result collection")
    adsk.doEvents()
    target.attributes.add(
        "cad-agent.mcmaster", "part-" + PART_NUMBER, PROVENANCE
    )
    after = _snapshot(document, design, target)
    structural_delta = (
        after["target_body_count"] > before["target_body_count"]
        or after["target_occurrence_count"] > before["target_occurrence_count"]
        or after["root_all_occurrence_count"] > before["root_all_occurrence_count"]
    )
    print(json.dumps({
        "imported": True,
        "created_object_count": created.count,
        "structural_delta": structural_delta,
        "expected_sha256": EXPECTED_SHA256,
        "source_channel": SOURCE_CHANNEL,
        "before": before,
        "after": after,
    }, sort_keys=True))
"""
    )


def parse_fusion_script_result(result: CallToolResult) -> dict[str, Any]:
    if result.isError:
        raise McMasterError("Autodesk Fusion MCP reported a tool error")
    texts = [
        content.text
        for content in result.content
        if isinstance(content, TextContent) and content.text.strip()
    ]
    if not texts:
        raise McMasterError("Autodesk Fusion MCP returned no script output")
    try:
        envelope = json.loads(texts[-1])
    except json.JSONDecodeError as exc:
        raise McMasterError("Autodesk Fusion MCP returned invalid JSON") from exc
    if not isinstance(envelope, dict):
        raise McMasterError("Autodesk Fusion MCP response is not an object")
    if envelope.get("success") is False:
        raise McMasterError(str(envelope.get("error") or "Fusion script failed"))
    message = envelope.get("message")
    if isinstance(message, str):
        for line in reversed([line.strip() for line in message.splitlines()]):
            if not line.startswith("{"):
                continue
            try:
                parsed = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(parsed, dict):
                return parsed
    if envelope.get("success") is True:
        return envelope
    raise McMasterError("Fusion script response did not contain structured output")


class McMasterModule:
    def __init__(
        self,
        api: McMasterApiClient | None = None,
        embedded_acquirer: Callable[..., dict[str, Any]] | None = None,
    ) -> None:
        self.api = api or McMasterApiClient()
        self._embedded_acquirer = embedded_acquirer or acquire_exact_step

    @staticmethod
    def normalize(part_number: str) -> dict[str, Any]:
        normalized = normalize_part_number(part_number)
        return {
            "part_number": normalized,
            "product_url": product_url(normalized),
            "existence_verified": False,
        }

    @staticmethod
    def inspect_step(path: str) -> dict[str, Any]:
        return inspect_local_step(path)

    def api_status(self) -> dict[str, Any]:
        return self.api.status()

    def api_product(self, part_number: str) -> dict[str, Any]:
        return self.api.product(part_number)

    def api_download(
        self, part_number: str, cad_path: str, destination: str
    ) -> dict[str, Any]:
        return self.api.download_step(part_number, cad_path, destination)

    def acquire_embedded_exact_step(
        self,
        *,
        part_number: str,
        format: str,
        target_path: str,
        devtools_port: int,
        timeout_seconds: float = 30.0,
    ) -> dict[str, Any]:
        """Execute the canonical S10 acquisition contract through a bounded adapter."""

        if not isinstance(part_number, str):
            raise McMasterError("part_number must be a string")
        normalized_request_part = normalize_part_number(part_number)
        if format != EMBEDDED_STEP_FORMAT:
            raise McMasterError(f"format must be exactly {EMBEDDED_STEP_FORMAT!r}")
        if isinstance(devtools_port, bool) or not isinstance(devtools_port, int):
            raise McMasterError("devtools_port must be an integer")
        if not 1 <= devtools_port <= 65_535:
            raise McMasterError("devtools_port must be between 1 and 65535")
        if isinstance(timeout_seconds, bool) or not isinstance(
            timeout_seconds, (int, float)
        ):
            raise McMasterError("timeout_seconds must be numeric")
        validated_timeout = float(timeout_seconds)
        if not 1.0 <= validated_timeout <= 120.0:
            raise McMasterError("timeout_seconds must be between 1 and 120")
        resolved_request_target = _preflight_embedded_target_path(target_path)

        try:
            evidence = self._embedded_acquirer(
                part_number=normalized_request_part,
                cad_format=EMBEDDED_STEP_FORMAT,
                destination=resolved_request_target,
                devtools_port=devtools_port,
                timeout_seconds=validated_timeout,
            )
        except McMasterEmbeddedCDPError as exc:
            bounded_detail = re.sub(
                r"(?:https?|wss?)://\S+", "<redacted-url>", str(exc)
            )[:1_000]
            raise McMasterError(
                bounded_detail or "embedded STEP acquisition failed"
            ) from exc

        if not isinstance(evidence, dict) or evidence.get("status") != "succeeded":
            raise McMasterError("embedded STEP acquisition returned an invalid report")
        recipe_report = evidence.get("recipe_report")
        artifact = evidence.get("artifact")
        if (
            not isinstance(recipe_report, dict)
            or recipe_report.get("recipe_id") != EMBEDDED_EXACT_STEP_RECIPE_ID
            or not isinstance(artifact, dict)
        ):
            raise McMasterError("embedded STEP acquisition evidence is incomplete")
        if recipe_report.get("devtools") != {
            "host": "127.0.0.1",
            "port": devtools_port,
            "matching_page_count": 1,
        } or recipe_report.get("page") != {
            "scheme": "https",
            "host": "www.mcmaster.com",
        }:
            raise McMasterError("embedded STEP acquisition context evidence is invalid")

        source_url = artifact.get("source_url")
        resolved_target = artifact.get("path")
        sha256 = artifact.get("sha256")
        normalized_part = evidence.get("part_number")
        evidence_format = evidence.get("cad_format")
        if (
            not isinstance(source_url, str)
            or not source_url
            or not isinstance(resolved_target, str)
            or resolved_target != resolved_request_target
            or not isinstance(sha256, str)
            or re.fullmatch(r"[0-9a-f]{64}", sha256) is None
            or normalized_part != normalized_request_part
            or evidence_format != EMBEDDED_STEP_FORMAT
        ):
            raise McMasterError("embedded STEP acquisition evidence is invalid")
        try:
            validate_download_url(
                source_url, expected_part_number=normalized_request_part
            )
        except McMasterEmbeddedCDPError as exc:
            raise McMasterError("embedded STEP source URL is invalid") from exc
        decoded_source_path = urllib.parse.unquote(
            urllib.parse.urlsplit(source_url).path
        ).upper()
        exact_part_pattern = re.compile(
            rf"(?<![A-Z0-9]){re.escape(normalized_request_part)}(?![A-Z0-9])"
        )
        if exact_part_pattern.search(decoded_source_path) is None:
            raise McMasterError(
                "embedded STEP source URL does not contain the exact part number"
            )

        return {
            "status": "succeeded",
            "recipe_id": EMBEDDED_EXACT_STEP_RECIPE_ID,
            "part_number": normalized_part,
            "format": evidence_format,
            "source_url": source_url,
            "target_path": resolved_target,
            "sha256": sha256,
            "evidence": evidence,
        }
