import{b as e}from"./index-1qQ7Z6lU.js";/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],a=e("loader-circle",o);export{a as L};
