#!/usr/bin/env node

/**
 * Parameterized, mouse-free McMaster-Carr acquisition recipe for Fusion's
 * embedded Qt WebEngine page.
 *
 * The process prints exactly one bounded JSON report to stdout on success.
 * It never prints page HTML, cookies, request headers, or an unvalidated URL.
 */

const REPORT_SCHEMA = "cad-agent.mcmaster-embedded-cdp-report.v1";
const RECIPE_ID = "McMasterEmbeddedCDPExactStepAcquisition";
const LOOPBACK_HOST = "127.0.0.1";
const MCMASTER_HOST = "www.mcmaster.com";
const STEP_FORMAT = "3-D STEP";
const DEFAULT_TIMEOUT_MS = 30_000;

const SELECTORS = Object.freeze({
  search_input: "#SrchEntryWebPart_InpBox",
  search_submit: "input[type=submit][title=search]",
  cad_format_combobox:
    "button[role=combobox][aria-label='Select CAD file type']",
  cad_format_option: "li[role=option]",
  download_action:
    "button,a,input[type=button],input[type=submit],[role=button]",
});

class RecipeError extends Error {
  constructor(code, message) {
    super(message);
    this.name = "RecipeError";
    this.code = code;
  }
}

function normalizePartNumber(value) {
  const normalized = String(value ?? "").replace(/\s+/gu, "").toUpperCase();
  if (!/^(?=.*[A-Z])(?=.*[0-9])[A-Z0-9]{3,24}$/.test(normalized)) {
    throw new RecipeError(
      "invalid_part_number",
      "part number must contain 3-24 ASCII letters/digits and include both",
    );
  }
  return normalized;
}

function validateFormat(value) {
  if (value !== STEP_FORMAT) {
    throw new RecipeError(
      "unsupported_format",
      `format must be exactly ${JSON.stringify(STEP_FORMAT)}`,
    );
  }
  return value;
}

function validatePort(value) {
  if (!/^\d{1,5}$/.test(String(value ?? ""))) {
    throw new RecipeError("invalid_port", "DevTools port must be an integer");
  }
  const port = Number(value);
  if (!Number.isSafeInteger(port) || port < 1 || port > 65_535) {
    throw new RecipeError(
      "invalid_port",
      "DevTools port must be between 1 and 65535",
    );
  }
  return port;
}

function validateTimeout(value) {
  if (!/^\d+$/.test(String(value ?? ""))) {
    throw new RecipeError("invalid_timeout", "timeout must be an integer");
  }
  const timeoutMs = Number(value);
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1_000 || timeoutMs > 120_000) {
    throw new RecipeError(
      "invalid_timeout",
      "timeout must be between 1000 and 120000 milliseconds",
    );
  }
  return timeoutMs;
}

function parseArguments(argv) {
  const values = new Map();
  for (let index = 0; index < argv.length; index += 2) {
    const flag = argv[index];
    if (!flag?.startsWith("--") || index + 1 >= argv.length) {
      throw new RecipeError("invalid_arguments", "arguments must be --name value pairs");
    }
    if (values.has(flag)) {
      throw new RecipeError("invalid_arguments", `duplicate argument: ${flag}`);
    }
    values.set(flag, argv[index + 1]);
  }
  const allowed = new Set(["--part-number", "--format", "--port", "--timeout-ms"]);
  for (const flag of values.keys()) {
    if (!allowed.has(flag)) {
      throw new RecipeError("invalid_arguments", `unsupported argument: ${flag}`);
    }
  }
  for (const required of ["--part-number", "--format", "--port"]) {
    if (!values.has(required)) {
      throw new RecipeError("invalid_arguments", `missing argument: ${required}`);
    }
  }
  return {
    partNumber: normalizePartNumber(values.get("--part-number")),
    format: validateFormat(values.get("--format")),
    port: validatePort(values.get("--port")),
    timeoutMs: validateTimeout(values.get("--timeout-ms") ?? DEFAULT_TIMEOUT_MS),
  };
}

function parsedUrl(value, errorCode) {
  try {
    return new URL(value);
  } catch {
    throw new RecipeError(errorCode, "received a malformed URL");
  }
}

function isExactMcMasterPage(value) {
  try {
    const parsed = new URL(value);
    return (
      parsed.protocol === "https:" &&
      parsed.hostname.toLowerCase() === MCMASTER_HOST &&
      parsed.port === "" &&
      parsed.username === "" &&
      parsed.password === ""
    );
  } catch {
    return false;
  }
}

function looksLikeStepUrl(value) {
  try {
    const pathname = decodeURIComponent(new URL(value).pathname).toLowerCase();
    return pathname.endsWith(".step") || pathname.endsWith(".stp");
  } catch {
    return false;
  }
}

function validatedDownloadUrl(value, partNumber) {
  const parsed = parsedUrl(value, "unsafe_download_url");
  if (
    parsed.protocol !== "https:" ||
    parsed.hostname.toLowerCase() !== MCMASTER_HOST ||
    parsed.port !== "" ||
    parsed.username !== "" ||
    parsed.password !== "" ||
    parsed.search !== "" ||
    parsed.hash !== ""
  ) {
    throw new RecipeError(
      "unsafe_download_url",
      "download URL must be credential-free HTTPS on www.mcmaster.com without query or fragment",
    );
  }
  let decodedPath;
  try {
    decodedPath = decodeURIComponent(parsed.pathname);
  } catch {
    throw new RecipeError("unsafe_download_url", "download URL path is malformed");
  }
  if (
    !(decodedPath.toLowerCase().endsWith(".step") || decodedPath.toLowerCase().endsWith(".stp"))
  ) {
    throw new RecipeError("unsafe_download_url", "download URL is not a STEP file");
  }
  if (!decodedPath.toUpperCase().includes(partNumber)) {
    throw new RecipeError(
      "part_url_mismatch",
      "download URL path does not contain the requested exact part number",
    );
  }
  // Reconstruct the only value allowed into the report. Any credentials,
  // query, fragment, non-default port, or alternate host was rejected above.
  return `https://${MCMASTER_HOST}${parsed.pathname}`;
}

async function discoverUniquePage(port, timeoutMs) {
  const discoveryUrl = `http://${LOOPBACK_HOST}:${port}/json/list`;
  let response;
  try {
    response = await fetch(discoveryUrl, {
      method: "GET",
      redirect: "error",
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch (error) {
    throw new RecipeError(
      "devtools_discovery_failed",
      `loopback DevTools discovery failed: ${error?.name ?? "error"}`,
    );
  }
  if (!response.ok) {
    throw new RecipeError(
      "devtools_discovery_failed",
      `loopback DevTools discovery returned HTTP ${response.status}`,
    );
  }
  let targets;
  try {
    targets = await response.json();
  } catch {
    throw new RecipeError(
      "devtools_discovery_failed",
      "loopback DevTools discovery did not return JSON",
    );
  }
  if (!Array.isArray(targets)) {
    throw new RecipeError(
      "devtools_discovery_failed",
      "loopback DevTools discovery response was not a target list",
    );
  }
  const matches = targets.filter(
    (target) =>
      target &&
      target.type === "page" &&
      typeof target.url === "string" &&
      isExactMcMasterPage(target.url),
  );
  if (matches.length !== 1) {
    throw new RecipeError(
      "mcmaster_page_cardinality",
      `expected exactly one www.mcmaster.com page, found ${matches.length}`,
    );
  }
  const target = matches[0];
  if (typeof target.webSocketDebuggerUrl !== "string") {
    throw new RecipeError(
      "devtools_target_invalid",
      "the McMaster page has no WebSocket debugger endpoint",
    );
  }
  const websocketUrl = parsedUrl(
    target.webSocketDebuggerUrl,
    "devtools_target_invalid",
  );
  if (
    websocketUrl.protocol !== "ws:" ||
    websocketUrl.hostname !== LOOPBACK_HOST ||
    Number(websocketUrl.port) !== port ||
    websocketUrl.username !== "" ||
    websocketUrl.password !== "" ||
    websocketUrl.search !== "" ||
    websocketUrl.hash !== ""
  ) {
    throw new RecipeError(
      "devtools_target_invalid",
      "refused a non-loopback or decorated WebSocket debugger endpoint",
    );
  }
  return websocketUrl.toString();
}

class CDPClient {
  constructor(websocketUrl, timeoutMs) {
    this.websocketUrl = websocketUrl;
    this.timeoutMs = timeoutMs;
    this.websocket = null;
    this.nextId = 1;
    this.pending = new Map();
    this.listeners = new Map();
  }

  async connect() {
    if (typeof WebSocket !== "function") {
      throw new RecipeError(
        "websocket_unavailable",
        "this Node runtime does not provide WebSocket",
      );
    }
    const websocket = new WebSocket(this.websocketUrl);
    this.websocket = websocket;
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        reject(new RecipeError("cdp_connect_timeout", "CDP connection timed out"));
      }, this.timeoutMs);
      websocket.addEventListener(
        "open",
        () => {
          clearTimeout(timer);
          resolve();
        },
        { once: true },
      );
      websocket.addEventListener(
        "error",
        () => {
          clearTimeout(timer);
          reject(new RecipeError("cdp_connect_failed", "CDP connection failed"));
        },
        { once: true },
      );
    });
    websocket.addEventListener("message", (event) => this.#onMessage(event.data));
    websocket.addEventListener("close", () => this.#onClose());
  }

  #onMessage(raw) {
    let message;
    try {
      message = JSON.parse(typeof raw === "string" ? raw : String(raw));
    } catch {
      this.#onClose(new RecipeError("cdp_protocol_error", "CDP returned invalid JSON"));
      return;
    }
    if (Number.isInteger(message.id)) {
      const pending = this.pending.get(message.id);
      if (!pending) return;
      this.pending.delete(message.id);
      clearTimeout(pending.timer);
      if (message.error) {
        pending.reject(
          new RecipeError(
            "cdp_command_failed",
            `CDP command failed (${message.error.code ?? "unknown"})`,
          ),
        );
      } else {
        pending.resolve(message.result ?? {});
      }
      return;
    }
    if (typeof message.method === "string") {
      for (const listener of this.listeners.get(message.method) ?? []) {
        listener(message.params ?? {});
      }
    }
  }

  #onClose(error = new RecipeError("cdp_closed", "CDP connection closed")) {
    for (const pending of this.pending.values()) {
      clearTimeout(pending.timer);
      pending.reject(error);
    }
    this.pending.clear();
  }

  on(method, listener) {
    const listeners = this.listeners.get(method) ?? new Set();
    listeners.add(listener);
    this.listeners.set(method, listeners);
    return () => {
      listeners.delete(listener);
      if (listeners.size === 0) this.listeners.delete(method);
    };
  }

  send(method, params = {}) {
    if (!this.websocket || this.websocket.readyState !== WebSocket.OPEN) {
      return Promise.reject(
        new RecipeError("cdp_not_connected", "CDP is not connected"),
      );
    }
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new RecipeError("cdp_command_timeout", `CDP command timed out: ${method}`));
      }, this.timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
      this.websocket.send(JSON.stringify({ id, method, params }));
    });
  }

  async evaluate(expression, { awaitPromise = false } = {}) {
    const result = await this.send("Runtime.evaluate", {
      expression,
      awaitPromise,
      returnByValue: true,
      userGesture: true,
    });
    if (result.exceptionDetails) {
      const description = result.exceptionDetails.exception?.description ?? "page expression failed";
      throw new RecipeError(
        "dom_recipe_failed",
        String(description).replace(/(?:https?|wss?):\/\/\S+/giu, "<redacted-url>"),
      );
    }
    return result.result?.value;
  }

  close() {
    if (this.websocket && this.websocket.readyState < WebSocket.CLOSING) {
      this.websocket.close();
    }
  }
}

function waitExpression(body, timeoutMs, values = {}) {
  const constants = Object.entries(values)
    .map(([name, value]) => `const ${name} = ${JSON.stringify(value)};`)
    .join("\n");
  return `
    (async () => {
      ${constants}
      const deadline = Date.now() + ${timeoutMs};
      const visible = (element) => {
        if (!(element instanceof Element)) return false;
        const style = getComputedStyle(element);
        return style.display !== "none" && style.visibility !== "hidden" &&
          element.getClientRects().length > 0;
      };
      const text = (element) => String(element.innerText || element.textContent || "")
        .replace(/\\s+/g, " ").trim();
      while (Date.now() < deadline) {
        const value = (() => { ${body} })();
        if (value !== undefined && value !== null && value !== false) return value;
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
      throw new Error("semantic DOM condition timed out");
    })()
  `;
}

async function dispatchExactSearch(client, partNumber) {
  return client.evaluate(`
    (() => {
      const inputSelector = ${JSON.stringify(SELECTORS.search_input)};
      const submitSelector = ${JSON.stringify(SELECTORS.search_submit)};
      const partNumber = ${JSON.stringify(partNumber)};
      const inputs = Array.from(document.querySelectorAll(inputSelector));
      if (inputs.length !== 1 || !(inputs[0] instanceof HTMLInputElement)) {
        throw new Error("expected exactly one McMaster search input");
      }
      const submits = Array.from(document.querySelectorAll(submitSelector)).filter(
        (element) => {
          const style = getComputedStyle(element);
          return style.display !== "none" && style.visibility !== "hidden" &&
            element.getClientRects().length > 0;
        },
      );
      if (submits.length !== 1) {
        throw new Error("expected exactly one visible McMaster search submit control");
      }
      const nativeSetter = Object.getOwnPropertyDescriptor(
        HTMLInputElement.prototype,
        "value",
      )?.set;
      if (typeof nativeSetter !== "function") {
        throw new Error("native HTMLInputElement value setter is unavailable");
      }
      nativeSetter.call(inputs[0], partNumber);
      inputs[0].dispatchEvent(new Event("input", { bubbles: true, composed: true }));
      inputs[0].dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      if (inputs[0].value !== partNumber) {
        throw new Error("search input did not retain the exact part number");
      }
      HTMLElement.prototype.click.call(submits[0]);
      return { search_dispatched: true };
    })()
  `);
}

async function confirmExactPartAndExposeFormat(client, partNumber, timeoutMs) {
  return client.evaluate(
    waitExpression(
      `
        const exact = Array.from(
          document.querySelectorAll("a,button,[role=link],[role=button],td,span"),
        ).filter((element) => visible(element) && text(element) === PART_NUMBER);
        const combo = Array.from(document.querySelectorAll(COMBO_SELECTOR)).filter(visible);
        if (exact.length > 0 && combo.length === 1) {
          return { exact_part_number_confirmed: true, product_action_clicked: false };
        }
        const actionable = exact.filter((element) =>
          element.matches("a,button,[role=link],[role=button]"),
        );
        if (actionable.length > 1) {
          throw new Error("exact part number matched multiple visible actions");
        }
        if (actionable.length === 1) {
          HTMLElement.prototype.click.call(actionable[0]);
          return { exact_part_number_confirmed: true, product_action_clicked: true };
        }
        return false;
      `,
      timeoutMs,
      {
        PART_NUMBER: partNumber,
        COMBO_SELECTOR: SELECTORS.cad_format_combobox,
      },
    ),
    { awaitPromise: true },
  );
}

async function selectExactFormat(client, format, timeoutMs) {
  await client.evaluate(
    waitExpression(
      `
        const matches = Array.from(document.querySelectorAll(COMBO_SELECTOR)).filter(visible);
        if (matches.length > 1) throw new Error("multiple visible CAD format comboboxes");
        if (matches.length !== 1) return false;
        HTMLElement.prototype.click.call(matches[0]);
        return { combobox_clicked: true };
      `,
      timeoutMs,
      { COMBO_SELECTOR: SELECTORS.cad_format_combobox },
    ),
    { awaitPromise: true },
  );

  await client.evaluate(
    waitExpression(
      `
        const options = Array.from(document.querySelectorAll(OPTION_SELECTOR))
          .filter((element) => visible(element) && text(element) === FORMAT);
        if (options.length > 1) throw new Error("multiple exact CAD format options");
        if (options.length !== 1) return false;
        // Exact text equality intentionally rejects variants such as
        // "3-D STEP (no threads)".
        HTMLElement.prototype.click.call(options[0]);
        return { exact_format_option_clicked: true };
      `,
      timeoutMs,
      { OPTION_SELECTOR: SELECTORS.cad_format_option, FORMAT: format },
    ),
    { awaitPromise: true },
  );

  return client.evaluate(
    waitExpression(
      `
        const combos = Array.from(document.querySelectorAll(COMBO_SELECTOR)).filter(visible);
        if (combos.length !== 1) return false;
        const comboValue = String(
          combos[0].getAttribute("aria-valuetext") ||
          combos[0].getAttribute("data-value") ||
          text(combos[0]),
        ).replace(/\\s+/g, " ").trim();
        const selected = Array.from(
          document.querySelectorAll("li[role=option][aria-selected=true]"),
        ).some((element) => text(element) === FORMAT);
        if (comboValue === FORMAT || selected) {
          return { exact_format_selected: true };
        }
        return false;
      `,
      timeoutMs,
      { COMBO_SELECTOR: SELECTORS.cad_format_combobox, FORMAT: format },
    ),
    { awaitPromise: true },
  );
}

function waitForDownloadUrl(client, partNumber, timeoutMs) {
  let cancel = () => {};
  const promise = new Promise((resolve, reject) => {
    let settled = false;
    const removers = [];
    const cleanup = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      for (const remove of removers) remove();
    };
    const finish = (callback, value) => {
      if (settled) return;
      cleanup();
      callback(value);
    };
    const inspect = (eventName, value) => {
      if (typeof value !== "string" || !looksLikeStepUrl(value)) return;
      try {
        finish(resolve, {
          url: validatedDownloadUrl(value, partNumber),
          capture_event: eventName,
        });
      } catch (error) {
        finish(reject, error);
      }
    };
    removers.push(
      client.on("Network.requestWillBeSent", (params) =>
        inspect("Network.requestWillBeSent", params.request?.url),
      ),
      client.on("Network.responseReceived", (params) =>
        inspect("Network.responseReceived", params.response?.url),
      ),
      client.on("Page.downloadWillBegin", (params) =>
        inspect("Page.downloadWillBegin", params.url),
      ),
    );
    const timer = setTimeout(
      () =>
        finish(
          reject,
          new RecipeError(
            "download_url_timeout",
            "no validated exact-part STEP download URL was observed",
          ),
        ),
      timeoutMs,
    );
    // Cancellation only removes listeners and the timer. Leaving the promise
    // pending avoids a secondary unhandled rejection when the DOM click itself
    // has already failed with the more useful primary error.
    cancel = cleanup;
  });
  return { promise, cancel };
}

async function clickExactDownload(client, timeoutMs) {
  return client.evaluate(
    waitExpression(
      `
        const matches = Array.from(document.querySelectorAll(DOWNLOAD_SELECTOR))
          .filter((element) => visible(element) && text(element) === "Download");
        if (matches.length > 1) throw new Error("multiple visible exact Download actions");
        if (matches.length !== 1) return false;
        HTMLElement.prototype.click.call(matches[0]);
        return { exact_download_clicked: true };
      `,
      timeoutMs,
      { DOWNLOAD_SELECTOR: SELECTORS.download_action },
    ),
    { awaitPromise: true },
  );
}

async function runRecipe({ partNumber, format, port, timeoutMs }) {
  const websocketUrl = await discoverUniquePage(port, timeoutMs);
  const client = new CDPClient(websocketUrl, timeoutMs);
  try {
    await client.connect();
    // QtWebEngine's page target can reject concurrent domain-enable commands
    // with CDP -32000 even though each domain is supported.  The successful
    // S10/S20 embedded route established the domains serially, so preserve that
    // adapter-level ordering as part of the reusable recipe.
    await client.send("Runtime.enable");
    await client.send("Page.enable");
    await client.send("Network.enable");
    await dispatchExactSearch(client, partNumber);
    await confirmExactPartAndExposeFormat(client, partNumber, timeoutMs);
    await selectExactFormat(client, format, timeoutMs);
    const downloadWaiter = waitForDownloadUrl(client, partNumber, timeoutMs);
    try {
      await clickExactDownload(client, timeoutMs);
    } catch (error) {
      downloadWaiter.cancel();
      throw error;
    }
    const download = await downloadWaiter.promise;
    return {
      schema: REPORT_SCHEMA,
      recipe_id: RECIPE_ID,
      status: "succeeded",
      part_number: partNumber,
      cad_format: format,
      devtools: {
        host: LOOPBACK_HOST,
        port,
        matching_page_count: 1,
      },
      page: {
        scheme: "https",
        host: MCMASTER_HOST,
      },
      selectors: SELECTORS,
      observations: {
        search_dispatched: true,
        exact_part_number_confirmed: true,
        exact_format_selected: true,
        exact_download_clicked: true,
      },
      download,
    };
  } finally {
    client.close();
  }
}

function safeError(error) {
  const code = error instanceof RecipeError ? error.code : "unexpected_error";
  const message = String(error?.message ?? "recipe failed")
    .replace(/(?:https?|wss?):\/\/\S+/giu, "<redacted-url>")
    .slice(0, 500);
  return {
    schema: REPORT_SCHEMA,
    status: "failed",
    error: { code, message },
  };
}

try {
  const options = parseArguments(process.argv.slice(2));
  const report = await runRecipe(options);
  process.stdout.write(`${JSON.stringify(report)}\n`);
} catch (error) {
  process.stderr.write(`${JSON.stringify(safeError(error))}\n`);
  process.exitCode = 1;
}
