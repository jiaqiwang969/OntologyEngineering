"""Owner-only challenge/receipt primitives for Fusion health recovery.

The recovery controller and the guarded cell must run on the same Fusion Mac.
The controller creates a one-shot challenge in the cell's private state
directory; the cell binds it to the exact live Fusion identity while holding
the PID owner lease and writes a receipt only after the exact health request
has completed and its response has received an exact delivery ACK.

This contract prevents accidental use of a fake command, a different cell, or
an SSH command targeting another host.  It is not intended to defend against a
malicious process running as the same macOS user, which can read owner-only
files and impersonate either endpoint.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import stat
from pathlib import Path
from typing import Any, Mapping

HEALTH_CHALLENGE_SCHEMA = "fusion-mcp.health-identity-challenge.v2"
HEALTH_RECEIPT_SCHEMA = "fusion-mcp.health-identity-attestation.v2"
HEALTH_USED_SCHEMA = "fusion-mcp.health-identity-challenge-used.v2"
HEALTH_TOOL = "fusion_mcp_read"
# ``document`` is an operation-dispatched query in Fusion 2704.1.53.  The
# explicit ``open`` operation lists the already-open documents locally; it
# does not open a document or enumerate cloud data.  Omitting ``operation``
# produces an inner InvalidParameterValue result even though MCP transport and
# delivery acknowledgement succeed.
HEALTH_ARGUMENTS = {"queryType": "document", "operation": "open"}
MAX_HEALTH_ATTESTATION_BYTES = 64 * 1024
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


class HealthAttestationError(RuntimeError):
    """A health identity challenge or receipt is unsafe or invalid."""


def canonical_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")


def sha256_hex(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


HEALTH_ARGUMENTS_SHA256 = sha256_hex(canonical_bytes(HEALTH_ARGUMENTS))


def is_sha256(value: object) -> bool:
    return isinstance(value, str) and _SHA256_RE.fullmatch(value) is not None


def read_owner_only_json(
    path: Path,
    *,
    label: str,
    maximum_bytes: int = MAX_HEALTH_ATTESTATION_BYTES,
) -> tuple[dict[str, Any], bytes]:
    """Read one pinned 0600 regular inode without following a symlink."""
    path = Path(os.path.abspath(path.expanduser()))
    try:
        path_metadata = os.lstat(path)
    except OSError as exc:
        raise HealthAttestationError(f"{label} is unavailable") from exc
    if stat.S_ISLNK(path_metadata.st_mode):
        raise HealthAttestationError(f"{label} must not be a symlink")
    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise HealthAttestationError(f"{label} cannot be opened safely") from exc
    try:
        before = os.fstat(descriptor)
        if (
            before.st_dev != path_metadata.st_dev
            or before.st_ino != path_metadata.st_ino
            or before.st_uid != os.geteuid()
            or not stat.S_ISREG(before.st_mode)
            or before.st_nlink != 1
            or stat.S_IMODE(before.st_mode) != 0o600
            or not 0 < before.st_size <= maximum_bytes
        ):
            raise HealthAttestationError(
                f"{label} must be one owner-only mode 0600 regular inode"
            )
        chunks: list[bytes] = []
        remaining = maximum_bytes + 1
        while remaining > 0:
            chunk = os.read(descriptor, min(4096, remaining))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        encoded = b"".join(chunks)
        after = os.fstat(descriptor)
        if (
            len(encoded) != before.st_size
            or len(encoded) > maximum_bytes
            or after.st_dev != before.st_dev
            or after.st_ino != before.st_ino
            or after.st_uid != before.st_uid
            or after.st_nlink != before.st_nlink
            or stat.S_IMODE(after.st_mode) != stat.S_IMODE(before.st_mode)
            or after.st_size != before.st_size
            or after.st_mtime_ns != before.st_mtime_ns
        ):
            raise HealthAttestationError(f"{label} changed while being read")
    finally:
        os.close(descriptor)

    def unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("duplicate JSON object key")
            result[key] = value
        return result

    try:
        payload = json.loads(encoded, object_pairs_hook=unique_object)
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise HealthAttestationError(f"{label} is not strict JSON") from exc
    if not isinstance(payload, dict):
        raise HealthAttestationError(f"{label} must be a JSON object")
    return payload, encoded


def create_owner_only_json(path: Path, payload: Mapping[str, object]) -> None:
    """Create and fsync one owner-only JSON inode and its parent directory."""
    path = Path(os.path.abspath(path.expanduser()))
    encoded = canonical_bytes(payload) + b"\n"
    if len(encoded) > MAX_HEALTH_ATTESTATION_BYTES:
        raise HealthAttestationError("health attestation payload is too large")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    descriptor = os.open(path, flags, 0o600)
    try:
        os.fchmod(descriptor, 0o600)
        view = memoryview(encoded)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise OSError("health attestation write made no progress")
            view = view[written:]
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    directory_descriptor = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(directory_descriptor)
    finally:
        os.close(directory_descriptor)
