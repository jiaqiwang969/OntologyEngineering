"""Streamable-HTTP client for Autodesk's built-in Fusion MCP endpoint."""

from __future__ import annotations

import math
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import AsyncExitStack, asynccontextmanager
from dataclasses import dataclass
from datetime import timedelta
from typing import Literal, TypeVar, cast

import anyio
import httpx
from mcp import ClientSession
from mcp.client.streamable_http import (
    RequestContext,
    StreamableHTTPError,
    StreamableHTTPTransport,
    streamable_http_client,
)
from mcp.types import (
    CallToolResult,
    CallToolRequest,
    CallToolRequestParams,
    ClientRequest,
    InitializeResult,
    ReadResourceResult,
    Resource,
    Tool,
)
from pydantic import AnyUrl

_T = TypeVar("_T")


@dataclass
class _OwnerCommand:
    """One serialized operation executed by the persistent session owner."""

    kind: Literal[
        "open",
        "list_tools",
        "call_tool",
        "list_resources",
        "read_resource",
        "info",
        "stop",
    ]
    done: anyio.Event
    name: str | None = None
    arguments: dict[str, object] | None = None
    uri: AnyUrl | None = None
    result: object | None = None
    error: BaseException | None = None


@dataclass(frozen=True)
class _NoReconnectSessionControl:
    """Explicit lifecycle hooks for one no-reconnect HTTP session."""

    get_session_id: Callable[[], str | None]
    wait_initialized_notification: Callable[[], Awaitable[None]]
    terminate_session: Callable[[], Awaitable[None]]


@dataclass
class _OwnerSession:
    """Contexts and protocol state owned by the dedicated upstream task."""

    stack: AsyncExitStack
    session: ClientSession
    initialized: InitializeResult
    control: _NoReconnectSessionControl


class NoReconnectStreamableHTTPTransport(StreamableHTTPTransport):
    """MCP transport variant that never emits automatic recovery traffic."""

    def __init__(self, url: str) -> None:
        super().__init__(url)
        self._initialized_notification_done = anyio.Event()
        self._initialized_notification_error: BaseException | None = None

    async def _handle_post_request(self, ctx: RequestContext) -> None:
        """Expose completion of the initialized notification's HTTP request.

        ``ClientSession.initialize()`` only waits until the notification has
        entered the SDK's zero-buffer memory stream.  It does not wait for the
        corresponding HTTP POST to receive its 202 response.  A synchronous
        Fusion window proof immediately after ``initialize()`` can therefore
        starve that unfinished POST on this same event loop.  Record the exact
        wire completion (or failure) so the owner can drain the handshake
        before it begins that proof.
        """
        initialized = self._is_initialized_notification(ctx.session_message.message)
        try:
            await super()._handle_post_request(ctx)
        except BaseException as exc:
            if initialized:
                self._initialized_notification_error = exc
                self._initialized_notification_done.set()
            raise
        else:
            if initialized:
                self._initialized_notification_done.set()

    async def wait_initialized_notification(self) -> None:
        await self._initialized_notification_done.wait()
        if self._initialized_notification_error is not None:
            raise self._initialized_notification_error

    async def terminate_session(self, client: httpx.AsyncClient) -> None:
        """Strict one-shot DELETE for a known-complete exact session."""
        session_id = self.get_session_id()
        if not session_id:
            raise StreamableHTTPError(
                "Fusion MCP initialize did not return a session identifier"
            )
        response = await client.delete(self.url, headers=self._prepare_headers())
        if response.status_code not in (200, 204):
            raise StreamableHTTPError(
                "Fusion MCP session DELETE failed with HTTP "
                f"{response.status_code}"
            )

    async def handle_get_stream(self, client, read_stream_writer) -> None:
        # Fusion control does not consume server-initiated messages.  Avoid the
        # SDK's persistent GET stream, which otherwise reconnects twice after a
        # disconnect independently of the request guard.
        return None

    async def _handle_reconnection(
        self,
        ctx,
        last_event_id: str,
        retry_interval_ms: int | None = None,
        attempt: int = 0,
    ) -> None:
        # A broken SSE response boundary must fail the request.  Reconnection
        # could cross a Fusion timeout/retirement boundary and is prohibited.
        raise StreamableHTTPError(
            "Fusion MCP SSE response ended before completion; reconnection disabled"
        )


@asynccontextmanager
async def no_reconnect_streamable_http_client(
    url: str,
    *,
    http_client: httpx.AsyncClient,
) -> AsyncIterator[tuple[object, object, _NoReconnectSessionControl]]:
    """Streamable HTTP client with explicit-success DELETE and no reconnect.

    Exiting this context never emits protocol traffic.  The owner may invoke
    the returned termination hook only after its requested operation completed
    normally; timeout, cancellation, and transport-fault cleanup stay local.
    """
    read_stream_writer, read_stream = anyio.create_memory_object_stream(0)
    write_stream, write_stream_reader = anyio.create_memory_object_stream(0)
    transport = NoReconnectStreamableHTTPTransport(url)

    try:
        async with anyio.create_task_group() as task_group:

            def start_get_stream() -> None:
                # The no-reconnect transport makes this task a no-op, but retaining
                # the callback preserves SDK post-writer initialization semantics.
                task_group.start_soon(
                    transport.handle_get_stream,
                    http_client,
                    read_stream_writer,
                )

            task_group.start_soon(
                transport.post_writer,
                http_client,
                write_stream_reader,
                read_stream_writer,
                write_stream,
                start_get_stream,
                task_group,
            )
            try:
                yield (
                    read_stream,
                    write_stream,
                    _NoReconnectSessionControl(
                        get_session_id=transport.get_session_id,
                        wait_initialized_notification=(
                            transport.wait_initialized_notification
                        ),
                        terminate_session=lambda: transport.terminate_session(
                            http_client
                        ),
                    ),
                )
            finally:
                # Deliberately no automatic terminate_session()/DELETE.  Only
                # the owner-side known-success path may call the explicit hook.
                task_group.cancel_scope.cancel()
    finally:
        await read_stream_writer.aclose()
        await write_stream.aclose()


class AutodeskFusionUpstream:
    def __init__(
        self, url: str = "http://127.0.0.1:27182/mcp", timeout_seconds: float = 120.0
    ) -> None:
        if not math.isfinite(timeout_seconds) or not 0 < timeout_seconds <= 300:
            raise ValueError("timeout_seconds must be finite and between 0 and 300")
        self.url = url
        self.timeout_seconds = timeout_seconds

    @asynccontextmanager
    async def _session(self) -> AsyncIterator[tuple[ClientSession, InitializeResult]]:
        # Autodesk's endpoint supports explicit session DELETE, but a DELETE must
        # never be emitted from a timeout/cancellation cleanup path: the request
        # may still occupy Fusion's dispatcher.  Disable transport auto-terminate
        # and send DELETE only after the requested operation returns normally.
        client_timeout = httpx.Timeout(
            self.timeout_seconds,
            read=self.timeout_seconds,
            write=self.timeout_seconds,
            connect=min(self.timeout_seconds, 10.0),
            pool=min(self.timeout_seconds, 10.0),
        )
        async with (
            httpx.AsyncClient(
                follow_redirects=False,
                trust_env=False,
                timeout=client_timeout,
            ) as client,
            streamable_http_client(
                self.url,
                http_client=client,
                terminate_on_close=False,
            ) as (read_stream, write_stream, _),
            ClientSession(
                read_stream,
                write_stream,
                read_timeout_seconds=timedelta(seconds=self.timeout_seconds),
            ) as session,
        ):
            initialized = await session.initialize()
            # Never DELETE an Autodesk session from this guarded client.  A
            # result can arrive immediately before an outer timeout/cancel; a
            # synchronous DELETE in that window would violate timeout
            # retirement semantics.  Closing the private HTTP transport is the
            # only cleanup performed here.
            yield session, initialized

    async def list_tools(self) -> list[Tool]:
        async with self._session() as (session, _):
            tools: list[Tool] = []
            cursor: str | None = None
            while True:
                result = await session.list_tools(cursor)
                tools.extend(result.tools)
                cursor = result.nextCursor
                if cursor is None:
                    return tools

    async def call_tool(
        self, name: str, arguments: dict[str, object]
    ) -> CallToolResult:
        async with self._session() as (session, _):
            return await session.call_tool(name, arguments)

    async def list_resources(self) -> list[Resource]:
        async with self._session() as (session, _):
            resources: list[Resource] = []
            cursor: str | None = None
            while True:
                result = await session.list_resources(cursor)
                resources.extend(result.resources)
                cursor = result.nextCursor
                if cursor is None:
                    return resources

    async def read_resource(self, uri: AnyUrl) -> ReadResourceResult:
        async with self._session() as (session, _):
            return await session.read_resource(uri)

    async def info(self) -> dict[str, object]:
        async with self._session() as (session, initialized):
            listed = await session.list_tools()
            resources = await session.list_resources()
            return {
                "url": self.url,
                "protocol_version": initialized.protocolVersion,
                "server_info": initialized.serverInfo.model_dump(mode="json"),
                "capabilities": initialized.capabilities.model_dump(mode="json"),
                "tools": [tool.name for tool in listed.tools],
                "resources": [str(resource.uri) for resource in resources.resources],
            }


class PersistentAutodeskFusionUpstream:
    """One persistent owner actor with operation-scoped Autodesk MCP sessions.

    The HTTP transport, MCP session, and their task-group-backed contexts are
    entered, used, and exited by one dedicated owner task.  Public methods only
    submit serialized commands to that task.  This is important because AnyIO
    cancel scopes are task-local stacks: returning from ``open`` with a task
    group entered by the caller would put an outer request deadline underneath
    a still-live inner scope and make the deadline's exit fail.

    Each guarded operation calls ``open`` to create one operation-scoped MCP
    session.  ``open`` does not return until both initialize and the HTTP 202
    for ``notifications/initialized`` have completed.  The guard then re-proves
    the exact Fusion process/window binding before the selected request uses
    that same session.  Every normally completed operation is DELETEd before
    its local contexts unwind.  A timeout/cancellation poisons the actor and
    cancels its current operation; that ambiguous path never queues another
    request, reconnects, probes, or DELETEs the ambiguous session.
    """

    def __init__(
        self, url: str = "http://127.0.0.1:27182/mcp", timeout_seconds: float = 120.0
    ) -> None:
        if not math.isfinite(timeout_seconds) or not 0 < timeout_seconds <= 300:
            raise ValueError("timeout_seconds must be finite and between 0 and 300")
        self.url = url
        self.timeout_seconds = timeout_seconds
        self._send_stream: anyio.abc.ObjectSendStream[_OwnerCommand] | None = None
        self._receive_stream: anyio.abc.ObjectReceiveStream[_OwnerCommand] | None = None
        self._owner_finished: anyio.Event | None = None
        self._current_operation_scope: anyio.CancelScope | None = None
        self._active_command: _OwnerCommand | None = None
        self._request_lock = anyio.Lock()
        self._owner_started = False
        self._closed = False
        self._poisoned = False

    async def start_owner(self, task_group: anyio.abc.TaskGroup) -> None:
        """Start the sole task allowed to own the persistent MCP contexts."""
        if self._owner_started:
            raise RuntimeError("Autodesk Fusion upstream owner is already started")
        if self._closed or self._poisoned:
            raise RuntimeError("Autodesk Fusion upstream owner cannot start")
        send_stream, receive_stream = anyio.create_memory_object_stream[_OwnerCommand](
            0
        )
        self._send_stream = send_stream
        self._receive_stream = receive_stream
        self._owner_finished = anyio.Event()
        self._owner_started = True
        await task_group.start(self._run_owner)

    async def open(self) -> None:
        if not self._owner_started:
            raise RuntimeError("Autodesk Fusion upstream owner is not started")
        if self._poisoned or self._closed:
            raise RuntimeError("Autodesk Fusion upstream cannot reopen")
        await self._submit(_OwnerCommand(kind="open", done=anyio.Event()))

    def abandon(self) -> None:
        """Retire a prepared session locally without any upstream cleanup."""
        self._poison()
        self._abort_current_operation()

    async def close(self) -> None:
        """Stop the owner; only a clean idle session may be terminated."""
        if self._closed:
            finished = self._owner_finished
            if finished is not None:
                await finished.wait()
            return
        self._closed = True
        if not self._owner_started:
            return

        finished = self._owner_finished
        send_stream = self._send_stream
        if finished is None or send_stream is None:
            return

        # An in-flight actor must not process a queued stop after an ambiguous
        # upstream boundary.  Cancel only its current owner-side operation.  If
        # caller cancellation happened before the zero-buffer send was
        # received, there is no active command; a stop is then required to wake
        # the otherwise idle owner.
        if self._active_command is not None:
            self._abort_current_operation()
        else:
            stop = _OwnerCommand(kind="stop", done=anyio.Event())
            try:
                await send_stream.send(stop)
                await stop.done.wait()
            except (anyio.BrokenResourceError, anyio.ClosedResourceError):
                pass
        await finished.wait()

    def _poison(self) -> None:
        """Prevent every later operation after an ambiguous boundary."""
        if self._poisoned:
            return
        self._poisoned = True
        # Synchronous local stream closure wakes an owner whose caller was
        # cancelled before the zero-buffer command send completed.  It emits no
        # HTTP/MCP traffic and ensures no later command can be queued.
        send_stream = self._send_stream
        if send_stream is not None:
            send_stream.close()

    def _abort_current_operation(self) -> None:
        scope = self._current_operation_scope
        if scope is not None:
            scope.cancel()

    async def _submit(self, command: _OwnerCommand) -> object | None:
        if self._poisoned:
            raise RuntimeError("Autodesk Fusion upstream is poisoned")
        if self._closed:
            raise RuntimeError("Autodesk Fusion upstream is closed")
        send_stream = self._send_stream
        if not self._owner_started or send_stream is None:
            raise RuntimeError("Autodesk Fusion upstream owner is not started")
        try:
            self._request_lock.acquire_nowait()
        except anyio.WouldBlock as exc:
            raise RuntimeError(
                "another Autodesk Fusion upstream operation is in flight"
            ) from exc
        try:
            try:
                await send_stream.send(command)
                await command.done.wait()
            except BaseException:
                self._poison()
                self._abort_current_operation()
                raise
            if command.error is not None:
                self._poison()
                self._abort_current_operation()
                raise command.error
            return command.result
        finally:
            self._request_lock.release()

    async def _run_owner(self, *, task_status: anyio.abc.TaskStatus[None]) -> None:
        """Own all long-lived contexts and execute exactly one command at a time."""
        receive_stream = self._receive_stream
        finished = self._owner_finished
        if receive_stream is None or finished is None:
            raise RuntimeError("Autodesk Fusion upstream owner was not prepared")

        owner_session: _OwnerSession | None = None
        active: _OwnerCommand | None = None
        owner_failure: BaseException | None = None
        try:
            task_status.started()
            try:
                async with receive_stream:
                    async for command in receive_stream:
                        active = command
                        self._active_command = command
                        if command.kind == "stop":
                            if owner_session is not None and not self._poisoned:
                                await self._release_known_complete_session(
                                    owner_session
                                )
                                owner_session = None
                            command.done.set()
                            active = None
                            self._active_command = None
                            break
                        try:
                            if command.kind == "open":
                                if owner_session is not None:
                                    raise RuntimeError(
                                        "Autodesk Fusion upstream is already open"
                                    )
                                owner_session = await self._owner_open()
                                result: object | None = None
                            else:
                                if owner_session is None:
                                    raise RuntimeError(
                                        "Autodesk Fusion upstream is not open"
                                    )
                                current_session = owner_session
                                result = await self._run_owner_operation(
                                    lambda: self._owner_request_and_terminate(
                                        command, current_session
                                    )
                                )
                                # Exit the operation cancel scope before
                                # unwinding task-group-backed contexts.  This
                                # preserves strict AnyIO cancel-scope order.
                                await current_session.stack.aclose()
                                owner_session = None
                            command.result = result
                        except BaseException as exc:
                            command.error = exc
                            self._poison()
                        finally:
                            command.done.set()
                            active = None
                            self._active_command = None
                        if command.error is not None:
                            break
            except BaseException as exc:
                owner_failure = exc
            finally:
                self._current_operation_scope = None
                # Ambiguous failure cleanup is local-only: do not call the
                # explicit session termination hook from this path.
                if owner_session is not None:
                    try:
                        await owner_session.stack.aclose()
                    except BaseException as exc:
                        if owner_failure is None:
                            owner_failure = exc
        except BaseException:
            self._poison()
            raise
        finally:
            self._current_operation_scope = None
            self._active_command = None
            if active is not None and active.error is None:
                active.error = owner_failure or RuntimeError(
                    "Autodesk Fusion upstream owner stopped during an operation"
                )
                active.done.set()
            finished.set()

    async def _owner_open(
        self,
    ) -> _OwnerSession:
        # These context entries only allocate local client/task-group state;
        # network I/O begins with initialize below.  They intentionally are not
        # placed in a request cancel scope that would have to exit underneath
        # their longer-lived task-group scopes.  A caller cancelled in this
        # short entry interval poisons the actor; check that before initialize.
        client_timeout = httpx.Timeout(
            self.timeout_seconds,
            read=self.timeout_seconds,
            write=self.timeout_seconds,
            connect=min(self.timeout_seconds, 10.0),
            pool=min(self.timeout_seconds, 10.0),
        )
        stack = AsyncExitStack()
        try:
            client = await stack.enter_async_context(
                httpx.AsyncClient(
                    follow_redirects=False,
                    trust_env=False,
                    timeout=client_timeout,
                    # Fusion may close an otherwise healthy HTTP/1.1 keep-alive
                    # socket while the guard is proving UI state.  MCP session
                    # identity is carried in headers, so use a fresh TCP
                    # connection for each serialized POST/DELETE instead of
                    # risking a half-closed pooled connection.
                    limits=httpx.Limits(
                        max_connections=1,
                        max_keepalive_connections=0,
                    ),
                )
            )
            read_stream, write_stream, control = await stack.enter_async_context(
                no_reconnect_streamable_http_client(
                    self.url,
                    http_client=client,
                )
            )
            session = await stack.enter_async_context(
                ClientSession(
                    read_stream,
                    write_stream,
                    read_timeout_seconds=timedelta(seconds=self.timeout_seconds),
                )
            )
            if self._poisoned or self._closed:
                raise RuntimeError("Autodesk Fusion upstream opening was cancelled")
            async def initialize_and_drain() -> InitializeResult:
                initialized = await session.initialize()
                await control.wait_initialized_notification()
                if not control.get_session_id():
                    raise StreamableHTTPError(
                        "Fusion MCP initialize did not return a session identifier"
                    )
                return initialized

            initialized = await self._run_owner_operation(initialize_and_drain)
            return _OwnerSession(
                stack=stack,
                session=session,
                initialized=initialized,
                control=control,
            )
        except BaseException:
            # The transport context has no automatic DELETE path.  If
            # initialization did not return normally, only unwind local state.
            await stack.aclose()
            raise

    async def _release_known_complete_session(
        self,
        owner_session: _OwnerSession,
    ) -> None:
        """Bounded DELETE after a known-complete operation, then local unwind."""
        await self._terminate_known_complete_session(owner_session)
        await owner_session.stack.aclose()

    async def _terminate_known_complete_session(
        self,
        owner_session: _OwnerSession,
    ) -> None:
        """Bounded strict DELETE with no automatic retry or reconnect."""
        with anyio.fail_after(min(self.timeout_seconds, 5.0)):
            await owner_session.control.terminate_session()

    async def _owner_request_and_terminate(
        self,
        command: _OwnerCommand,
        owner_session: _OwnerSession,
    ) -> object:
        # Caller cancellation can land after its zero-buffer command send but
        # before this owner task installs the operation scope.  Re-check inside
        # that scope, immediately before any selected MCP request is emitted.
        if self._poisoned or self._closed:
            raise RuntimeError("Autodesk Fusion upstream request was cancelled")
        result = await self._owner_request(
            command,
            owner_session.session,
            owner_session.initialized,
        )
        await self._terminate_known_complete_session(owner_session)
        return result

    async def _run_owner_operation(self, operation: Callable[[], Awaitable[_T]]) -> _T:
        error: BaseException | None = None
        result: _T | None = None
        with anyio.CancelScope() as operation_scope:
            self._current_operation_scope = operation_scope
            try:
                result = await operation()
            except BaseException as exc:
                error = exc
            finally:
                self._current_operation_scope = None
        if error is not None:
            raise error
        return cast(_T, result)

    async def _owner_request(
        self,
        command: _OwnerCommand,
        session: ClientSession,
        initialized: InitializeResult,
    ) -> object:
        if command.kind == "list_tools":

            async def list_tools() -> list[Tool]:
                tools: list[Tool] = []
                cursor: str | None = None
                while True:
                    result = await session.list_tools(cursor)
                    tools.extend(result.tools)
                    cursor = result.nextCursor
                    if cursor is None:
                        return tools

            return await list_tools()
        if command.kind == "call_tool":
            if command.name is None or command.arguments is None:
                raise RuntimeError("invalid call_tool owner command")
            # ClientSession.call_tool() performs an implicit tools/list after a
            # successful result when its output-schema cache is empty.  The
            # guarded Fusion cell intentionally never discovers tools from the
            # live PID: the package-local catalog is release-audited, and the
            # selected tool call must remain the only post-initialize request.
            # Send the same typed request directly so result parsing is kept
            # without the SDK's hidden discovery/retry traffic.
            request = ClientRequest(
                CallToolRequest(
                    params=CallToolRequestParams(
                        name=command.name,
                        arguments=command.arguments,
                    )
                )
            )
            return await session.send_request(request, CallToolResult)
        if command.kind == "list_resources":

            async def list_resources() -> list[Resource]:
                resources: list[Resource] = []
                cursor: str | None = None
                while True:
                    result = await session.list_resources(cursor)
                    resources.extend(result.resources)
                    cursor = result.nextCursor
                    if cursor is None:
                        return resources

            return await list_resources()
        if command.kind == "read_resource":
            if command.uri is None:
                raise RuntimeError("invalid read_resource owner command")
            return await session.read_resource(command.uri)
        if command.kind == "info":

            async def info() -> dict[str, object]:
                listed = await session.list_tools()
                resources = await session.list_resources()
                return {
                    "url": self.url,
                    "protocol_version": initialized.protocolVersion,
                    "server_info": initialized.serverInfo.model_dump(mode="json"),
                    "capabilities": initialized.capabilities.model_dump(mode="json"),
                    "tools": [tool.name for tool in listed.tools],
                    "resources": [
                        str(resource.uri) for resource in resources.resources
                    ],
                }

            return await info()
        raise RuntimeError(f"unknown Autodesk Fusion owner command: {command.kind}")

    async def list_tools(self) -> list[Tool]:
        result = await self._submit(
            _OwnerCommand(kind="list_tools", done=anyio.Event())
        )
        return cast(list[Tool], result)

    async def call_tool(
        self, name: str, arguments: dict[str, object]
    ) -> CallToolResult:
        result = await self._submit(
            _OwnerCommand(
                kind="call_tool",
                done=anyio.Event(),
                name=name,
                arguments=arguments,
            )
        )
        return cast(CallToolResult, result)

    async def list_resources(self) -> list[Resource]:
        result = await self._submit(
            _OwnerCommand(kind="list_resources", done=anyio.Event())
        )
        return cast(list[Resource], result)

    async def read_resource(self, uri: AnyUrl) -> ReadResourceResult:
        result = await self._submit(
            _OwnerCommand(kind="read_resource", done=anyio.Event(), uri=uri)
        )
        return cast(ReadResourceResult, result)

    async def info(self) -> dict[str, object]:
        result = await self._submit(_OwnerCommand(kind="info", done=anyio.Event()))
        return cast(dict[str, object], result)
