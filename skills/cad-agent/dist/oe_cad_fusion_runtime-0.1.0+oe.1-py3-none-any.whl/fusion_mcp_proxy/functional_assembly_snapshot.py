"""Build a bounded read-only Fusion observer for functional assemblies.

The observer accepts only identity and selector bindings.  It emits native
document, occurrence, landmark, interface, joint, distance, and interference
facts; it deliberately does not emit semantic roles, signed projections,
contact/engagement classifications, fit classes, or a PASS/FAIL decision.
Those conclusions belong to the profile-driven evaluator.
"""

from __future__ import annotations

import json
import math
from typing import Any, Mapping, Sequence


SNAPSHOT_SCHEMA = "cad-agent.fusion-functional-snapshot.v3"
BINDING_PLAN_SCHEMA = "cad-agent.functional-assembly-binding-plan.v1"

MAX_TEXT_LENGTH = 4096
MAX_OCCURRENCES = 64
MAX_LANDMARKS = 128
MAX_INTERFACE_PAIRS = 64
MAX_INTERFACE_BOUNDARIES = 128
MAX_JOINTS = 64

_LANDMARK_SELECTOR_KINDS = {
    "occurrence_origin",
    "body_bounding_box_center",
    "body_bounding_box_axis_extreme",
    "entity_token_point",
    "joint_geometry_origin",
    "owner_local_point",
}
_AXES = {"x", "y", "z"}
_EXTREMES = {"minimum", "maximum"}
_JOINT_SIDES = {"one", "two"}


class FunctionalAssemblySnapshotError(ValueError):
    """Raised when an observer request is ambiguous or exceeds its boundary."""


def _text(value: object, name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise FunctionalAssemblySnapshotError(f"{name} must be a non-empty string")
    if len(value) > MAX_TEXT_LENGTH:
        raise FunctionalAssemblySnapshotError(
            f"{name} exceeds {MAX_TEXT_LENGTH} characters"
        )
    if any(ord(character) < 32 for character in value):
        raise FunctionalAssemblySnapshotError(
            f"{name} contains a control character"
        )
    return value


def _optional_text(value: object | None, name: str) -> str | None:
    if value is None:
        return None
    return _text(value, name)


def _point3(value: object, name: str) -> list[float]:
    components = _sequence(value, name, 3)
    if len(components) != 3:
        raise FunctionalAssemblySnapshotError(
            f"{name} must contain exactly three coordinates"
        )
    result: list[float] = []
    for index, component in enumerate(components):
        if isinstance(component, bool) or not isinstance(component, (int, float)):
            raise FunctionalAssemblySnapshotError(
                f"{name}[{index}] must be a finite real number"
            )
        number = float(component)
        if not math.isfinite(number):
            raise FunctionalAssemblySnapshotError(
                f"{name}[{index}] must be a finite real number"
            )
        result.append(number)
    return result


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise FunctionalAssemblySnapshotError(f"{name} must be an object")
    return value


def _sequence(
    value: object,
    name: str,
    maximum: int,
) -> Sequence[object]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        raise FunctionalAssemblySnapshotError(f"{name} must be an array")
    if len(value) > maximum:
        raise FunctionalAssemblySnapshotError(
            f"{name} exceeds {maximum} items"
        )
    return value


def _closed_keys(
    value: Mapping[str, Any],
    *,
    name: str,
    allowed: set[str],
    required: set[str],
) -> None:
    missing = sorted(required.difference(value))
    if missing:
        raise FunctionalAssemblySnapshotError(
            f"{name} is missing required field(s): {', '.join(missing)}"
        )
    unexpected = sorted(set(value).difference(allowed))
    if unexpected:
        raise FunctionalAssemblySnapshotError(
            f"{name} has unsupported field(s): {', '.join(unexpected)}"
        )


def _unique_id(
    value: object,
    *,
    name: str,
    seen: set[str],
) -> str:
    identifier = _text(value, name)
    if identifier in seen:
        raise FunctionalAssemblySnapshotError(f"{name} duplicates {identifier!r}")
    seen.add(identifier)
    return identifier


def _normalize_binding_plan(binding_plan: Mapping[str, Any]) -> dict[str, Any]:
    plan = _mapping(binding_plan, "binding_plan")
    _closed_keys(
        plan,
        name="binding_plan",
        allowed={
            "schema",
            "reference_frame_bindings",
            "occurrence_role_bindings",
            "landmark_bindings",
            "interface_pair_bindings",
            "joint_bindings",
        },
        required={
            "schema",
            "occurrence_role_bindings",
            "landmark_bindings",
            "interface_pair_bindings",
            "joint_bindings",
        },
    )
    if plan["schema"] != BINDING_PLAN_SCHEMA:
        raise FunctionalAssemblySnapshotError(
            f"binding_plan.schema must be {BINDING_PLAN_SCHEMA!r}"
        )

    occurrence_values = _sequence(
        plan["occurrence_role_bindings"],
        "binding_plan.occurrence_role_bindings",
        MAX_OCCURRENCES,
    )
    if not occurrence_values:
        raise FunctionalAssemblySnapshotError(
            "binding_plan.occurrence_role_bindings must not be empty"
        )
    occurrence_ids: set[str] = set()
    occurrence_paths: set[str] = set()
    occurrences: list[dict[str, str]] = []
    for index, raw in enumerate(occurrence_values):
        path = f"binding_plan.occurrence_role_bindings[{index}]"
        item = _mapping(raw, path)
        _closed_keys(
            item,
            name=path,
            allowed={"id", "functional_role", "full_path"},
            required={"id", "functional_role", "full_path"},
        )
        identifier = _unique_id(item["id"], name=f"{path}.id", seen=occurrence_ids)
        role = _text(item["functional_role"], f"{path}.functional_role")
        full_path = _text(item["full_path"], f"{path}.full_path")
        if full_path in occurrence_paths:
            raise FunctionalAssemblySnapshotError(
                f"{path}.full_path duplicates {full_path!r}"
            )
        occurrence_paths.add(full_path)
        occurrences.append(
            {
                "id": identifier,
                "functional_role": role,
                "full_path": full_path,
            }
        )

    reference_frame_values = _sequence(
        plan.get("reference_frame_bindings", []),
        "binding_plan.reference_frame_bindings",
        MAX_OCCURRENCES,
    )
    reference_frame_ids: set[str] = set()
    reference_frames: list[dict[str, Any]] = []
    for index, raw in enumerate(reference_frame_values):
        path = f"binding_plan.reference_frame_bindings[{index}]"
        item = _mapping(raw, path)
        _closed_keys(
            item,
            name=path,
            allowed={"frame_role", "occurrence_id"},
            required={"frame_role", "occurrence_id"},
        )
        identifier = _unique_id(
            item["frame_role"],
            name=f"{path}.frame_role",
            seen=reference_frame_ids,
        )
        owner = _text(item["occurrence_id"], f"{path}.occurrence_id")
        if owner not in occurrence_ids:
            raise FunctionalAssemblySnapshotError(
                f"{path}.occurrence_id references unknown occurrence {owner!r}"
            )
        reference_frames.append(
            {
                "frame_role": identifier,
                "occurrence_id": owner,
            }
        )

    landmark_values = _sequence(
        plan["landmark_bindings"],
        "binding_plan.landmark_bindings",
        MAX_LANDMARKS,
    )
    landmark_ids: set[str] = set()
    landmarks: list[dict[str, Any]] = []
    functional_role_by_occurrence = {
        item["id"]: item["functional_role"] for item in occurrences
    }
    for index, raw in enumerate(landmark_values):
        path = f"binding_plan.landmark_bindings[{index}]"
        item = _mapping(raw, path)
        _closed_keys(
            item,
            name=path,
            allowed={
                "id",
                "occurrence_id",
                "functional_role",
                "landmark_role",
                "selector",
            },
            required={
                "id",
                "occurrence_id",
                "functional_role",
                "landmark_role",
                "selector",
            },
        )
        identifier = _unique_id(item["id"], name=f"{path}.id", seen=landmark_ids)
        occurrence_id = _text(item["occurrence_id"], f"{path}.occurrence_id")
        if occurrence_id not in occurrence_ids:
            raise FunctionalAssemblySnapshotError(
                f"{path}.occurrence_id references unknown occurrence "
                f"{occurrence_id!r}"
            )
        selector_path = f"{path}.selector"
        selector = _mapping(item["selector"], selector_path)
        kind = _text(selector.get("kind"), f"{selector_path}.kind")
        if kind not in _LANDMARK_SELECTOR_KINDS:
            raise FunctionalAssemblySnapshotError(
                f"{selector_path}.kind must be one of "
                + ", ".join(sorted(_LANDMARK_SELECTOR_KINDS))
            )
        allowed_selector_keys = {"kind"}
        required_selector_keys = {"kind"}
        if kind == "body_bounding_box_axis_extreme":
            allowed_selector_keys |= {"body_index", "axis", "extreme"}
            required_selector_keys |= {"axis", "extreme"}
        elif kind == "body_bounding_box_center":
            allowed_selector_keys |= {"body_index"}
        elif kind == "entity_token_point":
            allowed_selector_keys |= {"entity_token"}
            required_selector_keys |= {"entity_token"}
        elif kind == "joint_geometry_origin":
            allowed_selector_keys |= {"joint_id", "side"}
            required_selector_keys |= {"joint_id", "side"}
        elif kind == "owner_local_point":
            allowed_selector_keys |= {"point"}
            required_selector_keys |= {"point"}
        _closed_keys(
            selector,
            name=selector_path,
            allowed=allowed_selector_keys,
            required=required_selector_keys,
        )
        normalized_selector: dict[str, Any] = {"kind": kind}
        if "body_index" in selector:
            body_index = selector["body_index"]
            if (
                isinstance(body_index, bool)
                or not isinstance(body_index, int)
                or body_index < 0
            ):
                raise FunctionalAssemblySnapshotError(
                    f"{selector_path}.body_index must be a non-negative integer"
                )
            normalized_selector["body_index"] = body_index
        if kind == "body_bounding_box_axis_extreme":
            axis = _text(selector["axis"], f"{selector_path}.axis")
            extreme = _text(selector["extreme"], f"{selector_path}.extreme")
            if axis not in _AXES or extreme not in _EXTREMES:
                raise FunctionalAssemblySnapshotError(
                    f"{selector_path} has an invalid axis or extreme"
                )
            normalized_selector.update({"axis": axis, "extreme": extreme})
        elif kind == "entity_token_point":
            normalized_selector["entity_token"] = _text(
                selector["entity_token"], f"{selector_path}.entity_token"
            )
        elif kind == "joint_geometry_origin":
            side = _text(selector["side"], f"{selector_path}.side")
            if side not in _JOINT_SIDES:
                raise FunctionalAssemblySnapshotError(
                    f"{selector_path}.side must be one or two"
                )
            normalized_selector.update(
                {
                    "joint_id": _text(
                        selector["joint_id"], f"{selector_path}.joint_id"
                    ),
                    "side": side,
                }
            )
        elif kind == "owner_local_point":
            normalized_selector["point"] = _point3(
                selector["point"],
                f"{selector_path}.point",
            )
        functional_role = _text(
            item["functional_role"],
            f"{path}.functional_role",
        )
        if functional_role_by_occurrence[occurrence_id] != functional_role:
            raise FunctionalAssemblySnapshotError(
                f"{path}.functional_role does not match the occurrence-role binding"
            )
        landmarks.append(
            {
                "id": identifier,
                "occurrence_id": occurrence_id,
                "functional_role": functional_role,
                "landmark_role": _text(
                    item["landmark_role"],
                    f"{path}.landmark_role",
                ),
                "selector": normalized_selector,
            }
        )

    interface_pair_values = _sequence(
        plan["interface_pair_bindings"],
        "binding_plan.interface_pair_bindings",
        MAX_INTERFACE_PAIRS,
    )
    interface_pair_ids: set[str] = set()
    interface_ids: set[str] = set()
    interface_entity_tokens: set[str] = set()
    interface_pairs: list[dict[str, Any]] = []
    for index, raw in enumerate(interface_pair_values):
        path = f"binding_plan.interface_pair_bindings[{index}]"
        item = _mapping(raw, path)
        _closed_keys(
            item,
            name=path,
            allowed={"id", "interface_pair_role", "first", "second"},
            required={"id", "interface_pair_role", "first", "second"},
        )
        pair_id = _unique_id(
            item["id"], name=f"{path}.id", seen=interface_pair_ids
        )
        sides: list[dict[str, str]] = []
        for side_name in ("first", "second"):
            side_path = f"{path}.{side_name}"
            side = _mapping(item[side_name], side_path)
            _closed_keys(
                side,
                name=side_path,
                allowed={
                    "id",
                    "interface_role",
                    "occurrence_id",
                    "entity_tokens",
                },
                required={
                    "id",
                    "interface_role",
                    "occurrence_id",
                    "entity_tokens",
                },
            )
            interface_id = _unique_id(
                side["id"], name=f"{side_path}.id", seen=interface_ids
            )
            occurrence_id = _text(
                side["occurrence_id"], f"{side_path}.occurrence_id"
            )
            if occurrence_id not in occurrence_ids:
                raise FunctionalAssemblySnapshotError(
                    f"{side_path}.occurrence_id references unknown occurrence "
                    f"{occurrence_id!r}"
                )
            token_values = _sequence(
                side["entity_tokens"],
                f"{side_path}.entity_tokens",
                MAX_INTERFACE_BOUNDARIES,
            )
            if not token_values:
                raise FunctionalAssemblySnapshotError(
                    f"{side_path}.entity_tokens must not be empty"
                )
            entity_tokens = [
                _text(value, f"{side_path}.entity_tokens[{token_index}]")
                for token_index, value in enumerate(token_values)
            ]
            if len(set(entity_tokens)) != len(entity_tokens):
                raise FunctionalAssemblySnapshotError(
                    f"{side_path}.entity_tokens contains duplicates"
                )
            reused_tokens = sorted(
                set(entity_tokens).intersection(interface_entity_tokens)
            )
            if reused_tokens:
                raise FunctionalAssemblySnapshotError(
                    f"{side_path}.entity_tokens reuses a boundary from another "
                    "interface"
                )
            interface_entity_tokens.update(entity_tokens)
            sides.append(
                {
                    "id": interface_id,
                    "interface_role": _text(
                        side["interface_role"],
                        f"{side_path}.interface_role",
                    ),
                    "occurrence_id": occurrence_id,
                    "entity_tokens": entity_tokens,
                }
            )
        if sides[0]["occurrence_id"] == sides[1]["occurrence_id"]:
            raise FunctionalAssemblySnapshotError(
                f"{path} must bind interfaces owned by distinct occurrences"
            )
        interface_pairs.append(
            {
                "id": pair_id,
                "interface_pair_role": _text(
                    item["interface_pair_role"],
                    f"{path}.interface_pair_role",
                ),
                "first": sides[0],
                "second": sides[1],
            }
        )

    joint_values = _sequence(
        plan["joint_bindings"],
        "binding_plan.joint_bindings",
        MAX_JOINTS,
    )
    joint_ids: set[str] = set()
    joint_names: set[str] = set()
    joints: list[dict[str, Any]] = []
    for index, raw in enumerate(joint_values):
        path = f"binding_plan.joint_bindings[{index}]"
        item = _mapping(raw, path)
        _closed_keys(
            item,
            name=path,
            allowed={
                "id",
                "joint_role",
                "name",
                "moving_occurrence_id",
                "fixed_occurrence_id",
                "moving_interface_id",
                "fixed_interface_id",
            },
            required={
                "id",
                "joint_role",
                "name",
                "moving_occurrence_id",
                "fixed_occurrence_id",
            },
        )
        identifier = _unique_id(item["id"], name=f"{path}.id", seen=joint_ids)
        name = _text(item["name"], f"{path}.name")
        if name in joint_names:
            raise FunctionalAssemblySnapshotError(
                f"{path}.name duplicates {name!r}"
            )
        joint_names.add(name)
        moving = _text(
            item["moving_occurrence_id"], f"{path}.moving_occurrence_id"
        )
        fixed = _text(item["fixed_occurrence_id"], f"{path}.fixed_occurrence_id")
        if moving not in occurrence_ids or fixed not in occurrence_ids:
            raise FunctionalAssemblySnapshotError(
                f"{path} references an unknown moving or fixed occurrence"
            )
        if moving == fixed:
            raise FunctionalAssemblySnapshotError(
                f"{path} moving and fixed occurrences must be distinct"
            )
        normalized_joint: dict[str, Any] = {
            "id": identifier,
            "joint_role": _text(item["joint_role"], f"{path}.joint_role"),
            "name": name,
            "moving_occurrence_id": moving,
            "fixed_occurrence_id": fixed,
        }
        has_moving_interface = "moving_interface_id" in item
        has_fixed_interface = "fixed_interface_id" in item
        if has_moving_interface != has_fixed_interface:
            raise FunctionalAssemblySnapshotError(
                f"{path} must provide both moving/fixed interface ids or neither"
            )
        if has_moving_interface:
            for field in ("moving_interface_id", "fixed_interface_id"):
                interface_id = _text(item[field], f"{path}.{field}")
                if interface_id not in interface_ids:
                    raise FunctionalAssemblySnapshotError(
                        f"{path}.{field} references unknown interface "
                        f"{interface_id!r}"
                    )
                normalized_joint[field] = interface_id
        joints.append(normalized_joint)

    joint_participants = {
        item["id"]: {
            item["moving_occurrence_id"],
            item["fixed_occurrence_id"],
        }
        for item in joints
    }
    for index, landmark in enumerate(landmarks):
        selector = landmark["selector"]
        if (
            selector["kind"] == "joint_geometry_origin"
            and selector["joint_id"] not in joint_ids
        ):
            raise FunctionalAssemblySnapshotError(
                "binding_plan.landmark_bindings"
                f"[{index}].selector.joint_id references unknown joint "
                f"{selector['joint_id']!r}"
            )
        if (
            selector["kind"] == "joint_geometry_origin"
            and landmark["occurrence_id"]
            not in joint_participants[selector["joint_id"]]
        ):
            raise FunctionalAssemblySnapshotError(
                "binding_plan.landmark_bindings"
                f"[{index}] occurrence is not a participant of selector joint "
                f"{selector['joint_id']!r}"
            )

    return {
        "schema": BINDING_PLAN_SCHEMA,
        "reference_frame_bindings": reference_frames,
        "occurrence_role_bindings": occurrences,
        "landmark_bindings": landmarks,
        "interface_pair_bindings": interface_pairs,
        "joint_bindings": joints,
    }


def build_functional_assembly_snapshot_script(
    *,
    expected_document_name: str,
    expected_lineage_id: str,
    expected_version_id: str,
    binding_plan: Mapping[str, Any],
) -> str:
    """Return a read-only Fusion script for one closed functional snapshot."""

    document_name = _text(expected_document_name, "expected_document_name")
    lineage_id = _text(expected_lineage_id, "expected_lineage_id")
    version_id = _text(expected_version_id, "expected_version_id")
    normalized_plan = _normalize_binding_plan(binding_plan)
    constants = {
        "SNAPSHOT_SCHEMA": SNAPSHOT_SCHEMA,
        "EXPECTED_DOCUMENT_NAME": document_name,
        "EXPECTED_LINEAGE_ID": lineage_id,
        "EXPECTED_VERSION_ID": version_id,
        "BINDING_PLAN": normalized_plan,
    }
    encoded = "\n".join(
        f"{name} = {json.dumps(value, ensure_ascii=True, sort_keys=True)}"
        for name, value in constants.items()
    )
    return (
        "import adsk.core\n"
        "import adsk.fusion\n"
        "import itertools\n"
        "import json\n\n"
        + encoded
        + r'''

def _items(collection):
    count = getattr(collection, "count", None)
    item = getattr(collection, "item", None)
    if count is not None and not callable(count) and callable(item):
        return [item(index) for index in range(count)]
    return list(collection)

def _point(point):
    return [float(point.x), float(point.y), float(point.z)]

def _matrix(matrix):
    return [float(value) for value in matrix.asArray()]

def _box(box):
    return {
        "minimum": _point(box.minPoint),
        "maximum": _point(box.maxPoint),
    }

def _origin(matrix):
    return [
        float(matrix.getCell(0, 3)),
        float(matrix.getCell(1, 3)),
        float(matrix.getCell(2, 3)),
    ]

def _transform_point(matrix, local_point):
    return [
        sum(
            float(matrix.getCell(row, column))
            * float(local_point[column])
            for column in range(3)
        )
        + float(matrix.getCell(row, 3))
        for row in range(3)
    ]

def _entity_token(entity):
    token = getattr(entity, "entityToken", None)
    return str(token) if token else None

def _required_entity_token(entity, label):
    token = _entity_token(entity)
    if token is None:
        raise RuntimeError(label + " has no native entity token")
    return token

def _exact_entity_by_token(design, token):
    matches = design.findEntityByToken(token)
    if len(matches) != 1:
        raise RuntimeError(
            "interface or landmark entity token resolved to "
            + str(len(matches))
            + " entities"
        )
    return matches[0]

def _require_entity_owner(entity, expected_occurrence, label):
    assembly_context = getattr(entity, "assemblyContext", None)
    if (
        assembly_context is None
        or str(assembly_context.fullPathName)
        != str(expected_occurrence.fullPathName)
    ):
        raise RuntimeError(
            label + " is not native to the bound occurrence"
        )

def _exact_joint(joints_by_name, joint_id, name):
    matches = joints_by_name.get(name, [])
    if len(matches) != 1:
        raise RuntimeError(
            "joint binding "
            + joint_id
            + " expected one joint named "
            + name
            + "; found "
            + str(len(matches))
        )
    return matches[0]

def _body_rows(occurrence_id, occurrence):
    rows = []
    for index, body in enumerate(_items(occurrence.bRepBodies)):
        rows.append({
            "id": occurrence_id + "::body-" + str(index),
            "entity_token": _entity_token(body),
            "is_solid": bool(body.isSolid),
            "volume": float(body.volume),
        })
    return rows

def _occurrence_row(binding, occurrence):
    transform = getattr(occurrence, "transform2", None)
    if transform is None:
        transform = occurrence.transform
    document_reference = (
        occurrence.documentReference
        if bool(occurrence.isReferencedComponent)
        else None
    )
    source_lineage_id = (
        str(document_reference.id)
        if document_reference is not None
        else None
    )
    source_version_id = (
        str(document_reference.versionId)
        if document_reference is not None
        else None
    )
    return {
        "id": binding["id"],
        "full_path": str(occurrence.fullPathName),
        "entity_token": _entity_token(occurrence),
        "component_entity_token": _entity_token(occurrence.component),
        "source_lineage_id": source_lineage_id,
        "source_version_id": source_version_id,
        "transform": _matrix(transform),
        "grounded": bool(occurrence.isGrounded),
        "bodies": _body_rows(binding["id"], occurrence),
    }

def _bbox_selector_point(occurrence, selector):
    body_index = int(selector.get("body_index", 0))
    if body_index >= occurrence.bRepBodies.count:
        raise RuntimeError("landmark body_index is outside occurrence body inventory")
    body = occurrence.bRepBodies.item(body_index)
    box = body.boundingBox
    minimum = _point(box.minPoint)
    maximum = _point(box.maxPoint)
    center = [
        (minimum[index] + maximum[index]) * 0.5
        for index in range(3)
    ]
    if selector["kind"] == "body_bounding_box_center":
        return center
    axis_index = {"x": 0, "y": 1, "z": 2}[selector["axis"]]
    center[axis_index] = (
        minimum[axis_index]
        if selector["extreme"] == "minimum"
        else maximum[axis_index]
    )
    return center

def _entity_point(entity):
    if isinstance(entity, adsk.fusion.BRepVertex):
        return _point(entity.geometry)
    geometry = getattr(entity, "worldGeometry", None)
    if geometry is None:
        geometry = getattr(entity, "geometry", None)
    if isinstance(geometry, adsk.core.Point3D):
        return _point(geometry)
    point = getattr(entity, "pointOnFace", None)
    if isinstance(point, adsk.core.Point3D):
        return _point(point)
    raise RuntimeError("entity_token_point did not resolve to point geometry")

def _landmark_row(
    binding,
    occurrences_by_id,
    joints_by_id,
    occurrence_path_to_id,
    design,
):
    occurrence = occurrences_by_id[binding["occurrence_id"]]
    selector = binding["selector"]
    kind = selector["kind"]
    owner_token = _required_entity_token(
        occurrence,
        "landmark owner occurrence",
    )
    witness = None
    joint_id = None
    joint_side = None
    owner_local_point = None
    if kind == "occurrence_origin":
        transform = getattr(occurrence, "transform2", None)
        if transform is None:
            transform = occurrence.transform
        point = _origin(transform)
        witness = owner_token
    elif kind in (
        "body_bounding_box_center",
        "body_bounding_box_axis_extreme",
    ):
        point = _bbox_selector_point(occurrence, selector)
        body_index = int(selector.get("body_index", 0))
        witness = _required_entity_token(
            occurrence.bRepBodies.item(body_index),
            "landmark bounding-box body",
        )
    elif kind == "entity_token_point":
        entity = _exact_entity_by_token(design, selector["entity_token"])
        _require_entity_owner(
            entity,
            occurrence,
            "landmark entity-token witness",
        )
        point = _entity_point(entity)
        # Preserve the exact selector token.  Fusion may serialize a resolved
        # entity back to a different equivalent string.
        witness = selector["entity_token"]
    elif kind == "joint_geometry_origin":
        joint = joints_by_id[selector["joint_id"]]
        native_occurrence = (
            getattr(joint, "occurrenceOne", None)
            if selector["side"] == "one"
            else getattr(joint, "occurrenceTwo", None)
        )
        native_path = (
            str(native_occurrence.fullPathName)
            if native_occurrence is not None
            else None
        )
        if (
            _bound_occurrence_id(native_path, occurrence_path_to_id)
            != binding["occurrence_id"]
        ):
            raise RuntimeError(
                "joint geometry landmark side is not native to the bound "
                "occurrence"
            )
        matrix = (
            joint.geometryOneTransform
            if selector["side"] == "one"
            else joint.geometryTwoTransform
        )
        if matrix is None:
            raise RuntimeError("joint geometry transform is unavailable")
        point = _origin(matrix)
        witness = _required_entity_token(
            joint,
            "landmark joint witness",
        )
        joint_id = selector["joint_id"]
        joint_side = selector["side"]
    elif kind == "owner_local_point":
        transform = getattr(occurrence, "transform2", None)
        if transform is None:
            transform = occurrence.transform
        owner_local_point = list(selector["point"])
        point = _transform_point(transform, owner_local_point)
        witness = owner_token
    else:
        raise RuntimeError("unsupported normalized landmark selector")
    return {
        "id": binding["id"],
        "occurrence_id": binding["occurrence_id"],
        "point": point,
        "identity": {
            "selector_kind": kind,
            "source_entity_token": witness,
            "owner_occurrence_entity_token": owner_token,
            "joint_id": joint_id,
            "joint_side": joint_side,
            "owner_local_point": owner_local_point,
        },
    }

def _interface_row(
    pair_id,
    side_name,
    binding,
    design,
    expected_occurrence,
):
    faces = []
    for token in binding["entity_tokens"]:
        entity = _exact_entity_by_token(design, token)
        face = adsk.fusion.BRepFace.cast(entity)
        if face is None:
            raise RuntimeError(
                "interface binding entity must resolve to one BRepFace"
            )
        _require_entity_owner(
            face,
            expected_occurrence,
            "interface BRepFace",
        )
        faces.append(face)

    minimum = None
    maximum = None
    for face in faces:
        current = _box(face.boundingBox)
        if minimum is None:
            minimum = list(current["minimum"])
            maximum = list(current["maximum"])
        else:
            minimum = [
                min(minimum[index], current["minimum"][index])
                for index in range(3)
            ]
            maximum = [
                max(maximum[index], current["maximum"][index])
                for index in range(3)
            ]
    if minimum is None or maximum is None:
        raise RuntimeError("interface binding has no native bounds")
    native_bounds = {"minimum": minimum, "maximum": maximum}

    geometry_kind = "bounded_region"
    primary_axis = None
    secondary_axis = None
    radius = None
    axial_interval = None
    axis_origin = None
    key_point = [
        (minimum[index] + maximum[index]) * 0.5
        for index in range(3)
    ]
    cylinder = (
        adsk.core.Cylinder.cast(faces[0].geometry)
        if len(faces) == 1
        else None
    )
    if cylinder is not None:
        geometry_kind = "bounded_cylinder"
        face = faces[0]
        key_point = _point(face.pointOnFace)
        primary_axis = _point(cylinder.axis)
        radius = float(cylinder.radius)
        axis_origin = _point(cylinder.origin)
        radial = [
            key_point[index] - axis_origin[index]
            for index in range(3)
        ]
        axial_component = sum(
            radial[index] * primary_axis[index]
            for index in range(3)
        )
        radial = [
            radial[index] - axial_component * primary_axis[index]
            for index in range(3)
        ]
        radial_length = sum(value * value for value in radial) ** 0.5
        if radial_length <= 1.0e-12:
            raise RuntimeError(
                "cylindrical interface point cannot define a secondary axis"
            )
        secondary_axis = [
            value / radial_length
            for value in radial
        ]
        projections = []
        for vertex in _items(face.vertices):
            vertex_point = _point(vertex.geometry)
            projections.append(sum(
                (vertex_point[index] - axis_origin[index])
                * primary_axis[index]
                for index in range(3)
            ))
        for edge in _items(face.edges):
            evaluator = edge.evaluator
            success, start_parameter, end_parameter = (
                evaluator.getParameterExtents()
            )
            if not success:
                raise RuntimeError(
                    "could not read interface boundary parameter range"
                )
            for sample_index in range(9):
                parameter = start_parameter + (
                    end_parameter - start_parameter
                ) * sample_index / 8.0
                success, boundary_point = evaluator.getPointAtParameter(
                    parameter
                )
                if not success:
                    raise RuntimeError(
                        "could not sample interface boundary"
                    )
                boundary = _point(boundary_point)
                projections.append(sum(
                    (boundary[index] - axis_origin[index])
                    * primary_axis[index]
                    for index in range(3)
                ))
        if projections:
            axial_interval = [min(projections), max(projections)]
    if geometry_kind == "bounded_cylinder" and (
        axis_origin is None
        or primary_axis is None
        or secondary_axis is None
        or axial_interval is None
    ):
        raise RuntimeError(
            "bounded cylindrical interface geometry is incomplete"
        )
    return {
        "id": binding["id"],
        "occurrence_id": binding["occurrence_id"],
        # Fusion can re-serialize a resolved BRepFace to a different but
        # equivalent token string.  Preserve the exact version-bound selector
        # that was uniquely resolved and owner-checked above.
        "boundary_entity_tokens": list(binding["entity_tokens"]),
        "geometry_kind": geometry_kind,
        "key_point": key_point,
        "axis_origin": axis_origin,
        "primary_axis": primary_axis,
        "secondary_axis": secondary_axis,
        "radius": radius,
        "axial_interval": axial_interval,
        "native_bounds": native_bounds,
    }, faces

def _same_brep_entity(first, second):
    if first is None or second is None:
        return False
    first_context = getattr(first, "assemblyContext", None)
    second_context = getattr(second, "assemblyContext", None)
    if first_context is not None and second_context is not None:
        first_path = str(first_context.fullPathName)
        second_path = str(second_context.fullPathName)
        if first_path != second_path:
            return False
    if first == second:
        return True
    first_native = getattr(first, "nativeObject", None)
    second_native = getattr(second, "nativeObject", None)
    if first_native is not None and second_native is not None:
        if first_native == second_native:
            return True
        first_temp_id = getattr(first_native, "tempId", None)
        second_temp_id = getattr(second_native, "tempId", None)
        if (
            first_temp_id is not None
            and first_temp_id == second_temp_id
            and getattr(first_native, "body", None)
            == getattr(second_native, "body", None)
        ):
            return True
    return False

def _require_unique_interface_faces(interface_faces_by_id):
    resolved_faces = []
    for interface_id in sorted(interface_faces_by_id):
        for face in interface_faces_by_id[interface_id]:
            for prior_interface_id, prior_face in resolved_faces:
                if _same_brep_entity(face, prior_face):
                    raise RuntimeError(
                        "resolved native BRepFace is reused in interface "
                        + interface_id
                        + " and "
                        + prior_interface_id
                    )
            resolved_faces.append((interface_id, face))

def _joint_endpoint_uses_interface(
    joint_geometry,
    interface_faces,
    interface_row,
):
    if (
        interface_row["geometry_kind"] != "bounded_cylinder"
        or len(interface_faces) != 1
    ):
        return False
    interface_face = interface_faces[0]
    geometry = adsk.fusion.JointGeometry.cast(joint_geometry)
    if geometry is None:
        return False
    if (
        _same_brep_entity(geometry.entityOne, interface_face)
        or _same_brep_entity(geometry.entityTwo, interface_face)
    ):
        return True
    selected_edge = adsk.fusion.BRepEdge.cast(geometry.entityTwo)
    if selected_edge is not None:
        for edge in _items(interface_face.edges):
            if _same_brep_entity(edge, selected_edge):
                return True
    selected_face = adsk.fusion.BRepFace.cast(geometry.entityOne)
    if selected_face is not None:
        for selected in _items(selected_face.edges):
            for candidate in _items(interface_face.edges):
                if _same_brep_entity(selected, candidate):
                    return True
        frontier = [selected_face]
        visited = [selected_face]
        for _depth in range(2):
            next_frontier = []
            for current_face in frontier:
                for edge in _items(current_face.edges):
                    for adjacent in _items(edge.faces):
                        if _same_brep_entity(adjacent, interface_face):
                            return True
                        if not any(
                            _same_brep_entity(adjacent, prior)
                            for prior in visited
                        ):
                            visited.append(adjacent)
                            next_frontier.append(adjacent)
            frontier = next_frontier

    # A fillet or chamfer can separate the JointGeometry face from the
    # functional cylinder while preserving the same native endpoint and axis.
    # This is an adapter identity tolerance, not a product acceptance limit.
    tolerance = 1.0e-7
    axis = interface_row["primary_axis"]
    axis_length = sum(value * value for value in axis) ** 0.5
    if axis_length <= 1.0e-12:
        return False
    axis = [value / axis_length for value in axis]
    delta = [
        float(geometry.origin.asArray()[index])
        - interface_row["axis_origin"][index]
        for index in range(3)
    ]
    axial = sum(delta[index] * axis[index] for index in range(3))
    radial = [
        delta[index] - axial * axis[index]
        for index in range(3)
    ]
    radial_distance = sum(value * value for value in radial) ** 0.5
    joint_axis = _point(geometry.primaryAxisVector)
    joint_axis_length = sum(value * value for value in joint_axis) ** 0.5
    if joint_axis_length <= 1.0e-12:
        return False
    alignment = abs(sum(
        joint_axis[index] / joint_axis_length * axis[index]
        for index in range(3)
    ))
    lower, upper = interface_row["axial_interval"]
    return (
        radial_distance <= tolerance
        and lower - tolerance <= axial <= upper + tolerance
        and alignment >= 1.0 - tolerance
    )

def _limit_row(limit):
    return {
        "minimum_enabled": bool(limit.isMinimumValueEnabled),
        "minimum": (
            float(limit.minimumValue)
            if limit.isMinimumValueEnabled
            else None
        ),
        "maximum_enabled": bool(limit.isMaximumValueEnabled),
        "maximum": (
            float(limit.maximumValue)
            if limit.isMaximumValueEnabled
            else None
        ),
        "rest_enabled": bool(limit.isRestValueEnabled),
        "rest": (
            float(limit.restValue)
            if limit.isRestValueEnabled
            else None
        ),
    }

def _motion_row(joint):
    motion = joint.jointMotion
    row = None
    for value_name, limit_name in (
        ("rotationValue", "rotationLimits"),
        ("slideValue", "slideLimits"),
        ("pitchValue", "pitchLimits"),
        ("rollValue", "rollLimits"),
        ("yawValue", "yawLimits"),
    ):
        if hasattr(motion, value_name):
            limits = _limit_row(getattr(motion, limit_name))
            row = {
                "coordinate": float(getattr(motion, value_name)),
                **limits,
            }
            break
    if row is None:
        row = {
            "coordinate": None,
            "minimum_enabled": False,
            "minimum": None,
            "maximum_enabled": False,
            "maximum": None,
            "rest_enabled": False,
            "rest": None,
        }
    return row

def _health_state_name(value):
    states = adsk.fusion.FeatureHealthStates
    for name in (
        "HealthyFeatureHealthState",
        "WarningFeatureHealthState",
        "ErrorFeatureHealthState",
        "SuppressedFeatureHealthState",
        "RolledBackFeatureHealthState",
        "UnknownFeatureHealthState",
    ):
        candidate = getattr(states, name, None)
        if candidate is not None and value == candidate:
            return name
    return "UnrecognizedFeatureHealthState:" + str(value)

def _bound_occurrence_id(path, occurrence_path_to_id):
    if path in occurrence_path_to_id:
        return occurrence_path_to_id[path]
    if path is None:
        return None
    descendant_ids = {
        occurrence_id
        for bound_path, occurrence_id in occurrence_path_to_id.items()
        if bound_path.startswith(path + "+")
    }
    if len(descendant_ids) == 1:
        return next(iter(descendant_ids))
    return None

def _joint_row(
    binding,
    joint,
    occurrence_path_to_id,
    interface_faces_by_id,
    interface_rows_by_id,
):
    occurrence_one = getattr(joint, "occurrenceOne", None)
    occurrence_two = getattr(joint, "occurrenceTwo", None)
    path_one = str(occurrence_one.fullPathName) if occurrence_one else None
    path_two = str(occurrence_two.fullPathName) if occurrence_two else None
    moving_id = binding["moving_occurrence_id"]
    fixed_id = binding["fixed_occurrence_id"]
    occurrence_one_id = _bound_occurrence_id(
        path_one,
        occurrence_path_to_id,
    )
    occurrence_two_id = _bound_occurrence_id(
        path_two,
        occurrence_path_to_id,
    )
    participant_ids = {
        occurrence_one_id,
        occurrence_two_id,
    }
    if participant_ids != {moving_id, fixed_id}:
        raise RuntimeError(
            "joint "
            + binding["id"]
            + " participants do not match Fusion occurrenceOne/Two"
        )
    interface_one_id = None
    interface_two_id = None
    if "moving_interface_id" in binding:
        if occurrence_one_id == moving_id:
            interface_one_id = binding["moving_interface_id"]
            interface_two_id = binding["fixed_interface_id"]
        else:
            interface_one_id = binding["fixed_interface_id"]
            interface_two_id = binding["moving_interface_id"]
        if not _joint_endpoint_uses_interface(
            joint.geometryOrOriginOne,
            interface_faces_by_id[interface_one_id],
            interface_rows_by_id[interface_one_id],
        ):
            raise RuntimeError(
                "joint "
                + binding["id"]
                + " geometry one does not use the bound physical interface"
            )
        if not _joint_endpoint_uses_interface(
            joint.geometryOrOriginTwo,
            interface_faces_by_id[interface_two_id],
            interface_rows_by_id[interface_two_id],
        ):
            raise RuntimeError(
                "joint "
                + binding["id"]
                + " geometry two does not use the bound physical interface"
            )
    health_source = joint
    if not hasattr(health_source, "healthState"):
        health_source = getattr(joint, "timelineObject", None)
    health_state = (
        _health_state_name(health_source.healthState)
        if health_source is not None
        and hasattr(health_source, "healthState")
        else None
    )
    error_or_warning = (
        str(health_source.errorOrWarningMessage)
        if health_source is not None
        and hasattr(health_source, "errorOrWarningMessage")
        and health_source.errorOrWarningMessage
        else (
            ""
            if health_source is not None
            and hasattr(health_source, "errorOrWarningMessage")
            else None
        )
    )
    position_alignment = (
        float(joint.angle.value) if hasattr(joint, "angle") else None
    )
    position_offset = (
        float(joint.offset.value) if hasattr(joint, "offset") else None
    )
    row = {
        "id": binding["id"],
        "entity_token": _entity_token(joint),
        "construction_method": (
            "as_built"
            if adsk.fusion.AsBuiltJoint.cast(joint) is not None
            else "standard"
        ),
        "joint_type": str(joint.jointMotion.objectType),
        "occurrence_one_id": occurrence_one_id,
        "occurrence_two_id": occurrence_two_id,
        "occurrence_one_full_path": path_one,
        "occurrence_two_full_path": path_two,
        "interface_one_id": interface_one_id,
        "interface_two_id": interface_two_id,
        "is_valid": bool(joint.isValid),
        "is_suppressed": bool(joint.isSuppressed),
        "health_state": health_state,
        "error_or_warning": error_or_warning,
        "position_alignment": position_alignment,
        "position_offset": position_offset,
        "native_is_flipped": (
            bool(joint.isFlipped) if hasattr(joint, "isFlipped") else None
        ),
        "motion": _motion_row(joint),
    }
    return row

def _interface_pair_measurement(pair, interface_faces_by_id):
    first_id = pair["first"]["id"]
    second_id = pair["second"]["id"]
    first_faces = interface_faces_by_id[first_id]
    second_faces = interface_faces_by_id[second_id]
    distances = [
        float(
            adsk.core.Application.get()
            .measureManager.measureMinimumDistance(first_face, second_face)
            .value
        )
        for first_face, second_face in itertools.product(
            first_faces,
            second_faces,
        )
    ]
    if not distances:
        raise RuntimeError(
            "interface pair has no native face-to-face distance measurements"
        )
    return {
        "interface_pair_id": pair["id"],
        "first_interface_id": first_id,
        "second_interface_id": second_id,
        "minimum_distance": min(distances),
    }

def _pair_measurement(design, first, second):
    first_body = first["body"]
    second_body = second["body"]
    entities = adsk.core.ObjectCollection.create()
    entities.add(first_body)
    entities.add(second_body)
    interference_input = design.createInterferenceInput(entities)
    if interference_input is None:
        raise RuntimeError("Fusion could not create pair interference input")
    interference_input.areCoincidentFacesIncluded = False
    results = design.analyzeInterference(interference_input)
    volumes = []
    minimum_bound = None
    maximum_bound = None
    for index in range(results.count):
        interference_body = results.item(index).interferenceBody
        volumes.append(float(interference_body.volume))
        current = _box(interference_body.boundingBox)
        if minimum_bound is None:
            minimum_bound = list(current["minimum"])
            maximum_bound = list(current["maximum"])
        else:
            minimum_bound = [
                min(minimum_bound[axis], current["minimum"][axis])
                for axis in range(3)
            ]
            maximum_bound = [
                max(maximum_bound[axis], current["maximum"][axis])
                for axis in range(3)
            ]
    return {
        "body_a_id": first["id"],
        "body_b_id": second["id"],
        "interference_volume": sum(volumes),
        "interference_bounds": (
            {
                "minimum": minimum_bound,
                "maximum": maximum_bound,
            }
            if minimum_bound is not None
            else None
        ),
    }

def run(_context: str):
    app = adsk.core.Application.get()
    document = app.activeDocument
    if document is None:
        raise RuntimeError("Fusion has no active document")
    if document.name != EXPECTED_DOCUMENT_NAME:
        raise RuntimeError("active Fusion document name mismatch")
    data_file = document.dataFile
    if data_file is None:
        raise RuntimeError("active Fusion document has no cloud identity")
    if data_file.id != EXPECTED_LINEAGE_ID:
        raise RuntimeError("active Fusion document lineage mismatch")
    if data_file.versionId != EXPECTED_VERSION_ID:
        raise RuntimeError("active Fusion document version mismatch")
    if document.isModified:
        raise RuntimeError("functional assembly snapshot requires a clean document")

    design = adsk.fusion.Design.cast(app.activeProduct)
    if design is None:
        raise RuntimeError("active Fusion product is not a Design")
    root = design.rootComponent
    root_solid_body_count = sum(
        1 for body in _items(root.bRepBodies) if body.isSolid
    )
    if root_solid_body_count:
        raise RuntimeError(
            "root component contains a native solid body outside occurrence "
            "scope"
        )
    all_occurrences = _items(root.allOccurrences)
    occurrences_by_path = {
        str(occurrence.fullPathName): occurrence
        for occurrence in all_occurrences
    }

    occurrence_bindings = BINDING_PLAN["occurrence_role_bindings"]
    missing_paths = sorted(
        binding["full_path"]
        for binding in occurrence_bindings
        if binding["full_path"] not in occurrences_by_path
    )
    if missing_paths:
        raise RuntimeError(
            "bound occurrence path is missing: " + ", ".join(missing_paths)
        )
    bound_paths = {
        binding["full_path"] for binding in occurrence_bindings
    }
    unbound_physical_paths = sorted(
        path
        for path, occurrence in occurrences_by_path.items()
        if path not in bound_paths
        and any(body.isSolid for body in _items(occurrence.bRepBodies))
    )
    if unbound_physical_paths:
        raise RuntimeError(
            "native solid-body occurrence lacks a role binding: "
            + ", ".join(unbound_physical_paths)
        )
    occurrences_by_id = {
        binding["id"]: occurrences_by_path[binding["full_path"]]
        for binding in occurrence_bindings
    }
    occurrence_path_to_id = {
        binding["full_path"]: binding["id"]
        for binding in occurrence_bindings
    }

    all_joint_rows = [
        (joint, "standard") for joint in _items(root.allJoints)
    ] + [
        (joint, "as_built") for joint in _items(root.allAsBuiltJoints)
    ]
    joints_by_name = {}
    for joint, _construction in all_joint_rows:
        joints_by_name.setdefault(str(joint.name), []).append(joint)
    bound_joint_names = {
        binding["name"] for binding in BINDING_PLAN["joint_bindings"]
    }
    unbound_joint_names = sorted(set(joints_by_name) - bound_joint_names)
    if unbound_joint_names:
        raise RuntimeError(
            "native joint lacks a joint-role binding: "
            + ", ".join(unbound_joint_names)
        )
    joints_by_id = {
        binding["id"]: _exact_joint(
            joints_by_name,
            binding["id"],
            binding["name"],
        )
        for binding in BINDING_PLAN["joint_bindings"]
    }

    occurrence_rows = [
        _occurrence_row(binding, occurrences_by_id[binding["id"]])
        for binding in occurrence_bindings
    ]
    body_handles = []
    for occurrence_row in occurrence_rows:
        occurrence = occurrences_by_id[occurrence_row["id"]]
        for index, body_row in enumerate(occurrence_row["bodies"]):
            if body_row["is_solid"]:
                body_handles.append({
                    "id": body_row["id"],
                    "body": occurrence.bRepBodies.item(index),
                })

    interface_rows = []
    interface_faces_by_id = {}
    interface_rows_by_id = {}
    for pair in BINDING_PLAN["interface_pair_bindings"]:
        first, first_face = _interface_row(
            pair["id"],
            "first",
            pair["first"],
            design,
            occurrences_by_id[pair["first"]["occurrence_id"]],
        )
        second, second_face = _interface_row(
            pair["id"],
            "second",
            pair["second"],
            design,
            occurrences_by_id[pair["second"]["occurrence_id"]],
        )
        interface_rows.extend((first, second))
        interface_faces_by_id[first["id"]] = first_face
        interface_faces_by_id[second["id"]] = second_face
        interface_rows_by_id[first["id"]] = first
        interface_rows_by_id[second["id"]] = second

    _require_unique_interface_faces(interface_faces_by_id)
    interface_pair_measurements = [
        _interface_pair_measurement(pair, interface_faces_by_id)
        for pair in BINDING_PLAN["interface_pair_bindings"]
    ]
    joint_rows = [
        _joint_row(
            binding,
            joints_by_id[binding["id"]],
            occurrence_path_to_id,
            interface_faces_by_id,
            interface_rows_by_id,
        )
        for binding in BINDING_PLAN["joint_bindings"]
    ]
    landmark_rows = [
        _landmark_row(
            binding,
            occurrences_by_id,
            joints_by_id,
            occurrence_path_to_id,
            design,
        )
        for binding in BINDING_PLAN["landmark_bindings"]
    ]
    pair_measurements = [
        _pair_measurement(design, first, second)
        for first, second in itertools.combinations(body_handles, 2)
    ]

    if document.isModified:
        raise RuntimeError("read-only observer changed the Fusion document")
    report = {
        "schema": SNAPSHOT_SCHEMA,
        "observer": {
            "id": "fusion-mcp-proxy-functional-assembly-observer",
            "version": "1.2.0",
            "fusion_release": str(app.version),
        },
        "document": {
            "name": str(document.name),
            "lineage_id": str(data_file.id),
            "version_id": str(data_file.versionId),
            "version_number": int(data_file.versionNumber),
            "is_saved": bool(document.isSaved),
            "is_modified": bool(document.isModified),
            "is_complete": bool(data_file.isComplete),
        },
        "configuration": {
            "id": str(data_file.versionId) + "#saved",
            "kind": "saved",
            "pending_position_snapshot": bool(
                design.snapshots.hasPendingSnapshot
            ),
        },
        "coordinate_unit": "http://qudt.org/vocab/unit/CentiM",
        "root_component": {
            "id": "root-component",
            "entity_token": _entity_token(root),
            "scoped_occurrence_count": len(occurrence_rows),
            "native_occurrence_count": len(all_occurrences),
            "scoped_joint_count": len(joint_rows),
            "native_joint_count": len(all_joint_rows),
            "root_solid_body_count": root_solid_body_count,
        },
        "occurrences": occurrence_rows,
        "landmarks": landmark_rows,
        "interfaces": interface_rows,
        "interface_pair_measurements": interface_pair_measurements,
        "joints": joint_rows,
        "pair_measurements": pair_measurements,
    }
    print(json.dumps(report, sort_keys=True))
'''
    )


__all__ = [
    "BINDING_PLAN_SCHEMA",
    "SNAPSHOT_SCHEMA",
    "FunctionalAssemblySnapshotError",
    "build_functional_assembly_snapshot_script",
]
