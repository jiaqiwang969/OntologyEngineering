"""Reject interactive Fusion command dispatch before runtime activation.

``fusion_mcp_execute`` scripts are expected to be short public-API
transactions.  Interactive command dispatch crosses Fusion's event loop and
has previously crashed or hung the host.  This module performs a deliberately
small, conservative static check before the cell discovers a process, inspects
windows, acquires a lease, or opens the loopback upstream.
"""

from __future__ import annotations

import ast
from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum, auto


class UnsafeFusionScriptError(ValueError):
    """The script contains a command path that is unsafe in an MCP transaction."""


class _Kind(Enum):
    EXECUTE_TEXT_COMMAND = auto()
    COMMAND_DEFINITIONS = auto()
    COMMAND_DEFINITION = auto()
    COMMAND_DEFINITION_EXECUTE = auto()
    COMMAND_DEFINITION_TYPE = auto()


@dataclass(frozen=True)
class _Finding:
    code: str


_INTERACTIVE_TEXT_COMMAND_PREFIX = "Commands."
_MAX_ALIAS_DEPTH = 64
_MAX_STATIC_STRING_VALUES = 32
_MAX_STATIC_STRING_LENGTH = 4096
_COMMAND_DEFINITION_NAME_PARTS = (
    "commanddefinition",
    "command_definition",
    "commanddef",
    "command_def",
    "cmddefinition",
    "cmd_definition",
    "cmddef",
    "cmd_def",
)
UNTITLED_PRESERVATION_ROLE_NAME = "FUSION_MCP_UNTITLED_PRESERVATION_ROLE"
UNTITLED_PRESERVATION_SCRIPT_ROLES = frozenset(
    {"inspect", "destination-preflight", "save-as", "readback"}
)
_READ_ONLY_PRESERVATION_ROLES = frozenset(
    {"inspect", "destination-preflight", "readback"}
)
_PRESERVATION_ALLOWED_ATTRIBUTE_CALLS = frozenset(
    {
        "append",
        "casefold",
        "cast",
        "decode",
        "digest",
        "dumps",
        "encode",
        "endswith",
        "get",
        "getpid",
        "hexdigest",
        "index",
        "item",
        "itemById",
        "itemByName",
        "items",
        "join",
        "keys",
        "lower",
        "lstrip",
        "normalize",
        "replace",
        "rstrip",
        "split",
        "startswith",
        "strip",
        "uname",
        "upper",
        "values",
    }
)
_PRESERVATION_ALLOWED_NAME_CALLS = frozenset(
    {
        "Exception",
        "RuntimeError",
        "ValueError",
        "abs",
        "all",
        "any",
        "bool",
        "dict",
        "enumerate",
        "float",
        "int",
        "isinstance",
        "len",
        "list",
        "max",
        "min",
        "print",
        "range",
        "repr",
        "round",
        "set",
        "sorted",
        "str",
        "sum",
        "tuple",
        "type",
        "zip",
    }
)
_PRESERVATION_DYNAMIC_CALLS = frozenset(
    {
        "__import__",
        "compile",
        "delattr",
        "eval",
        "exec",
        "getattr",
        "setattr",
        "vars",
    }
)


def reject_unsafe_execute_script(
    tool_name: str,
    arguments: Mapping[str, object],
) -> None:
    """Raise for unsafe script calls without inspecting or activating Fusion."""
    if tool_name != "fusion_mcp_execute" or arguments.get("featureType") != "script":
        return
    payload = arguments.get("object")
    if not isinstance(payload, Mapping):
        return
    script = payload.get("script")
    if not isinstance(script, str):
        return

    try:
        tree = ast.parse(script, mode="exec")
    except (SyntaxError, ValueError) as exc:
        raise UnsafeFusionScriptError("script is not valid Python") from exc

    finding = _ScriptSafetyAnalyzer(tree).find()
    if finding is not None:
        raise UnsafeFusionScriptError(
            "forbidden interactive Fusion command path: " + finding.code
        )

    role = _declared_untitled_preservation_role(tree)
    if role is not None:
        _validate_untitled_preservation_script(tree, role)


def classify_untitled_preservation_role(
    tool_name: str,
    arguments: Mapping[str, object],
) -> str:
    """Classify one request for the runtime untitled-document gate.

    The classification is local and deterministic.  It does not claim native
    document state; the runtime guard combines it with the independently
    captured Fusion window census before any upstream request is forwarded.
    """
    if tool_name in {"fusion_mcp_electronics_read", "resources/list", "resources/read"}:
        return "read-only"
    if tool_name == "fusion_mcp_read":
        # In Fusion 2704.1.53, document/open on the read tool lists the
        # already-open documents; it does not open another document.  Actual
        # lifecycle open is fusion_mcp_execute(featureType=document).
        return "read-only"
    if tool_name == "fusion_mcp_update":
        return "mutation"
    if tool_name != "fusion_mcp_execute":
        return "unclassified"

    feature_type = arguments.get("featureType")
    payload = arguments.get("object")
    if feature_type == "document":
        operation = payload.get("operation") if isinstance(payload, Mapping) else None
        return f"document-{operation or 'unclassified'}"
    if feature_type != "script" or not isinstance(payload, Mapping):
        return "unclassified"
    script = payload.get("script")
    if not isinstance(script, str):
        return "unclassified-script"
    try:
        tree = ast.parse(script, mode="exec")
    except (SyntaxError, ValueError):
        return "unclassified-script"
    role = _declared_untitled_preservation_role(tree)
    return "unclassified-script" if role is None else f"preservation-{role}"


def _declared_untitled_preservation_role(tree: ast.Module) -> str | None:
    assignments: list[ast.AST] = []
    for node in tree.body:
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        value, targets = _assignment_parts(node)
        if value is None:
            continue
        if any(
            name == UNTITLED_PRESERVATION_ROLE_NAME
            for target in targets
            for name in _assigned_names(target)
        ):
            assignments.append(value)
    if not assignments:
        return None
    if len(assignments) != 1:
        raise UnsafeFusionScriptError(
            "untitled preservation role must be declared exactly once"
        )
    value = assignments[0]
    if not isinstance(value, ast.Constant) or not isinstance(value.value, str):
        raise UnsafeFusionScriptError(
            "untitled preservation role must be one literal string"
        )
    role = value.value
    if role not in UNTITLED_PRESERVATION_SCRIPT_ROLES:
        raise UnsafeFusionScriptError(
            "unknown untitled preservation role: " + role
        )
    return role


def _validate_untitled_preservation_script(tree: ast.Module, role: str) -> None:
    attribute_calls = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
    ]
    local_functions = {
        node.name
        for node in ast.walk(tree)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }
    name_calls = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
    ]
    dynamic_calls = sorted(
        {
            node.func.id
            for node in ast.walk(tree)
            if isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id in _PRESERVATION_DYNAMIC_CALLS
        }
    )
    attribute_writes = sorted(
        {
            node.attr
            for node in ast.walk(tree)
            if isinstance(node, ast.Attribute)
            and isinstance(node.ctx, (ast.Store, ast.Del))
        }
    )
    local_dicts = {
        target.id
        for node in ast.walk(tree)
        if isinstance(node, (ast.Assign, ast.AnnAssign))
        for value, targets in [_assignment_parts(node)]
        if isinstance(value, ast.Dict)
        for target in targets
        if isinstance(target, ast.Name)
    }
    unsafe_subscript_writes = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Subscript)
        and isinstance(node.ctx, (ast.Store, ast.Del))
        and not (isinstance(node.value, ast.Name) and node.value.id in local_dicts)
    ]
    unknown_attribute_calls = sorted(
        {
            node.func.attr
            for node in attribute_calls
            if node.func.attr not in _PRESERVATION_ALLOWED_ATTRIBUTE_CALLS
            and not (role == "save-as" and node.func.attr == "saveAs")
        }
    )
    unknown_name_calls = sorted(
        {
            node.func.id
            for node in name_calls
            if node.func.id not in _PRESERVATION_ALLOWED_NAME_CALLS
            and node.func.id not in local_functions
        }
    )
    mutation_member_references = sorted(
        {
            node.attr
            for node in ast.walk(tree)
            if isinstance(node, ast.Attribute)
            and node.attr
            in {
                "activate",
                "add",
                "close",
                "copyToComponent",
                "deleteMe",
                "doEvents",
                "execute",
                "executeTextCommand",
                "moveToComponent",
                "open",
                "remove",
                "save",
                "setOneSideExtent",
            }
        }
    )
    if dynamic_calls:
        raise UnsafeFusionScriptError(
            "untitled preservation role contains dynamic call paths: "
            + ", ".join(dynamic_calls)
        )
    if attribute_writes:
        raise UnsafeFusionScriptError(
            "untitled preservation role writes object attributes: "
            + ", ".join(attribute_writes)
        )
    if unsafe_subscript_writes:
        raise UnsafeFusionScriptError(
            "untitled preservation role writes a non-local-dict subscript"
        )
    if unknown_attribute_calls:
        raise UnsafeFusionScriptError(
            "untitled preservation role contains non-allowlisted method calls: "
            + ", ".join(unknown_attribute_calls)
        )
    if unknown_name_calls:
        raise UnsafeFusionScriptError(
            "untitled preservation role contains dynamic or non-allowlisted callees: "
            + ", ".join(unknown_name_calls)
        )
    if mutation_member_references:
        raise UnsafeFusionScriptError(
            "untitled preservation role references mutation/lifecycle members: "
            + ", ".join(mutation_member_references)
        )
    if role in _READ_ONLY_PRESERVATION_ROLES:
        return

    save_as_calls = [node for node in attribute_calls if node.func.attr == "saveAs"]
    cloud_enumeration = any(
        isinstance(node, ast.Attribute) and node.attr in {"dataFiles", "dataFolders"}
        for node in ast.walk(tree)
    )
    if len(save_as_calls) != 1:
        raise UnsafeFusionScriptError(
            "untitled preservation save-as role requires exactly one saveAs call"
        )
    save_as = save_as_calls[0]
    receiver = save_as.func.value
    folder_argument = save_as.args[1] if len(save_as.args) >= 2 else None
    exact_folder_argument = (
        isinstance(folder_argument, ast.Name) and folder_argument.id == "folder"
    ) or (
        isinstance(folder_argument, ast.Attribute)
        and folder_argument.attr == "rootFolder"
        and isinstance(folder_argument.value, ast.Name)
        and folder_argument.value.id == "project"
    )
    if not (
        isinstance(receiver, ast.Name)
        and receiver.id == "document"
        and exact_folder_argument
    ):
        raise UnsafeFusionScriptError(
            "untitled preservation save-as must call document.saveAs with the "
            "frozen folder or project.rootFolder"
        )
    if cloud_enumeration:
        raise UnsafeFusionScriptError(
            "untitled preservation save-as role cannot enumerate dataFiles/dataFolders"
        )
    post_save_attributes = sorted(
        {
            node.attr
            for node in ast.walk(tree)
            if isinstance(node, ast.Attribute)
            and getattr(node, "lineno", 0) > save_as.lineno
            and node.attr != "dumps"
        }
    )
    post_save_name_calls = sorted(
        {
            node.func.id
            for node in name_calls
            if node.lineno > save_as.lineno
            and node.func.id
            not in {"RuntimeError", "ValueError", "bool", "print", "str"}
        }
    )
    if post_save_attributes or post_save_name_calls:
        details = post_save_attributes + post_save_name_calls
        raise UnsafeFusionScriptError(
            "untitled preservation save-as performs non-output work after saveAs: "
            + ", ".join(details)
        )


class _ScriptSafetyAnalyzer:
    def __init__(self, tree: ast.Module) -> None:
        self.tree = tree
        self.kinds: dict[str, set[_Kind]] = {}
        self.string_assignments: dict[str, list[ast.AST]] = {}

    def find(self) -> _Finding | None:
        self._resolve_aliases()
        for node in ast.walk(self.tree):
            if not isinstance(node, ast.Call):
                continue
            finding = self._inspect_call(node)
            if finding is not None:
                return finding
        return None

    def _resolve_aliases(self) -> None:
        assignments = [
            node
            for node in ast.walk(self.tree)
            if isinstance(node, (ast.Assign, ast.AnnAssign, ast.NamedExpr))
        ]
        for node in assignments:
            value, targets = _assignment_parts(node)
            if value is None:
                continue
            for target in targets:
                for name in _assigned_names(target):
                    self.string_assignments.setdefault(name, []).append(value)
        for node in ast.walk(self.tree):
            if not isinstance(node, ast.ImportFrom):
                continue
            if node.module not in {"adsk.core", "adsk"}:
                continue
            for alias in node.names:
                if alias.name == "CommandDefinition":
                    self.kinds.setdefault(alias.asname or alias.name, set()).add(
                        _Kind.COMMAND_DEFINITION_TYPE
                    )

        # Alias chains in generated scripts are short.  A fixed point makes
        # assignment order irrelevant and conservatively unions branch values.
        changed = True
        while changed:
            changed = False
            for node in assignments:
                value, targets = _assignment_parts(node)
                if value is None:
                    continue
                value_kinds = self._expression_kinds(value)
                for target in targets:
                    for name in _assigned_names(target):
                        if value_kinds:
                            known_kinds = self.kinds.setdefault(name, set())
                            previous = len(known_kinds)
                            known_kinds.update(value_kinds)
                            changed |= len(known_kinds) != previous

    def _inspect_call(self, node: ast.Call) -> _Finding | None:
        function_kinds = self._expression_kinds(node.func)
        if _Kind.EXECUTE_TEXT_COMMAND in function_kinds:
            command = _first_call_argument(node)
            values = self._constant_strings(command) if command is not None else set()
            if not values:
                return _Finding("dynamic-executeTextCommand")
            if any(_is_interactive_text_command(value) for value in values):
                return _Finding("interactive-executeTextCommand")

        if _Kind.COMMAND_DEFINITION_EXECUTE in function_kinds:
            return _Finding("CommandDefinition.execute")

        if isinstance(node.func, ast.Attribute) and node.func.attr == "execute":
            receiver_kinds = self._expression_kinds(node.func.value)
            if (
                _Kind.COMMAND_DEFINITION in receiver_kinds
                or _Kind.COMMAND_DEFINITION_TYPE in receiver_kinds
            ):
                return _Finding("CommandDefinition.execute")
        return None

    def _expression_kinds(self, node: ast.AST) -> set[_Kind]:
        if isinstance(node, ast.Name):
            kinds = set(self.kinds.get(node.id, ()))
            if _looks_like_command_definition_name(node.id):
                kinds.add(_Kind.COMMAND_DEFINITION)
            return kinds

        if isinstance(node, ast.Attribute):
            if node.attr == "executeTextCommand":
                return {_Kind.EXECUTE_TEXT_COMMAND}
            if node.attr == "commandDefinitions":
                return {_Kind.COMMAND_DEFINITIONS}
            if node.attr == "CommandDefinition":
                return {_Kind.COMMAND_DEFINITION_TYPE}
            if node.attr == "execute":
                owner = self._expression_kinds(node.value)
                if (
                    _Kind.COMMAND_DEFINITION in owner
                    or _Kind.COMMAND_DEFINITION_TYPE in owner
                ):
                    return {_Kind.COMMAND_DEFINITION_EXECUTE}
            return set()

        if isinstance(node, ast.Call):
            getattr_kind = self._getattr_kind(node)
            if getattr_kind:
                return getattr_kind
            if isinstance(node.func, ast.Attribute) and node.func.attr in {
                "itemById",
                "item",
            }:
                owner = self._expression_kinds(node.func.value)
                if _Kind.COMMAND_DEFINITIONS in owner:
                    return {_Kind.COMMAND_DEFINITION}
            return set()

        if isinstance(node, (ast.IfExp, ast.BoolOp)):
            values = (
                [node.body, node.orelse]
                if isinstance(node, ast.IfExp)
                else list(node.values)
            )
            return set().union(*(self._expression_kinds(value) for value in values))

        return set()

    def _getattr_kind(self, node: ast.Call) -> set[_Kind]:
        if not isinstance(node.func, ast.Name) or node.func.id != "getattr":
            return set()
        if len(node.args) < 2:
            return set()
        attribute_names = self._constant_strings(node.args[1])
        if len(attribute_names) != 1:
            return set()
        attribute_name = next(iter(attribute_names))
        owner = self._expression_kinds(node.args[0])
        if attribute_name == "executeTextCommand":
            return {_Kind.EXECUTE_TEXT_COMMAND}
        if attribute_name == "commandDefinitions":
            return {_Kind.COMMAND_DEFINITIONS}
        if attribute_name == "execute" and (
            _Kind.COMMAND_DEFINITION in owner or _Kind.COMMAND_DEFINITION_TYPE in owner
        ):
            return {_Kind.COMMAND_DEFINITION_EXECUTE}
        return set()

    def _constant_strings(
        self,
        node: ast.AST,
        *,
        seen_names: frozenset[str] = frozenset(),
        depth: int = 0,
    ) -> set[str]:
        if depth > _MAX_ALIAS_DEPTH:
            return set()
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            if len(node.value) <= _MAX_STATIC_STRING_LENGTH:
                return {node.value}
            return set()
        if isinstance(node, ast.Name):
            if node.id in seen_names:
                return set()
            assignments = self.string_assignments.get(node.id, ())
            if not assignments:
                return set()
            resolved: set[str] = set()
            next_seen = seen_names | {node.id}
            for assignment in assignments:
                values = self._constant_strings(
                    assignment,
                    seen_names=next_seen,
                    depth=depth + 1,
                )
                # Any unresolved reaching definition makes the command dynamic.
                if not values:
                    return set()
                resolved.update(values)
                if len(resolved) > _MAX_STATIC_STRING_VALUES:
                    return set()
            return resolved
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            left = self._constant_strings(
                node.left,
                seen_names=seen_names,
                depth=depth + 1,
            )
            right = self._constant_strings(
                node.right,
                seen_names=seen_names,
                depth=depth + 1,
            )
            return _bounded_concatenation(left, right)
        if isinstance(node, ast.JoinedStr):
            pieces: list[set[str]] = []
            for value in node.values:
                if isinstance(value, ast.Constant) and isinstance(value.value, str):
                    pieces.append({value.value})
                elif isinstance(value, ast.FormattedValue):
                    pieces.append(
                        self._constant_strings(
                            value.value,
                            seen_names=seen_names,
                            depth=depth + 1,
                        )
                    )
                else:
                    return set()
            combined = {""}
            for piece in pieces:
                if not piece:
                    return set()
                combined = _bounded_concatenation(combined, piece)
                if not combined:
                    return set()
            return combined
        return set()


def _assignment_parts(
    node: ast.Assign | ast.AnnAssign | ast.NamedExpr,
) -> tuple[ast.AST | None, list[ast.AST]]:
    if isinstance(node, ast.Assign):
        return node.value, list(node.targets)
    if isinstance(node, ast.AnnAssign):
        return node.value, [node.target]
    return node.value, [node.target]


def _assigned_names(node: ast.AST) -> list[str]:
    if isinstance(node, ast.Name):
        return [node.id]
    if isinstance(node, (ast.Tuple, ast.List)):
        return [name for item in node.elts for name in _assigned_names(item)]
    return []


def _first_call_argument(node: ast.Call) -> ast.AST | None:
    if node.args:
        return node.args[0]
    for keyword in node.keywords:
        if keyword.arg in {"command", "text", "value"}:
            return keyword.value
    return None


def _bounded_concatenation(left: set[str], right: set[str]) -> set[str]:
    if not left or not right:
        return set()
    if len(left) * len(right) > _MAX_STATIC_STRING_VALUES:
        return set()
    combined = {prefix + suffix for prefix in left for suffix in right}
    if len(combined) > _MAX_STATIC_STRING_VALUES:
        return set()
    if any(len(value) > _MAX_STATIC_STRING_LENGTH for value in combined):
        return set()
    return combined


def _is_interactive_text_command(value: str) -> bool:
    return value.lstrip().startswith(_INTERACTIVE_TEXT_COMMAND_PREFIX)


def _looks_like_command_definition_name(name: str) -> bool:
    folded = name.casefold()
    return any(part in folded for part in _COMMAND_DEFINITION_NAME_PARTS)
