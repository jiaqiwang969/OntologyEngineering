"""Mouse-free McMaster-Carr STEP acquisition through Fusion's embedded CDP page.

This module deliberately separates two trust boundaries:

* the Node recipe performs semantic DOM operations in the one exact embedded
  ``www.mcmaster.com`` page and returns a bounded JSON observation; and
* this Python wrapper validates that observation before downloading a STEP to
  a no-overwrite atomic destination and hashing the artifact.

Neither a process exit code nor a captured URL is accepted as sufficient
evidence on its own.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Callable, Mapping
from pathlib import Path
from typing import Any, BinaryIO


REPORT_SCHEMA = "cad-agent.mcmaster-embedded-cdp-report.v1"
DOWNLOAD_REPORT_SCHEMA = "cad-agent.mcmaster-embedded-step-download.v1"
ACQUISITION_REPORT_SCHEMA = "cad-agent.mcmaster-embedded-step-acquisition.v1"
RECIPE_ID = "McMasterEmbeddedCDPExactStepAcquisition"
LOOPBACK_HOST = "127.0.0.1"
MCMASTER_HOST = "www.mcmaster.com"
STEP_FORMAT = "3-D STEP"
STEP_SUFFIXES = frozenset({".step", ".stp"})
DEFAULT_TIMEOUT_SECONDS = 30.0
MAX_REPORT_BYTES = 64 * 1024
MAX_STEP_BYTES = 250 * 1024 * 1024

SELECTORS = {
    "search_input": "#SrchEntryWebPart_InpBox",
    "search_submit": "input[type=submit][title=search]",
    "cad_format_combobox": (
        "button[role=combobox][aria-label='Select CAD file type']"
    ),
    "cad_format_option": "li[role=option]",
    "download_action": (
        "button,a,input[type=button],input[type=submit],[role=button]"
    ),
}

OBSERVATION_KEYS = frozenset(
    {
        "search_dispatched",
        "exact_part_number_confirmed",
        "exact_format_selected",
        "exact_download_clicked",
    }
)
CAPTURE_EVENTS = frozenset(
    {
        "Network.requestWillBeSent",
        "Network.responseReceived",
        "Page.downloadWillBegin",
    }
)


class McMasterEmbeddedCDPError(RuntimeError):
    """The embedded acquisition recipe or one of its safety gates failed."""


def normalize_part_number(value: str) -> str:
    """Return a normalized exact McMaster part number without claiming existence."""

    if not isinstance(value, str):
        raise McMasterEmbeddedCDPError("part_number must be a string")
    normalized = "".join(value.split()).upper()
    if not re.fullmatch(r"(?=.*[A-Z])(?=.*[0-9])[A-Z0-9]{3,24}", normalized):
        raise McMasterEmbeddedCDPError(
            "part_number must contain 3-24 ASCII letters/digits and include both"
        )
    return normalized


def validate_cad_format(value: str) -> str:
    """Accept only threaded 3-D STEP; variants such as 'no threads' fail closed."""

    if value != STEP_FORMAT:
        raise McMasterEmbeddedCDPError(
            f"cad_format must be exactly {STEP_FORMAT!r}"
        )
    return value


def validate_loopback_port(value: int) -> int:
    """Validate the port used with the fixed 127.0.0.1 DevTools host."""

    if isinstance(value, bool) or not isinstance(value, int):
        raise McMasterEmbeddedCDPError("devtools_port must be an integer")
    if value < 1 or value > 65_535:
        raise McMasterEmbeddedCDPError(
            "devtools_port must be between 1 and 65535"
        )
    return value


def _validate_timeout(value: float) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise McMasterEmbeddedCDPError("timeout_seconds must be numeric")
    timeout = float(value)
    if not 1.0 <= timeout <= 120.0:
        raise McMasterEmbeddedCDPError(
            "timeout_seconds must be between 1 and 120"
        )
    return timeout


def _strict_unquote_path(path: str) -> str:
    if re.search(r"%(?![0-9A-Fa-f]{2})", path):
        raise McMasterEmbeddedCDPError(
            "download URL contains malformed percent encoding"
        )
    try:
        decoded = urllib.parse.unquote(path, encoding="utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        raise McMasterEmbeddedCDPError(
            "download URL path is not valid UTF-8"
        ) from exc
    if not decoded.startswith("/") or "\\" in decoded:
        raise McMasterEmbeddedCDPError("download URL has an unsafe path")
    if any(ord(character) < 0x20 or ord(character) == 0x7F for character in decoded):
        raise McMasterEmbeddedCDPError(
            "download URL path contains a control character"
        )
    return decoded


def validate_download_url(
    value: str, *, expected_part_number: str | None = None
) -> str:
    """Validate and return a sanitized, credential-free McMaster STEP URL."""

    if not isinstance(value, str) or not value or value != value.strip():
        raise McMasterEmbeddedCDPError("download URL must be a non-empty string")
    if "\\" in value or any(
        ord(character) < 0x20 or ord(character) == 0x7F for character in value
    ):
        raise McMasterEmbeddedCDPError(
            "download URL contains a backslash or control character"
        )
    try:
        parsed = urllib.parse.urlsplit(value)
        username = parsed.username
        password = parsed.password
        hostname = parsed.hostname
        port = parsed.port
    except ValueError as exc:
        raise McMasterEmbeddedCDPError("download URL is malformed") from exc
    if parsed.scheme != "https":
        raise McMasterEmbeddedCDPError("download URL must use HTTPS")
    if hostname != MCMASTER_HOST:
        raise McMasterEmbeddedCDPError(
            "download URL host must be exactly www.mcmaster.com"
        )
    if username is not None or password is not None:
        raise McMasterEmbeddedCDPError("download URL must not contain credentials")
    if port is not None or parsed.netloc != MCMASTER_HOST:
        raise McMasterEmbeddedCDPError(
            "download URL must use the exact default McMaster HTTPS origin"
        )
    if parsed.query or parsed.fragment:
        raise McMasterEmbeddedCDPError(
            "download URL must not contain a query or fragment"
        )
    decoded_path = _strict_unquote_path(parsed.path)
    if Path(decoded_path).suffix.lower() not in STEP_SUFFIXES:
        raise McMasterEmbeddedCDPError(
            "download URL path must end in .step or .stp"
        )
    if expected_part_number is not None:
        normalized_part = normalize_part_number(expected_part_number)
        if normalized_part not in decoded_path.upper():
            raise McMasterEmbeddedCDPError(
                "download URL path does not contain the requested exact part number"
            )
    # The validated URL contains no data beyond the fixed origin and path.
    return urllib.parse.urlunsplit(("https", MCMASTER_HOST, parsed.path, "", ""))


def _require_object(value: Any, location: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise McMasterEmbeddedCDPError(f"{location} must be a JSON object")
    return value


def _require_exact_keys(
    value: Mapping[str, Any], expected: set[str] | frozenset[str], location: str
) -> None:
    actual = set(value)
    if actual != set(expected):
        missing = sorted(set(expected) - actual)
        extra = sorted(actual - set(expected))
        raise McMasterEmbeddedCDPError(
            f"{location} has invalid fields (missing={missing}, extra={extra})"
        )


def validate_recipe_report(
    value: Any,
    *,
    expected_part_number: str,
    expected_cad_format: str,
    expected_devtools_port: int,
) -> dict[str, Any]:
    """Fail closed unless the Node result proves every semantic postcondition."""

    normalized_part = normalize_part_number(expected_part_number)
    cad_format = validate_cad_format(expected_cad_format)
    port = validate_loopback_port(expected_devtools_port)
    report = _require_object(value, "report")
    _require_exact_keys(
        report,
        {
            "schema",
            "recipe_id",
            "status",
            "part_number",
            "cad_format",
            "devtools",
            "page",
            "selectors",
            "observations",
            "download",
        },
        "report",
    )
    if report["schema"] != REPORT_SCHEMA:
        raise McMasterEmbeddedCDPError("unexpected recipe report schema")
    if report["recipe_id"] != RECIPE_ID:
        raise McMasterEmbeddedCDPError("unexpected recipe identifier")
    if report["status"] != "succeeded":
        raise McMasterEmbeddedCDPError("recipe did not report success")
    if report["part_number"] != normalized_part:
        raise McMasterEmbeddedCDPError("recipe part number does not match request")
    if report["cad_format"] != cad_format:
        raise McMasterEmbeddedCDPError("recipe CAD format does not match request")

    devtools = _require_object(report["devtools"], "report.devtools")
    _require_exact_keys(
        devtools, {"host", "port", "matching_page_count"}, "report.devtools"
    )
    if (
        isinstance(devtools["port"], bool)
        or not isinstance(devtools["port"], int)
        or isinstance(devtools["matching_page_count"], bool)
        or not isinstance(devtools["matching_page_count"], int)
    ):
        raise McMasterEmbeddedCDPError(
            "recipe DevTools port and page count must be integers"
        )
    if devtools != {
        "host": LOOPBACK_HOST,
        "port": port,
        "matching_page_count": 1,
    }:
        raise McMasterEmbeddedCDPError(
            "recipe did not prove one exact loopback McMaster page"
        )

    page = _require_object(report["page"], "report.page")
    _require_exact_keys(page, {"scheme", "host"}, "report.page")
    if page != {"scheme": "https", "host": MCMASTER_HOST}:
        raise McMasterEmbeddedCDPError(
            "recipe page is not the exact McMaster HTTPS origin"
        )

    selectors = _require_object(report["selectors"], "report.selectors")
    if selectors != SELECTORS:
        raise McMasterEmbeddedCDPError(
            "recipe selectors differ from the validated semantic recipe"
        )

    observations = _require_object(
        report["observations"], "report.observations"
    )
    _require_exact_keys(observations, OBSERVATION_KEYS, "report.observations")
    if any(observations[key] is not True for key in OBSERVATION_KEYS):
        raise McMasterEmbeddedCDPError(
            "recipe did not prove every required DOM postcondition"
        )

    download = _require_object(report["download"], "report.download")
    _require_exact_keys(download, {"url", "capture_event"}, "report.download")
    if (
        not isinstance(download["capture_event"], str)
        or download["capture_event"] not in CAPTURE_EVENTS
    ):
        raise McMasterEmbeddedCDPError("unsupported download capture event")
    sanitized_url = validate_download_url(
        download["url"], expected_part_number=normalized_part
    )

    # Rebuild rather than return the caller's mutable/unbounded object.
    return {
        "schema": REPORT_SCHEMA,
        "recipe_id": RECIPE_ID,
        "status": "succeeded",
        "part_number": normalized_part,
        "cad_format": cad_format,
        "devtools": {
            "host": LOOPBACK_HOST,
            "port": port,
            "matching_page_count": 1,
        },
        "page": {"scheme": "https", "host": MCMASTER_HOST},
        "selectors": dict(SELECTORS),
        "observations": {key: True for key in sorted(OBSERVATION_KEYS)},
        "download": {
            "url": sanitized_url,
            "capture_event": download["capture_event"],
        },
    }


def _bounded_process_detail(value: Any) -> str:
    text = value if isinstance(value, str) else ""
    text = re.sub(r"(?:https?|wss?)://\S+", "<redacted-url>", text)
    return text.strip()[:1_000]


def run_embedded_cdp_recipe(
    *,
    part_number: str,
    devtools_port: int,
    cad_format: str = STEP_FORMAT,
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
    node_executable: str = "node",
    runner: Callable[..., subprocess.CompletedProcess[str]] | None = None,
) -> dict[str, Any]:
    """Run the semantic CDP recipe as an argument-vector subprocess, never a shell."""

    normalized_part = normalize_part_number(part_number)
    validated_format = validate_cad_format(cad_format)
    port = validate_loopback_port(devtools_port)
    timeout = _validate_timeout(timeout_seconds)
    if not isinstance(node_executable, str) or not node_executable or "\x00" in node_executable:
        raise McMasterEmbeddedCDPError(
            "node_executable must be a non-empty string without NUL"
        )
    script_path = Path(__file__).with_suffix(".mjs").resolve(strict=True)
    command = [
        node_executable,
        str(script_path),
        "--part-number",
        normalized_part,
        "--format",
        validated_format,
        "--port",
        str(port),
        "--timeout-ms",
        str(int(timeout * 1_000)),
    ]
    process_runner = runner or subprocess.run
    try:
        completed = process_runner(
            command,
            shell=False,
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=timeout + 5.0,
        )
    except subprocess.TimeoutExpired as exc:
        raise McMasterEmbeddedCDPError("embedded CDP recipe timed out") from exc
    except OSError as exc:
        raise McMasterEmbeddedCDPError(
            "could not start the embedded CDP recipe process"
        ) from exc

    if completed.returncode != 0:
        detail = _bounded_process_detail(completed.stderr)
        suffix = f": {detail}" if detail else ""
        raise McMasterEmbeddedCDPError(
            f"embedded CDP recipe exited with code {completed.returncode}{suffix}"
        )
    stdout = completed.stdout
    if not isinstance(stdout, str):
        raise McMasterEmbeddedCDPError("embedded CDP recipe stdout was not text")
    if len(stdout.encode("utf-8")) > MAX_REPORT_BYTES:
        raise McMasterEmbeddedCDPError("embedded CDP recipe report is oversized")
    try:
        raw_report = json.loads(stdout)
    except json.JSONDecodeError as exc:
        raise McMasterEmbeddedCDPError(
            "embedded CDP recipe did not return one JSON report"
        ) from exc
    return validate_recipe_report(
        raw_report,
        expected_part_number=normalized_part,
        expected_cad_format=validated_format,
        expected_devtools_port=port,
    )


def _destination_path(destination_value: str | os.PathLike[str]) -> Path:
    destination = Path(destination_value).expanduser()
    if not destination.is_absolute():
        raise McMasterEmbeddedCDPError("destination must be an absolute path")
    if destination.suffix.lower() not in STEP_SUFFIXES:
        raise McMasterEmbeddedCDPError(
            "destination must end in .step or .stp"
        )
    try:
        parent = destination.parent.resolve(strict=True)
    except FileNotFoundError as exc:
        raise McMasterEmbeddedCDPError(
            "destination parent directory does not exist"
        ) from exc
    if not parent.is_dir():
        raise McMasterEmbeddedCDPError(
            "destination parent path is not a directory"
        )
    resolved = parent / destination.name
    if os.path.lexists(resolved):
        raise McMasterEmbeddedCDPError(
            "destination already exists; overwrite is refused"
        )
    return resolved


def _response_status(response: Any) -> int:
    status = getattr(response, "status", None)
    if status is None and hasattr(response, "getcode"):
        status = response.getcode()
    if isinstance(status, bool) or not isinstance(status, int):
        raise McMasterEmbeddedCDPError("download response has no valid HTTP status")
    if status < 200 or status >= 300:
        raise McMasterEmbeddedCDPError(
            f"McMaster STEP download returned HTTP {status}"
        )
    return status


def _content_length(headers: Any) -> int | None:
    raw = headers.get("Content-Length")
    if raw is None:
        return None
    if not isinstance(raw, (str, int)) or isinstance(raw, bool):
        raise McMasterEmbeddedCDPError("invalid download Content-Length")
    text = str(raw)
    if not re.fullmatch(r"[0-9]+", text):
        raise McMasterEmbeddedCDPError("invalid download Content-Length")
    value = int(text)
    if value > MAX_STEP_BYTES:
        raise McMasterEmbeddedCDPError(
            f"STEP download exceeds {MAX_STEP_BYTES} bytes"
        )
    return value


def _read_response_chunks(response: BinaryIO):
    while True:
        chunk = response.read(1024 * 1024)
        if not chunk:
            return
        if not isinstance(chunk, bytes):
            raise McMasterEmbeddedCDPError(
                "STEP download returned a non-binary response"
            )
        yield chunk


def download_captured_step(
    *,
    download_url: str,
    destination: str | os.PathLike[str],
    expected_part_number: str,
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
    opener: Callable[..., Any] | None = None,
) -> dict[str, Any]:
    """Download, inspect, hash, and atomically publish one exact-part STEP.

    ``os.link`` publishes the fully written same-directory temporary inode.  It
    is an atomic create-if-absent operation, so a concurrent destination can
    never be overwritten.
    """

    normalized_part = normalize_part_number(expected_part_number)
    sanitized_url = validate_download_url(
        download_url, expected_part_number=normalized_part
    )
    target = _destination_path(destination)
    timeout = _validate_timeout(timeout_seconds)
    request = urllib.request.Request(
        sanitized_url,
        headers={
            "Accept": "model/step, application/step, application/octet-stream",
            "User-Agent": "cad-agent-mcmaster-embedded-cdp/1.0",
        },
        method="GET",
    )
    open_url = opener or urllib.request.urlopen
    temporary_path: Path | None = None
    try:
        try:
            response_context = open_url(request, timeout=timeout)
        except (urllib.error.URLError, TimeoutError) as exc:
            raise McMasterEmbeddedCDPError(
                "McMaster STEP download request failed"
            ) from exc
        with response_context as response:
            _response_status(response)
            response_headers = getattr(response, "headers", {})
            if not callable(getattr(response_headers, "get", None)):
                raise McMasterEmbeddedCDPError(
                    "download response headers are invalid"
                )
            expected_length = _content_length(response_headers)
            final_url_value = (
                response.geturl() if hasattr(response, "geturl") else sanitized_url
            )
            final_url = validate_download_url(
                final_url_value, expected_part_number=normalized_part
            )
            digest = hashlib.sha256()
            size = 0
            header_prefix = bytearray()
            with tempfile.NamedTemporaryFile(
                mode="wb",
                prefix=f".{target.name}.",
                suffix=".partial",
                dir=target.parent,
                delete=False,
            ) as temporary:
                temporary_path = Path(temporary.name)
                for chunk in _read_response_chunks(response):
                    if size + len(chunk) > MAX_STEP_BYTES:
                        raise McMasterEmbeddedCDPError(
                            f"STEP download exceeds {MAX_STEP_BYTES} bytes"
                        )
                    if len(header_prefix) < 4_096:
                        remaining = 4_096 - len(header_prefix)
                        header_prefix.extend(chunk[:remaining])
                    temporary.write(chunk)
                    digest.update(chunk)
                    size += len(chunk)
                temporary.flush()
                os.fsync(temporary.fileno())
            if size == 0:
                raise McMasterEmbeddedCDPError("STEP download is empty")
            if expected_length is not None and size != expected_length:
                raise McMasterEmbeddedCDPError(
                    "STEP download size does not match Content-Length"
                )
            normalized_header = bytes(header_prefix).lstrip(
                b"\xef\xbb\xbf \t\r\n"
            )
            if not normalized_header.startswith(b"ISO-10303-21;"):
                raise McMasterEmbeddedCDPError(
                    "downloaded file does not have an ISO-10303-21 STEP header"
                )
            try:
                os.link(temporary_path, target, follow_symlinks=False)
            except FileExistsError as exc:
                raise McMasterEmbeddedCDPError(
                    "destination appeared concurrently; overwrite is refused"
                ) from exc
            try:
                temporary_path.unlink()
                temporary_path = None
            except OSError:
                # The fully validated target is already published. A failed
                # temporary-name cleanup must not turn that successful atomic
                # publication into an ambiguous failure.
                pass
            return {
                "schema": DOWNLOAD_REPORT_SCHEMA,
                "part_number": normalized_part,
                "cad_format": STEP_FORMAT,
                "source_url": final_url,
                "path": str(target),
                "filename": target.name,
                "size_bytes": size,
                "sha256": digest.hexdigest(),
                "step_header_valid": True,
                "overwrite_performed": False,
                "atomic_publish": "same-directory-hardlink-create-if-absent",
            }
    except McMasterEmbeddedCDPError:
        raise
    except OSError as exc:
        raise McMasterEmbeddedCDPError(
            "could not write the McMaster STEP artifact"
        ) from exc
    finally:
        if temporary_path is not None:
            try:
                temporary_path.unlink(missing_ok=True)
            except OSError:
                pass


def acquire_exact_step(
    *,
    part_number: str,
    devtools_port: int,
    destination: str | os.PathLike[str],
    cad_format: str = STEP_FORMAT,
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
    node_executable: str = "node",
    runner: Callable[..., subprocess.CompletedProcess[str]] | None = None,
    opener: Callable[..., Any] | None = None,
) -> dict[str, Any]:
    """Run CDP acquisition and download the resulting exact STEP artifact."""

    recipe_report = run_embedded_cdp_recipe(
        part_number=part_number,
        devtools_port=devtools_port,
        cad_format=cad_format,
        timeout_seconds=timeout_seconds,
        node_executable=node_executable,
        runner=runner,
    )
    artifact = download_captured_step(
        download_url=recipe_report["download"]["url"],
        destination=destination,
        expected_part_number=recipe_report["part_number"],
        timeout_seconds=timeout_seconds,
        opener=opener,
    )
    return {
        "schema": ACQUISITION_REPORT_SCHEMA,
        "status": "succeeded",
        "part_number": recipe_report["part_number"],
        "cad_format": STEP_FORMAT,
        "recipe_report": recipe_report,
        "artifact": artifact,
    }


__all__ = [
    "ACQUISITION_REPORT_SCHEMA",
    "DOWNLOAD_REPORT_SCHEMA",
    "LOOPBACK_HOST",
    "MAX_STEP_BYTES",
    "MCMASTER_HOST",
    "McMasterEmbeddedCDPError",
    "REPORT_SCHEMA",
    "RECIPE_ID",
    "SELECTORS",
    "STEP_FORMAT",
    "acquire_exact_step",
    "download_captured_step",
    "normalize_part_number",
    "run_embedded_cdp_recipe",
    "validate_cad_format",
    "validate_download_url",
    "validate_loopback_port",
    "validate_recipe_report",
]
