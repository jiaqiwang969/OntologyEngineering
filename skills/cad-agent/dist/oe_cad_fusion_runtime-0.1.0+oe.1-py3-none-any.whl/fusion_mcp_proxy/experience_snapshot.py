"""Build bounded, read-only Fusion scripts for grounded experience capture."""

from __future__ import annotations

import json
from pathlib import Path


MAX_DOCUMENT_NAME_LENGTH = 255
MAX_IDENTITY_LENGTH = 2048
MAX_OCCURRENCE_PATH_LENGTH = 4096
MAX_OCCURRENCE_PATHS = 128
MAX_COLLECTION_ITEMS = 500
MAX_OUTPUT_PATH_LENGTH = 4096


class ExperienceSnapshotError(ValueError):
    """Raised when a snapshot request exceeds the closed candidate boundary."""


def _bounded_string(value: object, name: str, maximum: int) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ExperienceSnapshotError(f"{name} must be a non-empty string")
    if len(value) > maximum:
        raise ExperienceSnapshotError(f"{name} exceeds {maximum} characters")
    if any(ord(character) < 32 for character in value):
        raise ExperienceSnapshotError(f"{name} contains a control character")
    return value


def _optional_bounded_string(
    value: object | None, name: str, maximum: int
) -> str | None:
    if value is None:
        return None
    return _bounded_string(value, name, maximum)


def _bounded_count(value: object, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ExperienceSnapshotError(f"{name} must be an integer")
    if value < 1 or value > MAX_COLLECTION_ITEMS:
        raise ExperienceSnapshotError(
            f"{name} must be between 1 and {MAX_COLLECTION_ITEMS}"
        )
    return value


def _bounded_occurrence_paths(value: object | None) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ExperienceSnapshotError("occurrence_paths must be an array")
    if len(value) > MAX_OCCURRENCE_PATHS:
        raise ExperienceSnapshotError(
            f"occurrence_paths exceeds {MAX_OCCURRENCE_PATHS} items"
        )
    paths = [
        _bounded_string(
            item,
            f"occurrence_paths[{index}]",
            MAX_OCCURRENCE_PATH_LENGTH,
        )
        for index, item in enumerate(value)
    ]
    if len(set(paths)) != len(paths):
        raise ExperienceSnapshotError("occurrence_paths must be unique")
    return paths


def _bounded_output_path(value: object | None) -> str | None:
    if value is None:
        return None
    path = _bounded_string(value, "output_path", MAX_OUTPUT_PATH_LENGTH)
    if not Path(path).is_absolute():
        raise ExperienceSnapshotError("output_path must be absolute")
    return path


def build_experience_snapshot_script(
    expected_document_name: str,
    expected_lineage_id: str | None = None,
    expected_version_id: str | None = None,
    occurrence_paths: list[str] | None = None,
    max_occurrences: int = 100,
    max_joints: int = 100,
    output_path: str | None = None,
) -> str:
    """Return a Fusion script that reads a bounded document state."""

    document_name = _bounded_string(
        expected_document_name,
        "expected_document_name",
        MAX_DOCUMENT_NAME_LENGTH,
    )
    lineage_id = _optional_bounded_string(
        expected_lineage_id,
        "expected_lineage_id",
        MAX_IDENTITY_LENGTH,
    )
    version_id = _optional_bounded_string(
        expected_version_id,
        "expected_version_id",
        MAX_IDENTITY_LENGTH,
    )
    paths = _bounded_occurrence_paths(occurrence_paths)
    occurrence_limit = _bounded_count(max_occurrences, "max_occurrences")
    joint_limit = _bounded_count(max_joints, "max_joints")
    destination = _bounded_output_path(output_path)
    constants = {
        "EXPECTED_DOCUMENT_NAME": document_name,
        "EXPECTED_LINEAGE_ID": lineage_id or "",
        "EXPECTED_VERSION_ID": version_id or "",
        "REQUESTED_OCCURRENCE_PATHS": paths,
        "MAX_OCCURRENCES": occurrence_limit,
        "MAX_JOINTS": joint_limit,
        "OUTPUT_PATH": destination or "",
    }
    encoded = "\n".join(
        f"{name} = {json.dumps(value)}" for name, value in constants.items()
    )
    return (
        "import adsk.core\n"
        "import adsk.fusion\n"
        "import json\n\n"
        "import os\n\n"
        + encoded
        + r'''

def _items(collection):
    return [collection.item(index) for index in range(collection.count)]

def _safe_attr(value, name, default=None):
    try:
        result = getattr(value, name)
        return result if result is not None else default
    except Exception:
        return default

def _entity_token(entity):
    token = _safe_attr(entity, "entityToken")
    return str(token) if token else None

def _matrix_values(matrix):
    if matrix is None:
        return None
    try:
        return [float(value) for value in matrix.asArray()]
    except Exception:
        return None

def _point_values(point):
    if point is None:
        return None
    return [float(point.x), float(point.y), float(point.z)]

def _bounding_box(entity):
    box = _safe_attr(entity, "boundingBox")
    if box is None:
        return None
    return {
        "minimum_cm": _point_values(_safe_attr(box, "minPoint")),
        "maximum_cm": _point_values(_safe_attr(box, "maxPoint")),
    }

def _occurrence_path(occurrence):
    if occurrence is None:
        return None
    path = _safe_attr(occurrence, "fullPathName")
    return str(path) if path else None

def _body_snapshot(body):
    volume = _safe_attr(body, "volume")
    return {
        "name": str(_safe_attr(body, "name", "")),
        "entity_token": _entity_token(body),
        "is_solid": bool(_safe_attr(body, "isSolid", False)),
        "volume_cm3": float(volume) if volume is not None else None,
        "bounding_box": _bounding_box(body),
    }

def _occurrence_snapshot(occurrence):
    component = occurrence.component
    matrix = _safe_attr(occurrence, "transform2")
    if matrix is None:
        matrix = _safe_attr(occurrence, "transform")
    bodies = _items(occurrence.bRepBodies)
    return {
        "occurrence_path": occurrence.fullPathName,
        "occurrence_name": occurrence.name,
        "occurrence_entity_token": _entity_token(occurrence),
        "component_name": component.name,
        "component_entity_token": _entity_token(component),
        "is_grounded": bool(_safe_attr(occurrence, "isGrounded", False)),
        "is_visible": bool(_safe_attr(occurrence, "isLightBulbOn", False)),
        "transform_row_major": _matrix_values(matrix),
        "body_count": len(bodies),
        "bodies": [_body_snapshot(body) for body in bodies],
        "bounding_box": _bounding_box(occurrence),
    }

def _limit_snapshot(limit):
    if limit is None:
        return None
    fields = (
        "isMinimumValueEnabled",
        "minimumValue",
        "isMaximumValueEnabled",
        "maximumValue",
        "isRestValueEnabled",
        "restValue",
    )
    result = {}
    for field in fields:
        value = _safe_attr(limit, field)
        if value is not None:
            result[field] = value
    return result or None

def _joint_motion_snapshot(joint):
    motion = _safe_attr(joint, "jointMotion")
    if motion is None:
        return None
    result = {
        "object_type": str(_safe_attr(motion, "objectType", "")),
        "joint_type": _safe_attr(motion, "jointType"),
    }
    for field in (
        "rotationValue",
        "slideValue",
        "pitchValue",
        "rollValue",
        "yawValue",
    ):
        value = _safe_attr(motion, field)
        if value is not None:
            result[field] = float(value)
    for field in (
        "rotationLimits",
        "slideLimits",
        "pitchLimits",
        "rollLimits",
        "yawLimits",
    ):
        value = _limit_snapshot(_safe_attr(motion, field))
        if value is not None:
            result[field] = value
    return result

def _joint_snapshot(joint, construction_method):
    return {
        "name": str(_safe_attr(joint, "name", "")),
        "entity_token": _entity_token(joint),
        "object_type": str(_safe_attr(joint, "objectType", "")),
        "construction_method": construction_method,
        "occurrence_one": _occurrence_path(_safe_attr(joint, "occurrenceOne")),
        "occurrence_two": _occurrence_path(_safe_attr(joint, "occurrenceTwo")),
        "is_suppressed": bool(_safe_attr(joint, "isSuppressed", False)),
        "is_visible": bool(_safe_attr(joint, "isLightBulbOn", False)),
        "motion": _joint_motion_snapshot(joint),
    }

def run(_context):
    app = adsk.core.Application.get()
    document = app.activeDocument
    if document is None:
        raise RuntimeError("Fusion has no active document")
    if document.name != EXPECTED_DOCUMENT_NAME:
        raise RuntimeError(
            "active Fusion document mismatch: expected "
            + EXPECTED_DOCUMENT_NAME
            + ", actual "
            + document.name
        )

    data_file = document.dataFile
    lineage_id = data_file.id if data_file is not None else None
    version_id = data_file.versionId if data_file is not None else None
    if EXPECTED_LINEAGE_ID and lineage_id != EXPECTED_LINEAGE_ID:
        raise RuntimeError("active Fusion document lineage mismatch")
    if EXPECTED_VERSION_ID and version_id != EXPECTED_VERSION_ID:
        raise RuntimeError("active Fusion document version mismatch")

    design = adsk.fusion.Design.cast(app.activeProduct)
    if design is None:
        raise RuntimeError("active Fusion product is not a Design")
    root = design.rootComponent

    all_occurrences = _items(root.allOccurrences)
    by_path = {occurrence.fullPathName: occurrence for occurrence in all_occurrences}
    requested = list(REQUESTED_OCCURRENCE_PATHS)
    if requested:
        missing = sorted(set(requested).difference(by_path))
        if missing:
            raise RuntimeError(
                "requested occurrence path is missing: " + ", ".join(missing)
            )
        selected_occurrences = [by_path[path] for path in requested]
        snapshot_scope = "requested_occurrences"
    else:
        selected_occurrences = all_occurrences
        snapshot_scope = "all_occurrences"
    if len(selected_occurrences) > MAX_OCCURRENCES:
        raise RuntimeError(
            "occurrence snapshot exceeds declared maximum: "
            + str(len(selected_occurrences))
            + " > "
            + str(MAX_OCCURRENCES)
        )

    standard_joints = _items(root.joints)
    as_built_joints = _items(root.asBuiltJoints)
    total_joint_count = len(standard_joints) + len(as_built_joints)
    if total_joint_count > MAX_JOINTS:
        raise RuntimeError(
            "joint snapshot exceeds declared maximum: "
            + str(total_joint_count)
            + " > "
            + str(MAX_JOINTS)
        )
    joints = [
        _joint_snapshot(joint, "standard")
        for joint in standard_joints
    ] + [
        _joint_snapshot(joint, "as_built")
        for joint in as_built_joints
    ]

    timeline = _safe_attr(design, "timeline")
    units_manager = _safe_attr(design, "unitsManager")
    report = {
        "schema": "fusion-mcp.experience-snapshot.v1",
        "snapshot_scope": snapshot_scope,
        "document": {
            "name": document.name,
            "lineage_id": lineage_id,
            "version_id": version_id,
            "is_saved": bool(document.isSaved),
            "is_modified": bool(document.isModified),
        },
        "design": {
            "design_type": _safe_attr(design, "designType"),
            "default_length_units": (
                str(_safe_attr(units_manager, "defaultLengthUnits", ""))
                if units_manager is not None
                else None
            ),
            "timeline_count": (
                int(timeline.count) if timeline is not None else None
            ),
            "root_component": {
                "name": root.name,
                "entity_token": _entity_token(root),
            },
        },
        "cardinality": {
            "root_occurrence_count": int(root.occurrences.count),
            "all_occurrence_count": int(root.allOccurrences.count),
            "captured_occurrence_count": len(selected_occurrences),
            "standard_joint_count": len(standard_joints),
            "as_built_joint_count": len(as_built_joints),
        },
        "occurrences": [
            _occurrence_snapshot(occurrence)
            for occurrence in selected_occurrences
        ],
        "joints": joints,
        "requested_occurrence_paths": requested,
        "limitations": [
            "The snapshot observes the current Fusion object model only.",
            "It does not prove that a preceding tool caused the observed state.",
            "It does not enumerate mating faces, edges, feature dependencies, interference, clearance, rebuild, persistence, or continuous motion coverage.",
            "Only root-component standard and as-built joint collections are reported.",
            "Engineering validity remains Unknown until named checks are bound.",
        ],
    }
    rendered = json.dumps(report, sort_keys=True)
    if OUTPUT_PATH:
        temporary_path = OUTPUT_PATH + ".tmp"
        with open(temporary_path, "w", encoding="utf-8") as stream:
            stream.write(rendered)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_path, OUTPUT_PATH)
    print(rendered)
'''
    )
