"""External incident collection and health-only recovery for Fusion MCP cells.

This module deliberately lives outside the normal Fusion MCP request path.  Its
incident collector never sends a Fusion tool call.  Its recovery gate sends
only one exact bounded document read to a fresh PID; neither path closes/saves
a document or sends an MCP session DELETE.  Its responsibilities are narrow:

* freeze a PID/start-token-bound retirement marker and optional host evidence in
  an atomically published, owner-only incident bundle; and
* allow exactly one ``initialize`` + ``tools/list`` + bounded ``document`` read
  acceptance probe against a *different* Fusion process after a clean
  shallow-window preflight.

The successful gate is health evidence only.  It does not authorize document
open, modeling, save, close, or any other Fusion mutation.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import secrets
import stat
import time
import uuid
from collections.abc import Awaitable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Protocol

import anyio

from .acceptance_client import (
    DEFAULT_REQUIRED_TOOLS,
    PLAN_SCHEMA,
    run_acceptance,
)
from .health_attestation import (
    HEALTH_ARGUMENTS,
    HEALTH_ARGUMENTS_SHA256,
    HEALTH_CHALLENGE_SCHEMA,
    HEALTH_RECEIPT_SCHEMA,
    HEALTH_TOOL,
    HealthAttestationError,
    canonical_bytes as health_canonical_bytes,
    create_owner_only_json,
    read_owner_only_json,
    sha256_hex,
)
from .runtime_guard import (
    FUSION_EXECUTABLE_SUFFIX,
    FusionProcessIdentity,
    MacOSFusionProcessProbe,
    PeekabooWindowProbe,
    _KNOWN_WHITE_AUXILIARY_CAPTURE_SIZES,
    _KNOWN_WHITE_AUXILIARY_SIZE,
    _KNOWN_WHITE_AUXILIARY_TITLE,
    is_darwin_process_start_token,
)
from .tool_catalog import AUDITED_FUSION_RELEASES, SCHEMA_SHA256

INCIDENT_SCHEMA = "fusion-mcp.external-incident.v1"
HEALTH_GATE_SCHEMA = "fusion-mcp.health-only-recovery-gate.v1"
HEALTH_ATTEMPT_SCHEMA = "fusion-mcp.health-only-attempt.v1"
SHALLOW_CENSUS_SCHEMA = "fusion-mcp.shallow-window-census.v1"
UNKNOWN = "UNKNOWN"

_RETIREMENT_SCHEMA = "fusion-mcp.retirement.v2"
# Historical runtimes emitted quarantine markers.  They remain accepted as
# incident evidence, but are terminal exactly like retirement markers; they
# never authorize a same-PID health probe.
_QUARANTINE_SCHEMA = "fusion-mcp.quarantine.v1"
_INCIDENT_MARKER_SCHEMAS = (_RETIREMENT_SCHEMA, _QUARANTINE_SCHEMA)
_INFLIGHT_SCHEMA = "fusion-mcp.in-flight.v2"
_MAX_MARKER_BYTES = 2_000_000
_MAX_CENSUS_BYTES = 1_000_000
_MAX_APP_LOG_BYTES = 64 * 1024 * 1024
_MAX_APP_LOGS = 8
_MAX_WINDOWS = 128
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_HEALTH_CALL_ID = "health-document-read"
_HEALTH_CALL_TOOL = HEALTH_TOOL
_HEALTH_CALL_ARGUMENTS = HEALTH_ARGUMENTS


def _normalize_known_nonblocking_auxiliary(
    raw: Mapping[str, Any],
    *,
    titles: Sequence[str],
    reported_blocking: Sequence[str],
) -> dict[str, Any] | None:
    evidence = raw.get("known_nonblocking_auxiliary")
    if evidence is None:
        return None
    if not isinstance(evidence, Mapping):
        raise FusionRecoveryControlError(
            "known nonblocking auxiliary evidence is invalid"
        )
    if titles.count(_KNOWN_WHITE_AUXILIARY_TITLE) != 1:
        raise FusionRecoveryControlError(
            "known nonblocking auxiliary evidence has no unique matching title"
        )
    if reported_blocking:
        raise FusionRecoveryControlError(
            "reported blocking windows cannot be overridden by auxiliary evidence"
        )
    if raw.get("permission_source") not in {"local", "bridge"}:
        raise FusionRecoveryControlError(
            "known nonblocking auxiliary proof has no trusted permission source"
        )
    expected_bridge_verified = raw.get("permission_source") == "bridge"
    if raw.get("bridge_verified") is not expected_bridge_verified:
        raise FusionRecoveryControlError(
            "known nonblocking auxiliary proof has inconsistent bridge evidence"
        )
    if not any(
        title != _KNOWN_WHITE_AUXILIARY_TITLE
        and "autodesk fusion" in title.casefold()
        and not PeekabooWindowProbe._is_blocking_title(title)
        for title in titles
    ):
        raise FusionRecoveryControlError(
            "known nonblocking auxiliary proof has no independent Fusion window"
        )
    classification_raw = evidence.get("classification")
    expected_stable_census_count = (
        2
        if classification_raw == "known-nonblocking-uniform-white-auxiliary"
        else 3
    )
    if (
        classification_raw
        not in {
            "known-nonblocking-uniform-white-auxiliary",
            "known-nonblocking-uniform-blank-auxiliary",
        }
        or evidence.get("title") != _KNOWN_WHITE_AUXILIARY_TITLE
        or not isinstance(evidence.get("stable_census_count"), int)
        or isinstance(evidence.get("stable_census_count"), bool)
        or evidence.get("stable_census_count") != expected_stable_census_count
        or evidence.get("screenshot_command_success") is not True
    ):
        raise FusionRecoveryControlError(
            "known nonblocking auxiliary proof contract is incomplete"
        )

    window_id = evidence.get("window_id")
    if not isinstance(window_id, int) or isinstance(window_id, bool) or window_id <= 0:
        raise FusionRecoveryControlError(
            "known nonblocking auxiliary window identity is invalid"
        )
    bounds_raw = evidence.get("bounds")
    if not isinstance(bounds_raw, (list, tuple)) or len(bounds_raw) != 4:
        raise FusionRecoveryControlError(
            "known nonblocking auxiliary bounds are invalid"
        )
    bounds: list[float] = []
    for value in bounds_raw:
        if (
            not isinstance(value, (int, float))
            or isinstance(value, bool)
            or not math.isfinite(float(value))
        ):
            raise FusionRecoveryControlError(
                "known nonblocking auxiliary bounds are invalid"
            )
        bounds.append(float(value))
    if tuple(bounds[2:]) != _KNOWN_WHITE_AUXILIARY_SIZE:
        raise FusionRecoveryControlError(
            "known nonblocking auxiliary bounds are invalid"
        )

    screenshot = evidence.get("screenshot")
    if not isinstance(screenshot, Mapping):
        raise FusionRecoveryControlError(
            "known nonblocking auxiliary screenshot proof is invalid"
        )
    digest = screenshot.get("sha256")
    width = screenshot.get("width")
    height = screenshot.get("height")
    if (
        not isinstance(digest, str)
        or _SHA256_RE.fullmatch(digest) is None
        or not isinstance(width, int)
        or isinstance(width, bool)
        or not isinstance(height, int)
        or isinstance(height, bool)
        or width < 64
        or height < 64
        or width * height > 8_000_000
        or (width, height) not in _KNOWN_WHITE_AUXILIARY_CAPTURE_SIZES
    ):
        raise FusionRecoveryControlError(
            "known nonblocking auxiliary screenshot identity is invalid"
        )

    classification = evidence["classification"]
    surface_kind = screenshot.get("surface_kind")
    if classification == "known-nonblocking-uniform-white-auxiliary":
        if surface_kind not in {None, "opaque-near-white"}:
            raise FusionRecoveryControlError(
                "known nonblocking auxiliary screenshot surface is invalid"
            )
        surface_kind = "opaque-near-white"
    elif surface_kind not in {"opaque-near-white", "fully-transparent"}:
        raise FusionRecoveryControlError(
            "known nonblocking auxiliary screenshot surface is invalid"
        )

    thresholds = {
        "minimum_rgb_mean": (0.0, 255.0),
        "maximum_rgb_standard_deviation": (0.0, 255.0),
        "near_white_fraction": (0.0, 1.0),
        "opaque_fraction": (0.0, 1.0),
    }
    if classification == "known-nonblocking-uniform-blank-auxiliary":
        thresholds["transparent_fraction"] = (0.0, 1.0)
    normalized_screenshot: dict[str, Any] = {
        "sha256": digest,
        "width": width,
        "height": height,
        "surface_kind": surface_kind,
    }
    for field, (minimum, maximum) in thresholds.items():
        value = screenshot.get(field)
        if (
            not isinstance(value, (int, float))
            or isinstance(value, bool)
            or not math.isfinite(float(value))
            or (minimum is not None and float(value) < minimum)
            or (maximum is not None and float(value) > maximum)
        ):
            raise FusionRecoveryControlError(
                "known nonblocking auxiliary screenshot thresholds are invalid"
            )
        normalized_screenshot[field] = float(value)

    if surface_kind == "opaque-near-white":
        if (
            normalized_screenshot["minimum_rgb_mean"] < 250.0
            or normalized_screenshot["maximum_rgb_standard_deviation"] > 8.0
            or normalized_screenshot["near_white_fraction"] != 1.0
            or normalized_screenshot["opaque_fraction"] != 1.0
            or (
                "transparent_fraction" in normalized_screenshot
                and normalized_screenshot["transparent_fraction"] != 0.0
            )
        ):
            raise FusionRecoveryControlError(
                "known nonblocking auxiliary opaque-white proof is invalid"
            )
    elif (
        normalized_screenshot["transparent_fraction"] != 1.0
        or normalized_screenshot["opaque_fraction"] != 0.0
    ):
        raise FusionRecoveryControlError(
            "known nonblocking auxiliary transparent proof is invalid"
        )

    normalized_primary_canvas: dict[str, Any] | None = None
    primary_canvas = evidence.get("primary_canvas")
    if classification == "known-nonblocking-uniform-blank-auxiliary":
        if not isinstance(primary_canvas, Mapping):
            raise FusionRecoveryControlError(
                "known nonblocking auxiliary primary-canvas proof is invalid"
            )
        primary_title = primary_canvas.get("title")
        primary_window_id = primary_canvas.get("window_id")
        primary_bounds_raw = primary_canvas.get("bounds")
        if (
            not isinstance(primary_title, str)
            or titles.count(primary_title) != 1
            or not isinstance(primary_window_id, int)
            or isinstance(primary_window_id, bool)
            or primary_window_id <= 0
            or primary_window_id == window_id
            or not isinstance(primary_bounds_raw, (list, tuple))
            or len(primary_bounds_raw) != 4
            or not isinstance(primary_canvas.get("stable_census_count"), int)
            or isinstance(primary_canvas.get("stable_census_count"), bool)
            or primary_canvas.get("stable_census_count") != 3
        ):
            raise FusionRecoveryControlError(
                "known nonblocking auxiliary primary-canvas proof is invalid"
            )
        primary_bounds: list[float] = []
        for value in primary_bounds_raw:
            if (
                not isinstance(value, (int, float))
                or isinstance(value, bool)
                or not math.isfinite(float(value))
            ):
                raise FusionRecoveryControlError(
                    "known nonblocking auxiliary primary-canvas proof is invalid"
                )
            primary_bounds.append(float(value))
        if not PeekabooWindowProbe._is_primary_fusion_window(
            {
                "title": primary_title,
                "windowID": primary_window_id,
                "bounds": [primary_bounds[:2], primary_bounds[2:]],
                "isMinimized": False,
            }
        ):
            raise FusionRecoveryControlError(
                "known nonblocking auxiliary primary-canvas proof is invalid"
            )
        normalized_primary_canvas = {
            "title": primary_title,
            "window_id": primary_window_id,
            "bounds": primary_bounds,
            "stable_census_count": 3,
        }

    return {
        "classification": classification,
        "title": evidence["title"],
        "window_id": window_id,
        "bounds": bounds,
        "stable_census_count": expected_stable_census_count,
        "screenshot_command_success": True,
        "screenshot": normalized_screenshot,
        "primary_canvas": normalized_primary_canvas,
    }


class FusionRecoveryControlError(RuntimeError):
    """An external incident or recovery safety contract was not satisfied."""


class ProcessProbe(Protocol):
    def discover(self, *, deadline: float | None = None) -> FusionProcessIdentity: ...


class WindowProbe(Protocol):
    def verify(
        self,
        identity: FusionProcessIdentity,
        *,
        require_clean_start: bool,
        deadline: float | None = None,
    ) -> dict[str, Any]: ...


class AcceptanceRunner(Protocol):
    def __call__(
        self,
        plan: object,
        command_argv: Sequence[str],
        *,
        timeout_seconds: float,
        cwd: Path | None,
        max_response_bytes: int,
        max_schema_bytes: int,
        stderr_tail_chars: int,
    ) -> Awaitable[dict[str, Any]]: ...


@dataclass(frozen=True)
class IncidentBundle:
    path: Path
    manifest: dict[str, Any]


def _canonical_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")


def _sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _absolute(path: Path) -> Path:
    return Path(os.path.abspath(path.expanduser()))


def _safe_error(exc: BaseException) -> dict[str, str]:
    message = " ".join(str(exc).split())
    return {
        "type": type(exc).__name__,
        "message": (message or type(exc).__name__)[:1000],
    }


def _fsync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _require_owner_directory(path: Path, *, create: bool) -> Path:
    resolved = _absolute(path)
    if create:
        resolved.mkdir(mode=0o700, parents=True, exist_ok=True)
    try:
        metadata = resolved.lstat()
    except OSError as exc:
        raise FusionRecoveryControlError("owner-only directory is unavailable") from exc
    if (
        not stat.S_ISDIR(metadata.st_mode)
        or metadata.st_uid != os.geteuid()
        or stat.S_IMODE(metadata.st_mode) != 0o700
    ):
        raise FusionRecoveryControlError(
            "incident/recovery directory must be an owner-held mode 0700 directory"
        )
    return resolved


def _read_regular_file(
    path: Path,
    *,
    maximum_bytes: int,
    require_owner_only: bool,
) -> tuple[bytes, os.stat_result]:
    resolved = _absolute(path)
    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(resolved, flags)
    except OSError as exc:
        raise FusionRecoveryControlError(
            "evidence file cannot be opened safely"
        ) from exc
    try:
        metadata = os.fstat(descriptor)
        if (
            not stat.S_ISREG(metadata.st_mode)
            or metadata.st_uid != os.geteuid()
            or metadata.st_nlink != 1
        ):
            raise FusionRecoveryControlError(
                "evidence must be a single-link regular file owned by this user"
            )
        if require_owner_only and stat.S_IMODE(metadata.st_mode) != 0o600:
            raise FusionRecoveryControlError(
                "Fusion runtime marker must be owner-only mode 0600"
            )
        if metadata.st_size < 0 or metadata.st_size > maximum_bytes:
            raise FusionRecoveryControlError("evidence file exceeds its size bound")
        chunks: list[bytes] = []
        remaining = metadata.st_size
        while remaining:
            chunk = os.read(descriptor, min(1 << 20, remaining))
            if not chunk:
                raise FusionRecoveryControlError(
                    "evidence file changed while it was being frozen"
                )
            chunks.append(chunk)
            remaining -= len(chunk)
        after = os.fstat(descriptor)
        if require_owner_only and (
            metadata.st_dev != after.st_dev
            or metadata.st_ino != after.st_ino
            or metadata.st_size != after.st_size
            or metadata.st_mtime_ns != after.st_mtime_ns
        ):
            raise FusionRecoveryControlError(
                "Fusion runtime marker changed while it was being frozen"
            )
        return b"".join(chunks), metadata
    finally:
        os.close(descriptor)


def _load_json_file(
    path: Path,
    *,
    maximum_bytes: int,
    require_owner_only: bool,
) -> tuple[dict[str, Any], bytes]:
    raw, _ = _read_regular_file(
        path,
        maximum_bytes=maximum_bytes,
        require_owner_only=require_owner_only,
    )
    try:
        payload = json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise FusionRecoveryControlError("evidence JSON is invalid") from exc
    if not isinstance(payload, dict):
        raise FusionRecoveryControlError("evidence JSON must be an object")
    return payload, raw


def _write_new_file(path: Path, payload: bytes) -> None:
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    descriptor = os.open(path, flags, 0o600)
    try:
        os.fchmod(descriptor, 0o600)
        view = memoryview(payload)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise OSError("evidence write made no progress")
            view = view[written:]
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _atomic_write_json(path: Path, payload: Mapping[str, Any]) -> None:
    target = _absolute(path)
    parent = _require_owner_directory(target.parent, create=True)
    if target.is_symlink():
        raise FusionRecoveryControlError("recovery report path must not be a symlink")
    if target.exists():
        metadata = target.lstat()
        if (
            not stat.S_ISREG(metadata.st_mode)
            or metadata.st_uid != os.geteuid()
            or metadata.st_nlink != 1
            or stat.S_IMODE(metadata.st_mode) != 0o600
        ):
            raise FusionRecoveryControlError(
                "existing recovery report must be an owner-held mode 0600 file"
            )
    temporary = parent / f".{target.name}.tmp-{os.getpid()}-{uuid.uuid4().hex}"
    encoded = (
        json.dumps(dict(payload), ensure_ascii=False, indent=2, sort_keys=True).encode(
            "utf-8"
        )
        + b"\n"
    )
    try:
        _write_new_file(temporary, encoded)
        os.replace(temporary, target)
        _fsync_directory(parent)
    finally:
        temporary.unlink(missing_ok=True)


def _bounded_text(value: object, *, maximum: int = 500) -> str:
    text = str(value or "").strip()
    return text[:maximum]


def _require_positive_pid(value: object) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise FusionRecoveryControlError("Fusion PID must be a positive integer")
    return value


def _validate_marker(
    payload: Mapping[str, Any],
    *,
    expected_schema: str | tuple[str, ...],
    expected_pid: int | None = None,
    expected_start: str | None = None,
    expected_start_token: str | None = None,
) -> tuple[int, str, str]:
    accepted = (
        (expected_schema,) if isinstance(expected_schema, str) else expected_schema
    )
    if payload.get("schema") not in accepted:
        raise FusionRecoveryControlError(
            "Fusion runtime marker schema must be one of " + ", ".join(accepted)
        )
    pid = _require_positive_pid(payload.get("fusion_pid"))
    start_time = _bounded_text(payload.get("fusion_start_time"), maximum=300)
    if not start_time:
        raise FusionRecoveryControlError("Fusion runtime marker has no start time")
    if expected_pid is not None and pid != expected_pid:
        raise FusionRecoveryControlError("in-flight and retirement PID do not match")
    if expected_start is not None and start_time != expected_start:
        raise FusionRecoveryControlError(
            "in-flight and retirement process start time do not match"
        )
    raw_start_token = payload.get("fusion_start_token")
    start_token = (
        raw_start_token if is_darwin_process_start_token(raw_start_token) else UNKNOWN
    )
    if raw_start_token is not None and start_token == UNKNOWN:
        raise FusionRecoveryControlError(
            "Fusion runtime marker process start token is invalid"
        )
    if expected_start_token is not None and start_token != expected_start_token:
        raise FusionRecoveryControlError(
            "in-flight and retirement process start tokens do not match"
        )
    arguments_sha256 = payload.get("arguments_sha256", UNKNOWN)
    if arguments_sha256 != UNKNOWN and (
        not isinstance(arguments_sha256, str)
        or _SHA256_RE.fullmatch(arguments_sha256) is None
    ):
        raise FusionRecoveryControlError("runtime marker request hash is invalid")
    return pid, start_time, start_token


def _normalize_window_census(
    raw: Mapping[str, Any],
    *,
    expected_pid: int,
    allow_guard_proven_auxiliary: bool = False,
) -> dict[str, Any]:
    pid = raw.get("fusion_pid", raw.get("pid"))
    if _require_positive_pid(pid) != expected_pid:
        raise FusionRecoveryControlError(
            "shallow window census does not match the bound Fusion PID"
        )
    scope = raw.get("scope", raw.get("census_scope"))
    if scope != "shallow-top-level-windows":
        raise FusionRecoveryControlError(
            "window evidence must be a shallow top-level census"
        )

    titles_raw = raw.get("window_titles")
    if titles_raw is None and isinstance(raw.get("windows"), list):
        titles_raw = [
            row.get("title", "") if isinstance(row, Mapping) else ""
            for row in raw["windows"]
        ]
    if not isinstance(titles_raw, list) or len(titles_raw) > _MAX_WINDOWS:
        raise FusionRecoveryControlError(
            "window title inventory is invalid or unbounded"
        )
    titles = [_bounded_text(value) for value in titles_raw]
    blocking_raw = raw.get("blocking_titles", [])
    if not isinstance(blocking_raw, list) or len(blocking_raw) > _MAX_WINDOWS:
        raise FusionRecoveryControlError("blocking window inventory is invalid")
    reported_blocking = [_bounded_text(value) for value in blocking_raw]
    known_nonblocking_auxiliary = (
        _normalize_known_nonblocking_auxiliary(
            raw,
            titles=titles,
            reported_blocking=reported_blocking,
        )
        if allow_guard_proven_auxiliary
        else None
    )
    derived_blocking = [
        title
        for title in titles
        if PeekabooWindowProbe._is_blocking_title(title)
        and not (
            title == _KNOWN_WHITE_AUXILIARY_TITLE
            and known_nonblocking_auxiliary is not None
        )
    ]
    blocking = list(dict.fromkeys([*reported_blocking, *derived_blocking]))
    modified = raw.get("modified_document_count", UNKNOWN)
    if modified != UNKNOWN and (
        not isinstance(modified, int) or isinstance(modified, bool) or modified < 0
    ):
        raise FusionRecoveryControlError("modified-document count is invalid")
    derived_modified = sum(
        1
        for title in titles
        if (
            (separator := title.casefold().find(" - autodesk fusion")) >= 0
            and "*" in title[:separator]
        )
    )
    if modified == UNKNOWN:
        modified = derived_modified
    elif modified != derived_modified:
        raise FusionRecoveryControlError(
            "modified-document count disagrees with the title inventory"
        )
    reported_count = raw.get("window_count", len(titles))
    if (
        not isinstance(reported_count, int)
        or isinstance(reported_count, bool)
        or reported_count != len(titles)
    ):
        raise FusionRecoveryControlError("window count does not match its inventory")
    return {
        "schema": SHALLOW_CENSUS_SCHEMA,
        "fusion_pid": expected_pid,
        "scope": "shallow-top-level-windows",
        "observed_at_unix": raw.get("observed_at_unix", UNKNOWN),
        "permission_source": _bounded_text(
            raw.get("permission_source", UNKNOWN), maximum=100
        ),
        "window_count": len(titles),
        "window_titles": titles,
        "blocking_titles": blocking,
        "known_nonblocking_auxiliary": known_nonblocking_auxiliary,
        "modified_document_count": modified,
    }


def _classify_incident(reason: str) -> tuple[str, str]:
    lowered = reason.casefold()
    if "timeout" in lowered or "deadline" in lowered:
        return "mcp_timeout", "McpRetryAfterTimeoutOrHiddenModal"
    if any(
        token in lowered
        for token in (
            "brokenpipe",
            "broken pipe",
            "response delivery",
            "stdio input closed",
            "transport",
        )
    ):
        return "mcp_transport_failure", UNKNOWN
    if any(
        token in lowered
        for token in (
            "cancel scope",
            "taskgroup",
            "task group",
            "protocol",
            "initialize",
        )
    ):
        return "mcp_transport_failure", UNKNOWN
    if "cancelled" in lowered or "sigkill" in lowered or "forced" in lowered:
        return "forced_termination", UNKNOWN
    if "listener" in lowered or "process" in lowered or "pid" in lowered:
        return "process_exit_or_listener_transition", UNKNOWN
    return "runtime_failure", UNKNOWN


def _copy_app_log_snapshot(
    source: Path,
    destination: Path,
    *,
    maximum_bytes: int,
) -> dict[str, Any]:
    resolved = _absolute(source)
    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        source_descriptor = os.open(resolved, flags)
    except OSError as exc:
        raise FusionRecoveryControlError(
            "AppLog candidate cannot be opened safely"
        ) from exc
    try:
        before = os.fstat(source_descriptor)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_uid != os.geteuid()
            or before.st_nlink != 1
        ):
            raise FusionRecoveryControlError(
                "AppLog candidate must be a single-link regular file owned by this user"
            )
        if before.st_size < 0 or before.st_size > maximum_bytes:
            raise FusionRecoveryControlError("AppLog candidate exceeds its size bound")

        destination_flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        if hasattr(os, "O_NOFOLLOW"):
            destination_flags |= os.O_NOFOLLOW
        destination_descriptor = os.open(destination, destination_flags, 0o600)
        digest = hashlib.sha256()
        copied = 0
        try:
            os.fchmod(destination_descriptor, 0o600)
            remaining = before.st_size
            while remaining:
                chunk = os.read(source_descriptor, min(1 << 20, remaining))
                if not chunk:
                    raise FusionRecoveryControlError(
                        "AppLog candidate shrank while it was being frozen"
                    )
                view = memoryview(chunk)
                while view:
                    written = os.write(destination_descriptor, view)
                    if written <= 0:
                        raise OSError("AppLog snapshot write made no progress")
                    view = view[written:]
                digest.update(chunk)
                copied += len(chunk)
                remaining -= len(chunk)
            os.fsync(destination_descriptor)
        finally:
            os.close(destination_descriptor)
        after = os.fstat(source_descriptor)
    finally:
        os.close(source_descriptor)

    source_changed = (
        before.st_size != after.st_size
        or before.st_mtime_ns != after.st_mtime_ns
        or before.st_ino != after.st_ino
        or before.st_dev != after.st_dev
    )
    return {
        "source_path": str(resolved),
        "snapshot_file": destination.name,
        "copied_bytes": copied,
        "sha256": digest.hexdigest(),
        "source_changed_during_copy": source_changed,
        "complete_at_opened_size": copied == before.st_size,
        "request_observed": UNKNOWN,
    }


def _discard_private_bundle(path: Path) -> None:
    """Remove only the random private directory created by this module."""
    if not path.exists() or not path.is_dir():
        return
    for child in path.iterdir():
        if child.is_file() and not child.is_symlink():
            child.unlink()
        else:
            raise FusionRecoveryControlError(
                "temporary incident bundle contains an unexpected entry"
            )
    path.rmdir()


def collect_incident_bundle(
    retirement_marker: Path,
    output_directory: Path,
    *,
    inflight_marker: Path | None = None,
    app_log_candidates: Sequence[Path] = (),
    window_census: Mapping[str, Any] | None = None,
    max_app_log_bytes: int = _MAX_APP_LOG_BYTES,
) -> IncidentBundle:
    """Freeze one runtime retirement in an atomic owner-only bundle."""
    if (
        not isinstance(max_app_log_bytes, int)
        or isinstance(max_app_log_bytes, bool)
        or not 0 < max_app_log_bytes <= _MAX_APP_LOG_BYTES
    ):
        raise FusionRecoveryControlError(
            f"max_app_log_bytes must be between 1 and {_MAX_APP_LOG_BYTES}"
        )
    if len(app_log_candidates) > _MAX_APP_LOGS:
        raise FusionRecoveryControlError(
            f"at most {_MAX_APP_LOGS} AppLog candidates may be frozen"
        )

    retirement, retirement_raw = _load_json_file(
        retirement_marker,
        maximum_bytes=_MAX_MARKER_BYTES,
        require_owner_only=True,
    )
    failed_pid, failed_start, failed_start_token = _validate_marker(
        retirement, expected_schema=_INCIDENT_MARKER_SCHEMAS
    )
    inflight: dict[str, Any] | None = None
    inflight_raw: bytes | None = None
    if inflight_marker is not None:
        inflight, inflight_raw = _load_json_file(
            inflight_marker,
            maximum_bytes=_MAX_MARKER_BYTES,
            require_owner_only=True,
        )
        _validate_marker(
            inflight,
            expected_schema=_INFLIGHT_SCHEMA,
            expected_pid=failed_pid,
            expected_start=failed_start,
            expected_start_token=failed_start_token,
        )

    reason = _bounded_text(retirement.get("reason", UNKNOWN)) or UNKNOWN
    incident_kind, safety_signature = _classify_incident(reason)
    now_utc = datetime.now(timezone.utc)
    now_local = now_utc.astimezone()
    incident_id = str(uuid.uuid4())
    timestamp = now_utc.strftime("%Y%m%dT%H%M%SZ")
    root = _require_owner_directory(output_directory, create=True)
    final_name = f"fusion-mcp-incident-{timestamp}-{failed_pid}-{incident_id[:12]}"
    final_path = root / final_name
    temporary = root / f".{final_name}.tmp-{uuid.uuid4().hex}"
    os.mkdir(temporary, 0o700)
    files: dict[str, dict[str, Any]] = {}
    app_logs: list[dict[str, Any]] = []
    normalized_census: dict[str, Any] | str = UNKNOWN
    published = False
    try:
        retirement_copy = temporary / "retirement.json"
        _write_new_file(retirement_copy, retirement_raw)
        files[retirement_copy.name] = {
            "bytes": len(retirement_raw),
            "sha256": _sha256(retirement_raw),
        }
        if inflight_raw is not None:
            inflight_copy = temporary / "inflight.json"
            _write_new_file(inflight_copy, inflight_raw)
            files[inflight_copy.name] = {
                "bytes": len(inflight_raw),
                "sha256": _sha256(inflight_raw),
            }

        for index, candidate in enumerate(app_log_candidates, start=1):
            destination = temporary / f"app-log-{index:03d}.bin"
            snapshot = _copy_app_log_snapshot(
                candidate,
                destination,
                maximum_bytes=max_app_log_bytes,
            )
            app_logs.append(snapshot)
            files[destination.name] = {
                "bytes": snapshot["copied_bytes"],
                "sha256": snapshot["sha256"],
            }

        if window_census is not None:
            normalized_census = _normalize_window_census(
                window_census, expected_pid=failed_pid
            )
            census_bytes = _canonical_bytes(normalized_census) + b"\n"
            census_path = temporary / "shallow-window-census.json"
            _write_new_file(census_path, census_bytes)
            files[census_path.name] = {
                "bytes": len(census_bytes),
                "sha256": _sha256(census_bytes),
            }

        request_id = retirement.get("request_id", UNKNOWN)
        if not isinstance(request_id, (int, str)) or isinstance(request_id, bool):
            request_id = UNKNOWN
        release = _bounded_text(retirement.get("fusion_release", UNKNOWN), maximum=200)
        node_id = _bounded_text(retirement.get("node_id", UNKNOWN), maximum=200)
        request_hash = retirement.get("arguments_sha256", UNKNOWN)
        manifest: dict[str, Any] = {
            "schema": INCIDENT_SCHEMA,
            "incident_id": incident_id,
            "created_at_utc": now_utc.isoformat(),
            "created_at_local": now_local.isoformat(),
            "incident_kind": incident_kind,
            "primary_signature": UNKNOWN,
            "safety_control_signature": safety_signature,
            "causal_confidence": "UNKNOWN",
            "node_id": node_id or UNKNOWN,
            "failed_runtime": {
                "fusion_pid": failed_pid,
                "fusion_start_time": failed_start,
                "fusion_start_token": failed_start_token,
                "fusion_release": release or UNKNOWN,
                "stable_key_sha256": _sha256(
                    (
                        f"{failed_pid}:"
                        f"{failed_start_token if failed_start_token != UNKNOWN else failed_start}"
                    ).encode("utf-8")
                ),
            },
            "trigger_request": {
                "request_id": request_id,
                "tool": _bounded_text(retirement.get("tool", UNKNOWN), maximum=200)
                or UNKNOWN,
                "arguments_sha256": request_hash,
                "raw_arguments_retained": False,
            },
            "retirement": {
                "reason": reason,
                "retired_at_unix": retirement.get("retired_at_unix", UNKNOWN),
                "marker_file": retirement_copy.name,
                "marker_sha256": files[retirement_copy.name]["sha256"],
                "inflight_marker_file": (
                    "inflight.json" if inflight_raw is not None else UNKNOWN
                ),
                "inflight_phase": (
                    inflight.get("phase", UNKNOWN) if inflight is not None else UNKNOWN
                ),
            },
            "document_identity": UNKNOWN,
            "document_save_state": UNKNOWN,
            "document_save_evidence_channel": "external-only-no-post-failure-mcp",
            "last_successful_action": UNKNOWN,
            "active_command": UNKNOWN,
            "app_log_evidence": app_logs or UNKNOWN,
            "request_observed_in_app_log": UNKNOWN,
            "shallow_window_census": normalized_census,
            "post_failure_same_pid_mcp_calls": UNKNOWN,
            "collector_same_pid_mcp_calls": 0,
            "incident_marker_schema": retirement.get("schema"),
            "recoverable_same_pid": False,
            "no_retry_boundary": {
                # Every ambiguous outcome condemns the PID.  Historical
                # quarantine markers are input compatibility only, not a
                # recovery authorization.
                "same_pid_mcp_retry_forbidden": True,
                "same_pid_new_session_forbidden": True,
                "same_pid_delete_forbidden": True,
                "same_pid_close_forbidden": True,
                "same_pid_save_forbidden": True,
                "required_recovery": (
                    "different Fusion PID/start token, clean shallow-window "
                    "census, then one initialize/tools-list/document-read "
                    "health-only probe"
                ),
            },
            "bundle_files": files,
            "publication": {
                "mode": "same-filesystem-directory-rename",
                "owner_only_directory_mode": "0700",
                "owner_only_file_mode": "0600",
                "atomic_manifest_visibility": True,
            },
        }
        manifest_bytes = (
            json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True).encode(
                "utf-8"
            )
            + b"\n"
        )
        _write_new_file(temporary / "incident.json", manifest_bytes)
        _fsync_directory(temporary)
        if final_path.exists() or final_path.is_symlink():
            raise FusionRecoveryControlError("incident bundle destination collision")
        os.rename(temporary, final_path)
        _fsync_directory(root)
        published = True
        return IncidentBundle(path=final_path, manifest=manifest)
    finally:
        if not published and temporary.exists():
            _discard_private_bundle(temporary)


def _validate_incident_manifest(
    payload: Mapping[str, Any],
) -> tuple[int, str, str, str, str]:
    if payload.get("schema") != INCIDENT_SCHEMA:
        raise FusionRecoveryControlError(
            f"incident manifest schema must be {INCIDENT_SCHEMA}"
        )
    incident_id = payload.get("incident_id")
    if not isinstance(incident_id, str) or not incident_id:
        raise FusionRecoveryControlError("incident manifest has no incident ID")
    node_id = _bounded_text(payload.get("node_id"), maximum=200)
    if not node_id or node_id == UNKNOWN:
        raise FusionRecoveryControlError("incident manifest has no exact node ID")
    failed = payload.get("failed_runtime")
    if not isinstance(failed, Mapping):
        raise FusionRecoveryControlError("incident manifest has no failed runtime")
    pid = _require_positive_pid(failed.get("fusion_pid"))
    start = _bounded_text(failed.get("fusion_start_time"), maximum=300)
    if not start:
        raise FusionRecoveryControlError("incident failed runtime has no start time")
    raw_start_token = failed.get("fusion_start_token")
    start_token = (
        raw_start_token if is_darwin_process_start_token(raw_start_token) else UNKNOWN
    )
    if (
        raw_start_token is not None
        and raw_start_token != UNKNOWN
        and start_token == UNKNOWN
    ):
        raise FusionRecoveryControlError(
            "incident failed runtime has an invalid process start token"
        )
    no_retry = payload.get("no_retry_boundary")
    if payload.get("recoverable_same_pid") is not False:
        raise FusionRecoveryControlError(
            "incident must terminally forbid recovery on the failed Fusion PID"
        )
    required_true = [
        "same_pid_mcp_retry_forbidden",
        "same_pid_new_session_forbidden",
        "same_pid_delete_forbidden",
        "same_pid_close_forbidden",
        "same_pid_save_forbidden",
    ]
    if not isinstance(no_retry, Mapping) or any(
        no_retry.get(key) is not True for key in required_true
    ):
        raise FusionRecoveryControlError("incident no-retry boundary is incomplete")
    return pid, start, start_token, incident_id, node_id


def _validate_candidate_identity(identity: FusionProcessIdentity) -> None:
    _require_positive_pid(identity.pid)
    if not identity.start_time.strip():
        raise FusionRecoveryControlError("candidate Fusion start time is unavailable")
    if not identity.hostname.strip():
        raise FusionRecoveryControlError("candidate Fusion hostname is unavailable")
    if identity.release not in AUDITED_FUSION_RELEASES:
        raise FusionRecoveryControlError(
            "candidate Fusion release is not covered by the audited tool catalog"
        )
    if identity.listener != "127.0.0.1:27182":
        raise FusionRecoveryControlError(
            "candidate health probe requires the exact loopback Fusion listener"
        )
    executable = identity.command.split(" -", 1)[0]
    if not executable.endswith(FUSION_EXECUTABLE_SUFFIX):
        raise FusionRecoveryControlError(
            "candidate listener is not owned by Autodesk Fusion"
        )


def _gate_attempt_path(state_directory: Path, identity: FusionProcessIdentity) -> Path:
    digest = _sha256(identity.stable_key.encode("utf-8"))[:16]
    return state_directory / (
        f"fusion-mcp-health-attempt-{os.geteuid()}-{identity.pid}-{digest}.json"
    )


def _health_identity_payload(identity: FusionProcessIdentity) -> dict[str, object]:
    return {
        "pid": identity.pid,
        "start_time": identity.start_time,
        "start_token": identity.start_token,
        "release": identity.release,
        "listener": identity.listener,
        "hostname": identity.hostname,
        "command_sha256": _sha256(identity.command.encode("utf-8")),
    }


def _create_health_identity_challenge(
    *,
    state_directory: Path,
    identity: FusionProcessIdentity,
    node_id: str,
    incident_id: str,
    incident_manifest_sha256: str,
    expires_at_unix: float,
) -> tuple[Path, Path, dict[str, Any]]:
    nonce = secrets.token_hex(32)
    nonce_sha256 = sha256_hex(nonce.encode("ascii"))
    challenge_path = state_directory / (
        f"fusion-mcp-health-challenge-{nonce_sha256}.json"
    )
    receipt_path = state_directory / (
        f"fusion-mcp-health-attestation-{nonce_sha256}.json"
    )
    payload: dict[str, Any] = {
        "schema": HEALTH_CHALLENGE_SCHEMA,
        "nonce": nonce,
        "incident_id": incident_id,
        "incident_manifest_sha256": incident_manifest_sha256,
        "node_id": node_id,
        "state_directory": str(state_directory),
        "fusion_identity": _health_identity_payload(identity),
        "allowed_request": {
            "request_label": _HEALTH_CALL_ID,
            "tool": _HEALTH_CALL_TOOL,
            "arguments_sha256": HEALTH_ARGUMENTS_SHA256,
        },
        "receipt_path": str(receipt_path),
        "expires_at_unix": expires_at_unix,
    }
    try:
        create_owner_only_json(challenge_path, payload)
    except (HealthAttestationError, OSError) as exc:
        raise FusionRecoveryControlError(
            f"health identity challenge cannot be created safely: {exc}"
        ) from exc
    return challenge_path, receipt_path, payload


def _validate_health_identity_attestation(
    *,
    receipt_path: Path,
    challenge: Mapping[str, Any],
    identity: FusionProcessIdentity,
    node_id: str,
) -> tuple[dict[str, Any], bytes]:
    try:
        receipt, encoded = read_owner_only_json(
            receipt_path,
            label="health identity attestation receipt",
        )
    except HealthAttestationError as exc:
        raise FusionRecoveryControlError(str(exc)) from exc
    expected_keys = {
        "schema",
        "challenge_sha256",
        "nonce_sha256",
        "incident_id",
        "incident_manifest_sha256",
        "node_id",
        "fusion_identity",
        "proxy_pid",
        "request",
        "guard_evidence",
        "acknowledgement",
        "attested_at_unix",
    }
    request = receipt.get("request")
    guard = receipt.get("guard_evidence")
    acknowledgement = receipt.get("acknowledgement")
    request_id = request.get("request_id") if isinstance(request, Mapping) else None
    attested_at = receipt.get("attested_at_unix")
    challenge_expiry = challenge.get("expires_at_unix")
    attested_at_valid = False
    if not isinstance(attested_at, bool) and isinstance(attested_at, int | float):
        try:
            attested_at_valid = math.isfinite(float(attested_at))
        except (OverflowError, ValueError):
            pass
    nonce = challenge.get("nonce")
    if (
        set(receipt) != expected_keys
        or receipt.get("schema") != HEALTH_RECEIPT_SCHEMA
        or receipt.get("challenge_sha256")
        != sha256_hex(health_canonical_bytes(challenge))
        or not isinstance(nonce, str)
        or receipt.get("nonce_sha256") != sha256_hex(nonce.encode("ascii"))
        or receipt.get("incident_id") != challenge.get("incident_id")
        or receipt.get("incident_manifest_sha256")
        != challenge.get("incident_manifest_sha256")
        or receipt.get("node_id") != node_id
        or receipt.get("fusion_identity") != _health_identity_payload(identity)
        or isinstance(receipt.get("proxy_pid"), bool)
        or not isinstance(receipt.get("proxy_pid"), int)
        or receipt.get("proxy_pid", 0) <= 0
        or not isinstance(request, Mapping)
        or set(request) != {"request_id", "request_label", "tool", "arguments_sha256"}
        or not isinstance(request_id, (int, str))
        or isinstance(request_id, bool)
        or request.get("request_label") != _HEALTH_CALL_ID
        or request.get("tool") != _HEALTH_CALL_TOOL
        or request.get("arguments_sha256") != HEALTH_ARGUMENTS_SHA256
        or not isinstance(guard, Mapping)
        or guard
        != {
            "owner_lease_held": True,
            "preopen_identity_and_window_rechecked": True,
            "post_initialize_identity_and_window_rechecked": True,
            "selected_operation_completed": True,
            "response_flushed": True,
            "inflight_marker_phase": "response-flushed-awaiting-client-ack",
        }
        or not isinstance(acknowledgement, Mapping)
        or set(acknowledgement) != {"kind", "request_id"}
        or acknowledgement.get("kind") not in {"standard_ping", "explicit_notification"}
        or acknowledgement.get("request_id") != request_id
        or not attested_at_valid
        or isinstance(challenge_expiry, bool)
        or not isinstance(challenge_expiry, int | float)
        or float(attested_at) >= float(challenge_expiry)
    ):
        raise FusionRecoveryControlError(
            "health identity attestation does not match the exact challenge, "
            "candidate, request, guard checks, or ACK"
        )
    return receipt, encoded


def _summarize_acceptance(report: Mapping[str, Any]) -> dict[str, Any]:
    tools_list = report.get("tools_list")
    tools: list[str] = []
    if isinstance(tools_list, Mapping) and isinstance(tools_list.get("tools"), list):
        tools = sorted(
            row["name"]
            for row in tools_list["tools"]
            if isinstance(row, Mapping) and isinstance(row.get("name"), str)
        )
    summary: dict[str, Any] = {
        "report_sha256": _sha256(_canonical_bytes(report)),
        "status": report.get("status", UNKNOWN),
        "initialize_status": (
            report.get("initialize", {}).get("status", UNKNOWN)
            if isinstance(report.get("initialize"), Mapping)
            else UNKNOWN
        ),
        "tools_list_status": (
            tools_list.get("status", UNKNOWN)
            if isinstance(tools_list, Mapping)
            else UNKNOWN
        ),
        "tool_names": tools,
        "calls_planned": report.get("calls_planned", UNKNOWN),
        "calls_completed": report.get("calls_completed", UNKNOWN),
    }
    initialized = report.get("initialize")
    if isinstance(initialized, Mapping) and isinstance(
        initialized.get("server"), Mapping
    ):
        summary["server_name"] = _bounded_text(
            initialized["server"].get("name", UNKNOWN), maximum=300
        )
    calls = report.get("calls")
    if isinstance(calls, list) and len(calls) == 1 and isinstance(calls[0], Mapping):
        call = calls[0]
        delivery = call.get("delivery_ack")
        summary["health_call"] = {
            "id": _bounded_text(call.get("id", UNKNOWN)),
            "tool": _bounded_text(call.get("tool", UNKNOWN)),
            "arguments_sha256": _bounded_text(call.get("arguments_sha256", UNKNOWN)),
            "verdict": _bounded_text(call.get("verdict", UNKNOWN)),
            "delivery_ack_sent": call.get("delivery_ack_sent", UNKNOWN),
            "delivery_ack_status": (
                delivery.get("status", UNKNOWN)
                if isinstance(delivery, Mapping)
                else UNKNOWN
            ),
            "delivery_ack_confirmed": (
                delivery.get("confirmed", UNKNOWN)
                if isinstance(delivery, Mapping)
                else UNKNOWN
            ),
        }
    if isinstance(report.get("runtime_error"), Mapping):
        summary["runtime_error"] = {
            "phase": _bounded_text(report["runtime_error"].get("phase", UNKNOWN)),
            "type": _bounded_text(report["runtime_error"].get("type", UNKNOWN)),
            "message": _bounded_text(report["runtime_error"].get("message", UNKNOWN)),
        }
    attestation = report.get("identity_attestation")
    if isinstance(attestation, Mapping):
        summary["identity_attestation"] = {
            "status": attestation.get("status", UNKNOWN),
            "sha256": _bounded_text(attestation.get("sha256", UNKNOWN)),
        }
    return summary


def _health_acceptance_passed(
    report: Mapping[str, Any],
    *,
    expected_server_name: str,
    expected_attestation_path: Path,
    attestation: Mapping[str, Any],
    attestation_raw: bytes,
) -> bool:
    tools_list = report.get("tools_list")
    if not isinstance(tools_list, Mapping):
        return False
    initialized = report.get("initialize")
    if not isinstance(initialized, Mapping):
        return False
    production = initialized.get("production_acceptance")
    ack_extension = initialized.get("delivery_ack_extension")
    server = initialized.get("server")
    if not isinstance(production, Mapping) or not isinstance(ack_extension, Mapping):
        return False
    if not isinstance(server, Mapping):
        return False
    reported_attestation = report.get("identity_attestation")
    if not isinstance(reported_attestation, Mapping):
        return False
    tool_rows = tools_list.get("tools", [])
    if not isinstance(tool_rows, list):
        return False
    tool_hashes = {
        row.get("name"): row.get("input_schema_sha256")
        for row in tool_rows
        if isinstance(row, Mapping) and isinstance(row.get("name"), str)
    }
    calls = report.get("calls")
    if not isinstance(calls, list) or len(calls) != 1:
        return False
    call = calls[0]
    if not isinstance(call, Mapping):
        return False
    layers = call.get("layers")
    delivery_ack = call.get("delivery_ack")
    if not isinstance(layers, Mapping) or not isinstance(delivery_ack, Mapping):
        return False
    transport = layers.get("transport_protocol")
    mcp_result = layers.get("mcp_result")
    inner_result = layers.get("inner_result")
    return (
        report.get("status") == "pass"
        and initialized.get("status") == "success"
        and production.get("status") == "success"
        and production.get("server_name_matches") is True
        and production.get("server_name_exact_match") is True
        and production.get("expected_server_name") == expected_server_name
        and server.get("name") == expected_server_name
        and production.get("delivery_ack_advertised") is True
        and ack_extension.get("advertised") is True
        and tools_list.get("status") == "success"
        and tool_hashes == SCHEMA_SHA256
        and report.get("calls_planned") == 1
        and report.get("calls_completed") == 1
        and call.get("id") == _HEALTH_CALL_ID
        and call.get("tool") == _HEALTH_CALL_TOOL
        and call.get("arguments_sha256")
        == _sha256(_canonical_bytes(_HEALTH_CALL_ARGUMENTS))
        and call.get("verdict") == "pass"
        and isinstance(transport, Mapping)
        and transport.get("status") == "success"
        and transport.get("response_received") is True
        and isinstance(mcp_result, Mapping)
        and mcp_result.get("status") == "success"
        and mcp_result.get("is_error") is False
        and mcp_result.get("matches_expectation") is True
        and isinstance(inner_result, Mapping)
        and inner_result.get("status") == "success"
        and inner_result.get("matches_expectation") is True
        and call.get("delivery_ack_sent") is True
        and delivery_ack.get("status") == "success"
        and delivery_ack.get("explicit_notification_sent") is True
        and delivery_ack.get("confirmation") == "standard_ping"
        and delivery_ack.get("confirmed") is True
        and reported_attestation.get("status") == "success"
        and reported_attestation.get("path") == str(expected_attestation_path)
        and reported_attestation.get("sha256") == _sha256(attestation_raw)
        and reported_attestation.get("payload") == attestation
    )


def _new_gate_report(
    *,
    incident_id: str | object = UNKNOWN,
    incident_sha256: str | object = UNKNOWN,
) -> dict[str, Any]:
    return {
        "schema": HEALTH_GATE_SCHEMA,
        "status": "running",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "incident_id": incident_id,
        "incident_manifest_sha256": incident_sha256,
        "health_only": True,
        "modeling_authorized": False,
        "document_open_authorized": False,
        "document_close_authorized": False,
        "document_save_authorized": False,
        "session_delete_authorized": False,
        "probe_contract": {
            "allowed_mcp_methods": ["initialize", "tools/list", "tools/call"],
            "allowed_tool_call": {
                "id": _HEALTH_CALL_ID,
                "tool": _HEALTH_CALL_TOOL,
                "arguments": dict(_HEALTH_CALL_ARGUMENTS),
            },
            "tool_calls_planned": 1,
            "same_pid_retry_allowed": False,
            "same_host_controller_and_cell_required": True,
            "exact_candidate_identity_attestation_required": True,
            "attestation_written_before_inflight_clear_and_lease_release": True,
            "shell_used": False,
            "forbidden_operations": [
                "any tools/call other than the one exact document read",
                "MCP session DELETE",
                "Fusion quit",
                "document open",
                "document close",
                "document save",
                "document mutation",
            ],
        },
    }


async def run_health_only_recovery_gate(
    incident_manifest: Path,
    *,
    process_probe: ProcessProbe,
    window_probe: WindowProbe,
    command_argv: Sequence[str],
    state_directory: Path,
    output_path: Path,
    timeout_seconds: float = 150.0,
    cwd: Path | None = None,
    acceptance_runner: AcceptanceRunner = run_acceptance,
) -> dict[str, Any]:
    """Run one bounded new-PID initialize/list/document-read health probe.

    Any failure after a candidate PID is selected leaves a durable attempt
    marker.  A later invocation for that same PID/start token is refused before
    another MCP process is launched.
    """
    if not math.isfinite(timeout_seconds) or not 0 < timeout_seconds <= 600:
        raise FusionRecoveryControlError(
            "timeout_seconds must be finite and between 0 and 600"
        )
    if not command_argv or not command_argv[0]:
        raise FusionRecoveryControlError("health-only stdio command is empty")
    if any(
        value == "--health-attestation-challenge"
        or value.startswith("--health-attestation-challenge=")
        for value in command_argv
    ):
        raise FusionRecoveryControlError(
            "health attestation challenge is controller-owned and must not be supplied"
        )

    incident, incident_raw = _load_json_file(
        incident_manifest,
        maximum_bytes=_MAX_MARKER_BYTES,
        require_owner_only=True,
    )
    failed_pid, failed_start, failed_start_token, incident_id, node_id = (
        _validate_incident_manifest(incident)
    )
    incident_digest = _sha256(incident_raw)
    report = _new_gate_report(
        incident_id=incident_id,
        incident_sha256=incident_digest,
    )
    state_root = _require_owner_directory(state_directory, create=True)
    candidate: FusionProcessIdentity | None = None
    attempt_path: Path | None = None
    attempt_created = False
    challenge_path: Path | None = None
    receipt_path: Path | None = None
    challenge: dict[str, Any] | None = None
    deadline = time.monotonic() + timeout_seconds

    try:
        candidate = process_probe.discover(deadline=deadline)
        _validate_candidate_identity(candidate)
        report["candidate_runtime"] = {
            "fusion_pid": candidate.pid,
            "fusion_start_time": candidate.start_time,
            "fusion_start_token": candidate.start_token,
            "fusion_release": candidate.release,
            "hostname": candidate.hostname,
            "listener": candidate.listener,
            "node_id": node_id,
        }
        if candidate.pid == failed_pid:
            raise FusionRecoveryControlError(
                "same failed Fusion PID cannot receive a health probe"
            )

        attempt_path = _gate_attempt_path(state_root, candidate)
        if attempt_path.exists() or attempt_path.is_symlink():
            raise FusionRecoveryControlError(
                "this candidate Fusion PID/start token already had a health attempt"
            )
        attempt = {
            "schema": HEALTH_ATTEMPT_SCHEMA,
            "incident_id": incident_id,
            "incident_manifest_sha256": incident_digest,
            "candidate_pid": candidate.pid,
            "candidate_start_time": candidate.start_time,
            "candidate_start_token": candidate.start_token,
            "failed_start_token": failed_start_token,
            "started_at_unix": time.time(),
            "phase": "preflight",
            "allowed_mcp_methods": ["initialize", "tools/list", "tools/call"],
            "allowed_tool_call": {
                "id": _HEALTH_CALL_ID,
                "tool": _HEALTH_CALL_TOOL,
                "arguments": dict(_HEALTH_CALL_ARGUMENTS),
            },
            "tool_calls_planned": 1,
        }
        _write_new_file(
            attempt_path,
            json.dumps(attempt, sort_keys=True).encode("utf-8") + b"\n",
        )
        _fsync_directory(state_root)
        attempt_created = True

        trusted_live_window_probe = type(
            window_probe
        ) is PeekabooWindowProbe and PeekabooWindowProbe.has_uninjected_runner_shape(
            window_probe
        )
        signed_peekaboo_identity: tuple[object, ...] | None = None
        if trusted_live_window_probe:
            signed_peekaboo_identity = PeekabooWindowProbe.signed_executable_identity(
                window_probe, deadline=deadline
            )
            window_probe.executable = str(signed_peekaboo_identity[0])
        window_evidence = window_probe.verify(
            candidate,
            require_clean_start=True,
            deadline=deadline,
        )
        trusted_live_window_probe = (
            trusted_live_window_probe
            and type(window_probe) is PeekabooWindowProbe
            and PeekabooWindowProbe.has_uninjected_runner_shape(window_probe)
            and signed_peekaboo_identity
            == PeekabooWindowProbe.signed_executable_identity(
                window_probe, deadline=deadline
            )
        )
        normalized_census = _normalize_window_census(
            window_evidence,
            expected_pid=candidate.pid,
            allow_guard_proven_auxiliary=trusted_live_window_probe,
        )
        if (
            normalized_census["window_count"] <= 0
            or normalized_census["blocking_titles"]
            or normalized_census["modified_document_count"] != 0
        ):
            raise FusionRecoveryControlError(
                "candidate Fusion startup window census is not clean"
            )
        report["startup_window_census"] = normalized_census

        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("health-only recovery gate exceeded its deadline")
        challenge_path, receipt_path, challenge = _create_health_identity_challenge(
            state_directory=state_root,
            identity=candidate,
            node_id=node_id,
            incident_id=incident_id,
            incident_manifest_sha256=incident_digest,
            expires_at_unix=time.time() + remaining,
        )
        challenge_sha256 = sha256_hex(health_canonical_bytes(challenge))
        report["identity_challenge"] = {
            "status": "issued",
            "path": str(challenge_path),
            "sha256": challenge_sha256,
            "expected_server_name": f"fusion-mcp-cell-{node_id}",
            "same_host_required": True,
        }
        if attempt_path is None:
            raise FusionRecoveryControlError(
                "health attempt marker path was lost before challenge publication"
            )
        attempt_payload, _ = _load_json_file(
            attempt_path,
            maximum_bytes=_MAX_MARKER_BYTES,
            require_owner_only=True,
        )
        attempt_payload["phase"] = "identity-challenge-issued"
        attempt_payload["identity_challenge_sha256"] = challenge_sha256
        _atomic_write_json(attempt_path, attempt_payload)

        plan = {
            "schema": PLAN_SCHEMA,
            "required_tools": list(DEFAULT_REQUIRED_TOOLS),
            "calls": [
                {
                    "id": _HEALTH_CALL_ID,
                    "tool": _HEALTH_CALL_TOOL,
                    "arguments": dict(_HEALTH_CALL_ARGUMENTS),
                    "expect_mcp_error": False,
                    "expect_inner_success": True,
                }
            ],
        }
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("health-only recovery gate exceeded its deadline")
        expected_server_name = f"fusion-mcp-cell-{node_id}"
        guarded_command = [str(value) for value in command_argv] + [
            "--health-attestation-challenge",
            str(challenge_path),
        ]
        with anyio.fail_after(remaining):
            acceptance = await acceptance_runner(
                plan,
                guarded_command,
                timeout_seconds=remaining,
                cwd=cwd,
                max_response_bytes=1,
                max_schema_bytes=131_072,
                stderr_tail_chars=0,
                expected_server_name=expected_server_name,
                identity_attestation_path=receipt_path,
            )
        report["acceptance"] = _summarize_acceptance(acceptance)
        if receipt_path is None or challenge is None:
            raise FusionRecoveryControlError(
                "health identity challenge state was lost before attestation"
            )
        attestation, attestation_raw = _validate_health_identity_attestation(
            receipt_path=receipt_path,
            challenge=challenge,
            identity=candidate,
            node_id=node_id,
        )
        report["identity_attestation"] = {
            "status": "pass",
            "path": str(receipt_path),
            "sha256": _sha256(attestation_raw),
            "challenge_sha256": attestation["challenge_sha256"],
            "acknowledgement_kind": attestation["acknowledgement"]["kind"],
        }
        if not _health_acceptance_passed(
            acceptance,
            expected_server_name=expected_server_name,
            expected_attestation_path=receipt_path,
            attestation=attestation,
            attestation_raw=attestation_raw,
        ):
            raise FusionRecoveryControlError(
                "exact-node initialize/tools-list/document-read/ACK/identity "
                "attestation health acceptance did not pass exactly"
            )

        observed_after = process_probe.discover(deadline=deadline)
        _validate_candidate_identity(observed_after)
        if _health_identity_payload(observed_after) != _health_identity_payload(
            candidate
        ):
            raise FusionRecoveryControlError(
                "Fusion listener PID/start/release/hostname/command identity changed "
                "during the health-only probe"
            )
        report["identity_recheck"] = {
            "status": "pass",
            "fusion_pid": observed_after.pid,
            "fusion_start_time": observed_after.start_time,
            "fusion_start_token": observed_after.start_token,
            "fusion_release": observed_after.release,
            "hostname": observed_after.hostname,
            "node_id": node_id,
        }
        report["status"] = "pass"
        report["candidate_pid_retired_required"] = False
        report["safe_next_step"] = (
            "Health only passed. Start a separate guarded MCP owner for any later "
            "work; repeat shallow modal census after every document lifecycle action."
        )
    except BaseException as exc:
        report["status"] = "fail"
        report["error"] = _safe_error(exc)
        report["candidate_pid_retired_required"] = candidate is not None and (
            candidate.pid != failed_pid
        )
        report["safe_next_step"] = (
            "Do not retry this Fusion PID. Preserve external evidence and use a "
            "different PID/start token for any later health-only attempt."
        )

    if attempt_created and attempt_path is not None:
        attempt_payload, _ = _load_json_file(
            attempt_path,
            maximum_bytes=_MAX_MARKER_BYTES,
            require_owner_only=True,
        )
        attempt_payload["phase"] = (
            "health-passed-no-model-authority"
            if report["status"] == "pass"
            else "health-failed-retired"
        )
        attempt_payload["finished_at_unix"] = time.time()
        attempt_payload["gate_status"] = report["status"]
        _atomic_write_json(attempt_path, attempt_payload)

    report["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
    _atomic_write_json(output_path, report)
    return report


def _load_optional_census(path: Path | None) -> dict[str, Any] | None:
    if path is None:
        return None
    payload, _ = _load_json_file(
        path,
        maximum_bytes=_MAX_CENSUS_BYTES,
        require_owner_only=False,
    )
    return payload


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="operation", required=True)

    collect = subparsers.add_parser("collect", help="freeze an incident bundle")
    # The quarantine spelling is retained only to collect markers written by
    # older runtimes; both marker kinds are terminal incident sources.
    marker = collect.add_mutually_exclusive_group(required=True)
    marker.add_argument("--retirement", dest="retirement", type=Path)
    marker.add_argument("--quarantine", dest="retirement", type=Path)
    collect.add_argument("--inflight", type=Path)
    collect.add_argument("--incident-directory", type=Path, required=True)
    collect.add_argument("--app-log", type=Path, action="append", default=[])
    collect.add_argument("--window-census", type=Path)

    health = subparsers.add_parser(
        "health-gate",
        help="run one new-PID initialize/list/document read probe",
    )
    health.add_argument("--incident", type=Path, required=True)
    health.add_argument("--state-directory", type=Path, required=True)
    health.add_argument("--output", type=Path, required=True)
    health.add_argument("--expected-hostname", required=True)
    health.add_argument("--peekaboo", required=True)
    health.add_argument(
        "--peekaboo-mode",
        choices=("local", "bridge", "local-ondemand"),
        required=True,
    )
    health.add_argument("--timeout-seconds", type=float, default=150.0)
    health.add_argument("--cwd", type=Path)
    health.add_argument("command", nargs=argparse.REMAINDER)
    return parser


def main() -> None:
    args = _parser().parse_args()
    if args.operation == "collect":
        bundle = collect_incident_bundle(
            args.retirement,
            args.incident_directory,
            inflight_marker=args.inflight,
            app_log_candidates=args.app_log,
            window_census=_load_optional_census(args.window_census),
        )
        print(bundle.path)
        return

    command = list(args.command)
    if command and command[0] == "--":
        command = command[1:]
    process_probe = MacOSFusionProcessProbe(
        expected_hostname=args.expected_hostname,
    )
    window_probe = PeekabooWindowProbe(
        executable=args.peekaboo,
        mode=args.peekaboo_mode,
    )

    async def execute() -> dict[str, Any]:
        return await run_health_only_recovery_gate(
            args.incident,
            process_probe=process_probe,
            window_probe=window_probe,
            command_argv=command,
            state_directory=args.state_directory,
            output_path=args.output,
            timeout_seconds=args.timeout_seconds,
            cwd=_absolute(args.cwd) if args.cwd else None,
        )

    report = anyio.run(execute)
    if report.get("status") != "pass":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
