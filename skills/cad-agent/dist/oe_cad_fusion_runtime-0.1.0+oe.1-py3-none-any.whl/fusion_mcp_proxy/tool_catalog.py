"""Audited local tool catalog for Autodesk Fusion's built-in MCP.

The built-in MCP is loopback-only and must not be contacted merely because an
MCP client initialized a configured cell or requested ``tools/list``.  These
four schemas were independently captured from Fusion releases 2704.1.36 and
2704.1.53; both releases produced the exact same canonical SHA-256 values.

The catalog is deliberately small and immutable-by-construction.  Every call
returns fresh :class:`mcp.types.Tool` models, and the schema hashes are checked
before those models are exposed.
"""

from __future__ import annotations

import copy
import hashlib
import json
from typing import Any

from mcp.types import Tool

CATALOG_VERSION = "fusion-built-in-mcp-2704.1.36-2704.1.53-v1"
AUDITED_FUSION_RELEASES = ("2704.1.36", "2704.1.53")

SCHEMA_SHA256 = {
    "fusion_mcp_electronics_read": (
        "7c62fd9df46f983c84cfb8c1f3a551c0a87bd6a22d5e5e1eecc37ff72b279e11"
    ),
    "fusion_mcp_execute": (
        "a3f0a8c117501d601a8a4606d864770b2f3acbaa0831edc75724a6719917fb9a"
    ),
    "fusion_mcp_read": (
        "467b3d84884c6b3cd82de7fe9faa393ddb3cf70df83211965c10bb6dab19a403"
    ),
    "fusion_mcp_update": (
        "2643a822b2b8325ef3ca3332e2d2bd78f427713d85d3e7ec6d087bae064ad41c"
    ),
}

_SCHEMAS: dict[str, dict[str, Any]] = {
    "fusion_mcp_electronics_read": {
        "properties": {
            "entity_type": {
                "description": (
                    "One of the listed electronics.<Class> values. Per-class fields "
                    "and filter operators: "
                    "resource://mcp.electronics_schema_<class>."
                ),
                "enum": [
                    "electronics.Attribute",
                    "electronics.Bus",
                    "electronics.Circle",
                    "electronics.Contact",
                    "electronics.Element",
                    "electronics.Frame",
                    "electronics.Gate",
                    "electronics.Hole",
                    "electronics.Grid",
                    "electronics.Instance",
                    "electronics.Junction",
                    "electronics.Label",
                    "electronics.Layer",
                    "electronics.Module",
                    "electronics.ModuleInstance",
                    "electronics.Net",
                    "electronics.Signal",
                    "electronics.Pad",
                    "electronics.Part",
                    "electronics.Pin",
                    "electronics.PinRef",
                    "electronics.PolyCutout",
                    "electronics.Spline",
                    "electronics.PolyPour",
                    "electronics.PolyShape",
                    "electronics.Port",
                    "electronics.PortRef",
                    "electronics.Rectangle",
                    "electronics.Segment",
                    "electronics.Sheet",
                    "electronics.Schematic",
                    "electronics.Board",
                    "electronics.Library",
                    "electronics.Smd",
                    "electronics.Symbol",
                    "electronics.DeviceSet",
                    "electronics.Device",
                    "electronics.Package",
                    "electronics.Package3D",
                    "electronics.Technology",
                    "electronics.Text",
                    "electronics.VariantDef",
                    "electronics.Variant",
                    "electronics.Via",
                    "electronics.ContactRef",
                    "electronics.Wire",
                    "electronics.Dimension",
                    "electronics.NetClass",
                    "electronics.Error",
                ],
                "type": "string",
            },
            "object": {
                "description": (
                    "Optional query: fields (property names), filters (predicates), "
                    "pagination (limit, offset)."
                ),
                "properties": {
                    "fields": {
                        "description": (
                            "Property names to return; omit for all columns."
                        ),
                        "items": {"type": "string"},
                        "type": "array",
                    },
                    "filters": {
                        "description": (
                            "Predicates {property, op, value}. String properties: op "
                            "must be eq. Integer/number: lt/gt only if that property "
                            "exposes them in the per-class MCP schema resource."
                        ),
                        "items": {
                            "properties": {
                                "op": {
                                    "description": (
                                        "eq for any filterable property. lt/gt only "
                                        "for integer/number properties that list those "
                                        "operators in "
                                        "resource://mcp.electronics_schema_<class>; "
                                        "string properties require eq."
                                    ),
                                    "enum": ["eq", "lt", "gt"],
                                    "type": "string",
                                },
                                "property": {"type": "string"},
                                "value": {
                                    "anyOf": [
                                        {"type": "number"},
                                        {"type": "string"},
                                    ]
                                },
                            },
                            "required": ["property", "op", "value"],
                            "type": "object",
                        },
                        "type": "array",
                    },
                    "pagination": {
                        "description": (
                            "Page size (limit) and rows to skip (offset). For the next "
                            "page, use pagination.nextOffset from the response when "
                            "pagination.hasMore is true."
                        ),
                        "properties": {
                            "limit": {
                                "description": (
                                    "Max rows per page; default 100. Must not exceed "
                                    "1000."
                                ),
                                "type": "integer",
                            },
                            "offset": {
                                "description": (
                                    "Skip rows from the start of the result set; "
                                    "default 0."
                                ),
                                "type": "integer",
                            },
                        },
                        "type": "object",
                    },
                },
                "type": "object",
            },
        },
        "required": ["entity_type"],
        "type": "object",
    },
    "fusion_mcp_execute": {
        "properties": {
            "featureType": {
                "description": "Type of execution operation to perform",
                "enum": ["script", "document"],
                "type": "string",
            },
            "object": {
                "description": "Object containing execution parameters",
                "properties": {
                    "fileId": {
                        "description": "The id of the file to open",
                        "type": "string",
                    },
                    "operation": {
                        "description": "Document operation identifier",
                        "enum": ["open", "close", "save"],
                        "type": "string",
                    },
                    "script": {
                        "description": "Python script contents",
                        "type": "string",
                    },
                    "userConfirmedCloseWithoutSave": {
                        "description": (
                            "The user has confirmed that changes should be discarded"
                        ),
                        "type": "boolean",
                    },
                    "userConfirmedSaveAndClose": {
                        "description": (
                            "The user has confirmed that changes should be saved"
                        ),
                        "type": "boolean",
                    },
                },
                "type": "object",
            },
        },
        "required": ["featureType", "object"],
        "type": "object",
    },
    "fusion_mcp_read": {
        "properties": {
            "antiAliasing": {
                "description": (
                    "Enable anti-aliasing for 'screenshot' query (default: true)."
                ),
                "type": "boolean",
            },
            "apiCategory": {
                "description": (
                    "The category of objects to search for in the documentation for "
                    "the 'apiDocumentation' query. Use 'class' to search class names, "
                    "'member' to search property, function, or enum value names, "
                    "'description' to search for class or member descriptions, or "
                    "'all' to search all of these."
                ),
                "enum": ["class", "member", "description", "all"],
                "type": "string",
            },
            "direction": {
                "description": (
                    "Camera direction for 'screenshot' query before capture. Use "
                    "'current' to keep current view, or a standard/view cube "
                    "direction: 'front', 'back', 'bottom', 'top', 'left', 'right', "
                    "'iso-bottom-left', 'iso-bottom-right', 'iso-top-left', "
                    "'iso-top-right'."
                ),
                "enum": [
                    "current",
                    "front",
                    "back",
                    "bottom",
                    "top",
                    "left",
                    "right",
                    "iso-bottom-left",
                    "iso-bottom-right",
                    "iso-top-left",
                    "iso-top-right",
                ],
                "type": "string",
            },
            "filter": {
                "description": (
                    "A filter for the types to search for in the 'apiDocumentation' "
                    "query. Use a '.' separated list of namespace and class names to "
                    "optionally limit the search to a specific namespace or class.\n"
                    "Example: 'adsk.cam' will limit the search to the cam namespace. "
                    "'adsk.fusion.Extrude' will limit the search to the Extrude class."
                ),
                "type": "string",
            },
            "height": {
                "description": (
                    "Image height in pixels for 'screenshot' query (default: canvas "
                    "height, range: 32-4096)."
                ),
                "maximum": 4096,
                "minimum": 32,
                "type": "number",
            },
            "name": {
                "description": "Document search term (fuzzy match on document name).",
                "type": "string",
            },
            "operation": {
                "description": "Document operation identifier.",
                "enum": ["search", "open", "recent"],
                "type": "string",
            },
            "project": {
                "description": (
                    "Document search project name or id filter. Searches all projects "
                    "if not specified."
                ),
                "type": "string",
            },
            "queryType": {
                "description": (
                    "Type of geometry query to perform. Polymorphic queries adapt "
                    "behavior based on entityToken type. List queries enumerate all "
                    "entities. Parameter queries access design metadata."
                ),
                "enum": [
                    "apiDocumentation",
                    "screenshot",
                    "document",
                    "projects",
                    "activeCommand",
                ],
                "type": "string",
            },
            "searchPattern": {
                "description": (
                    "Regular expression pattern. For 'apiDocumentation' query: "
                    "searches API class/member names. For 'materialLibraries' query: "
                    "filters material/appearance names by pattern."
                ),
                "type": "string",
            },
            "transparentBackground": {
                "description": (
                    "Use transparent background for 'screenshot' query (default: true)."
                ),
                "type": "boolean",
            },
            "width": {
                "description": (
                    "Image width in pixels for 'screenshot' query (default: canvas "
                    "width, range: 32-4096)."
                ),
                "maximum": 4096,
                "minimum": 32,
                "type": "number",
            },
        },
        "required": ["queryType"],
        "type": "object",
    },
    "fusion_mcp_update": {
        "properties": {
            "featureType": {
                "description": "Type of update",
                "enum": ["undo", "redo"],
                "type": "string",
            }
        },
        "required": ["featureType"],
        "type": "object",
    },
}

# Only the input schemas and their canonical hashes are captured audit evidence.
# These concise descriptions are local explanatory metadata and make no claim to
# reproduce Autodesk's prose byte-for-byte.
_DESCRIPTIONS = {
    "fusion_mcp_electronics_read": (
        "Read Autodesk Fusion electronics entities through the built-in MCP."
    ),
    "fusion_mcp_execute": (
        "Execute a bounded script or document operation through Autodesk Fusion's "
        "built-in MCP."
    ),
    "fusion_mcp_read": "Read Autodesk Fusion state through the built-in MCP.",
    "fusion_mcp_update": (
        "Apply an Autodesk Fusion undo or redo through the built-in MCP."
    ),
}


def canonical_schema_sha256(schema: object) -> str:
    """Return the audit hash used by the acceptance client."""
    encoded = json.dumps(
        schema,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def audited_fusion_tools() -> list[Tool]:
    """Return fresh tool models after checking the bundled schema closure."""
    if set(_SCHEMAS) != set(SCHEMA_SHA256):
        raise RuntimeError("Fusion MCP local catalog names do not match its audit map")
    tools: list[Tool] = []
    for name in sorted(_SCHEMAS):
        schema = _SCHEMAS[name]
        observed = canonical_schema_sha256(schema)
        expected = SCHEMA_SHA256[name]
        if observed != expected:
            raise RuntimeError(
                f"Fusion MCP local catalog schema drifted for {name}: "
                f"expected {expected}, observed {observed}"
            )
        tools.append(
            Tool(
                name=name,
                description=_DESCRIPTIONS[name],
                inputSchema=copy.deepcopy(schema),
            )
        )
    return tools
